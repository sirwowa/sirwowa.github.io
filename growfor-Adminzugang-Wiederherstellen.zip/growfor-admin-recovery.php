<?php
/* One-use owner recovery. No app session or old password required; owner token required. */
header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
const RECOVERY_HASH='11dde738ee994e22687e1de0cdfa46e8a2c38d04473e939e918d28900a144c26';const RECOVERY_EXPIRES=1794493949;
$message='';$success=false;
$https=(!empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off')||($_SERVER['SERVER_PORT']??0)==443;
if(!$https){http_response_code(400);exit('Bitte diese Wiederherstellungsseite ausschließlich über HTTPS öffnen.');}
if(time()>RECOVERY_EXPIRES){http_response_code(410);exit('Dieser einmalige Wiederherstellungszugang ist abgelaufen. Bitte eine neue Wiederherstellungsdatei anfordern.');}
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $token=$_POST['token']??'';if(!is_string($token)||strlen($token)>128||!hash_equals(RECOVERY_HASH,hash('sha256',$token)))throw new RuntimeException('Wiederherstellungscode stimmt nicht.');
  $password=$_POST['password']??'';$confirm=$_POST['confirm']??'';
  if(!is_string($password)||!is_string($confirm)||strlen($password)<12||strlen($password)>72||$password!==$confirm)throw new RuntimeException('Bitte ein neues Passwort mit 12 bis 72 Bytes zweimal identisch eingeben.');
  $data=__DIR__.'/data';$path=$data.'/weedys.sqlite';if(!is_file($path)||is_link($data)||is_link($path))throw new RuntimeException('Die bestehende Datenbank fehlt an dieser Stelle. Datei neben index.html und api.php hochladen, nicht in data/.');
  $protection=is_file($data.'/.htaccess')?file_get_contents($data.'/.htaccess'):'';if(!preg_match('/Require\s+all\s+denied/i',$protection))throw new RuntimeException('Der Schutz des data/-Ordners fehlt. Bitte vor der Wiederherstellung prüfen.');
  $lock=fopen($data.'/admin-recovery.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new RuntimeException('Eine Wiederherstellung läuft bereits. Bitte kurz warten.');
  $db=new PDO('sqlite:'.$path,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);$db->exec('PRAGMA busy_timeout=5000');
  $q=$db->prepare("SELECT id,role,disabled FROM users WHERE lower(email)=? AND role='admin'");$q->execute(['waldemar@stiwing.de']);$users=$q->fetchAll();$q->closeCursor();if(count($users)!==1||$users[0]['disabled'])throw new RuntimeException('Das erwartete aktive Admin-Konto wurde nicht eindeutig gefunden. Es wurden keine Konten neu angelegt.');$id=(int)$users[0]['id'];
  $db->exec('CREATE TABLE IF NOT EXISTS password_recovery_receipts(token_hash TEXT PRIMARY KEY,used_at TEXT NOT NULL)');$q=$db->prepare('SELECT 1 FROM password_recovery_receipts WHERE token_hash=?');$q->execute([RECOVERY_HASH]);$used=$q->fetchColumn();$q->closeCursor();if($used)throw new RuntimeException('Dieser Wiederherstellungscode wurde bereits verwendet.');
  $backup=$data.'/admin-recovery-'.bin2hex(random_bytes(8)).'.blob';$snap=new PDO('sqlite:'.$path,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);$snap->exec('PRAGMA busy_timeout=5000');$snap->exec('VACUUM INTO '.$snap->quote($backup));$snap=null;
  $hash=password_hash($password,PASSWORD_DEFAULT);$db->exec('BEGIN IMMEDIATE');
  try{
   $db->prepare('INSERT INTO password_recovery_receipts(token_hash,used_at) VALUES(?,?)')->execute([RECOVERY_HASH,gmdate('c')]);
   $db->prepare('UPDATE users SET pass=?,must_change_password=0,auth_version=auth_version+1 WHERE id=?')->execute([$hash,$id]);
   $db->exec('COMMIT');
  }catch(Throwable $e){$db->exec('ROLLBACK');throw $e;}
  $success=true;$removed=@unlink(__FILE__);$message='Neues Adminpasswort gespeichert. Vorherige Anmeldesitzungen sind ungültig. Deine Grows und Einträge bleiben erhalten. '.($removed?'Die Wiederherstellungsdatei wurde automatisch gelöscht.':'Bitte diese Wiederherstellungsdatei jetzt per FTP löschen.');
 }catch(Throwable $e){http_response_code(400);$message=$e instanceof RuntimeException&&!($e instanceof PDOException)?$e->getMessage():'Wiederherstellung konnte nicht abgeschlossen werden. Bitte Dateirechte, PHP SQLite und freien Speicher prüfen. Bei Datenbankproblemen keine vorhandenen Dateien löschen.';}
}
?><!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>growfor · Adminzugang wiederherstellen</title><style>body{background:#101711;color:#eef5e9;font:16px/1.5 system-ui;max-width:600px;margin:35px auto;padding:20px}input,button{display:block;width:100%;box-sizing:border-box;margin:8px 0 20px;padding:13px;font:inherit;border-radius:9px}button{background:#b3e64b;border:0;color:#14210b}a{color:#b3e64b}.message{padding:16px;border:1px solid #537544;border-radius:12px}</style></head><body><h1>Adminzugang wiederherstellen</h1><p>Einmalige Wiederherstellung für den Inhaber dieser growfor-Installation. Benötigt den privat mitgeteilten Wiederherstellungscode. Das neue Passwort wird nur auf deinem Server gespeichert.</p><?php if($message):?><p class="message" role="status"><?=htmlspecialchars($message,ENT_QUOTES,'UTF-8')?></p><?php endif;?><?php if(!$success):?><form method="post"><label>Einmaliger Wiederherstellungscode<input name="token" required autocomplete="off" autocapitalize="none" spellcheck="false"></label><label>Neues Passwort (mindestens 12 Zeichen)<input name="password" type="password" required minlength="12" maxlength="72" autocomplete="new-password"></label><label>Neues Passwort bestätigen<input name="confirm" type="password" required minlength="12" maxlength="72" autocomplete="new-password"></label><button>Neues Adminpasswort setzen</button></form><?php else:?><p><a href="./">Zur App – danach mit Admin und deinem neuen Passwort anmelden</a></p><?php endif;?></body></html>
