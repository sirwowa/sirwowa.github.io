SIDELINE · NATIVE ANDROID-APP 1.9

Kamera2 und native Android-Ansichten, keine WebView-Hülle. API-Schlüssel bleiben
auf deinem PHP-Server. Das aktuelle Web-Paket 25 zuerst hochladen. sideline.apk
liegt direkt im Domain-Hauptordner; Web-App bleibt unter /touchdown/.

Die APK mit demselben Projektschlüssel wie die Vorversionen installieren; die
vorhandene App nicht löschen. Android ab 8.0. Mit bisherigem App-Passwort anmelden.

Kamera mit Rahmen, Auto-Scan und manuellem Auslöser. Jeder Treffer muss geprüft
und ausdrücklich gespeichert werden. Schiedsrichter hebt bei Vorschlägen beide
Arme; erst nach dem Speichern steht „Im VAULT gespeichert“ und es gibt Haptik.

Fehlende Kartenangaben werden beim Speichern aus verfügbaren Katalogdaten und
optional der Gemini-Fotoabschrift ergänzt. Verein und Position sind ausgeschrieben,
Kartentyp-Abkürzungen wie RC werden zu Rookie-Karte. Bestehende Angaben bleiben.
Bei einer Namens-/Nummerabweichung verlangt die Prüfung eine Bestätigung/Korrektur.
Unbekannte Werte werden nicht erfunden. Scan+ kann separat Kartentext ablesen.
Gleiche Bildabschriften werden kurzfristig serverseitig zwischengespeichert.

AI CardVault ist als zweite Bilderkennung verfügbar. Ohne sicheren Treffer gibt
es Alternativen oder einen verständlichen Nichttreffer; nie automatisches Speichern.
Bilder gehen als privater Multipart-Upload an den Anbieter, nicht als öffentliche URL.
Keine Fake-Cardsight-IDs. Die Sammlung kann ausdrücklich bestätigte CardVault-
Vorschläge auch ohne Cardsight-Verknüpfung enthalten. Schätzpreise dieses Anbieters
werden nicht als bestätigte Verkaufspreise ausgegeben.

TheCardAPI-Marktvergleich und Katalogrecherche öffnen als gekennzeichnete Web-
Funktionen im Browser. Dort kann eine erneute Anmeldung nötig sein. Bestätigte
Euro-Durchschnitte werden auf dem gemeinsamen Server gespeichert und nach dem
Aktualisieren auch im nativen VAULT und im Gesamtwert gezeigt. Werte werden nicht
auf andere Varianten oder geänderte Kartenidentitäten übertragen.

Weitere Funktionen: Sammlung mit Suche/Sortierung, große Fotos, Bearbeiten,
Duplikatbestätigung, Grading, Checklisten, öffentliche NFL/NBA-Spiele und deutsche
News, Backup, 41 lokale deutsche Ratgeber mit Merkliste und Gerätekopie des VAULTs.
Offline-VAULT benötigt eine zuvor gespeicherte Kopie; neue Scans und neue Preise
benötigen Internet. Offline-Daten und Serverdaten regelmäßig separat sichern.

Erkennungsqualität bei realen Karten ist nicht garantiert. Build und Signatur
wurden geprüft; physischer Smartphone-Test und echte Anbieteraufrufe stehen aus.
API-Limits und Einrichtung siehe GEMINI-UND-SCHIEDSRICHTER.txt im Web-Paket.
