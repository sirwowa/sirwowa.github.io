#!/usr/bin/env python3
"""Build a signed APK with official Android build-tools, without Gradle downloads.
ANDROID_SDK_ROOT, ANDROID_PLATFORM_JAR, ANDROID_BUILD_TOOLS may override SDK paths.
Signing: TOUCHDOWN_KEYSTORE, TOUCHDOWN_KEY_PASSWORD_FILE (never package secrets).
"""
from pathlib import Path
import os, subprocess, shutil, zipfile
root=Path(__file__).resolve().parent
sdk=Path(os.environ.get('ANDROID_SDK_ROOT',Path.home()/'Android/Sdk'))
platform=Path(os.environ.get('ANDROID_PLATFORM_JAR',str(sdk/'platforms/android-35/android.jar')))
tools=Path(os.environ.get('ANDROID_BUILD_TOOLS',str(sdk/'build-tools/35.0.0')))
key=os.environ.get('TOUCHDOWN_KEYSTORE'); password=os.environ.get('TOUCHDOWN_KEY_PASSWORD_FILE')
if not key or not password:raise SystemExit('Set TOUCHDOWN_KEYSTORE and TOUCHDOWN_KEY_PASSWORD_FILE to your private signing files.')
out=root/'build-manual'
if out.exists():shutil.rmtree(out)
for d in ['generated','classes','dex']: (out/d).mkdir(parents=True,exist_ok=True)
def run(*args):subprocess.run([str(x) for x in args],check=True)
run(tools/'aapt2','compile','--dir',root/'app/src/main/res','-o',out/'resources.zip')
# Standalone aapt2 needs package and version values normally supplied by Gradle.
manifest=(root/'app/src/main/AndroidManifest.xml').read_text().replace('<manifest xmlns:android=', '<manifest package="de.fourdoubleu.touchdown" android:versionCode="8" android:versionName="1.7" xmlns:android=')
(out/'AndroidManifest.xml').write_text(manifest)
run(tools/'aapt2','link','-I',platform,'-A',root/'app/src/main/assets','--manifest',out/'AndroidManifest.xml','--min-sdk-version','26','--target-sdk-version','35','--java',out/'generated','-o',out/'unsigned.apk',out/'resources.zip')
sources=[*root.glob('app/src/main/java/**/*.java'),*out.glob('generated/**/*.java')]
run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-classpath',platform,'-d',out/'classes',*sources)
run('java','-cp',tools/'lib/d8.jar','com.android.tools.r8.D8','--lib',platform,'--min-api','26','--output',out/'dex',*out.glob('classes/**/*.class'))
with zipfile.ZipFile(out/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
 for f in (out/'dex').glob('*.dex'):z.write(f,f.name)
run(tools/'zipalign','-p','-f','4',out/'unsigned.apk',out/'aligned.apk')
run('java','-jar',tools/'lib/apksigner.jar','sign','--ks',key,'--ks-pass','file:'+password,'--out',out/'touchdown-collector-android.apk',out/'aligned.apk')
run('java','-jar',tools/'lib/apksigner.jar','verify','--verbose',out/'touchdown-collector-android.apk')
print(out/'touchdown-collector-android.apk')
