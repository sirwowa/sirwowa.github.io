package de.fourdoubleu.touchdown;
import android.animation.ValueAnimator;import android.content.Context;import android.graphics.*;import android.view.View;
/** Original generic referee illustration; no team or league logo. */
final class RefereeView extends View{
 final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);float progress=1;ValueAnimator animator;
 RefereeView(Context context){super(context);setContentDescription("Schiedsrichter hebt beide Arme zum Touchdown-Zeichen");}
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();if(android.provider.Settings.Global.getFloat(getContext().getContentResolver(),android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,1f)>0){animator=ValueAnimator.ofFloat(0,1);animator.setDuration(800);animator.setInterpolator(new android.view.animation.DecelerateInterpolator());animator.addUpdateListener(v->{progress=(Float)v.getAnimatedValue();invalidate();});animator.start();}}
 @Override protected void onDetachedFromWindow(){if(animator!=null)animator.cancel();super.onDetachedFromWindow();}
 void rect(Canvas c,float l,float t,float r,float b,int color){paint.setColor(color);c.drawRoundRect(l,t,r,b,4,4,paint);}
 void arm(Canvas c,float x,float angle){c.save();c.rotate(angle,x,93);rect(c,x-6,29,x+6,96,Color.WHITE);for(int y=38;y<88;y+=13)rect(c,x-6,y,x+6,y+6,Color.rgb(19,35,52));paint.setColor(Color.rgb(239,196,162));c.drawOval(x-7,14,x+7,32,paint);c.restore();}
 @Override protected void onDraw(Canvas c){super.onDraw(c);float scale=Math.min(getWidth()/180f,getHeight()/210f);c.save();c.translate((getWidth()-180*scale)/2,(getHeight()-210*scale)/2);c.scale(scale,scale);int dark=Color.rgb(19,35,52),pants=Color.rgb(59,77,99),skin=Color.rgb(239,196,162);rect(c,72,145,88,193,pants);rect(c,98,145,114,193,pants);rect(c,65,189,90,198,Color.LTGRAY);rect(c,96,189,121,198,Color.LTGRAY);arm(c,64,-155*(1-progress));arm(c,116,155*(1-progress));rect(c,63,88,117,151,dark);for(int x=69;x<110;x+=12)rect(c,x,95,x+6,143,Color.WHITE);rect(c,82,76,98,91,skin);paint.setColor(skin);c.drawCircle(90,64,17,paint);rect(c,73,40,107,58,dark);rect(c,72,55,110,60,Color.LTGRAY);paint.setColor(Color.rgb(0,139,255));c.drawCircle(90,115,4,paint);c.restore();}
}
