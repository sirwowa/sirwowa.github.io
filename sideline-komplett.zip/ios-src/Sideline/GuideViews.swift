import SwiftUI

struct GuideLibrary: Decodable {
    let notice: String
    let items: [GuideArticle]
    let groups: [GuideGroup]
    static func load() -> GuideLibrary? { guard let url = Bundle.main.url(forResource: "guides", withExtension: "json"), let data = try? Data(contentsOf: url) else { return nil }; return try? JSONDecoder().decode(Self.self, from: data) }
}
struct GuideGroup: Decodable, Identifiable { let id: String; let title: String; let categories: [String] }
struct GuideArticle: Decodable, Identifiable {
    let id: Int; let title: String; let category: String; let summary: String; let sections: [GuideSection]; let url: URL; let contentCredit: String
    var searchable: String { ([title, category, summary] + sections.flatMap { [$0.heading] + $0.paragraphs }).joined(separator: " ") }
}
struct GuideSection: Decodable { let heading: String; let paragraphs: [String] }
struct LibraryView: View {
    private let library = GuideLibrary.load()
    @State private var query = ""
    @State private var group = ""
    @State private var onlySaved = false
    @AppStorage("sideline-saved-guides") private var saved = "|"
    var body: some View {
        Group {
            if let library {
                List {
                    Section { Text("41 deutsche Ratgeber · offline lesbar").font(.headline)
                        Picker("Wissensbereich", selection: $group) { Text("Alle Themen").tag(""); ForEach(library.groups) { g in Text(g.title).tag(g.id) } }
                        Toggle("Nur gemerkte Ratgeber", isOn: $onlySaved)
                    }
                    ForEach(library.groups.filter { group.isEmpty || $0.id == group }) { g in
                        let articles = library.items.filter { g.categories.contains($0.category) && (!onlySaved || saved.contains("|\($0.id)|")) && (query.isEmpty || $0.searchable.localizedStandardContains(query)) }
                        if !articles.isEmpty { Section(g.title) { ForEach(articles) { article in NavigationLink { GuideReader(article: article) } label: { VStack(alignment: .leading, spacing: 7) { Text((saved.contains("|\(article.id)|") ? "★ " : "") + article.title).font(.headline); Text(article.summary).font(.subheadline).foregroundStyle(.secondary) }.padding(.vertical, 5) } } } }
                    }
                    Section("Inhalte & Quellen") { Text(library.notice).font(.footnote); Text("Stand: 31.10.2026. Aktuelle Regeln und Gebühren beim Anbieter prüfen. Keine Cardsight-Aufrufe.").font(.footnote) }
                }.searchable(text: $query, prompt: "Alle Erklärungen durchsuchen")
            } else { ContentUnavailableView("Bibliothek nicht gefunden", systemImage: "books.vertical", description: Text("Bitte die mitgelieferte guides.json im Xcode-Ziel prüfen.")) }
        }.navigationTitle("Sammlerwissen")
    }
}
struct GuideReader: View {
    let article: GuideArticle
    @AppStorage("sideline-saved-guides") private var saved = "|"
    var isSaved: Bool { saved.contains("|\(article.id)|") }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Text(article.category.uppercased()).font(.caption).foregroundStyle(.cyan)
                Text(article.title).font(.largeTitle.bold())
                Text(article.summary).font(.title3).foregroundStyle(.secondary)
                ForEach(Array(article.sections.enumerated()), id: \.offset) { _, section in VStack(alignment: .leading, spacing: 12) { Text(section.heading).font(.title2.bold()); ForEach(Array(section.paragraphs.enumerated()), id: \.offset) { _, paragraph in Text(paragraph).lineSpacing(5).textSelection(.enabled) } } }
                Divider(); Text(article.contentCredit).font(.footnote).foregroundStyle(.secondary)
                Link("Originalthema bei COLLECT.Guide öffnen ↗", destination: article.url)
                Text("Der Originalartikel kann englisch sein und benötigt Internet. Eigene deutsche Erklärungen, keine vollständige Übersetzung der Quelle.").font(.footnote).foregroundStyle(.secondary)
            }.padding(22)
        }.toolbar { Button { let mark = "|\(article.id)|"; saved = isSaved ? saved.replacingOccurrences(of: mark, with: "|") : saved + "\(article.id)|" } label: { Label(isSaved ? "Gemerkt" : "Merken", systemImage: isSaved ? "star.fill" : "star") } }
    }
}
