import Foundation

struct ServerError: LocalizedError {
    let status: Int
    let message: String
    let isDuplicate: Bool
    var errorDescription: String? { message }
}

/// Credentials stay on the PHP server. Only a short-lived session lives in memory.
@MainActor final class APIClient {
    static let base = URL(string: "https://app.4doubleu.de/touchdown/")!
    private var csrf = ""
    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 55
        config.timeoutIntervalForResource = 65
        config.httpShouldSetCookies = true
        config.httpCookieAcceptPolicy = .always
        config.urlCache = nil
        return URLSession(configuration: config, delegate: NoRedirect(), delegateQueue: nil)
    }()
    func login(password: String) async throws {
        let initial = try await json(path: "native-login.php") as? [String: Any] ?? [:]
        guard initial["configured"] as? Bool == true else { throw ServerError(status: 503, message: "Bitte die Web-App zuerst einrichten.", isDuplicate: false) }
        csrf = initial["csrf"] as? String ?? ""
        let reply = try await json(path: "native-login.php", method: "POST", body: ["password": password]) as? [String: Any] ?? [:]
        guard let token = reply["csrf"] as? String, !token.isEmpty else { throw ServerError(status: 401, message: "Anmeldung konnte nicht bestätigt werden.", isDuplicate: false) }
        csrf = token
    }
    func request(_ route: String, method: String = "GET", body: [String: Any]? = nil) async throws -> Any {
        var parts = URLComponents(url: Self.base.appendingPathComponent("api.php"), resolvingAgainstBaseURL: false)!
        parts.queryItems = [URLQueryItem(name: "r", value: route)]
        return try await json(url: parts.url!, method: method, body: body)
    }
    func image(id: String) async throws -> Data {
        var parts = URLComponents(url: Self.base.appendingPathComponent("api.php"), resolvingAgainstBaseURL: false)!
        parts.queryItems = [URLQueryItem(name: "r", value: "image"), URLQueryItem(name: "id", value: id)]
        return try await data(url: parts.url!)
    }
    private func json(path: String, method: String = "GET", body: [String: Any]? = nil) async throws -> Any {
        try await json(url: Self.base.appendingPathComponent(path), method: method, body: body)
    }
    private func json(url: URL, method: String, body: [String: Any]?) async throws -> Any {
        let bytes = try await data(url: url, method: method, body: body)
        return try JSONSerialization.jsonObject(with: bytes)
    }
    private func data(url: URL, method: String = "GET", body: [String: Any]? = nil) async throws -> Data {
        guard url.scheme == "https", url.host == Self.base.host else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.httpMethod = ["PUT", "DELETE"].contains(method) ? "POST" : method
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(csrf, forHTTPHeaderField: "X-CSRF-Token")
        request.setValue("SidelineNativeIOS/1.0", forHTTPHeaderField: "User-Agent")
        if method == "PUT" || method == "DELETE" { request.setValue(method, forHTTPHeaderField: "X-HTTP-Method-Override") }
        if let body { request.httpBody = try JSONSerialization.data(withJSONObject: body); request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        let (bytes, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        guard (200..<300).contains(http.statusCode) else {
            let error = (try? JSONSerialization.jsonObject(with: bytes)) as? [String: Any]
            throw ServerError(status: http.statusCode, message: error?["error"] as? String ?? "Der Server antwortet mit Fehler \(http.statusCode).", isDuplicate: error?["duplicates"] != nil)
        }
        return bytes
    }
    func clear() { csrf = ""; session.configuration.httpCookieStorage?.cookies?.forEach { session.configuration.httpCookieStorage?.deleteCookie($0) } }
}
private final class NoRedirect: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
