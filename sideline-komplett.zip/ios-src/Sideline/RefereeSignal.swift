import SwiftUI

/// Original generic referee drawing, animated from lowered to raised arms.
struct RefereeSignal: View, Animatable {
    var progress: Double
    var animatableData: Double { get { progress } set { progress = newValue } }
    var body: some View {
        Canvas { original, size in
            var context = original
            let scale = min(size.width / 180, size.height / 210)
            context.translateBy(x: (size.width - 180 * scale) / 2, y: (size.height - 210 * scale) / 2)
            context.scaleBy(x: scale, y: scale)
            let dark = Color(red: 0.075, green: 0.137, blue: 0.204)
            let skin = Color(red: 0.937, green: 0.769, blue: 0.635)
            func rect(_ x: CGFloat, _ y: CGFloat, _ width: CGFloat, _ height: CGFloat, _ color: Color) {
                context.fill(Path(roundedRect: CGRect(x: x, y: y, width: width, height: height), cornerRadius: 4), with: .color(color))
            }
            func arm(_ x: CGFloat, _ angle: Double) {
                var c = context; c.translateBy(x: x, y: 93); c.rotate(by: .degrees(angle)); c.translateBy(x: -x, y: -93)
                c.fill(Path(roundedRect: CGRect(x: x - 6, y: 29, width: 12, height: 67), cornerRadius: 6), with: .color(.white))
                for y in stride(from: 38, to: 88, by: 13) { c.fill(Path(CGRect(x: x - 6, y: CGFloat(y), width: 12, height: 6)), with: .color(dark)) }
                c.fill(Path(ellipseIn: CGRect(x: x - 7, y: 14, width: 14, height: 18)), with: .color(skin))
            }
            rect(72, 145, 16, 48, .gray); rect(98, 145, 16, 48, .gray)
            rect(65, 189, 25, 9, .white); rect(96, 189, 25, 9, .white)
            arm(64, -155 * (1 - progress)); arm(116, 155 * (1 - progress))
            rect(63, 88, 54, 63, dark)
            for x in stride(from: 69, to: 110, by: 12) { rect(CGFloat(x), 95, 6, 48, .white) }
            rect(82, 76, 16, 15, skin)
            context.fill(Path(ellipseIn: CGRect(x: 73, y: 47, width: 34, height: 34)), with: .color(skin))
            rect(73, 40, 34, 18, dark); rect(72, 55, 38, 5, .white)
            context.fill(Path(ellipseIn: CGRect(x: 86, y: 111, width: 8, height: 8)), with: .color(.cyan))
        }.accessibilityHidden(true)
    }
}
