import SwiftUI

@main struct SidelineApp: App {
    @StateObject private var store = SidelineStore()
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            Group { if store.loggedIn { MainTabs() } else { LoginView() } }
                .environmentObject(store).tint(.cyan).preferredColorScheme(.dark)
                .overlay { if let player = store.celebration { SaveCelebration(player: player, saved: store.celebrationSaved).id(store.celebrationID).allowsHitTesting(false) } }
                .alert("Sideline", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) { Button("Verstanden") { store.message = nil } } message: { Text(store.message ?? "") }
                .onChange(of: phase) { _, phase in if phase == .background && store.offline { store.loggedIn = false; store.cards = []; store.prices = [:] } }
        }
    }
}
struct LoginView: View {
    @EnvironmentObject private var store: SidelineStore
    @State private var password = ""
    var body: some View {
        NavigationStack {
            Form {
                Section { HStack { Spacer(); VStack(spacing: 12) { Image("SidelineLogo").resizable().scaledToFit().frame(width: 100, height: 100); Text("SIDELINE").font(.largeTitle.bold()); Text("Dein Spiel. Deine Sammlung.").foregroundStyle(.secondary) }; Spacer() }.listRowBackground(Color.clear) }
                Section("Dein VAULT") {
                    SecureField("App-Passwort · mindestens 6 Zeichen", text: $password).textContentType(.password)
                    Toggle("Offline-Kopie auf diesem iPhone speichern", isOn: $store.keepOffline)
                    Button { let entered = password; password = ""; Task { await store.login(entered) } } label: { HStack { Text("Anmelden"); if store.busy { ProgressView() } } }.disabled(store.busy || password.count < 6)
                    Button("Offline-VAULT öffnen") { Task { await store.openOffline() } }.disabled(store.busy)
                }
                Section { Text("Erkennung und gemeinsame Sammlung verwenden deinen Server. Der Cardsight-Schlüssel bleibt dort. Die optionale Offline-Kopie ist durch den iPhone-Geräteschutz gesichert und ersetzt kein Backup.").font(.footnote); Link("Web-App öffnen", destination: APIClient.base) }
            }
        }
    }
}
struct MainTabs: View {
    @EnvironmentObject private var store: SidelineStore
    var body: some View {
        TabView {
            NavigationStack { DashboardView() }.tabItem { Label("Start", systemImage: "house.fill") }
            NavigationStack { VaultView() }.tabItem { Label("VAULT", systemImage: "rectangle.stack.fill") }
            if !store.offline { NavigationStack { ScannerView() }.tabItem { Label("Scannen", systemImage: "viewfinder") } }
            if !store.offline { CardSearchTab().tabItem { Label("Suche", systemImage: "magnifyingglass") } }
            NavigationStack { MoreView() }.tabItem { Label("Mehr", systemImage: "ellipsis.circle") }
        }
    }
}
struct DashboardView: View {
    @EnvironmentObject private var store: SidelineStore
    var total: Double { store.vault.reduce(0) { $0 + (store.price(for: $1) ?? 0) * Double(max(1, Int($1.text("quantity")) ?? 1)) } }
    var body: some View {
        List {
            Section { Text("Deine Sammlung. Dein Spielfeld.").font(.title.bold()); LabeledContent("Karten", value: "\(store.vault.reduce(0) { $0 + max(1, Int($1.text("quantity")) ?? 1) })"); LabeledContent("Gespeicherter Gesamtwert", value: total.formatted(.currency(code: "EUR"))); Text("\(store.vault.filter { store.price(for: $0) != nil }.count) von \(store.vault.count) Einträgen bewertet. Letzte gespeicherte Preise; Karten ohne Preis sind nicht eingerechnet.").font(.footnote).foregroundStyle(.secondary) }
            Section("Zuletzt gesammelt") { ForEach(Array(store.vault.suffix(8).reversed())) { card in NavigationLink { CardDetailView(card: card) } label: { CardRow(card: card) } } }
            if store.offline { Section { Text("Offline-Kopie: \(store.snapshotDate)") } }
        }.navigationTitle("Sideline")
    }
}
struct CardRow: View {
    @EnvironmentObject private var store: SidelineStore
    let card: CardRecord
    var body: some View { HStack(spacing: 14) { CardPhoto(card: card).frame(width: 55, height: 78); VStack(alignment: .leading, spacing: 6) { Text(card.player).font(.headline); Text(card.subtitle).font(.caption).foregroundStyle(.secondary); if let price = store.price(for: card) { Text(price.formatted(.currency(code: "EUR"))).foregroundStyle(.cyan) } else { Text("Kein gespeicherter Preis").font(.caption2).foregroundStyle(.secondary) } } } }
}
struct CardPhoto: View {
    let card: CardRecord
    var body: some View { Group { if let photo = card.photo { Image(uiImage: photo).resizable().scaledToFit() } else { ZStack { RoundedRectangle(cornerRadius: 8).fill(.quaternary); Image(systemName: "rectangle.portrait").foregroundStyle(.secondary) } } }.accessibilityLabel("Kartenfoto von \(card.player)") }
}
struct VaultView: View {
    @EnvironmentObject private var store: SidelineStore
    @State private var query = ""
    @State private var sort = "Zuletzt gesammelt"
    private let sorts = ["Zuletzt gesammelt", "Spieler", "Team / Position", "Jahr / Set / Nummer"]
    var rows: [CardRecord] {
        let filtered = store.vault.filter { query.isEmpty || [$0.player, $0.subtitle, $0.text("team"), $0.text("position")].joined(separator: " ").localizedStandardContains(query) }
        return filtered.sorted { a, b in
            let keys = sort == "Spieler" ? ["player"] : sort == "Team / Position" ? ["team", "position", "player"] : sort == "Jahr / Set / Nummer" ? ["year", "set", "number", "parallel"] : ["createdAt"]
            for key in keys {
                if key == "position" {
                    let order = ["quarterback", "running back", "fullback", "wide receiver", "tight end", "offensive tackle", "offensive guard", "center", "defensive end", "defensive tackle", "linebacker", "cornerback", "safety", "kicker", "punter", "long snapper"]
                    let left = order.firstIndex(of: a.text(key).lowercased()) ?? 99
                    let right = order.firstIndex(of: b.text(key).lowercased()) ?? 99
                    if left != right { return left < right }
                }
                let c = a.text(key).localizedStandardCompare(b.text(key)); if c != .orderedSame { return sort == "Zuletzt gesammelt" ? c == .orderedDescending : c == .orderedAscending } }; return a.id < b.id
        }
    }
    var body: some View { List { Picker("Sortierung", selection: $sort) { ForEach(sorts, id: \.self) { Text($0) } }; ForEach(rows) { card in NavigationLink { CardDetailView(card: card) } label: { CardRow(card: card) } }; if rows.isEmpty { ContentUnavailableView("Keine Karten gefunden", systemImage: "rectangle.stack", description: Text("Scanne eine Karte oder ändere deine Suche.")) } }.navigationTitle("VAULT").searchable(text: $query, prompt: "Spieler, Team, Set, Nummer").refreshable { guard !store.offline else { return }; do { try await store.refresh() } catch { store.message = error.localizedDescription } } }
}
struct CardDetailView: View {
    @EnvironmentObject private var store: SidelineStore
    let card: CardRecord
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 18) {
            CardPhoto(card: card).frame(maxWidth: .infinity).frame(height: 420)
            Text(card.player).font(.title.bold()); Text(card.subtitle).foregroundStyle(.secondary)
            ForEach([("serialNumber", "Nummerierung"), ("sport", "Sportart"), ("grader", "Grading-Anbieter"), ("grade", "Note"), ("certNumber", "Zertifikat")], id: \.0) { key, title in if !card.text(key).isEmpty { LabeledContent(title, value: card.text(key)) } }
            if let price = store.price(for: card) { Text(price.formatted(.currency(code: "EUR"))).font(.title).foregroundStyle(.cyan); Text("Letzter gespeicherter Marktwert").font(.caption).foregroundStyle(.secondary) }
            if !store.offline { Button("Marktpreis bewusst abrufen") { Task { await store.fetchPrice(for: card) } }.buttonStyle(.borderedProminent).disabled(store.busy || card.text("cardsightId").isEmpty); Text("Anfrage verbraucht gegebenenfalls Cardsight-Kontingent. Es werden keine laufenden Angebotspreise als bezahlte Verkäufe ausgegeben.").font(.footnote).foregroundStyle(.secondary) }
        }.padding(20) }.navigationTitle("Kartendetails").navigationBarTitleDisplayMode(.inline)
    }
}
struct MoreView: View {
    @EnvironmentObject private var store: SidelineStore
    var body: some View {
        List {
            Section { NavigationLink { LibraryView() } label: { Label("Sammlerwissen auf Deutsch", systemImage: "books.vertical") } }
            if !store.offline { Section("Weitere Funktionen im Browser") { ForEach([("TheCardAPI · Verkäufe & Katalog", "comparisons"), ("Checklisten", "checklists"), ("Live-Spiele", "live"), ("NEWS", "news"), ("Einstellungen & Backup", "settings")], id: \.1) { title, route in Link(title + " ↗", destination: URL(string: APIClient.base.absoluteString + "#" + route)!) }; Text("Öffnet Safari. Dort kann eine eigene Anmeldung erforderlich sein.").font(.footnote) } }
            Section("Dieses iPhone") {
                if !store.offline { Button("Geschützte Offline-Kopie aktualisieren") { do { try store.saveOffline(); store.keepOffline = true; store.message = "Offline-Kopie gespeichert." } catch { store.message = error.localizedDescription } } }
                Button("Offline-Kopie löschen", role: .destructive) { store.removeOffline() }
                Text("Die lokale Kopie enthält deine Fotos und gespeicherten Preise. Zum Öffnen wird die iPhone-Geräteauthentifizierung verwendet. Beim Verlassen der Offline-App wird sie gesperrt.").font(.footnote)
            }
            Button("Abmelden", role: .destructive) { Task { await store.logout() } }
        }.navigationTitle("Mehr")
    }
}
struct SaveCelebration: View {
    let player: String
    var saved: Bool = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var raised: Double = 0
    var body: some View { VStack(spacing: 10) {
        RefereeSignal(progress: reduceMotion ? 1 : raised).frame(width: 126, height: 147)
        Text(saved ? "TOUCHDOWN!" : "TREFFER GEFUNDEN").font(.title2.bold()).foregroundStyle(.cyan)
        Text(player); Text(saved ? "Im VAULT gespeichert" : "Treffervorschlag · bitte Karte prüfen").font(.footnote)
    }.padding(24).background(.ultraThickMaterial, in: RoundedRectangle(cornerRadius: 26)).padding(24)
        .onAppear { if reduceMotion { raised = 1 } else { withAnimation(.easeOut(duration: 0.8)) { raised = 1 } } }
        .accessibilityElement(children: .combine) }
}

struct CardSearchTab: View {
    @State private var selected: [CardRecord] = []
    var body: some View {
        CatalogSearchView(embedded: true) { record in selected = [record] }
            .sheet(isPresented: Binding(get: { !selected.isEmpty }, set: { if !$0 { selected = [] } })) {
                ReviewView(candidates: selected, photo: nil) { selected = [] }
            }
    }
}
