import UIKit
import AVFoundation
import SwiftUI
import CoreImage

/// Stable-image heuristic only. Actual card identity is determined by the server.
struct AutoScanGate {
    private var previous: [UInt8] = []
    private var captured: [UInt8] = []
    private var stableSince: TimeInterval?
    private var armed = true
    private var changed = 0
    private var blank = 0
    private func difference(_ a: [UInt8], _ b: [UInt8]) -> Double {
        guard a.count == b.count, !a.isEmpty else { return 255 }
        return zip(a, b).reduce(0.0) { $0 + abs(Double($1.0) - Double($1.1)) } / Double(a.count)
    }
    mutating func lock() { captured = previous; armed = false; stableSince = nil; changed = 0; blank = 0 }
    mutating func pause() { previous = []; stableSince = nil }
    mutating func update(_ gray: [UInt8], now: TimeInterval) -> Bool {
        guard gray.count == 80 * 112 else { return false }
        let mean = gray.reduce(0.0) { $0 + Double($1) } / Double(gray.count)
        let variance = gray.reduce(0.0) { $0 + pow(Double($1) - mean, 2) } / Double(gray.count)
        var sides = 0
        for side in 0..<4 {
            let vertical = side < 2
            let nominal = [8, 72, 11, 101][side]
            var best = 0.0
            for offset in -4...4 {
                let pos = nominal + offset; let range = vertical ? 16..<96 : 12..<68
                var edges = 0
                for k in range {
                    let a = vertical ? k * 80 + pos - 2 : (pos - 2) * 80 + k
                    let b = vertical ? k * 80 + pos + 2 : (pos + 2) * 80 + k
                    if abs(Int(gray[a]) - Int(gray[b])) > 18 { edges += 1 }
                }
                best = max(best, Double(edges) / Double(range.count))
            }
            if best > 0.45 { sides += 1 }
        }
        let good = sides >= 2 && variance > 484 && mean > 22 && mean < 240
        if !armed {
            blank = good ? 0 : blank + 1; changed = difference(gray, captured) > 14 ? changed + 1 : 0
            if blank >= 3 || changed >= 3 { armed = true; pause(); changed = 0; blank = 0 } else { return false }
        }
        let still = difference(gray, previous) < 3; previous = gray
        guard good && still else { stableSince = nil; return false }
        if stableSince == nil { stableSince = now }
        if now - (stableSince ?? now) >= 1.5 { lock(); return true }
        return false
    }
}

final class CameraController: NSObject, ObservableObject, AVCapturePhotoCaptureDelegate, AVCaptureVideoDataOutputSampleBufferDelegate {
    let session = AVCaptureSession()
    @Published private(set) var ready = false
    @Published var error: String?
    @Published var automatic = true
    var onPhoto: ((UIImage) -> Void)?
    var viewport = CGSize(width: 390, height: 650) // Written/read on main thread.
    var suspended = false
    private let queue = DispatchQueue(label: "de.fourdoubleu.sideline.camera")
    private let output = AVCapturePhotoOutput()
    private let video = AVCaptureVideoDataOutput()
    private var configured = false
    private var gate = AutoScanGate()
    private var lastSample: TimeInterval = 0
    private var capturePending = false
    private var foreground = false
    static func frame(in size: CGSize) -> CGRect {
        let height = min(size.height * 0.65, size.width * 0.80 * 7 / 5)
        let width = height * 5 / 7
        return CGRect(x: (size.width - width) / 2, y: (size.height - 80 - height) / 2, width: width, height: height)
    }
    static func cropRect(image: CGSize, viewport: CGSize) -> CGRect {
        let scale = max(viewport.width / image.width, viewport.height / image.height)
        let rect = frame(in: viewport)
        return CGRect(x: (rect.minX + (image.width * scale - viewport.width) / 2) / scale,
                      y: (rect.minY + (image.height * scale - viewport.height) / 2) / scale,
                      width: rect.width / scale, height: rect.height / scale).intersection(CGRect(origin: .zero, size: image))
    }
    func start() {
        foreground = true
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: configureAndRun()
        case .notDetermined: AVCaptureDevice.requestAccess(for: .video) { granted in DispatchQueue.main.async { if granted && self.foreground { self.configureAndRun() } else if !granted { self.error = "Bitte den Kamerazugriff in den iPhone-Einstellungen erlauben." } } }
        default: error = "Kein Kamerazugriff. Bitte unter Einstellungen → Sideline → Kamera erlauben."
        }
    }
    private func configureAndRun() {
        queue.async {
            if !self.configured {
                do {
                    self.session.beginConfiguration(); self.session.sessionPreset = .photo
                    defer { self.session.commitConfiguration() }
                    guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else { throw CameraFailure.unavailable }
                    let input = try AVCaptureDeviceInput(device: camera)
                    guard self.session.canAddInput(input), self.session.canAddOutput(self.output), self.session.canAddOutput(self.video) else { throw CameraFailure.unavailable }
                    self.session.addInput(input); self.session.addOutput(self.output); self.session.addOutput(self.video)
                    self.video.alwaysDiscardsLateVideoFrames = true
                    self.video.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
                    self.video.setSampleBufferDelegate(self, queue: .main)
                    if self.video.connection(with: .video)?.isVideoOrientationSupported == true { self.video.connection(with: .video)?.videoOrientation = .portrait }
                    self.configured = true
                } catch { DispatchQueue.main.async { self.error = error.localizedDescription }; return }
            }
            // start/stop are serialized on this queue; a queued stop wins when leaving the screen.
            if !self.session.isRunning { self.session.startRunning() }
            DispatchQueue.main.async { self.ready = self.foreground && self.session.isRunning }
        }
    }
    func stop() { foreground = false; ready = false; gate.pause(); queue.async { if self.session.isRunning { self.session.stopRunning() } } }
    func take() {
        guard ready, foreground, !suspended, !capturePending else { return }
        capturePending = true; gate.lock()
        let settings = AVCapturePhotoSettings(); settings.flashMode = .off
        if output.connection(with: .video)?.isVideoOrientationSupported == true { output.connection(with: .video)?.videoOrientation = .portrait }
        output.capturePhoto(with: settings, delegate: self)
    }
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        DispatchQueue.main.async {
            self.capturePending = false
            guard self.foreground else { return }
            if let error { self.error = error.localizedDescription; return }
            guard let data = photo.fileDataRepresentation(), let image = UIImage(data: data), let cg = image.cgImage else { self.error = "Foto konnte nicht gelesen werden."; return }
            let swaps = [UIImage.Orientation.left, .leftMirrored, .right, .rightMirrored].contains(image.imageOrientation)
            let size = CGSize(width: CGFloat(swaps ? cg.height : cg.width), height: CGFloat(swaps ? cg.width : cg.height))
            let format = UIGraphicsImageRendererFormat(); format.scale = 1
            let normalized = UIGraphicsImageRenderer(size: size, format: format).image { _ in image.draw(in: CGRect(origin: .zero, size: size)) }
            let rect = Self.cropRect(image: size, viewport: self.viewport)
            guard !rect.isNull, let crop = normalized.cgImage?.cropping(to: rect) else { self.error = "Karten-Ausschnitt konnte nicht erstellt werden."; return }
            let scale = min(1, 2200 / max(rect.width, rect.height)); let target = CGSize(width: rect.width * scale, height: rect.height * scale)
            let result = UIGraphicsImageRenderer(size: target, format: format).image { _ in UIImage(cgImage: crop).draw(in: CGRect(origin: .zero, size: target)) }
            self.suspended = true; self.onPhoto?(result)
        }
    }
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard automatic, foreground, ready, !suspended, !capturePending else { gate.pause(); return }
        let now = ProcessInfo.processInfo.systemUptime
        guard now - lastSample > 0.35, let buffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }; lastSample = now
        CVPixelBufferLockBaseAddress(buffer, .readOnly); defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(buffer) else { return }
        let width = CVPixelBufferGetWidth(buffer), height = CVPixelBufferGetHeight(buffer), stride = CVPixelBufferGetBytesPerRow(buffer)
        // Expand the guide slightly to include card edges for the stability heuristic.
        let crop = Self.cropRect(image: CGSize(width: CGFloat(width), height: CGFloat(height)), viewport: viewport).insetBy(dx: -CGFloat(width) * 0.045, dy: -CGFloat(height) * 0.045)
        let bytes = base.assumingMemoryBound(to: UInt8.self); var gray: [UInt8] = []; gray.reserveCapacity(80 * 112)
        for y in 0..<112 { for x in 0..<80 {
            let px = min(width - 1, max(0, Int(crop.minX + CGFloat(x) * crop.width / 80)))
            let py = min(height - 1, max(0, Int(crop.minY + CGFloat(y) * crop.height / 112))); let i = py * stride + px * 4
            gray.append(UInt8((Int(bytes[i + 2]) * 299 + Int(bytes[i + 1]) * 587 + Int(bytes[i]) * 114) / 1000))
        } }
        if gate.update(gray, now: now) { take() }
    }
    enum CameraFailure: LocalizedError { case unavailable; var errorDescription: String? { "Keine geeignete Kamera verfügbar." } }
}

struct CameraPreview: UIViewRepresentable {
    let controller: CameraController
    func makeUIView(context: Context) -> PreviewView { let view = PreviewView(); view.layerView.session = controller.session; view.layerView.videoGravity = .resizeAspectFill; return view }
    func updateUIView(_ view: PreviewView, context: Context) { view.layerView.connection?.videoOrientation = .portrait }
}
final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var layerView: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}
