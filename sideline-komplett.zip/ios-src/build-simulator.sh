#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 check-project.py
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo 'Xcode auf einem Mac ist erforderlich. Dieses Skript erzeugt keine installierbare IPA auf Linux.' >&2
  exit 1
fi
xcodebuild -project Sideline.xcodeproj -scheme Sideline -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build
