# Update V26

Gemini prüft Karte und Parallelvariante mit dem gemeinsamen Server. Vorhandene Daten beim Web-Update behalten. Android 2.0, iOS-Quellprojekt 1.4; iOS weiterhin ohne Xcode-Build und Signierung.

# Sideline für iPhone · natives iOS-Projekt 1.3

Dieses Paket enthält ein eigenständiges SwiftUI-/AVFoundation-Projekt, keine WebView-Hülle. Es enthält **keine gebaute, signierte oder bereits installierbare iPhone-App**. Erstellt auf Linux; Swift-Syntax, Ressourcen und Konfiguration geprüft. **Xcode-Kompilierung und iPhone-Hardwaretest stehen aus.**

## Sofort nutzbar ohne Mac oder Apple-Developer-Konto

Die bestehende Sideline-Web-App in Safari öffnen:
https://app.4doubleu.de/touchdown/

Teilen → Zum Home-Bildschirm → ggf. „Als Web-App öffnen“ → Hinzufügen.
Die neue öffentliche Anleitung liegt nach Hochladen des Web-Pakets unter:
https://app.4doubleu.de/touchdown/install.html#iphone

Das ist die installierte **Web-App**, kein nativer App-Store-Download. Eine APK funktioniert auf dem iPhone nicht. Das Xcode-Projekt allein lässt sich dort ebenfalls nicht installieren.

## Umfang der nativen ersten Version

- iPhone ab iOS 17, Hochformat, SwiftUI und AVFoundation.
- Anmeldung mit bisherigem App-Passwort, Session und CSRF über native-login.php.
- Gleicher PHP-Server und VAULT unter app.4doubleu.de/touchdown/.
- Rückkamera, Kartenrahmen und Aufnahme des sichtbaren Ausschnitts, manueller Auslöser und lokale Stabilitätsheuristik für Auto-Scan. Kein neuer lokaler KI-Identifikator.
- Kartenidentifikation ausschließlich über den bestehenden Cardsight-Proxy. Kein Kartenanbieter-Schlüssel im iPhone-Projekt.
- Kein Speichern allein wegen „High“: ausdrückliche Trefferprüfung, alternative Anbieter-Vorschläge, Nummer/Jahr/Hersteller-Suche mit optionalem Spieler, Varianteneingabe und Katalogvarianten zum Auswählen.
- Eigene Scan-Fotos; Katalog-Vergleichsbild nur auf Wunsch. Automatische Aufnahme wird bis zur Prüfung pausiert und wartet anschließend auf Kartenwechsel.
- Duplikate bestätigen und nächste Karte scannen; Bestand wird dabei nicht erhöht.
- Haptik und Football-Animation erst nach erfolgreichem Speichern.
- VAULT, Suche, Sortierung, große Kartendetails, gespeicherte Einzel- und Gesamtwerte in Euro. Preisabruf nur ausdrücklich auf Knopfdruck.
- 41 deutsche Ratgeber vollständig lokal, mit Suche, Rubriken und Merkliste.
- Optionale Offline-Kopie mit iOS Complete File Protection und Geräteauthentifizierung (z. B. Face ID/Gerätecode). Ein Gerätecode muss eingerichtet sein. Kein eigenes zusätzliches Offline-Passwort. Offline-Ansicht wird im Hintergrund gesperrt; die Datei ist vom iCloud-Backup ausgeschlossen.

Checklisten, Live-Spiele, News, ausführliche Kartenbearbeitung, Datenbank-Import und Servereinstellungen werden aus dieser ersten iOS-Version im Safari-Webangebot geöffnet; dort kann eine erneute Anmeldung erforderlich sein. Diese Funktionen sind **noch keine eigenen nativen iOS-Ansichten**. Kein Mehrkarten-Raster, keine garantierte Erkennung jeder Karte, keine lokale OCR und keine neue Verkaufsdaten-API. Scans/Preise benötigen Internet und verbrauchen dasselbe serverseitig begrenzte Kontingent.

## Bauen auf einem Mac

1. Aktuelles Xcode mit iOS SDK installieren (Xcode 16 oder neuer empfohlen).
2. `Sideline.xcodeproj` öffnen, Scheme „Sideline“ auswählen.
3. Zuerst einen iPhone-Simulator wählen und Build ausführen. Alternativ `sh build-simulator.sh`. Das Skript signiert nichts und erzeugt keine verteilbare IPA.
4. Fehler aus Xcode beheben und auf einem echten iPhone Kamera, Ausschnitt und Ausrichtung prüfen. Automatik, Vordergrundwechsel, Login/Logout, Fehlzuordnungen, Varianten, Duplikate und Offline-Sperre ebenfalls testen. Syntaxprüfung allein ersetzt das nicht.
5. Für ein eigenes angeschlossenes iPhone unter Signing & Capabilities ein eigenes Apple-Team auswählen. Bei Bedarf die Bundle-ID `de.fourdoubleu.sideline` eindeutig anpassen. Automatische Signierung verwenden. Kostenlose persönliche Teams haben Apples Installations- und Laufzeitbeschränkungen.
6. Für TestFlight/App Store ist das passende kostenpflichtige Apple-Developer-Konto nötig. Archive erstellen und über den Organizer in App Store Connect hochladen; Datenschutzangaben und tatsächliche Datenflüsse prüfen. Es gibt noch keinen TestFlight- oder App-Store-Link.

Ohne Mac kann später ein Entwickler oder ein Cloud-Mac mit Xcode den Build übernehmen. Apple-Konto/Signierung und die erforderlichen Tests bleiben notwendig. Es wurden keine Zertifikate, Provisioning-Profile oder privaten Signierschlüssel angelegt oder beigelegt.

## Server und Datenschutz

Das aktuelle ALL-INKL-Paket muss auf dem Server liegen. `native-login.php` und `api.php` müssen per HTTPS erreichbar sein. Die Website zuerst einrichten und den Cardsight-Schlüssel dort privat speichern. App-Passwort nicht in Swift-Dateien eintragen.

Beim Scan wird dein zugeschnittenes Foto über deinen Server an Cardsight gesendet. Karten und eigene Fotos werden auf deinem Server gespeichert. Die native Sitzung bleibt im Arbeitsspeicher; das Passwort wird nicht dauerhaft gespeichert. Kein Tracking-SDK. Die PrivacyInfo-Datei beschreibt die verwendeten Systemzugriffe (eigene Einstellungen und Zeitmessung für Scan-Stabilität); sie ersetzt keine Datenschutzerklärung oder App-Store-Datenschutzangaben zu Server und Kartenanbieter.

Die Offline-Kopie gehört nur zu diesem Gerät und ersetzt kein Backup. Vor Deinstallation/Update Sammlung über die Web-App sichern.

## Ergänzung 1.1: Scan+ und Schiedsrichter

Die Trefferprüfung kann sichtbaren Kartentext über den geschützten Gemini-Proxy lesen. Nur per Knopfdruck; dabei geht der Ausschnitt zusätzlich an Google. Abweichende Spielernamen/Nummern müssen vor dem Speichern bestätigt oder im Katalog korrigiert werden. Kein API-Schlüssel im iPhone-Projekt. Einrichtung und Schlüssel bleiben auf dem PHP-Server. Eigene animierte Schiedsrichterdarstellung bei Treffer und Speicherung, mit Rücksicht auf reduzierte Bewegung. Auch diese Erweiterung ist bislang nur syntaktisch und auf Ressourcenebene geprüft, nicht mit Xcode oder auf einem iPhone gebaut/getestet.

## Ergänzung 1.3: automatische Kartenangaben und AI CardVault

Fehlende Karteninformationen werden vor dem Speichern über den geschützten Backend-Adapter vervollständigt. Bestehende Angaben bleiben erhalten; bekannte Abkürzungen werden ausgeschrieben. Bei widersprüchlichem Foto-Text muss die Auswahl geprüft werden. Unverfügbare Fakten bleiben offen. AI CardVault kann das eigene Foto per privatem Upload als zweite Bilderkennung prüfen; Alternativen werden nur nach ausdrücklicher Auswahl übernommen. Keine öffentlichen Foto-URLs und kein automatisches Feedback. Die im Browser erreichbare TheCardAPI-Vergleichsseite liefert ausdrücklich geprüfte Euro-Durchschnitte an die gemeinsame Sammlung. Diese Version ist weiterhin nur ein syntaktisch geprüftes Xcode-Quellprojekt, kein gebautes oder signiertes IPA.
