<?php
declare(strict_types=1);
function pq_card(string $id): array {foreach(read_private('cards',[])as $c)if(($c['id']??'')===$id)return $c;throw new AppError('Karte nicht gefunden.',404);}
function pq_save(array $input): array {
    $image=photo_field($input['image']??'');$back=photo_field($input['backImage']??'');if(($input['requireBack']??false)===true&&$back==='')throw new AppError('Bitte auch die Rückseite aufnehmen.');if(!$image)throw new AppError('Bitte zuerst ein Foto aufnehmen.');
    $token=text_field($input['token']??'',80);if(!preg_match('/^[a-zA-Z0-9-]{16,80}$/D',$token))throw new AppError('Ungültige Aufnahme-ID.');
    return private_transaction('cards',function($rows)use($image,$back,$token){$rows??=[];foreach($rows as $c)if(($c['scan']['captureToken']??'')===$token)return[$rows,$c];if(count($rows)>=1000)throw new AppError('Maximal 1.000 Karten pro Sammlung.');
        $c=validate_card(['player'=>'Neue Karte','image'=>$image,'backImage'=>$back,'sport'=>'Andere','catalogSource'=>'Eigenes Foto']);$c['id']=uuid();$c['createdAt']=$c['updatedAt']=now_iso();$c['scan']=['captureToken'=>$token,'queueState'=>'pending','message'=>'Wird im Hintergrund ergänzt.','attempts'=>0];$rows[]=$c;return[$rows,$c];});
}
function pq_step(string $id,array $config,?callable $identify=null): array {
    $token=bin2hex(random_bytes(16));
    $snapshot=private_transaction('cards',function($rows)use($id,$token){$rows??=[];foreach($rows as &$c)if($c['id']===$id){$s=$c['scan']??[];if(empty($s['localChecked']))throw new AppError('Bitte zuerst den lokalen Checklistenabgleich ausführen.',409);if(!in_array($s['queueState']??'',['pending','processing'],true)||($s['leaseUntil']??0)>time())return[$rows,null];$c['scan']=array_merge($s,['queueState'=>'processing','lease'=>$token,'leaseUntil'=>time()+100]);$copy=$c;unset($c);return[$rows,$copy];}throw new AppError('Karte nicht gefunden.',404);});
    if(!$snapshot)return pq_card($id);
    $state='review';$message='Keine eindeutige Erkennung. Du kannst die Angaben selbst ergänzen.';$proposal=[];$sources=[];$local=[];
    try{
        $r=$identify?$identify($snapshot):pipeline_identify(['image'=>$snapshot['image'],'backImage'=>$snapshot['backImage']??'','segment'=>'auto'],$config);$sources=array_slice($r['providers']??[],0,10);
        $candidates=array_values(array_filter($r['detections']??[],fn($c)=>!empty($c['player'])&&($c['matchLevel']??'')==='card'&&!($c['isAlternative']??false)));
        if(count($candidates)===1&&!empty($snapshot['scan']['localSuggestions'])){$names=array_unique(array_map(fn($s)=>oc_norm($s['card']['player']),$snapshot['scan']['localSuggestions']));if(!in_array(oc_norm($candidates[0]['player']),$names,true)){$sources[]=['name'=>'Spielerabgleich','state'=>'conflict','message'=>'Bildanbieter und gelesener Checklisten-Spieler widersprechen sich. Keine automatische Übernahme.'];$candidates=[];}}
        if(count($candidates)===1){$candidate=$candidates[0];if(isset($candidate['serialNumber']))$candidate['serialNumber']=serial_read($candidate['serialNumber']);if(!preg_match('~^\d{4}(?:[-/]\d{2,4})?$~D',(string)($candidate['year']??'')))unset($candidate['year']);foreach(['cardsightId','cardsightSetId','cardsightReleaseId']as $key)if(!valid_uuid($candidate[$key]??''))unset($candidate[$key]);foreach(['player','year','set','number','serialNumber','team','jerseyNumber','position','cardType','parallel','rarity','grader','grade','certNumber','gradingBarcode','sport','cardsightId','cardsightSetId','cardsightReleaseId','localCatalogId','localSetId','catalogSource']as $k)if(is_string($candidate[$k]??null))$proposal[$k]=$candidate[$k];
            // A provider proposal can be filled automatically, but remains visibly unconfirmed.
            if(($candidate['parallelNeedsReview']??false)||!empty($candidate['isParallelOnly']))$proposal['parallel']='';
            $lookup=oc_route('own-catalog-search',['player'=>$candidate['player'],'year'=>$candidate['year']??'','number'=>$candidate['number']??''],$config);$local=array_slice($lookup['results']??[],0,6);
            if(count($local)===1&&oc_norm($local[0]['set'])===oc_norm($candidate['set']??''))foreach(['team','cardType','localCatalogId','localSetId']as $k)if(empty($proposal[$k])&&!empty($local[0][$k]))$proposal[$k]=$local[0][$k];
            $dupes=array_filter(duplicate_cards($candidate,read_private('cards',[])),fn($row)=>$row['id']!==$id);$message=$dupes?'Bereits im VAULT vorhanden · als eigenes Exemplar gespeichert. Angaben prüfen.':'Angaben automatisch ergänzt · bitte am Foto prüfen.';
        }
        $failed=array_values(array_filter($sources,fn($s)=>($s['state']??'')==='failed'));
        if(!$proposal&&$failed){$state='paused';$message='Erkennung später erneut versuchen. Foto ist gespeichert.';}
    }catch(AppError $e){$state='paused';$message=$e->status===429?'Anbieterlimit erreicht. Foto gespeichert; später erneut prüfen.':'Erkennung derzeit nicht verfügbar. Foto gespeichert; später erneut prüfen.';}
    catch(Throwable $e){$state='paused';$message='Erkennung derzeit nicht verfügbar. Foto bleibt gespeichert.';system_error_report($e,$config);}
    return private_transaction('cards',function($rows)use($id,$token,$snapshot,$state,$message,$proposal,$sources,$local){$rows??=[];foreach($rows as &$c)if($c['id']===$id){if(($c['scan']['lease']??'')!==$token)return[$rows,$c];
        if($c['updatedAt']!==$snapshot['updatedAt']){$state='review';$message='Karte zwischenzeitlich bearbeitet. Deine Angaben bleiben erhalten.';$proposal=[];}
        $patch=[];foreach($proposal as $k=>$v)if($v!==''&&(($c[$k]??'')===''||($k==='player'&&$c[$k]==='Neue Karte')||($k==='sport'&&($c[$k]??'')==='Andere')||($k==='catalogSource'&&($c[$k]??'')==='Eigenes Foto')))$patch[$k]=$v;
        if($patch){try{$validated=validate_card(array_merge($c,$patch));$c=array_merge($c,$validated);$c['updatedAt']=now_iso();}catch(AppError){$state='review';$message='Unvollständiger Vorschlag. Foto gespeichert; Angaben selbst ergänzen.';}}
        if(!$proposal&&!empty($c['scan']['localSuggestions'])){$state='review';$message='Vorschläge aus deiner Checkliste vorhanden. Antippen und am Foto prüfen.';}$c['scan']=array_merge($c['scan'],['queueState'=>$state,'message'=>$message,'attempts'=>($c['scan']['attempts']??0)+1,'leaseUntil'=>0,'lease'=>'','providers'=>$sources,'localMatches'=>$local]);$copy=$c;unset($c);return[$rows,$copy];}throw new AppError('Karte wurde gelöscht.',404);});
}
function pq_retry(string $id): array {return private_transaction('cards',function($rows)use($id){$rows??=[];foreach($rows as &$c)if($c['id']===$id){if(($c['scan']['leaseUntil']??0)>time())throw new AppError('Diese Karte wird bereits geprüft.',409);$c['scan']=array_merge($c['scan']??[],['queueState'=>'pending','message'=>'Erkennung wartet.','leaseUntil'=>0,'localChecked'=>false,'forceRemote'=>true]);$copy=$c;unset($c);return[$rows,$copy];}throw new AppError('Karte nicht gefunden.',404);});}

function pq_excerpt(string $s,int $max): string {preg_match('/^.{0,'.$max.'}/us',$s,$m);return $m[0]??'';}
function pq_name_visible(string $person,string $text): bool {
    $person=oc_norm($person);$short=trim(preg_replace('/\b(?:jr|sr|ii|iii|iv)\b/','',$person)??$person);$short=preg_replace('/\s+/',' ',$short)??$short;
    foreach(array_unique([$person,$short])as $name)if(strlen($name)>4&&str_contains($text,' '.$name.' '))return true;
    $joined=str_replace(' ','',$short);return strlen($joined)>=8&&str_contains($text,' '.$joined.' ');
}
function pq_local_candidates(string $text,bool $partial=false): array {
    $n=' '.oc_norm($text).' ';$numberText=' '.oc_norm(preg_replace('~\b\d{1,6}\s*/\s*\d{1,6}\b~',' ',$text)??$text).' ';if(strlen(trim($n))<8)return [];$families=[];
    $catalog=oc_manifest()['products'];$seed=oc_seed()['products'];foreach($seed as $pid=>$entry)if(($entry['product']['source']??'')==='Degree Grading PDF')$catalog[$pid]=$entry['product'];
    foreach($catalog as $id=>$product){
        $year=substr((string)$product['year'],0,4);$yearRead=preg_match('/(?<!\d)'.preg_quote($year,'/').'(?!\d)/',$n)===1;if(!$partial&&!$yearRead)continue;
        $words=array_values(array_filter(explode(' ',oc_norm($product['name'])),fn($w)=>strlen($w)>2&&!in_array($w,['panini','topps','football','basketball','american','collection','base','mega','box','set','the','and','nfl'],true)&&!ctype_digit_safe($w)));
        if(!$words)continue;$matchedWords=array_filter($words,fn($w)=>preg_match('/(?<![a-z])'.preg_quote($w,'/').'(?![a-z])/',$n)===1);if(!$matchedWords)continue;
        $people=[];foreach($product['players']??[]as $person)if(pq_name_visible($person,$n))$people[$person]=true;if(!$people)continue;
        $fromPdf=($seed[$id]['product']['source']??'')==='Degree Grading PDF';$data=$fromPdf?read_private('nfl-seed/'.$id,$seed[$id]):oc_rows($id);
        foreach($data['rows']??[]as $row){if(!isset($people[oc_norm($row['player'])]))continue;$number=oc_norm(ltrim($row['number'],'#'));$numberRead=$number!==''&&(str_contains($numberText,' '.$number.' ')||str_contains($numberText,' '.str_replace(' ','',$number).' ')||preg_match('/(?:^|\s)(?:no|nr|number|card)\s*'.preg_quote(str_replace(' ','',$number),'/').'(?![a-z0-9])/',$numberText)===1);if(!$partial&&!$numberRead)continue;
            $key=$id.'|'.oc_norm($row['player']).'|'.$number;$score=8+count($matchedWords)*2+($yearRead?8:0)+($numberRead?10:0);
            $families[$key]??=['product'=>$product,'rows'=>[],'variants'=>[],'complete'=>$yearRead&&$numberRead,'yearRead'=>$yearRead,'numberRead'=>$numberRead,'score'=>$score];$families[$key]['rows'][]=$row;
            foreach($data['parallelSections'][$row['sectionId']??'']??[]as $v)$families[$key]['variants'][$v]=$v;
        }
    }
    $result=array_values($families);usort($result,fn($a,$b)=>$b['score']<=>$a['score']?:strcmp($b['product']['year'],$a['product']['year']));return $result;
}
function pq_suggestions(array $families): array {
    $out=[];foreach($families as $f)foreach($f['rows']as $r){$p=$f['product'];$out[]=['reference'=>$p['id'].'|'.$r['id'],'missing'=>array_values(array_filter([!$f['yearRead']?'Jahr nicht gelesen':null,!$f['numberRead']?'Kartennummer nicht gelesen':null])),'card'=>['player'=>$r['player'],'year'=>$p['year'],'set'=>$p['name'].' · '.$r['subset'],'number'=>$r['number'],'parallel'=>'','sport'=>$p['sport']??'American Football','localSetId'=>$p['id'],'localCatalogId'=>$r['id'],'catalogSource'=>$p['source']]];if(count($out)>=12)return $out;}return $out;
}
function ctype_digit_safe(string $value): bool {return preg_match('/^\d+$/D',$value)===1;}
function pq_side_conflict(string $front,string $back): bool {
    if($front===''||$back==='')return false;$names=[];foreach(oc_manifest()['products']as $p)foreach($p['players']??[]as $name)$names[$name]=true;$a=[];$b=[];$f=' '.oc_norm($front).' ';$r=' '.oc_norm($back).' ';foreach($names as $name=>$ignored){if(pq_name_visible($name,$f))$a[]=$name;if(pq_name_visible($name,$r))$b[]=$name;}return $a&&$b&&!array_intersect($a,$b);
}
function pq_local(string $id,string $text,string $version,array $ocr=[]): array {
    $ranked=pq_local_candidates($text,true);$families=array_values(array_filter($ranked,fn($f)=>$f['complete']));$suggestions=pq_suggestions($ranked);$ocrError=is_string($ocr['error']??null)?pq_excerpt($ocr['error'],500):'';$sideConflict=pq_side_conflict(is_string($ocr['front']??null)?pq_excerpt($ocr['front'],8000):'',is_string($ocr['back']??null)?pq_excerpt($ocr['back'],8000):'');if($sideConflict)$families=[];
    return private_transaction('cards',function($rows)use($id,$text,$version,$families,$suggestions,$ocrError,$sideConflict){$rows??=[];foreach($rows as &$c)if($c['id']===$id){
        if(!in_array($c['scan']['queueState']??'',['pending'],true))return[$rows,$c];
        $s=$c['scan'];$s['localChecked']=true;$s['localStatus']=$text===''?'ocr-unavailable':(count($families)===1?'family-match':($suggestions?'candidates-found':'no-unique-match'));$s['localSuggestions']=$suggestions;$s['localDiagnostics']=['text'=>pq_excerpt($text,2000),'error'=>$ocrError,'suggestions'=>count($suggestions)];
        if($c['updatedAt']!==$version){$s['queueState']='review';$s['message']='Zwischenzeitlich bearbeitet. Deine Angaben bleiben erhalten.';}
        elseif(count($families)===1&&!in_array($c['player']??'',['','Neue Karte'],true)&&oc_norm($c['player'])!==oc_norm($families[0]['rows'][0]['player'])){$s['queueState']='review';$s['localStatus']='identity-conflict';$s['message']='Die Checkliste nennt einen anderen Spieler. Bitte den Vorschlag prüfen; bestehende Angaben bleiben erhalten.';}
        elseif(count($families)===1){$family=$families[0];$p=$family['product'];$first=$family['rows'][0];
            $patch=['player'=>$first['player'],'year'=>$p['year'],'set'=>$p['name'],'number'=>$first['number'],'catalogSource'=>$p['source'],'sport'=>$p['sport']??'American Football','localSetId'=>$p['id']];
            if(count($family['rows'])===1){$patch['localCatalogId']=$first['id'];foreach(['team','cardType']as $k)if(!empty($first[$k]))$patch[$k]=$first[$k];}
            foreach($patch as $k=>$v)if($v!==''&&(($c[$k]??'')===''||($k==='player'&&$c[$k]==='Neue Karte')||($k==='sport'&&($c[$k]??'')==='Andere')||($k==='catalogSource'&&($c[$k]??'')==='Eigenes Foto')))$c[$k]=$v;
            // Family text does not establish a parallel; no default Base or invented serial.
            $c['updatedAt']=now_iso();$s['queueState']=!empty($s['forceRemote'])?'pending':'review';$s['message']=!empty($s['forceRemote'])?'Lokaler Abgleich abgeschlossen · weitere Ergänzung läuft.':'Lokal mit deiner Checkliste abgeglichen · Parallelvariante am Foto prüfen.';$s['localVariants']=array_values($family['variants']);$s['localMatchCount']=count($family['rows']);$stamps=[];preg_match_all('~\b\d{1,6}\s*/\s*\d{1,6}\b~',$text,$stamps);$serials=array_values(array_unique(array_filter(array_map('serial_read',$stamps[0]??[]))));if(count($serials)===1&&empty($c['serialNumber']))$c['serialNumber']=$serials[0];
        }
        if($sideConflict){$s['localStatus']='side-conflict';$s['queueState']='review';$s['message']='Vorder- und Rückseite nennen unterschiedliche Spieler. Bitte die beiden Fotos prüfen.';}$c['scan']=$s;$copy=$c;unset($c);return[$rows,$copy];}throw new AppError('Karte nicht gefunden.',404);});
}
