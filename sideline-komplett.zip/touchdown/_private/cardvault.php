<?php
declare(strict_types=1);
function cv_status(array $config): array {
    $s=read_private('cardvault-usage',[]);$used=($s['month']??'')===gmdate('Y-m')?(int)($s['used']??0):0;
    return ['configured'=>!empty($config['externalCardVaultKey']),'used'=>$used,'limit'=>100,'month'=>gmdate('Y-m')];
}
function cv_reserve(): void {
    private_transaction('cardvault-usage',function($s){if(($s['month']??'')!==gmdate('Y-m'))$s=['month'=>gmdate('Y-m'),'used'=>0,'next'=>0];if($s['used']>=100)throw new AppError('Die lokale AI-CardVault-Monatsgrenze von 100 Versuchen ist erreicht.',429);if(($s['next']??0)>microtime(true))throw new AppError('Bitte kurz warten, bevor du AI CardVault erneut startest.',429);$s['used']++;$s['next']=microtime(true)+1;return[$s,null];});
}
function cv_sport(string $hint): string {
    return match(strtolower(trim($hint))){'football','american football','nfl'=>'American Football','basketball','nba'=>'Basketball','baseball','mlb'=>'Baseball','hockey','ice hockey','nhl'=>'Eishockey','soccer','fußball'=>'Fußball','pokemon','pokémon'=>'Pokémon','mtg','magic'=>'Magic: The Gathering',default=>''};
}
function cv_scalar(mixed $v): string {return clean_api_text(is_string($v)||is_int($v)?(string)$v:'');}
function cv_parse(array $reply,string $hint=''): array {
    if(($reply['ok']??null)!==true||!is_array($reply['result']??null))throw new AppError('AI CardVault hat keine gültige Erkennungsantwort geliefert.',502);
    $result=$reply['result'];$card=$result['card']??null;if($card!==null&&!is_array($card))throw new AppError('AI CardVault hat ein unerwartetes Kartenformat geliefert.',502);
    $alternates=$result['alternates']??[];if(!is_array($alternates))$alternates=[];
    $request=cv_scalar($reply['requestId']??'');$ref=cv_scalar($result['referenceId']??'');$reason=cv_scalar($result['reviewReason']??'');
    $map=static function(array $c,mixed $confidence,bool $alternate)use($request,$ref,$result,$hint,$reason):?array{
        $name=cv_scalar($c['name']??'');if($name==='')return null;
        $sport=cv_sport(cv_scalar($c['category']??''));if($sport==='')$sport=cv_sport($hint);
        $score=(is_int($confidence)||is_float($confidence))&&is_finite((float)$confidence)&&$confidence>=0&&$confidence<=1?(float)$confidence:null;
        return ['player'=>$name,'set'=>cv_scalar($c['set']??''),'number'=>cv_scalar($c['number']??''),'year'=>preg_match('~^\d{4}(?:[-/]\d{2,4})?$~D',cv_scalar($c['year']??''))?cv_scalar($c['year']):'','rarity'=>cv_scalar($c['rarity']??''),'language'=>cv_scalar($c['language']??''),'sport'=>$sport?:'Andere','sportNeedsReview'=>$sport==='','cardsightId'=>'','parallel'=>'','catalogSource'=>'AI CardVault','cardVaultRequestId'=>$request,'cardVaultReferenceId'=>$ref,'cardVaultSource'=>cv_scalar($result['source']??''),'providerConfidence'=>$score,'providerNeedsReview'=>($result['needsReview']??true)===true||$alternate,'providerReviewReason'=>$reason,'confidence'=>'Unknown','confidenceKnown'=>false,'matchLevel'=>'card','isAlternative'=>$alternate,'_scanReviewRequired'=>true,'scanRequestId'=>$request];
    };
    $choices=[];if($card!==null){$mapped=$map($card,$result['confidence']??null,false);if($mapped)$choices[]=$mapped;}
    foreach(array_slice($alternates,0,5)as $alt)if(is_array($alt)){$mapped=$map($alt,$alt['confidence']??null,true);if($mapped&&!array_filter($choices,fn($c)=>[$c['player'],$c['set'],$c['number']]==[$mapped['player'],$mapped['set'],$mapped['number']]))$choices[]=$mapped;}
    if($choices){$first=array_shift($choices);$first['alternatives']=$choices;$choices=[$first];}
    return ['detections'=>$choices,'needsReview'=>($result['needsReview']??true)===true||$card===null,'reviewReason'=>$reason,'notice'=>'AI CardVault liefert Vorschläge, keine sichere Identitäts- oder Echtheitsbestätigung. Unsichere Alternativen und Varianten vor dem Speichern selbst prüfen. Planabhängige Anbieter-Schätzpreise werden nicht als bestätigte eBay-Verkaufspreise übernommen.'];
}
function cv_identify(array $input,array $config,?callable $transport=null): array {
    if(empty($config['externalCardVaultKey']))throw new AppError('Bitte den AI-CardVault-Schlüssel in den Einstellungen hinterlegen.',503);
    $photo=photo_field($input['image']??'');if(!$photo)throw new AppError('Bitte zuerst eine Karte fotografieren.');
    preg_match('~^data:(image/[^;]+);base64,(.+)$~D',$photo,$parts);$bytes=base64_decode($parts[2],true);
    $hint=text_field($input['sport']??$input['segment']??'',80);if($hint==='auto'||$hint==='Andere')$hint='';$hint=cv_sport($hint)?:$hint;
    $form=[];if($hint!=='')$form['sport']=$hint;
    $language=$input['language']??'';if(in_array($language,['en','ja','ko','zh','de','fr','es','it','pt'],true))$form['language']=$language;
    cv_reserve();
    if($transport!==null)$reply=$transport($bytes,$parts[1],$form,photo_field($input['backImage']??''));
    else{
        if(!function_exists('curl_init')||!class_exists('CURLStringFile'))throw new AppError('AI CardVault benötigt PHP 8.1 oder neuer mit cURL.',503);
        $form['front']=new CURLStringFile($bytes,'card.'.($parts[1]==='image/png'?'png':($parts[1]==='image/webp'?'webp':'jpg')),$parts[1]);
        $back=photo_field($input['backImage']??'');if($back&&preg_match('~^data:(image/[^;]+);base64,(.+)$~D',$back,$b))$form['back']=new CURLStringFile(base64_decode($b[2],true),'back.'.($b[1]==='image/png'?'png':($b[1]==='image/webp'?'webp':'jpg')),$b[1]);
        $ch=curl_init('https://aicardvault.io/api/v1/identify');$raw='';
        curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$form,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$config['externalCardVaultKey'],'Accept: application/json'],CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>provider_http_timeout(35),CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_WRITEFUNCTION=>static function($ch,$chunk)use(&$raw){if(strlen($raw)+strlen($chunk)>1000000)return 0;$raw.=$chunk;return strlen($chunk);}]);
        $ok=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);
        if($ok===false)throw new AppError('AI CardVault ist nicht erreichbar oder hat zu lange gebraucht. Vorhandene Vorschläge bleiben erhalten.',502);
        if($status<200||$status>=300)throw new AppError(match($status){401,403=>'AI CardVault hat den Zugang abgelehnt. Bitte Schlüssel und Tarif im Dashboard prüfen.',429=>'Das AI-CardVault-Anfragelimit ist erreicht.',400,422=>'AI CardVault konnte das Foto oder die Hinweise nicht verarbeiten.',default=>'AI CardVault ist momentan nicht verfügbar.'},$status===429?429:502);
        try{$reply=json_decode($raw,true,64,JSON_THROW_ON_ERROR);}catch(JsonException){throw new AppError('AI CardVault hat kein gültiges JSON geliefert.',502);}
    }
    if(!is_array($reply))throw new AppError('Ungültige AI-CardVault-Antwort.',502);
    return array_merge(cv_parse($reply,$hint),['usage'=>cv_status($config)]);
}
