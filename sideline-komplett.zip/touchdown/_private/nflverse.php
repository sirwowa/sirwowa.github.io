<?php
declare(strict_types=1);

// Only season-level public roster facts are used. No current-roster substitution.
function nv_name(string $value): string {
    $value=preg_replace('/\b(?:jr\.?|sr\.?|ii|iii|iv)\b/iu','',$value)??$value;
    return sleeper_name($value);
}
function nv_data(): array { static $data=null;return $data??=read_private('nflverse-data',[]); }
function nv_status(): array {
    $d=nv_data();$counts=[];foreach($d['seasons']??[]as $year=>$season)if(!empty($season['rows']))$counts[(string)$year]=count($season['rows']);
    return ['provider'=>'nflverse','seasons'=>$counts,'fetchedAt'=>$d['fetchedAt']??null,'source'=>'https://github.com/nflverse/nflverse-data','dictionary'=>'https://nflreadr.nflverse.com/articles/dictionary_rosters.html'];
}
function nv_match(array $card,?array $data=null): array {
    if(!in_array(strtolower(trim($card['sport']??'')),['american football','football','nfl'],true))return ['status'=>'unsupported','fields'=>[]];
    $year=(int)substr($card['year']??'',0,4);$name=nv_name($card['player']??'');
    if(!$name||$year<1920||$year>2100)return ['status'=>'missing-context','fields'=>[],'message'=>'Für NFLverse werden Spielername und Kartenjahr benötigt.'];
    $data??=nv_data();$seasons=$data['seasons']??[];$team=trim($card['team']??'');$teamKey=nv_name(sleeper_full_team($team,'nfl'));
    $select=static function(array $rows)use($name,$teamKey):array{
        $rows=array_values(array_filter($rows,fn($p)=>in_array($name,[nv_name($p['name']??''),nv_name($p['alias']??'')],true)));
        if($teamKey!=='')$rows=array_values(array_filter($rows,fn($p)=>nv_name(sleeper_full_team($p['team']??'','nfl'))===$teamKey));
        return $rows;
    };
    $rows=$select($seasons[$year]['rows']??[]);$sourceYear=$year;
    // A retired player may have a later card. Historical fallback requires the card's
    // known team; never pick his final/current team just because the name agrees.
    if(!$rows&&$teamKey!==''){
        $years=array_keys($seasons);rsort($years,SORT_NUMERIC);
        foreach($years as $candidateYear){if((int)$candidateYear>=$year)continue;$found=$select($seasons[$candidateYear]['rows']??[]);if($found){$rows=$found;$sourceYear=(int)$candidateYear;break;}}
    }
    if(!$rows)return ['status'=>'not-found','fields'=>[],'message'=>'Kein eindeutiger NFLverse-Kader zum Spieler und Kartenjahr/Team gefunden.'];
    $ids=array_unique(array_map(fn($p)=>($p['id']??'')?:nv_name($p['name']??''),$rows));
    if(count($ids)!==1)return ['status'=>'ambiguous','fields'=>[],'message'=>'Mehrere NFL-Spieler mit diesem Namen. Verein auf der Karte prüfen.'];
    $fields=[];
    foreach(['team','jerseyNumber','position']as $field){
        $values=[];foreach($rows as $r){$v=trim((string)($r[$field]??''));
            if($field==='team'){$v=sleeper_full_team($v,'nfl');if(in_array($v,['Free Agent','FA',''],true))continue;}
            if($field==='position')$v=sleeper_full_position($v);
            if($field==='jerseyNumber'){if(!is_numeric($v)||(float)$v!==(float)(int)$v||(int)$v<0||(int)$v>99)continue;$v=(string)(int)$v;}
            if($v!=='')$values[$v]=true;
        }
        if(count($values)===1)$fields[$field]=(string)array_key_first($values);
    }
    return ['status'=>'matched','fields'=>$fields,'season'=>$sourceYear,'source'=>'nflverse · Saison '.$sourceYear.($sourceYear!==$year?' · historischer Teamabgleich':''),'sourceUrl'=>$seasons[$sourceYear]['source']??'https://github.com/nflverse/nflverse-data'];
}
function nv_team_known(string $team): bool {
    static $teams=null;if($teams===null){$teams=[];foreach(nv_data()['seasons']??[]as $season)foreach($season['rows']??[]as $r){$name=sleeper_full_team($r['team']??'','nfl');if($name!==''&&$name!=='Free Agent')$teams[nv_name($name)]=true;}}
    return isset($teams[nv_name(sleeper_full_team($team,'nfl'))]);
}
