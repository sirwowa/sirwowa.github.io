<?php
declare(strict_types=1);
// Sideline PHP adaptation of Cardloader CSV interoperability. Cardloader: Apache-2.0.
// Modified 2026-11-01: web review sessions, explicit VAULT import, no native filesystem/scanner access.
function cl_header(string $s): string {$ascii=function_exists('iconv')?iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s):$s;return preg_replace('/[^a-z0-9]/','',strtolower($ascii?:$s))??'';}
function cl_parse(string $csv): array {
    if(strlen($csv)>2000000||preg_match('//u',$csv)!==1)throw new AppError('CSV bitte als UTF-8 mit maximal 2 MB hochladen.');$csv=preg_replace('/^\xEF\xBB\xBF/','',$csv)??$csv;
    $separator=',';$best=0;foreach([',',';',"\t"]as $sep){$n=count(str_getcsv(strtok($csv,"\r\n")?:'',$sep,'"',''));if($n>$best){$best=$n;$separator=$sep;}}
    $h=fopen('php://temp','r+');fwrite($h,$csv);rewind($h);$header=fgetcsv($h,0,$separator,'"','');if(!$header||$best<2)throw new AppError('CSV-Kopfzeile mit mindestens zwei Spalten erforderlich.');$header=array_map('cl_header',$header);$rows=[];$skipped=0;
    while(($line=fgetcsv($h,0,$separator,'"',''))!==false){if(count($rows)+$skipped>=500)throw new AppError('Pro Importsitzung sind höchstens 500 CSV-Zeilen möglich.');if(count($line)>100)throw new AppError('Zu viele CSV-Spalten.');$get=function(array $names)use($header,$line){foreach($names as $name){$i=array_search($name,$header,true);if($i!==false&&trim((string)($line[$i]??''))!=='')return text_field(trim((string)$line[$i]),4000);}return '';};
        $player=$get(['player','name','cardname','fullname','spieler']);if($player===''){$skipped++;continue;}
        $sport=$get(['sport','category','subcategory','game']);if($sport==='')$sport='American Football';$sport=sport_name($sport);$set=$get(['setname','set','expansion','edition']);$series=$get(['series','subset']);if($series!==''&&am_norm($series)!==am_norm($set))$set=trim($set.' · '.$series,' ·');
        $notes=$get(['notes','note','comment','comments','notizen']);$location=$get(['location','storage','box','binder','lagerort']);$usd=$get(['priceusd']);$eur=$get(['priceeur']);if($usd!==''||$eur!=='')$notes=trim($notes."\nImportierter Fremdpreis (ungeprüft): ".($eur!==''?$eur.' EUR':$usd.' USD').'. Kein bestätigter Marktpreis.');if($location!=='')$notes=trim($notes."\nLagerort: ".$location);
        $card=['player'=>$player,'set'=>$set,'number'=>$get(['cardnumber','number','no','collectornumber','kartennummer']),'year'=>$get(['year','releaseyear','jahr']),'sport'=>$sport,'parallel'=>$get(['parallel','variant','variante']),'serialNumber'=>$get(['serialnumber','seriennummer','nummerierung']),'grader'=>$get(['slabcompany','grader']),'grade'=>$get(['slabgrade']),'certNumber'=>$get(['slabcertificate','certnumber']),'notes'=>$notes,'quantity'=>1,'catalogSource'=>'Cardloader CSV'];$quantity=$get(['quantity','anzahl']);if($quantity!==''){if(!ctype_digit($quantity))throw new AppError('Ungültige Anzahl in CSV.');$card['quantity']=(int)$quantity;}
        $condition=$get(['condition','zustand']);if(in_array($condition,['Unbewertet','Mint','Near Mint','Excellent','Good','Fair'],true))$card['condition']=$condition;
        $card=validate_card($card);$path=$get(['front','frontpath','image','imagepath','photo','picture']);$name=basename(str_replace('\\','/',$path));$rows[]=['index'=>count($rows),'state'=>'review','card'=>$card,'imageName'=>$name,'sourcePriceImported'=>$usd!==''||$eur!==''];
    }fclose($h);if(!$rows)throw new AppError('Keine benannten Karten gefunden. Reine Dateipfad-Zeilen benötigen die separate Desktop-Erkennung.');return ['rows'=>$rows,'skipped'=>$skipped,'separator'=>$separator==="\t"?'Tab':$separator];
}
function cl_sessions(): array {return read_private('cardloader-sessions',[]);}
function cl_route(string $route,array $input=[]): array {
    if($route==='cardloader-sessions')return ['sessions'=>array_values(array_map(fn($s)=>['id'=>$s['id'],'name'=>$s['name'],'createdAt'=>$s['createdAt'],'count'=>count($s['rows']),'imported'=>count(array_filter($s['rows'],fn($r)=>$r['state']==='imported'))],cl_sessions()))];
    if($route==='cardloader-create'){$parsed=cl_parse(text_field($input['csv']??'',2000000));$session=array_merge($parsed,['id'=>uuid(),'name'=>text_field($input['name']??'Cardloader-Import',200),'createdAt'=>now_iso()]);private_transaction('cardloader-sessions',function($all)use($session){$all=is_array($all)?$all:[];if(count($all)>=20)throw new AppError('Maximal 20 Importsitzungen. Bitte eine alte Sitzung entfernen; VAULT-Karten bleiben erhalten.',409);$all[$session['id']]=$session;return[$all,null];});return $session;}
    $id=text_field($input['id']??'',80);$session=cl_sessions()[$id]??null;if(!$session)throw new AppError('Importsitzung nicht gefunden.',404);
    if($route==='cardloader-session')return $session;
    if($route==='cardloader-delete')return private_transaction('cardloader-sessions',function($all)use($id){unset($all[$id]);return[$all,['ok'=>true]];});
    if($route==='cardloader-import-row'){
        if(($input['confirmed']??false)!==true)throw new AppError('Bitte die ausgewählten Karten zuerst selbst prüfen und bestätigen.',409);$index=$input['index']??null;if(!is_int($index)||$index<0)throw new AppError('Ungültige Zeile.');$image=photo_field($input['image']??'');
        return private_transaction('cardloader-sessions',function($all)use($id,$index,$image){$row=$all[$id]['rows'][$index]??null;if(!$row)throw new AppError('Zeile nicht gefunden.',404);if($row['state']==='imported')return[$all,['cardId'=>$row['cardId'],'alreadyImported'=>true]];
            $card=$row['card'];$card['image']=$image;$card['id']='cl-'.substr(hash('sha256',$id.'|'.$index),0,32);$card['createdAt']=$card['updatedAt']=now_iso();
            $result=private_transaction('cards',function($rows)use($card){$rows??=[];foreach($rows as $r)if($r['id']===$card['id'])return[$rows,['cardId'=>$r['id'],'alreadyImported'=>true]];if(duplicate_cards($card,$rows))return[$rows,['duplicate'=>true]];$rows[]=$card;return[$rows,['cardId'=>$card['id']]];});
            if(empty($result['duplicate'])){$all[$id]['rows'][$index]['state']='imported';$all[$id]['rows'][$index]['cardId']=$result['cardId'];}return[$all,$result];
        });
    }throw new AppError('Unbekannte Cardloader-Funktion.',404);
}
function cl_export(): string {
    $h=fopen('php://temp','r+');fwrite($h,"\xEF\xBB\xBF");$keys=['name','set_name','card_number','year','sport','parallel','serial_number','quantity','condition','slab_company','slab_grade','slab_certificate','notes'];fputcsv($h,$keys,',','"','');foreach(read_private('cards',[])as $c){$vals=array_map(fn($k)=>(string)($c[$k]??''),['player','set','number','year','sport','parallel','serialNumber','quantity','condition','grader','grade','certNumber','notes']);$vals=array_map(fn($v)=>preg_match('/^[=+@\-\t\r]/',$v)?"'".$v:$v,$vals);fputcsv($h,$vals,',','"','');}rewind($h);$csv=stream_get_contents($h);fclose($h);return $csv;
}
