<?php
declare(strict_types=1);
function sport_name(string $name): string {
    return ['Football'=>'American Football','Soccer'=>'Fußball','Hockey'=>'Eishockey','Ice Hockey'=>'Eishockey','Boxing'=>'Boxen','Wrestling'=>'Wrestling','Racing'=>'Motorsport','Motorsports'=>'Motorsport'][$name]??$name;
}
function supported_segments(string $key): array {
    $cache=read_private('segments-cache');
    if($cache&&$cache['expires']>time())return $cache['segments'];
    $segments=[];$skip=0;
    do{
        $response=cardsight_request('/v1/catalog/segments?'.http_build_query(['take'=>100,'skip'=>$skip,'is_identifiable'=>'true']),$key);
        if(!isset($response['segments'])||!is_array($response['segments']))throw new AppError('Die Sportartenliste konnte nicht geladen werden.',502);
        foreach($response['segments']as $s)if(!empty($s['is_identifiable']))$segments[]=['id'=>$s['id'],'name'=>sport_name(clean_api_text($s['name'])),'providerName'=>clean_api_text($s['name']),'shortname'=>clean_api_text($s['shortname']??'')];
        $skip+=100;
    }while($skip<(int)($response['total_count']??0)&&$skip<1000);
    private_transaction('segments-cache',fn($old)=>[['expires'=>time()+21600,'segments'=>$segments],null]);
    return $segments;
}
function detection_sport(array $card,string $segment,array $segments): array {
    $id=$card['segmentId']??'';
    foreach($segments as $s)if(($id&&$s['id']===$id)||($segment!=='auto'&&($s['id']===$segment||strcasecmp($s['shortname'],$segment)===0)))return ['sport'=>$s['name'],'sportNeedsReview'=>false];
    $known=['football'=>'American Football','basketball'=>'Basketball','baseball'=>'Baseball','hockey'=>'Eishockey','soccer'=>'Fußball','mma'=>'MMA'];
    foreach([$card['segmentName']??'',$card['sport']??'',$card['segmentId']??'']as $hint){$hint=strtolower(trim((string)$hint));$alias=['american football'=>'American Football','nfl'=>'American Football','nba'=>'Basketball']+$known;if(isset($alias[$hint]))return ['sport'=>$alias[$hint],'sportNeedsReview'=>false];}
    return ['sport'=>$known[$segment]??'Andere','sportNeedsReview'=>!isset($known[$segment])];
}

// Preserve provider alternatives. A confidence tier never verifies a player's identity.
function reviewed_detections(array $reply,string $segment,array $segments,array $existing): array {
    $result=[];
    foreach(array_slice($reply['detections']??[],0,10) as $d){
        if(!is_array($d)||!is_array($d['card']??null))continue;
        $card=$d['card'];$mapped=array_merge(map_detection($d,$segment),detection_sport($card,$segment,$segments));
        $mapped=expand_player_fields($mapped);$mapped['_scanReviewRequired']=true;$mapped['scanRequestId']=clean_api_text($reply['requestId']??'');$mapped['alternatives']=[];
        $seen=[$mapped['cardsightId']=>true];
        foreach(array_slice($card['suggestions']??[],0,8) as $alternative){
            if(!is_array($alternative)||!valid_uuid($alternative['id']??'')||isset($seen[$alternative['id']]))continue;
            $seen[$alternative['id']]=true;
            $candidate=array_merge(map_detection(['card'=>$alternative,'grading'=>$d['grading']??[],'confidence'=>'Low'],$segment),detection_sport($alternative,$segment,$segments));
            $candidate=expand_player_fields($candidate);$candidate['confidence']='Unknown';$candidate['confidenceKnown']=false;$candidate['_scanReviewRequired']=true;$candidate['scanRequestId']=$mapped['scanRequestId'];$candidate['parallelNeedsReview']=true;$candidate['isAlternative']=true;
            $candidate['duplicates']=duplicate_summaries(duplicate_cards($candidate,$existing));$mapped['alternatives'][]=$candidate;
        }
        $mapped['duplicates']=duplicate_summaries(duplicate_cards($mapped,$existing));if($mapped['matchLevel']!=='none')$result[]=$mapped;
    }
    return $result;
}
