<?php
declare(strict_types=1);
function eb_status(array $c): array {$u=read_private('ebay-search-usage',[]);return ['configured'=>!empty($c['ebayClientId'])&&!empty($c['ebayClientSecret']),'used'=>($u['day']??'')===gmdate('Y-m-d')?(int)($u['used']??0):0,'limit'=>300];}
function eb_reserve(): void {private_transaction('ebay-search-usage',function($s){if(($s['day']??'')!==gmdate('Y-m-d'))$s=['day'=>gmdate('Y-m-d'),'used'=>0];if($s['used']>=300)throw new AppError('Die lokale Grenze von 300 eBay-Such-/Detailabfragen pro UTC-Tag ist erreicht.',429);$s['used']++;return[$s,null];});}
function eb_http(string $path,array $c,?array $form=null,string $token=''): array {
    if(!function_exists('curl_init'))throw new AppError('PHP-cURL fehlt.',503);$ch=curl_init('https://api.ebay.com'.$path);$raw='';
    $headers=$form!==null?['Authorization: Basic '.base64_encode($c['ebayClientId'].':'.$c['ebayClientSecret']),'Content-Type: application/x-www-form-urlencoded']:['Authorization: Bearer '.$token,'X-EBAY-C-MARKETPLACE-ID: EBAY_US','Accept-Language: en-US'];
    $opts=[CURLOPT_HTTPHEADER=>$headers,CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_TIMEOUT=>function_exists('provider_http_timeout')?provider_http_timeout(20):20,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_WRITEFUNCTION=>static function($ch,$part)use(&$raw){if(strlen($raw)+strlen($part)>1000000)return 0;$raw.=$part;return strlen($part);}];if($form!==null){$opts[CURLOPT_POST]=true;$opts[CURLOPT_POSTFIELDS]=http_build_query($form);}if(defined('CURLOPT_PROTOCOLS_STR'))$opts[constant('CURLOPT_PROTOCOLS_STR')]='https';curl_setopt_array($ch,$opts);$ok=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
    if($ok===false||$status<200||$status>=300)throw new AppError('eBay-Suche nicht verfügbar (HTTP '.$status.'). Produktionsschlüssel, Browse-API-Freigabe und Kontingent prüfen.',502,['ebayStatus'=>$status]);try{$r=json_decode($raw,true,40,JSON_THROW_ON_ERROR);}catch(JsonException){throw new AppError('eBay hat keine lesbare Antwort geliefert.',502);}if(!is_array($r))throw new AppError('Unerwartete eBay-Antwort.',502);return $r;
}
function eb_token(array $c): string {
    $hash=hash('sha256',$c['ebayClientId'].'|'.$c['ebayClientSecret']);$s=read_private('ebay-browse-token',[]);if(($s['keyHash']??'')===$hash&&($s['expires']??0)>time()&&is_string($s['token']??null))return $s['token'];
    $r=eb_http('/identity/v1/oauth2/token',$c,['grant_type'=>'client_credentials','scope'=>'https://api.ebay.com/oauth/api_scope']);if(!is_string($r['access_token']??null)||!is_numeric($r['expires_in']??null)||$r['expires_in']<=120)throw new AppError('eBay hat kein gültiges Zugriffstoken geliefert.',502);private_transaction('ebay-browse-token',fn($old)=>[['keyHash'=>$hash,'token'=>$r['access_token'],'expires'=>time()+min(7200,(int)$r['expires_in'])-90],null]);return $r['access_token'];
}
function eb_authorized(string $path,array $c,?callable $http=null,?callable $getToken=null): array {
    $send=$http??fn($p,$token)=>eb_http($p,$c,null,$token);$token=$getToken??fn()=>eb_token($c);
    try{return $send($path,$token());}catch(AppError $e){if(($e->details['ebayStatus']??0)!==401)throw $e;}
    private_transaction('ebay-browse-token',fn()=>[[],null]);return $send($path,$token());
}
function eb_request(string $path,array $c,?callable $transport=null): array {if(!eb_status($c)['configured'])throw new AppError('Bitte eBay-Produktionsschlüssel in den Einstellungen hinterlegen.',503);eb_reserve();return $transport?$transport($path):eb_authorized($path,$c);}
function eb_url(mixed $url,bool $image=false): string {if(!is_string($url)||strlen($url)>2000)return '';$p=parse_url($url);$h=strtolower($p['host']??'');if(($p['scheme']??'')!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['port']))return '';return ($image?($h==='ebayimg.com'||str_ends_with($h,'.ebayimg.com')):in_array($h,['www.ebay.com','ebay.com','www.ebay.de','ebay.de','www.ebay.co.uk','ebay.co.uk'],true))?$url:'';}
function eb_seed(mixed $raw): array {$out=[];if(!is_array($raw))return $out;foreach(['player','year','set','number','parallel','serialNumber','sport']as $f)$out[$f]=text_field($raw[$f]??'');return $out;}
function eb_query(array $seed): string {$parts=[];foreach(['player','year','set','number','parallel']as $f){$s=trim(preg_replace('/[^\p{L}\p{N}\s-]/u',' ',$seed[$f]??'')??'');if($s!=='')$parts[]=$s;}return mb_safe_cut(implode(' ',$parts),180);}
function eb_search(array $input,array $c,?callable $transport=null): array {
    $seed=eb_seed($input['seed']??[]);$query=trim(text_field($input['query']??'',180));if($query===''&&((!empty($seed['player'])&&(!empty($seed['set'])||!empty($seed['number'])))||(!empty($seed['set'])&&!empty($seed['number'])&&!empty($seed['year']))))$query=eb_query($seed);
    if(strlen($query)<4||count(array_filter(preg_split('/\s+/u',$query)))<2)return ['items'=>[],'query'=>$query,'notice'=>'Keine ausreichenden Kartenmerkmale lesbar. Suchtext ergänzen, z. B. Spieler, Jahr, Set und Kartennummer. Es wurde keine eBay-Abfrage gesendet.'];
    $reply=eb_request('/buy/browse/v1/item_summary/search?'.http_build_query(['q'=>$query,'limit'=>8]),$c,$transport);$items=[];
    foreach(array_slice($reply['itemSummaries']??[],0,8)as $r){if(!is_array($r)||!is_string($r['itemId']??null)||!preg_match('/^[A-Za-z0-9_|-]{1,100}$/D',$r['itemId']))continue;$items[]=['id'=>$r['itemId'],'title'=>clean_api_text($r['title']??''),'image'=>eb_url($r['image']['imageUrl']??'',true),'url'=>eb_url($r['itemWebUrl']??'')];}
    $token=bin2hex(random_bytes(16));private_transaction('ebay-fallback-searches',function($all)use($token,$items,$seed){$all=is_array($all)?$all:[];$all=array_filter($all,fn($s)=>($s['expires']??0)>time());$all[$token]=['expires'=>time()+900,'items'=>$items,'seed'=>$seed];return[array_slice($all,-20,null,true),null];});return ['items'=>$items,'token'=>$token,'query'=>$query,'notice'=>'Letzte Rückfallsuche: eBay-Angebote sind unbestätigte Vorschläge, keine Fotoidentifikation. Angebotsbilder und Verkäuferangaben können falsch sein. Angebotspreise werden nicht übernommen.'];
}
function eb_select(array $input,array $c,?callable $transport=null): array {
    $token=text_field($input['token']??'',32);$id=text_field($input['id']??'',100);$s=read_private('ebay-fallback-searches',[])[$token]??null;if(!$s||($s['expires']??0)<=time())throw new AppError('eBay-Suche abgelaufen. Bitte erneut suchen.',409);$hits=array_values(array_filter($s['items'],fn($r)=>$r['id']===$id));if(count($hits)!==1)throw new AppError('Dieses Angebot gehört nicht zur aktuellen Suche.',409);
    $detail=eb_request('/buy/browse/v1/item/'.rawurlencode($id),$c,$transport);if(($detail['itemId']??'')!==$id)throw new AppError('eBay hat ein anderes Angebot geliefert.',502);$aspects=[];foreach($detail['localizedAspects']??[]as $a)if(is_array($a))$aspects[normalized(clean_api_text($a['name']??''))]=clean_api_text($a['value']??'');
    $get=function(array $names)use($aspects){foreach($names as $name)if(!empty($aspects[normalized($name)]))return $aspects[normalized($name)];return '';};$fields=['player'=>$get(['Player/Athlete','Player','Athlete','Spieler/Sportler']),'year'=>$get(['Year Manufactured','Year','Herstellungsjahr']),'set'=>$get(['Set','Card Set']),'number'=>$get(['Card Number','Kartennummer']),'parallel'=>$get(['Parallel/Variety','Parallel','Variante']),'sport'=>$get(['Sport','Sportart'])];$warnings=[];
    foreach($fields as $k=>$v){$old=$s['seed'][$k]??'';if($old!==''&&$v!==''&&normalized($old)!==normalized($v))$warnings[]='Abweichende Angabe bei '.$k.': Foto-/Suchvorschlag und Verkäufer stimmen nicht überein.';if($v==='')$fields[$k]=$old;}
    $fields['serialNumber']=$s['seed']['serialNumber']??'';$fields['sport']=cv_sport($fields['sport'])?:'Andere';$fields=array_merge($fields,['cardsightId'=>'','catalogSource'=>'eBay','matchLevel'=>'card','confidence'=>'Unknown','confidenceKnown'=>false,'_scanReviewRequired'=>true,'parallelNeedsReview'=>true,'sportNeedsReview'=>$fields['sport']==='Andere','notes'=>'Unbestätigter eBay-Vergleich: '.$hits[0]['title'].' '.$hits[0]['url'],'_metadataWarnings'=>$warnings]);return ['card'=>$fields,'offer'=>$hits[0],'warnings'=>$warnings];
}

function eb_variant_key(string $s): string {return str_replace(['rookies','retros'],['rookie','retro'],am_norm($s));}
function eb_set_key(string $s): string {$s=am_norm($s);$s=preg_replace('/\b(?:19|20)\d{2}\b/',' ',$s)??'';$s=preg_replace('/\b(?:panini|topps|football|american|basketball|nfl|nba|trading|cards|card)\b/',' ',$s)??'';return trim(preg_replace('/\s+/',' ',$s)??'');}
// Browse exposes active asking prices, never completed sales. Keep the price kind explicit.
function eb_offer_matches(array $item,array $card): bool {
    if(!in_array('FIXED_PRICE',$item['buyingOptions']??[],true))return false;
    $title=clean_api_text($item['title']??'');
    if(preg_match('/\b(lot|bundle|bulk|sealed|booster|packs?|reprint|replica|digital)\b/i',$title))return false;
    foreach($item['estimatedAvailabilities']??[]as $availability)if(($availability['minimumOrderQuantity']??1)>1)return false;
    $a=[];foreach($item['localizedAspects']??[]as $aspect)if(is_array($aspect))$a[am_norm(clean_api_text($aspect['name']??''))]=clean_api_text($aspect['value']??'');
    $get=static function(array $names)use($a): string {foreach($names as $n)if(isset($a[am_norm($n)]))return $a[am_norm($n)];return '';};
    $fields=['player'=>$get(['Player/Athlete','Player','Athlete','Spieler/Sportler']),'year'=>$get(['Year Manufactured','Year','Herstellungsjahr']),'number'=>$get(['Card Number','Kartennummer'])];
    foreach($fields as $k=>$v)if($v===''||empty($card[$k])||am_norm($v)!==am_norm($card[$k]))return false;
    $parts=preg_split('/[·|]/u',$card['set']??'');$wantedSet=eb_set_key($parts[0]??'');$listingSet=eb_set_key($get(['Set','Card Set']));if($wantedSet===''||$listingSet!==$wantedSet)return false;
    $insert=eb_variant_key($get(['Insert Set','Insert','Unterset','Subset']));$var=eb_variant_key($get(['Parallel/Variety','Parallel','Variante']));
    $wantedInsert=eb_variant_key(implode(' ',array_slice($parts,1)));if(in_array($wantedInsert,['base','base set','standard'],true))$wantedInsert='';
    $wantedVariant=eb_variant_key($card['parallel']??'');
    if($wantedInsert!==''&&$insert!==$wantedInsert&&$var!==$wantedInsert)return false;
    if($wantedVariant!==''){
        if($var!==$wantedVariant){if($insert!==$wantedVariant||!in_array($var,['base','base set','standard'],true))return false;}
    }else if(!in_array($var,['base','base set','standard'],true))return false;
    $grader=$get(['Professional Grader','Grading Company','Grader']);$grade=$get(['Grade']);
    if(!empty($card['grader'])){if(am_norm($grader)!==am_norm($card['grader'])||$grade===''||am_norm($grade)!==am_norm($card['grade']??''))return false;}
    elseif(($grader!==''&&!in_array(am_norm($grader),['not graded','ungraded'],true))||($grade!==''&&!in_array(am_norm($grade),['not graded','ungraded'],true))||preg_match('/\b(PSA|BGS|SGC|CGC|graded)\b/i',$title))return false;
    $serial=$card['serialNumber']??'';
    if($serial!==''){$run=explode('/',$serial)[1]??'';$supply=$get(['Print Run','Auflage']);if($run===''||!preg_match('/^\d+$/D',$run)||!preg_match('/^\d+$/D',$supply)||(int)$run!==(int)$supply)return false;}
    return true;
}
function eb_offer_market(array $card,array $config,?callable $transport=null,?callable $fx=null): ?array {
    foreach(['player','year','set','number']as $k)if(empty($card[$k]))return null;
    $query=eb_query($card);$reply=eb_request('/buy/browse/v1/item_summary/search?'.http_build_query(['q'=>$query,'limit'=>5,'filter'=>'buyingOptions:{FIXED_PRICE}']),$config,$transport);
    $matches=[];$seen=[];$rates=[];$warnings=[];$failed=0;
    foreach(array_slice($reply['itemSummaries']??[],0,5)as $r){
        $id=$r['itemId']??'';if(!is_string($id)||!preg_match('/^[A-Za-z0-9_|-]{1,100}$/D',$id))continue;
        $legacy=explode('|',$id)[1]??$id;if(isset($seen[$legacy]))continue;$seen[$legacy]=true;
        try{$item=eb_request('/buy/browse/v1/item/'.rawurlencode($id),$config,$transport);}catch(AppError $e){if(!$matches)throw $e;$failed++;break;}
        if(($item['itemId']??'')!==$id||!eb_offer_matches($item,$card))continue;
        $price=$item['price']['value']??null;$currency=strtoupper((string)($item['price']['currency']??''));
        if(!is_numeric($price)||!is_finite((float)$price)||(float)$price<=0||!in_array($currency,['EUR','USD','GBP','CAD','AUD','JPY','CHF','CNY','HKD','SGD','NZD'],true))continue;
        $url=eb_url($item['itemWebUrl']??'');if($url==='')continue;
        $rates[$currency]??=$fx?$fx($currency):tca_fx($currency);$rate=$rates[$currency]['rate']??null;if(!is_numeric($rate)||!is_finite((float)$rate)||$rate<=0)throw new AppError('Kein gültiger Euro-Wechselkurs für eBay-Angebote.',502);
        $matches[]=['id'=>$id,'url'=>$url,'title'=>clean_api_text($item['title']??''),'price'=>(float)$price,'currency'=>$currency,'eur'=>(float)$price*(float)$rate];
    }
    if(!$matches)return null;
    if($failed)$warnings[]='Weitere eBay-Angebote konnten nicht geprüft werden. Der Durchschnitt umfasst nur die erfolgreich geprüften Angebote.';
    return ['source'=>'eBay','marketplace'=>'eBay','priceKind'=>'ebay-offer-average','averageEur'=>round(array_sum(array_column($matches,'eur'))/count($matches),2),'averageCount'=>count($matches),'offers'=>$matches,'exchangeRates'=>$rates,'warnings'=>$warnings,'context'=>['parallel'=>$card['parallel']??'','grade'=>trim(($card['grader']??'').' '.($card['grade']??''))?:'Unbewertet'],'notice'=>'eBay-Angebotspreis: Durchschnitt passender laufender Festpreisangebote, ohne Versand und Einfuhrkosten. Keine abgeschlossenen Verkäufe und kein garantierter Marktwert. Verkäuferangaben sind nicht unabhängig bestätigt. Maximal fünf Suchtreffer werden strukturiert geprüft.'];
}
