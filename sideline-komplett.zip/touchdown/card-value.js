const kinds=new Set(['average-sales','last-ebay-sale','thecardapi-auto-average','thecardapi-confirmed-average','ebay-offer-average']);
export function valueThreshold(value){const n=Number(value);return Number.isFinite(n)&&n>=1&&n<=1000000?Math.round(n):50;}
export function cardValueStatus(card,price,threshold=50,now=Date.now()){
 threshold=valueThreshold(threshold);const amount=price?.averageEur;
 if(typeof amount!=='number'||!Number.isFinite(amount)||amount<threshold||price.currency!=='EUR'||!kinds.has(price.priceKind))return null;
 const time=Date.parse(price.fetchedAt),missing=['player','year','set','number','parallel'].some(k=>!String(card[k]||'').trim())||card.player==='Neue Karte';
 const unreviewed=!!card.scan?.queueState&&card.scan.queueState!=='done',stale=!Number.isFinite(time)||now-time>30*86400000||time>now+300000;
 if(missing||unreviewed||stale)return {tier:'review',label:stale?'Preis prüfen':'Wert prüfen',basis:stale?'Preisstand älter als 30 Tage oder unklar':'Kartendaten noch nicht geprüft',amount};
 const tier=amount>=threshold*10?'top':amount>=threshold*2?'highlight':'valuable';const base=({top:'Topkarte',highlight:'Highlight',valuable:'Wertvoll'})[tier];const offer=price.priceKind==='ebay-offer-average';
 return {tier,label:base+(offer?' · Potenzial':''),basis:offer?'eBay-Angebotsbasis':'Verkaufsbasis',amount,offer};
}
