import {providerImportView,geminiSettingsView,geminiReadingView,geminiWarningView,applyGeminiReading} from './gemini-assist.js?v=23';
import {showReferee} from './referee.js?v=23';
import {layoutScanner,openScannerTools} from './scanner-layout.js?v=23';
import {OwnCatalog} from './own-catalog.js?v=23';
import {Guides} from './guides.js?v=23';
import {usageView,setupUsage,refreshUsage,queueUsageRefresh} from './usage.js?v=23';
import {readGradingBarcodes} from './barcode.js?v=23';
import { SportsFeed } from './sports.js?v=23';
import {installView,setupInstall} from './install.js?v=23';
import { sortOptions, preferredSort, rememberSort, compareCards, sortHint } from './sorting.js?v=23';
import { SetChecklists } from './checklists.js?v=23';
import { CardCapture } from './capture.js?v=23';
const paths = {
  dashboard:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  cards:'<rect x="7" y="3" width="13" height="17" rx="2"/><path d="M4 7H3v13a2 2 0 0 0 2 2h11M11 8h5M11 12h5M11 16h3"/>',
  scan:'<path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m8 0h3a2 2 0 0 0 2-2v-3M3 12h18"/>',
  heart:'<path d="m12 21-8-7C-3 7 6-1 12 6 18-1 27 7 20 14Z"/>',
  settings:'<path d="m9 3-1 3-3 1-2 3 2 2-1 3 2 3h3l2 3 3-1 1-3 3-1 2-3-2-2 1-3-2-3h-3l-2-3Z"/><circle cx="11.5" cy="12" r="3"/>',
  plus:'<path d="M12 5v14M5 12h14"/>', close:'<path d="m6 6 12 12M6 18 18 6"/>', arrow:'<path d="M4 12h15m-6-6 6 6-6 6"/>',
  lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 11h18"/>',
  wallet:'<path d="M20 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h15V8H5a3 3 0 0 1 0-6"/><path d="M20 12h-6v5h6m-4-2.5h.01"/>',
  star:'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2-5.5-2.9-5.5 2.9 1-6.2L3 9.6l6.2-.9Z"/>',
  camera:'<path d="m8 5 1-2h6l1 2h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/><circle cx="12" cy="13" r="4"/>',
  search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  ball:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3v18M5.5 5.5c8 2 8 11 13 13M18.5 5.5c-8 2-8 11-13 13"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
  download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
  upload:'<path d="M12 16V4m-5 5 5-5 5 5M4 16v5h16v-5"/>',
  check:'<path d="m5 12 4 4L19 6"/>',edit:'<path d="m15 4 5 5M4 20l5-1L21 7a2 2 0 0 0-4-4L5 15Zm0 0 1-5"/>',
  trash:'<path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7"/>',
};
const icon = name => `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.cards}</svg>`;
function icons(scope=document) { scope.querySelectorAll('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon)); }
const $ = selector => document.querySelector(selector);
const esc = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const eur = value => value === null || value === undefined ? '—' : new Intl.NumberFormat('de-DE',{style:'currency',currency:'EUR',maximumFractionDigits:2}).format(value);
const count = value => new Intl.NumberFormat('de-DE').format(value);
const ownCatalog=new OwnCatalog(api);const knowledge=new Guides();
const labels={owncatalog:'Eigene Datenbank',knowledge:'Sammlerwissen',overview:'Übersicht',collection:'VAULT',live:'Live-Spiele',news:'NEWS',install:'App installieren',scan:'Karte erfassen',wishlist:'Wunschliste',settings:'Einstellungen',checklists:'Set-Checklisten'};
let autoScan=true;try{autoScan=localStorage.getItem('touchdown-auto-scan')!=='false';}catch{}
let appReady=false;let cards=[], status={}, loadError='', route='overview', editingId=null, formImage='', scanImage='', deleteId=null;
let filter={query:'',sport:'',sort:preferredSort(),favorite:false};
let toastTimer;
let haptics=true,pendingDuplicate=null,activeDetailId=null,detailIds=[],detailRequest=0,linkingCardId=null;
let numberResults=[],numberSearch=null,numberTotal=0;
const marketSnapshots=new Map();
const marketPending=new Map(),marketFailed=new Map();let priceQueue=Promise.resolve(),priceTimer;

let scanSegments=[],segmentsLoading=false,segmentsLoaded=false;
try{haptics=localStorage.getItem('sideline-haptics')!=='false';}catch{}
let slabMode=false,barcodeResult=null;let multiCount=1,scanQueue=[];let foilMode=false,foilFirst=null;const parallelOptions=new Map();
let batchScan=true,batchCount=0,lastScanned='';
let scanIssue='';let scanPhase='idle',savedScanId=null,scanOperation=0;

const capture=new CardCapture({getAutomatic:()=>autoScan&&route==='scan'&&multiCount===1&&!foilMode&&!scanBusy&&!scanImage&&!pendingDuplicate&&!document.getElementById('scanner-tools')?.open,getCount:()=>multiCount,onPhotos:async photos=>{scanQueue=photos;await nextQueuedScan();},keepOpen:()=>(batchScan||foilMode)&&route==='scan',canRecognize:()=>!!status.scanAvailable,onError:message=>toast(message,true),onPhoto:async(photo,recognize)=>{scanOperation++;scanIssue='';barcodeResult=null;scanImage=photo;scanResults=[];savedScanId=null;scanPhase='idle';render();if(recognize)await actions.identify();}});
const photoCapture=new CardCapture({canRecognize:()=>false,keepOpen:()=>false,onError:message=>toast(message,true),onPhoto:async photo=>{formImage=photo;photoPreview();$('#photo-capture-dialog').close();toast('Foto übernommen. Zum Übernehmen die Karte speichern.');}});
let segment='auto', scanResults=[], scanBusy=false, catalogResults=[];
document.addEventListener('touchdown-quota-warning',event=>toast(event.detail.remaining===0?'Die lokale Cardsight-Grenze ist erreicht. Weitere gezählte Anfragen sind gesperrt.':`Cardsight-Verbrauch: ${event.detail.used} von ${event.detail.limit} konservativ gezählt.`,true));setupUsage(api);const catalogPhotos=new Map();let retryScan=false;
const sportsFeed=new SportsFeed(api);setupInstall(()=>cards);
const setChecklists=new SetChecklists({api,getStatus:()=>status,getCards:()=>cards,onWish:prefill=>openForm(null,{wish:true,prefill})});
function toast(message,error=false) { const t=$('#toast'); t.textContent=message; t.classList.toggle('error',error); t.hidden=false; clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.hidden=true,5000); }
async function api(url,options={}) {
  const route=url.replace(/^\/api\//,'');
  const method=options.method || 'GET';
  const response=await fetch(`./api.php?r=${encodeURIComponent(route)}`,{...options,method:['PUT','DELETE'].includes(method)?'POST':method,credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':document.querySelector('meta[name=csrf-token]').content,...(['PUT','DELETE'].includes(method)?{'X-HTTP-Method-Override':method}:{}),...options.headers}});
  if(response.status===401){location.assign('./');throw new Error('Bitte erneut anmelden.');}
  let result;try{result=await response.json();}catch{throw new Error('Die PHP-Schnittstelle antwortet nicht korrekt. Bitte alle Dateien inklusive api.php hochladen und PHP im Hosting aktivieren.');}
  if(!route.startsWith('usage'))queueUsageRefresh();
  if(!response.ok)throw Object.assign(new Error(result.error || 'Die Anfrage konnte nicht abgeschlossen werden.'),{status:response.status,details:result});
  return result;
}
const valuationIdentity=c=>[c.cardsightId||'',c.parallel||'',c.grader||'',c.grade||''];
const sameValuation=(c,d)=>d.valuationIdentity?JSON.stringify(valuationIdentity(c))===JSON.stringify(d.valuationIdentity):d.cardUpdatedAt===c.updatedAt;
async function refresh() { cards=await api('/api/cards');setChecklists.invalidate();for(const[id,snapshot]of marketSnapshots)if(!cards.some(c=>c.id===id&&sameValuation(c,snapshot)))marketSnapshots.delete(id); $('#nav-count').textContent=count(cards.filter(c=>c.status!=='Wunschliste').reduce((sum,c)=>sum+c.quantity,0)); }
const actionButton=(action,label,kind='button-dark',name='plus')=>`<button class="button ${kind}" data-action="${action}">${icon(name)}${label}</button>`;
function heading(title,subtitle,extra='') { return `<div class="page-heading"><div><span class="eyebrow">DEIN SPIEL. DEINE GESCHICHTE.</span><h1>${title}</h1><p>${subtitle}</p></div>${extra}</div>`; }
function empty(title,description,action='add',label='Erste Karte scannen',symbol='cards') { return `<div class="empty-state"><div class="empty-icon">${icon(symbol)}</div><h3>${title}</h3><p>${description}</p>${actionButton(action,label,'button-dark','plus')}</div>`; }
function placeholder(c) { const initials=c.player.split(/\s+/).slice(0,2).map(s=>s[0]).join(''); return `<div class="card-placeholder">${icon('ball')}<strong>${esc(initials)}</strong><small>${esc(c.sport)}${c.number?' · '+esc(c.number):''}</small></div>`; }
function cardTile(c) { return `<article class="collection-card"><button class="favorite-button ${c.favorite?'selected':''}" data-action="favorite" data-id="${c.id}" aria-label="${c.favorite?'Favorit entfernen':'Als Favorit markieren'}" aria-pressed="${c.favorite}">${icon('heart')}</button><button class="card-open" data-action="detail" data-id="${c.id}" aria-label="Details zu ${esc(c.player)}"><div class="card-visual sport-${esc(c.sport)}">${cardPicture(c,true)}</div><div class="card-info"><div class="card-meta">${esc(c.sport)} <span>·</span> ${esc(c.year || 'Ohne Jahr')}</div><h3>${esc(c.player)}</h3><p>${esc(c.set || c.team || 'Set noch nicht erfasst')}${c.number?' · '+esc(c.number):''}</p>${filter.sort==='team'&&route==='collection'?`<div class="team-position">${esc(c.team||'Team nicht angegeben')}<span>${esc(c.position||'Position nicht angegeben')}</span></div>`:''}<div class="card-bottom"><span class="card-value" data-price-id="${c.id}" title="Durchschnitt abgeschlossener Verkäufe in Euro">${freshPrice(c)?eur(freshPrice(c).averageEur):'—'}</span><small class="price-basis" data-basis-id="${c.id}">${freshPrice(c)?.priceKind==='last-ebay-sale'?'Letzter eBay-Verkauf':''}</small><span class="grade-badge">${esc(c.grader && c.grade ? `${c.grader} ${c.grade}`:c.condition)}${c.quantity>1?` · ×${count(c.quantity)}`:''}</span></div></div></button></article>`; }
function overview() {
 const owned=cards.filter(c=>c.status!=='Wunschliste'),total=owned.reduce((n,c)=>n+c.quantity,0);
 const players=new Set(owned.map(c=>c.player.toLocaleLowerCase())).size,sets=new Set(owned.map(c=>c.set).filter(Boolean)).size;
 const priced=owned.filter(c=>freshPrice(c)?.averageEur!=null),value=priced.reduce((n,c)=>n+freshPrice(c).averageEur*c.quantity,0),latest=owned[0];
 const stat=(label,value,symbol,sub='')=>`<div class="stat"><span class="stat-symbol">${icon(symbol)}</span><div><span class="stat-top">${label}</span><div class="stat-value">${value}</div>${sub?`<small>${sub}</small>`:''}</div></div>`;
 const sports=[...new Set(owned.map(c=>c.sport))].map(sport=>({sport,total:owned.filter(c=>c.sport===sport).reduce((n,c)=>n+c.quantity,0)})).sort((a,b)=>b.total-a.total);
 return heading('Deine Sammlung. Dein Spielfeld.','Willkommen zurück. Hier sind die Highlights deiner Sammlung.',`<a class="button button-dark" href="#scan">${icon('scan')} Karte scannen</a>`)+
 `<p><button class="button button-secondary" data-action="prices-load">Preise bewusst abrufen</button> <small>Kann mehrere Cardsight-Anfragen pro Karte verbrauchen · Anzeige bleibt beim letzten Abrufstand.</small></p><div class="dashboard-layout"><div class="dashboard-primary"><section class="stats-grid" aria-label="Sammlungsstatistik">${stat('Gesamte Karten',count(total),'cards')}${stat('Anzahl Spieler',count(players),'star')}${stat('Anzahl Sets',count(sets),'cards')}${stat('Gesamtwert (Markt)',`<span data-total-market>${priced.length?eur(value):'—'}</span>`,'wallet',`<span data-market-coverage>${priced.length} von ${owned.length} Karten bewertet${priced.length<owned.length?' · Teilwert':''}</span>`)}</section><section class="dashboard-panel recent-panel"><div class="section-heading"><div><h2>Zuletzt hinzugefügt</h2><p>Deine Karten. Deine Momente.</p></div><a class="text-link" href="#collection">Alle anzeigen ${icon('arrow')}</a></div>${owned.length?`<div class="card-grid dashboard-cards">${owned.slice(0,5).map(cardTile).join('')}</div>`:empty('Jede Sammlung beginnt mit einer Karte.','Fotografiere deine Karte. Wir kümmern uns um die Details.')}</section><div class="dashboard-features"><a class="dashboard-panel feature-panel" href="#scan"><span class="feature-icon">${icon('camera')}</span><h2>Automatische Kartenerkennung</h2><p>Ein Foto genügt. Karte erkennen, speichern und direkt in deiner Sammlung wiederfinden.</p><span class="text-link">Karte hinzufügen →</span><div class="feature-scan-art" aria-hidden="true"><span>SCAN</span><i></i></div></a><section class="dashboard-panel feature-panel"><span class="feature-icon">${icon('wallet')}</span><h2>Marktpreis in Euro</h2><p>Ein Durchschnittspreis passender abgeschlossener Verkäufe. Direkt in deinen Kartendetails.</p>${latest?`<button class="button button-dark" data-action="detail" data-id="${latest.id}">Letzte Karte ansehen</button>`:'<a class="text-link" href="#scan">Erste Karte scannen →</a>'}<small class="feature-note">Cardsight · Tageskurs in Euro · abhängig von verfügbaren Verkaufsdaten</small></section><section class="dashboard-panel feature-panel"><span class="feature-icon">${icon('dashboard')}</span><h2>Deine Sammlung im Blick</h2><p>Alle Sportarten. Dein persönlicher Fortschritt.</p><div class="sport-distribution">${sports.length?sports.slice(0,4).map(s=>`<div><span>${esc(s.sport)}</span><strong>${s.total}</strong><progress value="${s.total}" max="${total}" aria-label="${esc(s.sport)}: ${s.total} Karten"></progress></div>`).join(''):'<p>Noch keine Karten gesammelt.</p>'}</div><a class="text-link" href="#checklists">Set-Checklisten öffnen →</a></section></div></div><aside class="dashboard-secondary"><section class="dashboard-panel dashboard-spotlight"><div class="section-heading"><h2>Karten-Details</h2><span class="live-badge">DEIN HIGHLIGHT</span></div>${latest?`<button class="spotlight-photo" data-action="detail" data-id="${latest.id}" aria-label="Highlight ${esc(latest.player)} ansehen">${cardPicture(latest)}</button><h3>${esc(latest.player)}</h3><p class="spotlight-team">${esc(latest.team||latest.sport)}</p><dl>${[['Position',latest.position],['Set',latest.set],['Jahr',latest.year],['Kartennummer',latest.number],['Variante',latest.parallel],['Sport',latest.sport]].map(([label,value])=>`<div><dt>${label}</dt><dd>${esc(value||'Nicht angegeben')}</dd></div>`).join('')}</dl><div class="spotlight-quantity">Sammlung <strong>${latest.quantity} Exemplar${latest.quantity===1?'':'e'}</strong></div><button class="button button-dark" data-action="detail" data-id="${latest.id}">Details öffnen ${icon('arrow')}</button>`:'<div class="spotlight-empty">'+icon('cards')+'<h3>Dein nächstes Highlight wartet.</h3><p>Scanne deine erste Karte und entdecke alle Details hier.</p></div>'}</section><section class="dashboard-panel anywhere-panel"><span class="feature-icon">${icon('lock')}</span><h2>Deine Karten. Überall.</h2><p>Auf Smartphone, Tablet und Computer. Deine Fotos und Sammlung auf deinem Webspace.</p><div class="device-art" aria-hidden="true"><span></span><span></span></div></section></aside></div>`;
}
function collection(wishlist=false) {
  return heading(wishlist?'Die nächsten Highlights.':'Deine Karten. Alle im Blick.',wishlist?'Hier warten deine nächsten Lieblingsstücke.':'Suchen, sortieren, wiederentdecken. Das ist deine Sammlung.',actionButton(wishlist?'add-wish':'add',wishlist?'Wunsch hinzufügen':'Karte scannen'))+
  `<div class="toolbar"><label class="search-box"><span>${icon('search')}</span><input id="search" type="search" placeholder="Spieler, Team, Set oder Nummer suchen …" aria-label="Sammlung durchsuchen" value="${esc(filter.query)}"></label><select id="sport-filter" aria-label="Nach Sportart filtern"><option value="">Alle Sportarten</option>${sportOptions().map(s=>`<option ${filter.sport===s?'selected':''}>${s}</option>`).join('')}</select><select id="sort-filter" aria-label="Sortierung">${sortOptions.map(([v,l])=>`<option value="${v}" ${filter.sort===v?'selected':''}>${l}</option>`).join('')}</select><button class="filter-toggle ${filter.favorite?'active':''}" data-action="filter-favorites" aria-pressed="${filter.favorite}">${icon('heart')} Favoriten</button></div><div id="collection-results"></div>`;
}
function renderResults() {
  const el=$('#collection-results'); if(!el)return;
  const source=cards.filter(c=>route==='wishlist'?c.status==='Wunschliste':c.status!=='Wunschliste');
  let result=source.filter(c=>(!filter.sport || c.sport===filter.sport)&&(!filter.favorite || c.favorite)&&[c.player,c.team,c.set,c.number,c.parallel,c.year].join(' ').toLocaleLowerCase('de').includes(filter.query.toLocaleLowerCase('de')));
  result.sort((a,b)=>compareCards(a,b,filter.sort,c=>freshPrice(c)?.averageEur??null));
  el.innerHTML=`<button class="button button-secondary" data-action="prices-load">Preise bewusst abrufen</button><div class="results-line"><span>${count(result.length)} ${result.length===1?'Eintrag':'Einträge'}${filter.query || filter.sport || filter.favorite?` von ${count(source.length)}`:''}</span><button class="text-link" data-action="reset-filters">Filter zurücksetzen</button></div>`+(result.length?`<p class="collection-sort-hint">${esc(sortHint(filter.sort))}</p><div class="card-grid">${result.map(cardTile).join('')}</div>`:source.length?empty('Kein Treffer für diese Auswahl.','Versuche einen anderen Suchbegriff oder setze die Filter zurück.','reset-filters','Filter zurücksetzen','search'):empty(route==='wishlist'?'Wovon träumt deine Sammlung?':'Dein nächster Fund wartet schon.',route==='wishlist'?'Merke dir Karten, die du noch ergattern möchtest.':'Füge deine erste Sportkarte hinzu – mit Foto und allen Details.',route==='wishlist'?'add-wish':'add',route==='wishlist'?'Ersten Wunsch hinzufügen':'Erste Karte scannen',route==='wishlist'?'heart':'cards'));
}
async function nextQueuedScan(){if(!scanQueue.length||scanBusy)return;const photo=scanQueue.shift();scanOperation++;scanIssue='';barcodeResult=null;scanImage=photo;scanResults=[];savedScanId=null;scanPhase='idle';render();await actions.identify();}
let geminiResult=null,geminiPhoto='';
function scan() {
  const reading=geminiPhoto===scanImage?geminiResult?.reading:null;
  if(reading)for(const c of scanResults)applyGeminiReading(c,reading);
  const saved=cards.find(c=>c.id===savedScanId);
  const phaseLabel=scanBusy?'Deine Karte wird erkannt …':scanPhase==='saved'?'Erkannt & gespeichert':scanPhase==='recognized'?'Treffervorschlag prüfen':scanPhase==='error'?'Bitte erneut versuchen':'Bereit für den Scan';
  return heading('Deine Karte. Dein Moment.','Fotografieren. Sportart automatisch erkennen. Sammeln.')+`
  <div class="scan-layout"><section class="scan-zone">
    <details class="scan-advanced" id="scan-options"><summary>Scan-Optionen · ${multiCount>1?multiCount+' Karten':foilMode?'Folienkarte':slabMode?'Grading':'Einzelkarte'} · Galerie</summary><label>Foto aus Galerie<input id="scanner-upload" type="file" accept="image/jpeg,image/png,image/webp" ${scanBusy?'disabled':''}></label><p class="field-hint">JPG, PNG oder WebP, maximal 12 MB. Foto zuschneiden und erst dann zur Erkennung senden.</p><label><input id="retry-scan" type="checkbox" ${retryScan?'checked':''} ${scanBusy?'disabled':''}> Bei fehlendem Treffer einen optimierten zweiten Versuch senden (zusätzlicher Aufruf)</label><label class="foil-mode"><input id="slab-mode" type="checkbox" ${slabMode?'checked':''} ${scanBusy?'disabled':''}> Grading-Hülle / Barcode prüfen</label>${slabMode?'<p class="field-hint">Die gesamte Hülle einschließlich Etikett in den Rahmen legen. Barcode-Lesen ist browserabhängig; Note und Zertifikatsnummer vor dem Speichern prüfen.</p>':''}<label class="multi-select">Aufnahme<select id="multi-count" ${scanBusy||scanQueue.length?'disabled':''}><option value="1" ${multiCount===1?'selected':''}>Eine Karte</option><option value="2" ${multiCount===2?'selected':''}>Zwei Karten nebeneinander</option><option value="4" ${multiCount===4?'selected':''}>Vier Karten im Raster</option></select></label>${multiCount>1?'<p>Je eine Karte pro Feld, ohne Überlappung. Jedes Feld wird einzeln geprüft. Mehr Karten bedeuten mehr API-Aufrufe. Der Folienmodus ist nur für Einzelkarten verfügbar.</p>':''}<label class="foil-mode"><input type="checkbox" id="foil-mode" ${foilMode?'checked':''} ${scanBusy||multiCount>1?'disabled':''}> Parallel-/Folienkarte · zwei Aufnahmewinkel</label><p class="field-hint foil-hint">${foilMode?(foilFirst?'Zweite Aufnahme: Karte leicht kippen, bis die Reflexion wandert.':'Erste Aufnahme möglichst gerade. Danach leicht schräg fotografieren.'):'Bei spiegelnden Karten den Zwei-Winkel-Modus verwenden. Diffuses Licht, kein Blitz.'}</p></details>${scanQueue.length?`<p role="status">Noch ${scanQueue.length} Karte(n) aus dieser Aufnahme · ${actionButton('queue-next','Nächstes Feld prüfen / aktuelles überspringen','button-secondary')}</p>`:''}<div class="scanner-toolbar"><label><input type="checkbox" id="batch-scan" ${batchScan?'checked':''} ${scanBusy?'disabled':''}> Mehrere Karten nacheinander</label><a class="button button-secondary button-small" href="#collection">Fertig · Sammlung</a></div><label class="foil-mode"><input id="auto-scan" type="checkbox" ${autoScan?'checked':''} ${scanBusy?'disabled':''}> Automatisch scannen · nur bei geöffneter Kamera</label><p class="field-hint">${autoScan?multiCount>1||foilMode?'Raster-/Folienmodus: bitte den Auslöser verwenden.':'Einzelkarte ruhig in den Rahmen legen. Nach jedem Scan die Karte wechseln. Jeder Erkennungsversuch verbraucht Kontingent.':'Manueller Auslöser aktiv.'}</p><p class="scanner-status" role="status">${batchCount?`${batchCount} Karte${batchCount===1?'':'n'} gespeichert · zuletzt ${esc(lastScanned)}`:'Karte in den Rahmen halten und auf den Auslöser tippen.'}</p>
    <div id="camera-host" ${scanImage?'hidden':''}></div>
    ${scanImage?`<div class="scan-preview phase-${scanPhase}" aria-label="Scan-Vorschau">
      <div class="scan-photo-card"><img src="${esc(scanImage)}" alt="Zugeschnittenes Kartenfoto">${scanBusy?'<div class="scan-beam"></div><div class="scan-grid-overlay"></div>':''}</div>
      ${scanPhase==='saved'?`<div class="scan-success-icon">${icon('check')}</div><span class="scan-spark s1"></span><span class="scan-spark s2"></span><span class="scan-spark s3"></span><span class="scan-spark s4"></span>`:''}
      <div class="scan-phase-label" role="status">${scanBusy?'<span class="mini-spinner"></span>':''}${phaseLabel}</div>
    </div>`:''}
    <div class="scan-note ${status.scanAvailable?'connected':''}">${icon(status.scanAvailable?'lock':'info')}<div><strong>${status.scanAvailable?'Nur deine Karte kommt in die Sammlung.':'API-Schlüssel noch nicht eingerichtet.'}</strong><br>${status.scanAvailable?'Der Rahmen schneidet den Hintergrund ab. Beim Fotografieren & Erkennen wird nur der Zuschnitt an Cardsight gesendet.':esc(status.scanMessage)}</div></div>
    <div class="scan-actions">${scanImage&&!savedScanId?`<button class="button button-dark" data-action="identify" ${!status.scanAvailable||scanBusy?'disabled':''}>${icon('scan')}${scanBusy?'Karte wird erkannt …':'Karte erkennen'}</button>`:''}${scanImage?`<button class="button button-secondary" data-action="clear-scan" ${scanBusy?'disabled':''}>${icon('camera')} Nächste Karte</button>`:''}</div>
    ${saved?`<div class="saved-scan-panel"><span>${icon('check')}</span><div><strong>${esc(saved.player)} ist in deiner Sammlung.</strong><small>${esc([saved.year,saved.set,saved.number].filter(Boolean).join(' · '))}</small></div><button class="text-link" data-action="detail" data-id="${saved.id}">Ansehen ${icon('arrow')}</button>${saved.cardsightSetId?`<button class="text-link" data-action="open-set" data-set-id="${esc(saved.cardsightSetId)}">Checkliste öffnen ${icon('cards')}</button>`:''}</div>`:''}
    <div id="scan-results" aria-live="polite">${scanImage&&status.gemini?.configured&&status.gemini?.enabled?`<button class="button button-secondary" data-action="gemini-read" ${scanBusy?'disabled':''}>Scan+ · Kartentext mit Gemini prüfen</button>`:''}${geminiReadingView(reading)}${barcodeResult?`<section class="scan-quality-advice"><strong>Grading-Barcode</strong><p>${esc(barcodeResult.message)}</p>${barcodeResult.codes.map(code=>`<p><code>${esc(code)}</code></p>`).join('')}</section>`:''}${scanImage&&!scanBusy?`<button class="button button-secondary" data-action="correct-scan">Falscher oder fehlender Treffer? Im Katalog korrigieren</button>`:''}${scanIssue?`<p class="scan-quality-advice">${esc(scanIssue)}</p>`:''}${scanPhase==='error'?'<p class="scan-quality-advice">Nicht erkannt. Karte leicht kippen, direkte Lampen und Blitz vermeiden, Kamera-Linse reinigen und erneut aufnehmen. Bei Folienkarten hilft eine Aufnahme ohne Hülle. Fehlt die Karte im Cardsight-Katalog, kann auch ein gutes Foto ohne Treffer bleiben.</p>':''}${scanResults.length&&!savedScanId?`<div class="scan-result-heading">Vorschläge von Cardsight · Spieler, Set und Nummer prüfen</div>${scanResults.map((c,i)=>`<div class="recognition-result" data-variant-review="${c.parallelNeedsReview||c.geminiNeedsReview?'1':'0'}"><div class="detection-row"><div><span class="confidence confidence-${c.confidence}">${c.confidenceKnown===false?'Alternative · ohne eigene Sicherheitseinstufung':({High:'Anbieter: High · kein Identitätsnachweis',Medium:'Anbieter: Medium · unsicher',Low:'Anbieter: Low · unsicher'}[c.confidence]||'Keine Sicherheitseinstufung')}</span><strong>${esc(c.player||'Nur das Set erkannt')}</strong><small>${esc([c.year,c.set,c.number,c.parallel].filter(Boolean).join(' · '))}</small></div></div>${geminiWarningView(c,i)}<p class="field-hint">Vergleiche den vorgeschlagenen Namen mit deiner fotografierten Karte. Auch ein High-Treffer kann falsch sein.</p>${c.cardsightId?`<button class="button button-secondary" data-action="scan-reference" data-id="${esc(c.cardsightId)}">Katalogbild zum Vergleichen laden · 1 Anfrage</button>${catalogPhotos.has(c.cardsightId)?`<img class="scan-reference-image" src="${esc(catalogPhotos.get(c.cardsightId))}" alt="Katalogvorschlag: ${esc(c.player)}">`:' '}`:''}${c.localMatches?.length?`<div class="scan-alternatives"><p>Eigene CSV: ${c.localTotal} passende Datensätze zum vorgeschlagenen Namen/Nummer – kein unabhängiger Beweis der Fotoidentität.</p>${c.localMatches.slice(0,8).map((a,j)=>`<button class="button button-secondary" data-action="own-scan-pick" data-index="${i}" data-local="${j}">${esc(a.player)} · ${esc(a.set)} #${esc(a.number)} · ${esc(a.parallel||'Variante offen')}</button>`).join('')}</div>`:''}${c.alternatives?.some(a=>a.catalogSource!=='CARDLEAGUE CSV')?`<div class="scan-alternatives"><p>Weitere Vorschläge des Anbieters:</p>${c.alternatives.map((a,j)=>a.catalogSource==='CARDLEAGUE CSV'?'':`<button class="button button-secondary" data-action="scan-alternative" data-index="${i}" data-alternative="${j}">${esc(a.player)} · ${esc(a.year)} · ${esc(a.set)} #${esc(a.number)}</button>`).join('')}</div>`:''}${c.matchLevel==='card'?`<label class="parallel-review">Variante prüfen<select data-parallel-index="${i}"><option value="${esc(c.parallel||'')}">${esc(c.parallel||'Variante noch nicht bestimmt')}</option></select></label>`:''}${slabMode||c.grader?`<div class="fields"><label>Grading-Anbieter<input data-review-grader="${i}" maxlength="200" value="${esc(c.grader||'')}"></label><label>Note<input data-review-grade="${i}" maxlength="200" value="${esc(c.grade||'')}"></label><label>Zertifikatsnummer<input data-review-cert="${i}" maxlength="200" value="${esc(c.certNumber||'')}"></label><label>Barcode-Inhalt (ungeprüft)<input data-review-barcode="${i}" maxlength="200" value="${esc(c.gradingBarcode||'')}"></label></div>`:''}${c.player&&c.matchLevel==='card'&&!c.sportNeedsReview?`<button class="button button-dark" data-action="save-detection" data-index="${i}" ${scanBusy?'disabled':''}>Diese Karte speichern</button>`:'<p>Bitte eine neue Aufnahme machen. Die Karte ist noch nicht eindeutig zugeordnet.</p>'}</div>`).join('')}`:''}</div>
    <details class="number-search"><summary>Statt Foto: Kartennummer suchen</summary><form id="card-number-form"><label>Kartennummer<input name="number" required maxlength="60" placeholder="z. B. 269"></label><label>Jahr<input name="year" required pattern="[0-9]{4}" maxlength="4" inputmode="numeric" placeholder="2020"></label><label>Hersteller<input name="manufacturer" required maxlength="100" placeholder="z. B. Panini oder Topps"></label><label>Spielername (optional)<input name="player" maxlength="200" placeholder="z. B. Patrick Mahomes"></label><button class="button button-dark" type="submit" ${!status.scanAvailable?'disabled':''}>Karte suchen</button></form><p class="field-hint">Nummer und Jahr sind nicht immer eindeutig. Prüfe Set, Spieler und Variante, bevor du die Karte übernimmst. Diese Karten verwenden das Cardsight-Katalogbild.</p><div id="number-results" aria-live="polite"></div></details>
    <details class="scan-advanced" id="catalog-tools" ${linkingCardId?'open':''}><summary>Im Katalog suchen</summary><section class="catalog-section"><h3>Oder im Katalog finden</h3><p>Suche nach Spieler, Jahr und Set. Übernimm einen Treffer als Vorlage.</p><div class="catalog-search"><input id="catalog-query" type="search" placeholder="z. B. Patrick Mahomes Prizm 2017" aria-label="Cardsight-Katalog durchsuchen" maxlength="200"><button class="button button-secondary" data-action="catalog-search" ${!status.scanAvailable?'disabled':''}>${icon('search')} Suchen</button></div><div id="catalog-results"></div></section></details>
  </section></div>`;
}
function sportOptions(){return [...new Set(['Basketball','Fußball','American Football','Baseball','Eishockey','MMA','Boxen','Wrestling','Motorsport','Golf','Tennis','Rugby','Cricket','Andere',...scanSegments.map(s=>s.name),...cards.map(c=>c.sport)])].sort((a,b)=>a.localeCompare(b,'de'));}
function scanSegmentOptions(){const fallback=[{id:'football',name:'American Football'},{id:'basketball',name:'Basketball'},{id:'baseball',name:'Baseball'},{id:'hockey',name:'Eishockey'},{id:'soccer',name:'Fußball'},{id:'mma',name:'MMA'}];return '<option value="auto">Automatisch erkennen · alle Kategorien</option>'+(scanSegments.length?scanSegments:fallback).map(s=>{const id=s.shortname||s.id;return `<option value="${esc(id)}" ${segment===id?'selected':''}>${esc(s.name)}</option>`;}).join('');}
async function loadScanSegments(){if(segmentsLoading||segmentsLoaded||!status.scanAvailable)return;segmentsLoading=true;try{const data=await api('/api/segments',{method:'POST',body:'{}'});scanSegments=data.segments;segmentsLoaded=true;if($('#scan-segment'))$('#scan-segment').innerHTML=scanSegmentOptions();}catch{}finally{segmentsLoading=false;}}
function renderCatalog() {
  const el=$('#catalog-results');if(!el)return;
  el.innerHTML=catalogResults.map((c,i)=>`<button class="detection-row" data-action="pick-catalog" data-index="${i}"><span class="catalog-thumb">${c.cardsightId?`<img src="${catalogImage(c.cardsightId)}" alt="Katalogbild von ${esc(c.player)}" loading="lazy" data-catalog-thumb="true">`:icon('cards')}</span><div><strong>${esc(c.player)}</strong><small>${esc([c.year,c.set,c.number,c.parallel].filter(Boolean).join(' · '))}</small></div>${icon('plus')}</button>`).join('');
}
function settings() {
  return heading('Dein Space. Deine Regeln.','Sichere deine Sammlung und behalte die Kontrolle über deine Daten.')+
  `<a class="button button-dark" href="#install">App auf iOS / Android installieren</a><a class="button button-secondary" href="#owncatalog">Eigene Datenbank / CSV-Import</a><div class="mobile-more-links"><a href="#knowledge">Sammlerwissen →</a><a href="#news">NEWS →</a><a href="#live">Live-Spiele →</a><a href="#install">App installieren →</a><a href="#checklists">Set-Checklisten →</a><a href="#wishlist">Wunschliste →</a></div><div class="settings-grid">${geminiSettingsView(status.gemini)}${providerImportView(status.additionalApis)}${usageView()}<section class="settings-panel appearance-panel"><span>${icon('star')}</span><h2>So fühlt sich deine App an.</h2><label class="setting-label">Darstellung<select id="theme-setting"><option value="system" ${window.SidelineTheme.getPreference()==='system'?'selected':''}>Wie auf deinem Gerät</option><option value="light" ${window.SidelineTheme.getPreference()==='light'?'selected':''}>Hell</option><option value="dark" ${window.SidelineTheme.getPreference()==='dark'?'selected':''}>Dunkel</option></select></label><p class="field-hint">In deiner Sammlung erscheinen deine eigenen Kartenfotos. Die Checklisten verwenden weiterhin Katalogbilder.</p><label class="setting-check"><input type="checkbox" id="haptics-setting" ${haptics?'checked':''}><span>Vibration bei Erkennung<small>Nur in unterstützten Browsern, etwa Chrome auf Android. Safari auf dem iPhone unterstützt die Vibrations-API nicht.</small></span></label><p>Neue Sets werden nur nach deinem Klick auf „Jetzt prüfen“ in den Checklisten abgefragt.</p></section><section class="settings-panel"><span>${icon('download')}</span><h2>Ein Backup für deine Highlights.</h2><p>Exportiere alle Karten inklusive Fotos als JSON-Datei. Bewahre regelmäßig eine Kopie an einem sicheren Ort auf.</p><a class="button button-dark" href="./api.php?r=export" download="sideline-sammlung.json">${icon('download')} Backup herunterladen</a><button class="button button-secondary" data-action="import">${icon('upload')} Backup importieren</button><p class="field-hint">Import ergänzt fehlende Einträge. Bereits vorhandene IDs werden übersprungen. Bestehende Karten werden nicht überschrieben. Maximal 1.000 Karten und 60 MB pro Import.</p></section><section class="settings-panel"><span>${icon('scan')}</span><h2>Cardsight-Erkennung</h2><span class="connection-status ${status.scanAvailable?'ready':''}">${status.scanAvailable?'Schlüssel auf dem Server hinterlegt':'Schlüssel fehlt'}</span><p>Erkenne unterstützte Sportkarten und Kategorien automatisch oder suche im Cardsight-Katalog. Eindeutige Treffer können direkt gespeichert werden; bei Duplikaten, unsicheren Treffern oder unklarer Sportart entscheidest du selbst.</p><p class="field-hint">Der Schlüssel bleibt auf deinem Webspace. Er erscheint nicht in Sammlungs-Backups. Zum Ändern bestätigst du dein App-Passwort.</p><form id="api-key-form" class="auth-form settings-key-form"><label>Neuer Cardsight-Schlüssel<input name="apiKey" type="password" maxlength="256" autocomplete="off" placeholder="Leer lassen, um den Schlüssel zu entfernen"></label><label>Dein App-Passwort<input name="password" type="password" required autocomplete="current-password"></label><button class="button button-dark" type="submit">Schlüssel speichern</button><p class="field-hint" id="key-result" role="status"></p></form></section><section class="settings-panel"><span>${icon('lock')}</span><h2>Passwort ändern</h2><form id="password-form" class="auth-form"><label>Aktuelles Passwort<input name="currentPassword" type="password" required autocomplete="current-password"></label><label>Neues Passwort<input name="newPassword" type="password" minlength="6" maxlength="200" required autocomplete="new-password"></label><label>Neues Passwort wiederholen<input name="repeatPassword" type="password" minlength="6" maxlength="200" required autocomplete="new-password"></label><button class="button button-dark" type="submit">Passwort ändern</button><p class="field-hint">Mindestens 6 Zeichen.</p></form><h2>Persönlich. Lokal. Übersichtlich.</h2><p>Deine Sammlung ist durch dein Passwort geschützt. Fotos und Kartendaten bleiben auf deinem ALL-INKL-Webspace. Sichere regelmäßig ein Backup.</p><ul class="info-list"><li>Speicherung<strong>Geschützt auf deinem Webspace</strong></li><li>Währung<strong>Euro (€)</strong></li><li>Marktdaten<strong>Cardsight · Euro-Durchschnitt</strong></li><li>Eigene Werte<strong>Euro (€)</strong></li><li>Gespeicherte Einträge<strong>${count(cards.length)}</strong></li></ul></section><section class="settings-panel"><h2>eBay-Zugang</h2><p>AppID und CertID werden nur auf deinem Server gespeichert. Inventory Mapping liefert keine abgeschlossenen Verkaufspreise. Eine separate Freischaltung für Verkaufsdaten ist erforderlich. Ohne belegte Verkaufsdaten wird kein Ersatzpreis erfunden.</p><form id="ebay-form" class="auth-form"><label>AppID (ClientID)<input name="clientId" autocomplete="off" maxlength="256"></label><label>CertID (ClientSecret)<input name="clientSecret" type="password" autocomplete="off" maxlength="256"></label><label>Dein App-Passwort<input name="password" type="password" required autocomplete="current-password"></label><button class="button button-dark">eBay-Zugang speichern</button></form><button class="button button-secondary" data-action="ebay-test">Verbindung prüfen</button><p id="ebay-result" role="status"></p></section><section class="settings-panel"><span>${icon('heart')}</span><h2>Für die Liebe zum Spiel.</h2><p>Eine eigene Heimat für deine Sportkarten. Halte Käufe fest, markiere Favoriten und plane mit deiner Wunschliste die nächsten Funde.</p><p class="field-hint">In den Kartendetails erscheint ein Durchschnittspreis abgeschlossener Verkäufe der letzten 90 Tage, mit aktuellem Tageskurs in Euro umgerechnet. Dies ist keine garantierte Bewertung. Fotos werden zur Identifikation erkannt; der Zustand wird dadurch nicht automatisch bewertet. Die App ist ein eigenständiges Projekt und nicht mit LUDEX verbunden.</p><a class="button button-secondary" href="#wishlist">Zur Wunschliste ${icon('arrow')}</a></section></div>`;
}
function render() {
  route=location.hash.slice(1) || 'overview'; if(!labels[route])route='overview';
  if(route!=='scan')scanQueue=[];
  document.body.classList.toggle('route-scan',route==='scan');
  document.title=`${labels[route]} · Sideline`;
  $('#page-name').textContent=labels[route];
  document.querySelectorAll('[data-nav]').forEach(el=>{ el.classList.toggle('active',el.dataset.nav===route); if(el.dataset.nav===route)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current'); });
  $('#main').innerHTML=loadError?`<div class="error-panel"><h2>Die Sammlung ist gerade nicht erreichbar.</h2><p>${esc(loadError)}</p>${actionButton('retry','Erneut versuchen','button-dark','arrow')}</div>`:route==='overview'?overview():route==='collection'||route==='wishlist'?collection(route==='wishlist'):route==='scan'?scan():route==='live'||route==='news'?heading(route==='live'?'Live-Spiele':'NEWS',route==='live'?'NFL und NBA · aktuelle Spielstände und Ereignisse':'Nachrichten aus deutschsprachigen Quellen')+'<div id="sports-root"></div>':route==='owncatalog'?heading('Eigene Kartendatenbank','CARDLEAGUE CSV · lokal auf deinem Webspace')+'<div id="own-catalog-root"></div>':route==='knowledge'?heading('Sammlerwissen','Deutsche Ratgeber · Sammelkarten & TCG')+'<div id="knowledge-root"></div>':route==='install'?heading('Deine App. Überall.','Auf iPhone und Android installieren.')+installView():route==='checklists'?heading('Jede Karte zählt.','Entdecke Sets, finde fehlende Karten und verfolge deinen Fortschritt.')+setChecklists.view():settings();
  renderResults();
  schedulePrices();
  if(route==='owncatalog')ownCatalog.mount($('#own-catalog-root')).catch(error=>toast(error.message,true));
  if(route==='knowledge')knowledge.mount($('#knowledge-root'));
  if(route==='settings')refreshUsage().catch(()=>{});
  if(route==='live'||route==='news')sportsFeed.mount($('#sports-root'),route==='live'?'live':'news');
  if(route==='checklists')setChecklists.mount($('#checklist-body'));
  if(route==='scan') {
    loadParallelOptions();
    layoutScanner({root:$('#main'),icon,automatic:autoScan,count:batchCount,connected:status.scanAvailable,autoAvailable:multiCount===1&&!foilMode,aim:foilMode?(foilFirst?'Zweite Aufnahme: Karte leicht kippen.':'Erste Aufnahme: Karte gerade halten.'):multiCount>1?`${multiCount} Karten – je eine pro Feld`:'Eine Karte in den Rahmen halten'});capture.mount($('#camera-host'));

    renderCatalog();renderNumberResults();
  }else {capture.stop();foilFirst=null;document.getElementById('scanner-tools')?.close();}
}
function photoPreview() { $('#form-photo-preview').innerHTML=formImage?`<img src="${esc(formImage)}" alt="Ausgewähltes Kartenfoto">`:`${icon('camera')}<strong>Noch kein Scan-Foto</strong><small>Fotografiere die Karte im Scanner.</small>`; }
function openForm(card=null,options={}) {
  if(capture.mode==='live'){capture.stop();render();}
  editingId=card?.id || null;const form=$('#card-form');form.reset();$('#form-error').textContent='';
  $('#dialog-title').textContent=card?'Karte bearbeiten':'Karte hinzufügen';
  formImage=card?.image || options.image || '';
  const sport=card?.sport||options.prefill?.sport;if(sport&&![...form.elements.sport.options].some(o=>o.value===sport))form.elements.sport.add(new Option(sport,sport));
  if(!card && options.prefill)for(const el of form.elements)if(el.name && options.prefill[el.name]!==undefined)el.value=options.prefill[el.name];
  if(!card && !options.prefill)form.elements.sport.value=segment==='football'?'American Football':segment==='basketball'?'Basketball':'Andere';
  if(card)for(const el of form.elements)if(el.name && card[el.name]!==undefined){if(el.type==='checkbox')el.checked=card[el.name];else el.value=card[el.name]??'';}
  if(options.wish)form.elements.status.value='Wunschliste';
  photoPreview();$('#card-dialog').showModal();
}
const usd=value=>value===null||value===undefined?'—':new Intl.NumberFormat('de-DE',{style:'currency',currency:'USD'}).format(value);
const catalogImage=id=>`./api.php?r=image&id=${encodeURIComponent(id)}`;
function cardPicture(c,lazy=false,allowLoad=false){const image=c.image||catalogPhotos.get(c.cardsightId);if(image)return `<img src="${esc(image)}" alt="Karte von ${esc(c.player)}" ${lazy?'loading="lazy"':''}><span class="image-origin">${c.image?'Dein Foto':'Cardsight'}</span>`;return placeholder(c)+(allowLoad&&c.catalogImage&&c.cardsightId?`<span class="button button-secondary" role="button" tabindex="0" data-action="catalog-photo" data-id="${esc(c.cardsightId)}">Katalogbild laden · 1 Anfrage</span>`:'');}

function detail(id,keepOrder=false) {
  const c=cards.find(c=>c.id===id);if(!c)return;
  if(!keepOrder){const visible=[...document.querySelectorAll('#main .card-open')].map(el=>el.dataset.id);detailIds=visible.includes(id)?visible:cards.map(c=>c.id);}
  detailIds=detailIds.filter(id=>cards.some(c=>c.id===id));activeDetailId=id;detailRequest++;
  const index=detailIds.indexOf(id);
  const row=(label,value)=>value!==''&&value!==null&&value!==undefined?`<div class="detail-row"><span>${label}</span><strong>${esc(value)}</strong></div>`:'';
  $('#detail-dialog').innerHTML=`<div class="dialog-heading"><div><span class="eyebrow">DEIN COLLECTOR HIGHLIGHT</span><h2>Kartendetails</h2></div><button class="icon-button" data-action="close-detail" aria-label="Schließen">${icon('close')}</button></div><div class="detail-gallery-nav"><button class="icon-button" data-action="detail-prev" aria-label="Vorherige Karte" ${index<=0?'disabled':''}>‹</button><span>Karte ${index+1} von ${detailIds.length}</span><button class="icon-button" data-action="detail-next" aria-label="Nächste Karte" ${index>=detailIds.length-1?'disabled':''}>›</button></div><div class="detail-body"><div><div class="detail-image" role="button" tabindex="0" aria-label="Kartenbild – nach links oder rechts wischen">${cardPicture(c,false,true)}</div><p class="swipe-hint">Antippen zum Vergrößern · ← Wischen →</p></div><div class="detail-info"><div class="card-meta">${esc(c.sport)} · ${esc(c.status)}</div><h2>${esc(c.player)}</h2><div id="player-metadata">${metadataRows(c)}</div><p id="sleeper-status" class="field-hint" role="status">Aktuelle Spielerdaten werden abgeglichen …</p>${row('Set',c.set||'Nicht angegeben')}${row('Ausstellungsjahr',c.year||'Nicht angegeben')}${row('Sprache',c.language||'Nicht verfügbar')}${row('Seltenheit',c.rarity||'Nicht verfügbar')}${row('Kartennummer',c.number||'Nicht angegeben')}${c.cardsightId?`<button class="button button-secondary button-small card-set-button" data-action="card-set" data-id="${c.id}">Set-Checkliste öffnen</button>`:''}${row('Parallel',c.parallel)}${row('Zustand',c.condition)}${row('Grading',[c.grader,c.grade].filter(Boolean).join(' '))}${row('Zertifikatsnummer',c.certNumber)}${row('Barcode (ungeprüft)',c.gradingBarcode)}${row('Anzahl',c.quantity)}${c.notes?`<p class="detail-notes">${esc(c.notes)}</p>`:''}</div><section class="market-panel" id="market-panel" aria-live="polite"><div class="market-heading"><div><span class="eyebrow">CARDSIGHT · MARKTDATEN</span><h3>Was bewegt den Markt?</h3></div></div>${!c.cardsightId?`<p>Für diese Karte fehlt die Katalogzuordnung. Ordne sie im Cardsight-Katalog zu, um passende Preise und Bilder zu laden.</p><button class="button button-secondary" data-action="link-card">Im Katalog zuordnen ${icon('arrow')}</button>`:!status.scanAvailable?'<p>Bitte deinen Cardsight-Schlüssel in den Einstellungen hinterlegen.</p>':'<p>Aktuelle Marktdaten werden geladen …</p>'}</section></div><div class="detail-footer"><button class="button button-secondary" data-action="link-card">Katalogzuordnung korrigieren</button><button class="button button-quiet" data-action="delete" data-id="${c.id}">${icon('trash')} Löschen</button><button class="button button-dark" data-action="edit" data-id="${c.id}">${icon('edit')} Bearbeiten</button></div>`;
  if(!$('#detail-dialog').open)$('#detail-dialog').showModal();
  $('#sleeper-status').textContent='Gespeicherte Kartendaten · Ergänzungen ausschließlich über Cardsight.';if(c.cardsightId&&status.scanAvailable){const cached=marketSnapshots.get(id);if(cached&&cached.context)renderMarket(cached);else $('#market-panel').innerHTML='<p>Preise werden erst auf deinen Wunsch abgefragt und können mehrere API-Aufrufe benötigen.</p><button class="button button-dark" data-action="market-refresh">Preis jetzt abrufen</button>';}
}
function metadataRows(c){return [['Verein',c.team],['Trikotnummer',c.jerseyNumber],['Position',c.position],['Kartentyp',c.cardType]].map(([label,value])=>`<div class="detail-row"><span>${label}</span><strong>${esc(value||'Nicht angegeben')}</strong></div>`).join('');}
async function loadCardInfo(c){try{const info=await api('/api/card-info',{method:'POST',body:JSON.stringify({id:c.cardsightId})});if(activeDetailId!==c.id)return;const merged={...cards.find(row=>row.id===c.id)};for(const key of ['cardType'])if(!merged[key]&&info[key])merged[key]=info[key];$('#player-metadata').innerHTML=metadataRows(merged);}catch{}}
document.addEventListener('keydown',event=>{if(event.target.matches('[data-action=catalog-photo]')&&['Enter',' '].includes(event.key)){event.preventDefault();event.target.click();return;}if(event.target.matches('.detail-image')&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openImage(activeDetailId);}});
function moveDetail(delta){const index=detailIds.indexOf(activeDetailId),next=detailIds[index+delta];if(next)detail(next,true);}
function dateLabel(value){const d=new Date(value);return Number.isNaN(d.getTime())?'Datum nicht angegeben':new Intl.DateTimeFormat('de-DE',{dateStyle:'medium',timeStyle:'short'}).format(d);}
function freshPrice(c){const d=marketSnapshots.get(c.id);return d&&sameValuation(c,d)?d:null;}
function fetchPrice(c,force=false){
 if(!force&&freshPrice(c))return Promise.resolve(freshPrice(c));
 if(marketPending.get(c.id)?.updatedAt===c.updatedAt)return marketPending.get(c.id).promise;
 const promise=priceQueue.catch(()=>{}).then(async()=>{const data=await api('/api/market',{method:'POST',body:JSON.stringify({id:c.id,refresh:force})});if(cards.some(row=>row.id===c.id&&JSON.stringify(valuationIdentity(row))===JSON.stringify(valuationIdentity(c))))marketSnapshots.set(c.id,{...data,cardUpdatedAt:c.updatedAt,valuationIdentity:valuationIdentity(c)});marketFailed.delete(c.id);return data;});
 priceQueue=promise;marketPending.set(c.id,{updatedAt:c.updatedAt,promise});
 promise.then(()=>updatePrices(),()=>{marketFailed.set(c.id,Date.now());updatePrices();}).finally(()=>{if(marketPending.get(c.id)?.promise===promise)marketPending.delete(c.id);});return promise;
}
function schedulePrices(){clearTimeout(priceTimer);updatePrices();}

function updatePrices(){
 if(route==='collection'&&filter.sort==='value')renderResults();
 document.querySelectorAll('[data-price-id]').forEach(el=>{const c=cards.find(c=>c.id===el.dataset.priceId);if(c){const data=freshPrice(c);el.textContent=data?eur(data.averageEur):'—';el.title=data?'Zuletzt abgerufener Preis in Euro · '+dateLabel(data.fetchedAt):'Marktdaten werden geladen oder sind nicht verfügbar';}});
 document.querySelectorAll('[data-basis-id]').forEach(el=>{const c=cards.find(c=>c.id===el.dataset.basisId);el.textContent=c&&freshPrice(c)?.priceKind==='last-ebay-sale'?'Letzter eBay-Verkauf':'';});
 const owned=cards.filter(c=>c.status!=='Wunschliste'),priced=owned.filter(c=>freshPrice(c)?.averageEur!=null),total=priced.reduce((n,c)=>n+freshPrice(c).averageEur*c.quantity,0);
 const value=document.querySelector('[data-total-market]'),coverage=document.querySelector('[data-market-coverage]');
 if(value)value.textContent=priced.length?eur(total):'—';
 if(coverage)coverage.textContent=`${priced.length} von ${owned.length} Karten bewertet${priced.length<owned.length?' · Teilwert':''}`;
}
async function loadMarket(id,force=false){
  const c=cards.find(c=>c.id===id);if(!c||!$('#market-panel'))return;
  const request=++detailRequest;
  if(force)$('#market-panel').innerHTML='<p>Marktdaten werden aktualisiert …</p>';
  try{
    let data=marketSnapshots.get(id);
    data=await fetchPrice(c,force);
    if(request!==detailRequest||activeDetailId!==id)return;
    marketSnapshots.set(id,{...data,cardUpdatedAt:c.updatedAt,valuationIdentity:valuationIdentity(c)});renderMarket(data);renderResults();
  }catch(error){if(request!==detailRequest||activeDetailId!==id)return;$('#market-panel').innerHTML=`<h3>Marktdaten gerade nicht verfügbar.</h3><p>${esc(error.message)}</p><button class="button button-secondary" data-action="market-refresh">Erneut versuchen</button>`;}
}
function renderMarket(data){
  $('#market-panel').innerHTML=`<div class="market-heading"><div><span class="eyebrow">CARDSIGHT · EURO</span><h3>${data.priceKind==='last-ebay-sale'?'Letzter bezahlter eBay-Preis':'Durchschnittlicher Marktpreis'}</h3></div><button class="button button-secondary button-small" data-action="market-refresh">Aktualisieren</button></div><div class="market-stats"><div><strong>${eur(data.averageEur)}</strong><span>${data.priceKind==='last-ebay-sale'?'Letzter über Cardsight belegter eBay-Verkauf · '+esc(data.lastEbaySale?.date||''):(data.averageCount??data.salesCount)+' passende abgeschlossene Verkäufe · 90 Tage'}</span></div></div><p class="field-hint">${esc(data.context.parallel)} · ${esc(data.context.grade)}. ${data.priceKind==='last-ebay-sale'?'Ein einzelner belegter Verkauf; kein garantierter heutiger Marktwert.':'Arithmetischer Durchschnitt, kein garantierter Verkaufspreis.'} ${data.exchange?`USD in EUR umgerechnet · Kursdatum ${esc(data.exchange.date)} · ${esc(data.exchange.source)}.`:''} Abgerufen ${esc(dateLabel(data.fetchedAt))}.</p>${data.averageEur==null?'<p>Keine ausreichenden Verkaufsdaten für einen Euro-Preis vorhanden.</p>':''}${(data.warnings||[]).map(w=>`<p>${esc(w)}</p>`).join('')}`;
}
let imageCard=null;
function openImage(id){
  imageCard=cards.find(c=>c.id===id);if(!imageCard)return;paintImage();if(!$('#image-dialog').open)$('#image-dialog').showModal();
}
function paintImage(){
  const c=imageCard;
  $('#image-view').innerHTML=`<div class="image-toolbar"><strong>${esc(c.player)} · Dein Kartenfoto</strong><button class="icon-button" data-action="close-image" aria-label="Großansicht schließen">×</button></div><div class="large-card">${cardPicture(c)}</div><p class="field-hint">Zum Vergrößern auf das Bild tippen.</p>`;
}
document.addEventListener('click',event=>{
  const image=event.target.closest('.detail-image');if(image&&!event.target.closest('[data-action]')&&!suppressImageClick)openImage(activeDetailId);
  if(event.target.closest('.large-card img'))event.target.closest('.large-card').classList.toggle('zoomed');
});
let suppressImageClick=false;
let swipeStart=null;
document.addEventListener('pointerdown',event=>{if(event.target.closest('.detail-image')&&event.isPrimary!==false)swipeStart={x:event.clientX,y:event.clientY,id:event.pointerId};});
document.addEventListener('pointerup',event=>{if(!swipeStart||event.pointerId!==swipeStart.id)return;const dx=event.clientX-swipeStart.x,dy=event.clientY-swipeStart.y;swipeStart=null;suppressImageClick=Math.abs(dx)>20||Math.abs(dy)>20;setTimeout(()=>suppressImageClick=false,300);if($('#detail-dialog').open&&Math.abs(dx)>60&&Math.abs(dx)>Math.abs(dy)*1.5)moveDetail(dx<0?1:-1);});
document.addEventListener('pointercancel',()=>swipeStart=null);
document.addEventListener('keydown',event=>{if(!$('#detail-dialog').open||event.target.closest('input,select,textarea')||$('#confirm-dialog').open||$('#image-dialog').open)return;if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();moveDetail(event.key==='ArrowLeft'?-1:1);}});
$('#detail-dialog').addEventListener('close',()=>{activeDetailId=null;detailRequest++;});
document.addEventListener('error',event=>{
  const img=event.target;if(!(img instanceof HTMLImageElement))return;
  if(img.dataset.catalogThumb){img.replaceWith(document.createTextNode('▧'));return;}
  if(!img.dataset.catalogPicture)return;
  delete img.dataset.catalogPicture;const c=cards.find(c=>c.id===img.dataset.cardPicture);
  const label=img.parentElement.querySelector('.image-origin');if(label)label.textContent=c?.image?'Dein Foto':'Bild nicht verfügbar';
  if(c?.image)img.src=c.image;else if(c)img.outerHTML=placeholder(c);else img.remove();
},true);
async function saveDetection(card,photo=scanImage,duplicateAction='',duplicateId='') {
  if(card?.parallel==='Base')card={...card,parallel:''};
  if(!card?.player)throw new Error('Bitte zuerst den Spielernamen ergänzen.');
  if(!duplicateAction){const matches=duplicateMatches(card);if(matches.length){openDuplicate(card,photo,matches);return null;}}
  let saved;
  try{saved=await api('/api/cards',{method:'POST',body:JSON.stringify({...card,image:photo,quantity:1,status:'Sammlung',_scanConfirmed:card._scanConfirmed===true,_duplicateAction:duplicateAction,_duplicateId:duplicateId})});}
  catch(error){if(error.status===409&&error.details?.duplicates){openDuplicate(card,photo,error.details.duplicates);return null;}throw error;}
  recognitionHaptic();footballSaved(saved.player);foilFirst=null;savedScanId=saved.id;scanPhase='saved';
  await refresh();toast(saved.duplicateMerged?`Anzahl erhöht: ${saved.player} · ${saved.quantity} Karten.`:`${saved.player} wurde nach deiner Bestätigung gespeichert.`);
  batchCount++;lastScanned=saved.player;
  scanImage='';scanResults=[];savedScanId=null;scanPhase='idle';
  if(!batchScan||card.catalogImage){filter={query:'',sport:'',sort:preferredSort(),favorite:false};capture.stop();location.hash='collection';}
  return saved;
}
async function loadParallelOptions(){for(let i=0;i<scanResults.length;i++){const c=scanResults[i];if(!c.cardsightId)continue;try{if(!parallelOptions.has(c.cardsightId)){const d=await api('/api/parallel-options',{method:'POST',body:JSON.stringify({id:c.cardsightId})});parallelOptions.set(c.cardsightId,d.parallels);}const select=document.querySelector(`[data-parallel-index="${i}"]`);if(select&&scanResults[i]?.cardsightId===c.cardsightId){const value=select.value;select.innerHTML='<option value="">Variante noch nicht bestimmt</option><option value="Base">Base · bewusst auswählen</option>'+parallelOptions.get(c.cardsightId).map(p=>`<option value="${esc(p.name)}">${esc(p.name)}${p.numberedTo?' /'+p.numberedTo:''}</option>`).join('');select.value=value;if(select.selectedIndex<0)select.insertAdjacentHTML('afterbegin',`<option value="${esc(value)}" selected>${esc(value)}</option>`);}}catch{}}}
async function recognitionPhoto(photo){
 const image=new Image();await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('Aufnahme konnte nicht gelesen werden.'));image.src=photo;});
 const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(image,0,0);
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);let mean=0;for(let i=0;i<pixels.data.length;i+=4)mean+=(pixels.data[i]+pixels.data[i+1]+pixels.data[i+2])/3;mean/=pixels.data.length/4;
 const gain=Math.max(.9,Math.min(1.2,125/Math.max(mean,1)));
 for(let i=0;i<pixels.data.length;i+=4)for(let c=0;c<3;c++)pixels.data[i+c]=Math.max(0,Math.min(255,(pixels.data[i+c]*gain-128)*1.07+128));
 ctx.putImageData(pixels,0,0);return canvas.toDataURL('image/jpeg',.94);
}
function renderNumberResults(){const el=$('#number-results');if(!el)return;el.innerHTML=numberSearch?`<p>${numberTotal} Treffer · Seite ${Math.floor(numberSearch.skip/20)+1}</p>${numberResults.map((c,i)=>`<article class="number-result"><img src="${catalogImage(c.id)}" alt="Cardsight-Katalogbild von ${esc(c.player)}" loading="lazy" data-catalog-thumb="true"><div><strong>${esc(c.player)}</strong><p>${esc(c.year)} · ${esc(c.set)} · #${esc(c.number)}</p><label>Variante<select id="number-parallel-${i}"><option value="">${c.parallelOnly?'Bitte Variante wählen':'Basiskarte'}</option>${c.parallels.map(p=>`<option>${esc(p.name)}</option>`).join('')}</select></label><button class="button button-dark" data-action="number-pick" data-index="${i}">In Sammlung übernehmen</button></div></article>`).join('')}<div class="number-pager"><button class="button button-secondary" data-action="number-prev" ${!numberSearch.skip?'disabled':''}>Zurück</button><button class="button button-secondary" data-action="number-next" ${numberSearch.skip+20>=numberTotal?'disabled':''}>Weiter</button></div>`:'';}
async function searchNumber(fields){const data=await api('/api/catalog-number',{method:'POST',body:JSON.stringify(fields)});numberSearch=fields;numberResults=data.cards;numberTotal=data.total;renderNumberResults();}
document.addEventListener('submit',async event=>{if(event.target.id!=='card-number-form')return;event.preventDefault();const button=event.target.querySelector('button');button.disabled=true;try{await searchNumber({...Object.fromEntries(new FormData(event.target)),skip:0});}catch(error){toast(error.message,true);}finally{button.disabled=false;}});
function footballSaved(player){showReferee(player,{saved:true});}
function recognitionHaptic(){if(haptics&&typeof navigator.vibrate==='function'&&!document.hidden)try{navigator.vibrate([35,40,65]);}catch{}}
function duplicateMatches(candidate){
  if(Array.isArray(candidate.duplicates))return candidate.duplicates;
  const norm=v=>String(v??'').trim().replace(/\s+/g,' ').toLocaleLowerCase();
  return cards.filter(c=>c.status!=='Wunschliste'&&['sport','parallel','grader','grade'].every(k=>norm(c[k])===norm(candidate[k]))&&((c.cardsightId&&candidate.cardsightId)?c.cardsightId===candidate.cardsightId:['player','set','year','number'].every(k=>c[k]&&candidate[k]&&norm(c[k])===norm(candidate[k]))));
}
function openDuplicate(card,photo,matches){
  pendingDuplicate={card,photo,matches};
  $('#duplicate-description').textContent=`${card.player}: ${matches.reduce((n,c)=>n+c.quantity,0)} Exemplar(e) bereits vorhanden.`;
  $('#duplicate-target').innerHTML=matches.map(c=>`<option value="${esc(c.id)}">${esc(c.player)} · ${esc(c.set)} · ${c.quantity} Stück</option>`).join('');
  $('#duplicate-error').textContent='';
  if(!$('#duplicate-dialog').open)$('#duplicate-dialog').showModal();
}
async function confirmDuplicate(action){
  if(!pendingDuplicate)return;const pending=pendingDuplicate;const buttons=$('#duplicate-dialog').querySelectorAll('button');buttons.forEach(b=>b.disabled=true);
  try{const saved=await saveDetection(pending.card,pending.photo,action,$('#duplicate-target').value);if(saved){pendingDuplicate=null;$('#duplicate-dialog').close();render();}}
  catch(error){$('#duplicate-error').textContent=error.message;}finally{buttons.forEach(b=>b.disabled=false);}
}
document.addEventListener('submit',async event=>{
  if(event.target.id!=='api-key-form')return;
  event.preventDefault();const form=event.target,button=form.querySelector('button');button.disabled=true;
  try{await api('/api/settings',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(form)))});status=await api('/api/status');marketSnapshots.clear();render();setChecklists.start();toast('Cardsight-Einstellung gespeichert.');}catch(error){form.querySelector('#key-result').textContent=error.message;}finally{button.disabled=false;}
});
const actions={
  'catalog-photo':async el=>{const response=await fetch(catalogImage(el.dataset.id),{credentials:'same-origin'});queueUsageRefresh();if(!response.ok){let data;try{data=await response.json();}catch{}throw Error(data?.error||'Bild konnte nicht geladen werden.');}const blob=await response.blob();const photo=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(blob);});catalogPhotos.set(el.dataset.id,photo);if($('#detail-dialog').open)detail(activeDetailId,true);else render();},
  'prices-load':async el=>{el.disabled=true;try{for(const c of cards.filter(c=>c.cardsightId&&c.status!=='Wunschliste')){try{await fetchPrice(c,true);}catch(error){toast(error.message,true);if(error.status===429)break;}}updatePrices();toast('Preisabfrage abgeschlossen. Verfügbare Werte werden angezeigt.');}finally{el.disabled=false;}},
  'own-scan-pick':el=>{const i=Number(el.dataset.index),c=scanResults[i]?.localMatches?.[Number(el.dataset.local)];if(c){scanResults[i]=c;render();}},
  'scan-alternative':el=>{const i=Number(el.dataset.index),a=scanResults[i]?.alternatives?.[Number(el.dataset.alternative)];if(!a)return;const old=scanResults[i];scanResults[i]={...a,alternatives:[{...old,alternatives:undefined},...old.alternatives.filter(x=>x.cardsightId!==a.cardsightId)]};render();},
  'scan-reference':async el=>{el.disabled=true;try{const r=await fetch(catalogImage(el.dataset.id),{credentials:'same-origin'});queueUsageRefresh();if(!r.ok){let error;try{error=await r.json();}catch{}throw Error(error?.error||'Kein Vergleichsbild verfügbar.');}const blob=await r.blob();const photo=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(blob);});catalogPhotos.set(el.dataset.id,photo);render();}finally{el.disabled=false;}},
  'correct-scan':()=>{openScannerTools('#catalog-tools');const box=document.querySelector('#catalog-tools');box.open=true;const c=scanResults[0];$('#catalog-query').value=[c?.player,c?.year,c?.set].filter(Boolean).join(' ');$('#catalog-query').focus();box.scrollIntoView({behavior:'smooth',block:'center'});},
  'queue-next':async()=>{await nextQueuedScan();},
  'gemini-read':async()=>{if(scanBusy||!scanImage)return;const photo=scanImage;scanBusy=true;render();try{const result=await api('/api/gemini-read',{method:'POST',body:JSON.stringify({image:photo})});if(photo!==scanImage||route!=='scan')return;geminiResult=result;geminiPhoto=photo;status.gemini=await api('/api/gemini-status');}finally{scanBusy=false;render();}},
  'gemini-search':()=>{const r=geminiPhoto===scanImage?geminiResult?.reading:null;if(!r?.player)return;openScannerTools('#catalog-tools');$('#catalog-query').value=[r.player,r.year,r.manufacturer,r.number].filter(Boolean).join(' ');$('#catalog-query').focus();},
  'ebay-test':async()=>{const result=await api('/api/ebay-test',{method:'POST',body:'{}'});$('#ebay-result').textContent=result.message;},
  'duplicate-next':()=>{const catalog=pendingDuplicate?.card?.catalogImage&&!pendingDuplicate?.photo;pendingDuplicate=null;$('#duplicate-dialog').close();if(catalog){location.hash='collection';render();}else actions['clear-scan']();},
  'duplicate-increment':()=>confirmDuplicate('increment'),
  'duplicate-separate':()=>confirmDuplicate('separate'),
  'duplicate-cancel':()=>{pendingDuplicate=null;$('#duplicate-dialog').close();},
  'open-set':el=>{$('#detail-dialog').close();setChecklists.open(el.dataset.setId);location.hash='checklists';render();},
  'card-set':async el=>{const c=cards.find(c=>c.id===el.dataset.id);el.disabled=true;try{let id=c.cardsightSetId;if(!id){const result=await api('/api/resolve-set',{method:'POST',body:JSON.stringify({id:c.id})});id=result.setId;await refresh();}$('#detail-dialog').close();setChecklists.open(id);location.hash='checklists';render();}finally{el.disabled=false;}},
  'detail-prev':()=>moveDetail(-1),'detail-next':()=>moveDetail(1),
  'close-image':()=>$('#image-dialog').close(),
  'number-pick':async el=>{el.disabled=true;try{const hit=numberResults[Number(el.dataset.index)],parallel=$(`#number-parallel-${el.dataset.index}`).value;const card=await api('/api/catalog-card',{method:'POST',body:JSON.stringify({id:hit.id,parallel})});await saveDetection(card,'');render();}finally{el.disabled=false;}},
  'number-prev':()=>searchNumber({...numberSearch,skip:Math.max(0,numberSearch.skip-20)}),
  'number-next':()=>searchNumber({...numberSearch,skip:numberSearch.skip+20}),
  'take-card-photo':async()=>{capture.stop();photoCapture.mount($('#photo-capture-host'));$('#photo-capture-dialog').showModal();await photoCapture.start();},
  'close-photo-camera':()=>$('#photo-capture-dialog').close(),
  'market-refresh':()=>loadMarket(activeDetailId,true),
  'link-card':()=>{linkingCardId=activeDetailId;const c=cards.find(c=>c.id===activeDetailId);$('#detail-dialog').close();location.hash='scan';render();$('#catalog-query').value=[c.player,c.year,c.set].filter(Boolean).join(' ');$('#catalog-query').focus();},
  add:()=>{location.hash='scan';render();}, 'add-wish':()=>openForm(null,{wish:true}),
  scan:()=>location.hash='scan',
  'segment-auto':()=>{if(scanBusy)return;segment='auto';scanResults=[];catalogResults=[];savedScanId=null;scanPhase='idle';render();},
  'segment-nfl':()=>{if(scanBusy)return;segment='football';scanResults=[];catalogResults=[];savedScanId=null;scanPhase='idle';render();},
  'segment-nba':()=>{if(scanBusy)return;segment='basketball';scanResults=[];catalogResults=[];savedScanId=null;scanPhase='idle';render();},
  identify:async()=>{
    if(scanBusy||savedScanId)return;
    if(!scanImage){toast('Bitte zuerst die Karte fotografieren.',true);return;}
    const operation=++scanOperation;let photo=scanImage;scanIssue='';
    scanBusy=true;scanPhase='scanning';scanResults=[];render();
    try{
      let result=await api('/api/identify',{method:'POST',body:JSON.stringify({image:photo,segment})});
      if(operation!==scanOperation)return;
      if(retryScan&&!(result.detections||[]).some(c=>c.matchLevel==='card')){
        const normalized=await recognitionPhoto(photo);
        if(operation!==scanOperation)return;
        toast('Kein eindeutiger Treffer – optimierte Aufnahme wird geprüft …');
        const retry=await api('/api/identify',{method:'POST',body:JSON.stringify({image:normalized,segment})});
        if(operation!==scanOperation)return;
        if((retry.detections||[]).some(c=>c.matchLevel==='card')||!result.detections?.length)result=retry;
      }
      if(foilMode&&!foilFirst){foilFirst={photo,detections:result.detections||[]};scanImage='';scanResults=[];scanPhase='idle';toast('Erste Aufnahme geprüft. Karte leicht kippen und zweite Aufnahme machen.');return;}
      if(foilMode&&foilFirst){
        const firstCapture=foilFirst,first=firstCapture.detections,second=result.detections||[];foilFirst=null;
        const same=second.filter(c=>first.some(a=>a.cardsightId&&a.cardsightId===c.cardsightId));
        const firstExact=first.filter(c=>c.matchLevel==='card'),secondExact=second.filter(c=>c.matchLevel==='card');if(firstExact.length&&secondExact.length&&!same.length){result.detections=[];scanIssue='Die beiden Aufnahmen ergeben unterschiedliche Karten. Keine Zuordnung übernommen. Bitte dieselbe Karte erneut aufnehmen oder im Katalog suchen.';}else{result.detections=same.length?same:(second.length?second:first);if(!second.length&&first.length){photo=firstCapture.photo;scanImage=photo;}}
        for(const c of result.detections){const a=first.find(a=>a.cardsightId===c.cardsightId);if(!c.parallel||!a||!same.length||a.parallel!==c.parallel||a.parallelNeedsReview||c.parallelNeedsReview)c.parallelNeedsReview=true;}
      }
      if(slabMode){try{barcodeResult=await readGradingBarcodes(photo);}catch{barcodeResult={codes:[],message:'Barcode konnte nicht gelesen werden. Bitte Etikett prüfen.'};}if(operation!==scanOperation)return;for(const c of result.detections||[])if(barcodeResult.codes.length===1)c.gradingBarcode=barcodeResult.codes[0];}
      scanResults=result.detections;
      scanPhase=scanResults.length?'recognized':'error';
      if(scanResults.some(c=>c.matchLevel==='card'))showReferee(scanResults[0].player||'Karte',{saved:false});
      if(!scanResults.length)toast('Nicht erkannt. Reflexion vermeiden und eine neue Aufnahme machen.',true);

    }catch(error){scanPhase=scanResults.length?'recognized':'error';throw error;}
    finally{scanBusy=false;render();if(!scanImage&&scanQueue.length&&route==='scan')setTimeout(()=>nextQueuedScan().catch(error=>toast(error.message,true)),250);}
  },
  'save-detection':async el=>{if(scanBusy||savedScanId)return;el.disabled=true;try{const index=Number(el.dataset.index);if(scanResults[index].geminiNeedsReview&&!scanResults[index].geminiAcknowledged)throw Error('Bitte zuerst den abweichenden Gemini-Text prüfen und die Bestätigung ankreuzen.');scanResults[index]._scanConfirmed=true;const selected=document.querySelector(`[data-parallel-index="${index}"]`);if(selected)scanResults[index].parallel=selected.value;for(const [key,field]of Object.entries({grader:'grader',grade:'grade',certNumber:'cert',gradingBarcode:'barcode'})){const input=document.querySelector(`[data-review-${field}="${index}"]`);if(input)scanResults[index][key]=input.value;}await saveDetection(scanResults[index]);render();if(!scanImage&&scanQueue.length)await nextQueuedScan();}catch(error){el.disabled=false;throw error;}},
  
  'pick-catalog':async el=>{el.disabled=true;try{const hit=catalogResults[Number(el.dataset.index)],selected=await api('/api/catalog-card',{method:'POST',body:JSON.stringify({id:hit.cardsightId,parallel:hit.parallel||''})});if(linkingCardId){const existing=cards.find(c=>c.id===linkingCardId);linkingCardId=null;openForm({...existing,...selected,image:existing.image,catalogImage:!existing.image});}else{const previous=scanResults[0]||{};const grading=Object.fromEntries(Object.entries({grader:'grader',grade:'grade',certNumber:'cert',gradingBarcode:'barcode'}).map(([key,field])=>[key,document.querySelector(`[data-review-${field}="0"]`)?.value??previous[key]??'']));scanResults=[{...selected,...grading,catalogImage:!scanImage,confidence:'High',matchLevel:'card',parallelNeedsReview:true,gradingBarcode:grading.gradingBarcode||(barcodeResult?.codes.length===1?barcodeResult.codes[0]:'')}];scanPhase='recognized';render();document.querySelector('#scan-results').scrollIntoView({behavior:'smooth',block:'center'});toast('Katalogtreffer übernommen. Variante prüfen und speichern. Dein Foto bleibt erhalten.');}}finally{el.disabled=false;}},
  'catalog-search':async el=>{
    const query=$('#catalog-query').value;el.disabled=true;
    try{const result=await api('/api/catalog',{method:'POST',body:JSON.stringify({query,segment})});catalogResults=result.results;renderCatalog();if(!catalogResults.length)toast('Keine Katalogtreffer. Bitte Suche präzisieren.');}finally{el.disabled=false;}
  }, 'close-dialog':()=>$('#card-dialog').close(), 'close-detail':()=>$('#detail-dialog').close(),
  detail:el=>detail(el.dataset.id),edit:el=>{$('#detail-dialog').close();openForm(cards.find(c=>c.id===el.dataset.id));},
  favorite:async el=>{const c=cards.find(c=>c.id===el.dataset.id);if(!c)return;el.disabled=true;await api(`/api/cards/${c.id}`,{method:'PUT',body:JSON.stringify({...c,favorite:!c.favorite})});await refresh();render();},
  delete:el=>{deleteId=el.dataset.id;$('#confirm-dialog').showModal();},
  'filter-favorites':()=>{filter.favorite=!filter.favorite;render();},
  'reset-filters':()=>{filter={query:'',sport:'',sort:preferredSort(),favorite:false};render();},
  'clear-scan':()=>{if(scanBusy)return;scanIssue='';barcodeResult=null;if(scanQueue.length){nextQueuedScan().catch(error=>toast(error.message,true));return;}scanImage='';scanResults=[];savedScanId=null;scanPhase='idle';render();if(capture.mode==='idle')capture.start();},
  import:()=>$('#backup-input').click(),retry:async()=>{await refresh();loadError='';render();}
};
document.addEventListener('click',async e=>{if(e.target.closest('[data-camera=start]'))document.getElementById('scanner-tools')?.close();const el=e.target.closest('[data-action]');if(!el)return;try{await actions[el.dataset.action]?.(el);}catch(error){toast(error.message,true);el.disabled=false;}});
document.addEventListener('keydown',e=>{if(e.target.id==='catalog-query'&&e.key==='Enter'){e.preventDefault();document.querySelector('[data-action=catalog-search]')?.click();}});
document.addEventListener('input',e=>{if(e.target.id==='search'){filter.query=e.target.value;renderResults();}});
document.addEventListener('change',async e=>{
  if(e.target.matches('[data-gemini-confirm-index]')){const c=scanResults[Number(e.target.dataset.geminiConfirmIndex)];if(c)c.geminiAcknowledged=e.target.checked;}

  if(e.target.matches('[data-parallel-index]')){const c=scanResults[Number(e.target.dataset.parallelIndex)];if(c)c.parallel=e.target.value;}

  if(e.target.id==='auto-scan'){autoScan=e.target.checked;try{localStorage.setItem('touchdown-auto-scan',String(autoScan));}catch{}render();}
  if(e.target.id==='retry-scan')retryScan=e.target.checked;
  if(e.target.id==='scanner-upload'){const file=e.target.files[0];if(!file)return;try{if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>12000000)throw Error('Bitte JPG, PNG oder WebP mit maximal 12 MB wählen.');const photo=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});scanImage='';scanResults=[];scanQueue=[];barcodeResult=null;foilFirst=null;render();await capture.load(photo);}catch(error){toast(error.message||'Foto konnte nicht geöffnet werden.',true);}}
  if(e.target.id==='slab-mode'){slabMode=e.target.checked;barcodeResult=null;render();}
  if(e.target.id==='multi-count'){multiCount=Number(e.target.value);scanQueue=[];foilMode=false;foilFirst=null;batchScan=true;capture.paint();render();}
  if(e.target.id==='scan-segment'){segment=e.target.value;scanResults=[];catalogResults=[];savedScanId=null;scanPhase='idle';render();}
  if(e.target.id==='set-notices-setting')setChecklists.setAutoNews(e.target.checked);
  if(e.target.id==='theme-setting')window.SidelineTheme.setPreference(e.target.value);
  if(e.target.id==='haptics-setting'){haptics=e.target.checked;try{localStorage.setItem('sideline-haptics',String(haptics));}catch{}}
  if(e.target.id==='auto-save'){autoSave=e.target.checked;try{localStorage.setItem('sideline-auto-save',String(autoSave));}catch{}}
  if(e.target.id==='sport-filter'){filter.sport=e.target.value;renderResults();}
  if(e.target.id==='sort-filter'){filter.sort=e.target.value;rememberSort(filter.sort);renderResults();}
  if(e.target.id==='foil-mode'){foilMode=e.target.checked;foilFirst=null;render();}
  if(e.target.id==='batch-scan')batchScan=e.target.checked;
});
$('#card-form').addEventListener('submit',async e=>{
  e.preventDefault();const button=$('#save-card');button.disabled=true;$('#form-error').textContent='';
  const data=Object.fromEntries(new FormData(e.target));delete data[''];
  data.favorite=e.target.elements.favorite.checked;data.quantity=Number(data.quantity);
  for(const key of ['purchasePrice','marketValue'])data[key]=data[key]===''?null:Number(data[key]);
  data.image=formImage;data.catalogImage=!formImage&&cards.find(c=>c.id===editingId)?.catalogImage===true;
  try{await api(editingId?`/api/cards/${editingId}`:'/api/cards',{method:editingId?'PUT':'POST',body:JSON.stringify(data)});await refresh();$('#card-dialog').close();if(!editingId){scanOperation++;scanImage='';scanResults=[];savedScanId=null;scanPhase='idle';}if(!editingId&&location.hash==='#scan'){batchCount++;lastScanned=data.player;if(!batchScan||data.catalogImage){filter={query:'',sport:'',sort:preferredSort(),favorite:false};capture.stop();location.hash='collection';}}render();toast(editingId?'Änderungen gespeichert.':'Dein neues Highlight ist gespeichert.');}catch(error){$('#form-error').textContent=error.message;}finally{button.disabled=false;}
});
$('#cancel-delete').addEventListener('click',()=>$('#confirm-dialog').close());
$('#confirm-delete').addEventListener('click',async()=>{
  const button=$('#confirm-delete');button.disabled=true;
  try{await api(`/api/cards/${deleteId}`,{method:'DELETE',body:'{}'});await refresh();$('#confirm-dialog').close();$('#detail-dialog').close();render();toast('Karte gelöscht.');}catch(error){toast(error.message,true);}finally{button.disabled=false;}
});
$('#backup-input').addEventListener('change',async e=>{
  const file=e.target.files[0];if(!file)return;
  try{if(file.size>60_000_000)throw new Error('Das Backup ist zu groß (maximal 60 MB).');const data=JSON.parse(await file.text());const result=await api('/api/import',{method:'POST',body:JSON.stringify(data)});await refresh();render();toast(`${result.imported} Einträge importiert, ${result.skipped} vorhandene übersprungen.`);}catch(error){toast(error instanceof SyntaxError?'Die Datei enthält kein gültiges JSON.':error.message,true);}finally{e.target.value='';}
});
$('#photo-capture-dialog').addEventListener('close',()=>photoCapture.stop());
$('#card-dialog').addEventListener('close',()=>{$('#photo-capture-dialog').close();photoCapture.stop();});
window.addEventListener('pagehide',()=>{capture.stop();photoCapture.stop();capture.paint();});
document.addEventListener('visibilitychange',()=>{if(document.hidden){capture.stop();photoCapture.stop();capture.paint();}});
window.addEventListener('hashchange',()=>{if(!appReady)return;render();$('#main').focus({preventScroll:true});window.scrollTo(0,0);});
icons();$('#main').innerHTML='<div class="loading">Deine Sammlung wird geladen …</div>';
try{await refresh();status=await api('/api/status');for(const value of await api('/api/market-saved'))marketSnapshots.set(value.id,value);await refreshUsage();}catch(error){loadError=error.message;}
appReady=true;render();
setChecklists.start();
document.addEventListener('sideline-set-news',event=>{const badge=$('#set-news-count');badge.textContent=event.detail.newCount;badge.hidden=!event.detail.newCount;if(event.detail.newCount)toast(`${event.detail.newCount} neu entdeckte Sets. Sieh in deine Checklisten.`);});

document.addEventListener('submit',async event=>{
 if(event.target.id!=='password-form')return;event.preventDefault();const form=event.target,button=form.querySelector('button');button.disabled=true;
 try{await api('/api/password',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(form)))});form.reset();toast('Passwort geändert.');}catch(error){toast(error.message,true);}finally{button.disabled=false;}
});

setInterval(schedulePrices,600000);
document.addEventListener("visibilitychange",()=>{if(!document.hidden)schedulePrices();});

document.addEventListener('toggle',event=>{if(event.target.matches?.('.number-search')&&event.target.open){if(scanBusy){event.target.open=false;return;}capture.stop();foilFirst=null;capture.paint();}},true);

document.addEventListener('submit',async event=>{if(event.target.id!=='ebay-form')return;event.preventDefault();const button=event.target.querySelector('button');button.disabled=true;try{await api('/api/ebay-settings',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(event.target)))});event.target.reset();$('#ebay-result').textContent='Zugangsdaten gespeichert. Verkaufspreise benötigen eine gesonderte Datenfreigabe.';}catch(error){toast(error.message,true);}finally{button.disabled=false;}});

document.addEventListener('own-card-chosen',event=>{scanResults=[event.detail];scanPhase='recognized';location.hash='scan';render();});

document.addEventListener('submit',async event=>{if(event.target.id!=='gemini-settings')return;event.preventDefault();const form=event.target,button=form.querySelector('button');button.disabled=true;try{status.gemini=await api('/api/gemini-settings',{method:'POST',body:JSON.stringify({apiKey:form.elements.apiKey.value,password:form.elements.password.value,enabled:form.elements.enabled.checked,clearKey:form.elements.clearKey.checked,limit:Number(form.elements.limit.value)})});form.reset();render();toast('Gemini-Einstellungen gespeichert. Scan+ steht beim Kartenfoto bereit.');}catch(error){form.querySelector('#gemini-settings-result').textContent=error.message;}finally{button.disabled=false;}});

document.addEventListener('submit',async event=>{if(event.target.id!=='provider-import')return;event.preventDefault();const form=event.target,button=form.querySelector('button');button.disabled=true;try{let credentials={};const file=form.elements.credentialsFile.files[0];if(file){if(file.size>10000)throw Error('Die Schlüsseldatei ist zu groß.');credentials=JSON.parse(await file.text());if(!credentials||Array.isArray(credentials)||typeof credentials!=='object')throw Error('Ungültige Schlüsseldatei.');}if(form.elements.cardApi.value)credentials.CARDAPI_KEY=form.elements.cardApi.value;if(form.elements.cardVault.value)credentials.CARDVALUT_LIVE_KEY=form.elements.cardVault.value;const reply=await api('/api/provider-import',{method:'POST',body:JSON.stringify({password:form.elements.password.value,credentials})});status.gemini=reply.gemini;status.additionalApis=reply.additionalApis;form.reset();render();toast('Schlüssel privat gespeichert. Weitere Karten-APIs benötigen noch ihre Dokumentation.');}catch(error){form.querySelector('.provider-import-result').textContent=error.message;}finally{button.disabled=false;}});
