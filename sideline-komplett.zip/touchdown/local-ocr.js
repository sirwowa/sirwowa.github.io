let libraryPromise;
function library(){return libraryPromise??=new Promise((resolve,reject)=>{if(window.Tesseract)return resolve(window.Tesseract);const script=document.createElement('script');script.src=new URL('./ocr/tesseract.min.js',import.meta.url);script.onload=()=>resolve(window.Tesseract);script.onerror=()=>{libraryPromise=null;reject(Error('Lokale Texterkennung konnte nicht geladen werden.'));};document.head.append(script);});}
export class LocalOcr{
 async read(photo){let timer;try{return await Promise.race([this.perform(photo),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Lokale Texterkennung dauert zu lange.')),25000);})]);}catch(error){const w=this.worker;this.worker=null;w?.then(worker=>worker.terminate()).catch(()=>{});throw error;}finally{clearTimeout(timer);}}
 async perform(photo){
  const Tesseract=await library();this.worker??=Tesseract.createWorker('eng',1,{workerPath:new URL('./ocr/worker.min.js',import.meta.url).href,corePath:new URL('./ocr/tesseract-core-lstm.js',import.meta.url).href,langPath:new URL('./ocr/lang/',import.meta.url).href,workerBlobURL:false,logger:()=>{}});
  const worker=await this.worker;await worker.setParameters({tessedit_pageseg_mode:'11',preserve_interword_spaces:'1'});
  const image=new Image();await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=reject;image.src=photo;});const scale=Math.min(1,2000/Math.max(image.width,image.height));const canvas=document.createElement('canvas');canvas.width=Math.round(image.width*scale);canvas.height=Math.round(image.height*scale);canvas.getContext('2d').drawImage(image,0,0,canvas.width,canvas.height);
  const {data}=await worker.recognize(canvas);let text=String(data.text||'');
  // A second view reads small names/labels near the lower edge; the saved photo is untouched.
  const crop=document.createElement('canvas'),width=Math.min(2000,image.width),ratio=width/image.width;crop.width=width;crop.height=Math.round(image.height*.5*ratio);const ctx=crop.getContext('2d',{willReadFrequently:true});ctx.drawImage(image,0,image.height*.5,image.width,image.height*.5,0,0,crop.width,crop.height);
  const pixels=ctx.getImageData(0,0,crop.width,crop.height),hist=new Uint32Array(256);for(let i=0;i<pixels.data.length;i+=4)hist[Math.round(pixels.data[i]*.299+pixels.data[i+1]*.587+pixels.data[i+2]*.114)]++;let sum=0,lo=0,hi=255,total=pixels.data.length/4;for(let i=0;i<256;i++){sum+=hist[i];if(sum>=total*.05){lo=i;break;}}sum=0;for(let i=255;i>=0;i--){sum+=hist[i];if(sum>=total*.05){hi=i;break;}}if(hi-lo<30){lo=0;hi=255;}const gain=Math.min(2.5,255/(hi-lo));for(let i=0;i<pixels.data.length;i+=4){const v=Math.max(0,Math.min(255,((pixels.data[i]*.299+pixels.data[i+1]*.587+pixels.data[i+2]*.114)-lo)*gain));pixels.data[i]=pixels.data[i+1]=pixels.data[i+2]=v;}ctx.putImageData(pixels,0,0);
  await worker.setParameters({tessedit_pageseg_mode:'6'});const second=await worker.recognize(crop);return (text+'\n'+String(second.data.text||'')).slice(0,8000);
 }
}
