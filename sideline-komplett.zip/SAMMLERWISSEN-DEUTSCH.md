# Sideline · Sammelkarten & TCG

Alle 41 verlinkten Themen sind hier mit eigenständig verfassten deutschen Erklärungen enthalten. Grundlage für Themen und Original-Links ist die gespeicherte COLLECT.Guide-Übersicht. Die Originalartikel lagen nicht vollständig vor und konnten nicht abgerufen werden; dies ist keine vollständige Übersetzung dieser Website.

Stand: 31.10.2026. Eigene deutsche Erklärungen; keine vollständige Übersetzung der externen Website.

## Einstieg & Grundlagen

Begriffe verstehen, Karten unterscheiden und die Sammlung planen.

### Häufige Fragen zu Sammelkarten

Die wichtigsten Entscheidungen beim Einstieg in eine Kartensammlung.

#### Womit anfangen?

Wähle ein überschaubares Ziel: einen Spieler, ein Team, ein Set oder eine bestimmte Kartenart. Einzelkarten sind gezielter planbar als zufällige Booster oder Boxen. Lege ein Budget fest, das auch Schutzhüllen und Versand berücksichtigt.

#### Welche Angaben brauche ich?

Notiere Spieler oder Kartenname, Sport beziehungsweise Spiel, Jahr, Hersteller, Set und Kartennummer. Varianten und Seriennummern gehören zusätzlich dazu. Eine Nummer wie 7/99 bezeichnet normalerweise das konkrete Exemplar innerhalb einer Auflage, nicht die Kartennummer des Sets.

#### Was macht eine Karte wertvoll?

Nachfrage, genaue Ausgabe, Zustand, Echtheit und nachweisbare Seltenheit wirken zusammen. Eine niedrige Auflage allein bedeutet nicht automatisch einen hohen Marktpreis. Vergleiche gleichartige abgeschlossene Verkäufe und dokumentiere deine tatsächlichen Ausgaben.

#### Ist eine seltene Karte immer teuer?

Nein. Die tatsächliche Nachfrage, der Zustand und die konkrete Ausgabe sind ebenso wichtig wie die Auflage. Eine seltene Karte ohne interessierte Käufer kann schwer zu verkaufen sein.

#### Was bedeutet 12/99?

In der Regel ist dies Exemplar Nummer 12 einer auf 99 Exemplare begrenzten Ausgabe. Es ist normalerweise nicht die Nummer der Karte innerhalb der Set-Checkliste.

#### Ist eine Karte aus dem Booster automatisch makellos?

Nein. Drucklinien, Dellen, Kantenfehler und ungünstige Zentrierung können schon bei der Herstellung oder Verpackung entstehen.

#### Warum erkennt der Scanner meine Parallel-Karte als Base?

Ein Bild kann ausreichend für die Grundkarte sein, während Reflexionen oder ähnliche Designs die Variante unklar lassen. Vergleiche Variantenliste, Seriennummer und Merkmale selbst. Ein Erkennungstreffer ist kein Echtheitsnachweis.

#### Kann ich ohne Internet Karten erkennen lassen?

Deinen lokal gespeicherten Bestand und diese Ratgeber kannst du nach Einrichtung offline ansehen. Die Cardsight-Erkennung, aktuelle Preise und externe Quellen benötigen Internet. Eine Offline-Kopie ist kein Ersatz für ein Backup.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/the-complete-trading-cards-faq/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Lizenzierte und unlizenzierte Sammelkarten unterscheiden

Lizenzen beeinflussen Gestaltung und Vermarktung, beweisen aber keine Seltenheit.

#### Welche Rechte sind gemeint?

Ein Produkt kann unterschiedliche Rechte für Liga, Teammarken oder Spielerabbildungen benötigen. Der Umfang kann je nach Hersteller, Jahr und Produkt variieren. Ein Spielername allein sagt deshalb nicht, welche Logos offiziell verwendet werden dürfen.

#### Ausgabe prüfen

Achte auf Hersteller, Produktbezeichnung und Lizenzhinweise auf Karte oder Verpackung. Unlizenzierte Karten können beispielsweise ohne Teamlogos gestaltet sein. Sie sind nicht automatisch Fälschungen: Entscheidend ist, ob die Ausgabe echt ist und korrekt beschrieben wird.

#### Beim Sammeln und Bewerten

Vergleiche Preise innerhalb derselben Ausgabe und Lizenzsituation. Nutze die offizielle Produktcheckliste zur Identifikation. Übertrage heutige Lizenzverhältnisse nicht pauschal auf ältere Jahrgänge; Hersteller- und Ligavereinbarungen können sich ändern.

#### Praktisches Beispiel

Beispiel: Zwei Karten zeigen denselben Spieler, aber nur eine verwendet offiziell freigegebene Teamlogos. Beide können echte Produkte sein. Sie sind trotzdem unterschiedliche Ausgaben und brauchen getrennte Preisvergleiche.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/beginners-guide-to-licensed-vs-unlicensed-trading-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Arten und Kategorien von Sammelkarten

Karten lassen sich nach Spiel, Sport, Funktion und Ausgabe ordnen.

#### Sportkarten und TCGs

Sportkarten zeigen häufig Spieler, Teams und Ereignisse. Trading Card Games verwenden Karten zusätzlich als Spielmaterial mit Regeln und Deckbau. Daneben gibt es weitere Motive wie Unterhaltung oder Kunst. Diese Gruppen können sich in Produkten überschneiden.

#### Innerhalb eines Sets

Base-Karten bilden häufig die Grundserie. Inserts sind zusätzliche Motiv- oder Themenserien; Parallels variieren eine konkrete Grundkarte. Autogramm- und Memorabilia-Karten haben weitere Merkmale. Die genaue Einteilung bestimmt das jeweilige Produkt.

#### Praktisch sortieren

Erfasse zunächst Sport oder Spiel, dann Hersteller, Jahr, Set und Nummer. Ergänze Variante und Zustand separat. So lassen sich eine vollständige Grundserie und eine Sammlung sämtlicher Sondervarianten als unterschiedliche Ziele verfolgen.

#### Praktisches Beispiel

Beispiel: „American Football → Hersteller → 2025 → Set → Kartennummer → Parallel“ ist eine nachvollziehbare Ordnung. Ein Autogramm ergänzt die Kartenmerkmale, ersetzt aber nicht die Set-Zuordnung.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/types-of-trading-card-genres/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Häufige Begriffe beim Sammelkartensammeln

Häufige Begriffe kurz erklärt – für Einkauf, Ordnung und Preisvergleich.

#### Karte und Ausgabe

Base: Grundkarte eines Sets. Insert: zusätzliche Unterserie. Parallel: Variante einer konkreten Karte. Reprint: erneute Veröffentlichung. Rookie Card: eine frühe Ausgabe eines Spielers nach der jeweiligen Sammelkonvention. Eine genaue Produktprüfung bleibt nötig.

#### Zustand und Schutz

Raw: nicht in einer professionellen Bewertungsverpackung. Slab: versiegelte Hülle eines Prüfdienstes. Centering: Zentrierung des Druckbilds. Sleeve: weiche Schutzhülle. Toploader: stabiler Kartenhalter. „Mint“ ist eine Zustandsbeschreibung, die ohne Anbieter und Prüfung nicht automatisch eine festgelegte Note bedeutet.

#### Handel und Auflage

Comps: geeignete Vergleichsverkäufe. Lot: gemeinsam angebotenes Kartenpaket. Serial Number: Exemplar- und Auflagenkennzeichnung, etwa 12/99. One of One: ein Exemplar einer bestimmten Ausgabe. Coining: Nachweisfoto mit Namenszettel. Keiner dieser Begriffe ist allein eine Preisgarantie.

#### Weitere Begriffe

Auto / Autograph: Autogramm; „on-card“ bedeutet direkt auf der Karte, „sticker auto“ auf einem aufgebrachten Aufkleber. Memorabilia / Relic: Karte mit einem eingearbeiteten Materialstück; die Herkunft ergibt sich aus der Herstellerangabe. Patch: ein Materialstück mit charakteristischem Teil eines Motivs oder Stoffaufbaus. Print Run: Auflagenhöhe. Checklist: Liste der zu einem Produkt oder Set gehörenden Karten. Rainbow: persönliches Sammelziel mit mehreren Parallels derselben Grundkarte; der genaue Umfang muss definiert werden. Population Report: Statistik eines Prüfdienstes zu bewerteten Exemplaren, keine vollständige Zählung aller existierenden Karten.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/trading-card-collecting-common-terms-glossary/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

## Sportkarten & Varianten

Basketball, Kampfsport, Parallels und die Merkmale deiner Karten.

### Refractor-Karten verstehen

So unterscheidest du einen Refractor von einer gewöhnlichen glänzenden Karte.

#### Was ist ein Refractor?

Ein Refractor ist eine Kartenvariante mit einer Oberfläche, die Licht je nach Blickwinkel in unterschiedlichen Farben reflektiert. Die Bezeichnung wird besonders bei Topps-Chrome-Produkten verwendet. Andere Hersteller nutzen eigene Namen. Glanz allein beweist weder einen Refractor noch eine bestimmte Seltenheit.

#### Die genaue Variante finden

Vergleiche Spieler, Kartennummer, Jahr und Set. Prüfe anschließend Muster, Farbe, Rückseitentext und eine mögliche Seriennummer. Eine Farbe kann in mehreren Varianten vorkommen; ein Goldton auf dem Foto reicht als Zuordnung nicht aus. Maßgeblich ist die Checkliste des konkreten Produkts.

#### Beim Scannen

Fotografiere ohne Blitz in weichem Licht und kippe die Karte für ein zweites Vergleichsbild leicht. Wenn die App nur die Grundkarte erkennt, wähle die passende Katalogvariante vor dem Speichern selbst aus. Lasse die Variante offen, solange die Merkmale nicht eindeutig passen.

#### Praktisches Beispiel

Beispiel: Dieselbe Kartennummer gibt es als Grundkarte und als grün gemusterten Refractor. Der grüne Schimmer allein genügt nicht. Erst Muster, Rückseitentext und die offizielle Variantenliste ergeben eine belastbare Zuordnung.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-refractors/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### UFC- und MMA-Karten im Überblick

Bei Kampfsportkarten helfen Produktdaten und genaue Varianten statt nur des Kämpfernamens.

#### Produkt einordnen

Notiere Kämpfer, Hersteller, Jahr, Produkt und Nummer. Lizenz- und Produktverhältnisse können sich über die Jahre ändern; prüfe die konkrete Ausgabe. UFC ist eine Organisation innerhalb des MMA-Sports und nicht die Bezeichnung für jedes Kampfsportprodukt.

#### Kartenarten unterscheiden

Base-Karten, Inserts, Autogramme, Memorabilia und nummerierte Parallels können denselben Kämpfer zeigen. Lies bei Unterschriften und Materialkarten den Echtheits- beziehungsweise Herkunftstext. Ein abgebildetes Materialstück ist nicht automatisch kampfgetragen.

#### Sammlung und Preise

Definiere ein Ziel nach Kämpfer, Gewichtsklasse oder Set. Vergleiche Preise nur bei passender Variante und passendem Zustand. Begriffe wie „Rookie“ müssen zur jeweiligen Produkt- und Sammelkonvention passen und sollten nicht aus einem einzelnen Verkäufertext übernommen werden.

#### Praktisches Beispiel

Beispiel: Ein Stück Stoff auf einer MMA-Karte ist nicht allein deshalb aus einem Kampf. Lies, ob der Hersteller tatsächlich „fight-worn“, eine andere Herkunft oder keine konkrete Nutzung zusichert.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/a-complete-guide-to-ufc-mma-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Seltene Sammelkarten überprüfen

Eine seltene Karte prüfst du über Ausgabe, Merkmale und Herkunft gemeinsam.

#### Identität zuerst

Vergleiche Jahr, Hersteller, Set, Nummer, Bild und Rückseitentext mit zuverlässigen Produktinformationen. Prüfe eine Seriennummer auf plausible Auflage und Position. „1/1“ bezeichnet ein Exemplar einer Ausgabe; andere 1/1-Varianten derselben Grundkarte können daneben existieren.

#### Herkunft und Zertifikate

Bitte um detailreiche eigene Fotos und nachvollziehbare Verkaufsinformationen. Kontrolliere Zertifikatsdaten beim Aussteller. Eine echte Zertifikatsnummer kann kopiert werden; vergleiche daher auch sichtbare Eigenschaften von Karte und Hülle.

#### Unsicherheit behandeln

Verlasse dich bei hohen Beträgen nicht allein auf die App oder ein einzelnes Foto. Ein spezialisierter Händler oder geeigneter Prüfdienst kann weitere Hinweise liefern. Vermeide zerstörerische Tests und dokumentiere Widersprüche vor dem Kauf.

#### Praktisches Beispiel

Beispiel: Eine Karte ist mit 1/1 nummeriert. Prüfe zusätzlich den Namen der Parallel-Version: Von derselben Grundkarte können mehrere unterschiedliche One-of-One-Ausgaben existieren.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-verifying-rare-trading-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Basketballkarten sammeln: Einstieg für Anfänger

Basketballkarten gezielt nach Spielern, Teams oder Sets sammeln.

#### Dein Schwerpunkt

Wähle NBA-Spieler, Lieblingsmannschaft, Jahrgang oder Produkt als Ausgangspunkt. Unterscheide offizielle Produktbezeichnungen und konkrete Ausgaben. Ein Spieler kann in vielen Produkten desselben Jahres mit unterschiedlichen Karten vorkommen.

#### Varianten sauber trennen

Base, Inserts, Autogramme und nummerierte Parallels benötigen getrennte Einträge. Ein Rookie-Schriftzug oder ein vergleichbarer Begriff sollte am konkreten Produkt geprüft werden. Bei Materialkarten erklärt der Rückseitentext, welche Herkunft tatsächlich zugesichert wird.

#### Ordnung im VAULT

Erfasse Set und Nummer und ergänze Team sowie Position, soweit sicher bekannt. Für Set-Sammlungen eignet sich die Reihenfolge nach Kartennummer, für Team-Sammlungen die Mannschaft als Hauptsortierung. Preise nur mit identischer Variante und passendem Zustand vergleichen.

#### Praktisches Beispiel

Beispiel: Du sammelst ein Team. Sortiere zuerst nach Mannschaft, dann nach Spieler und innerhalb des Spielers nach Jahr, Set und Nummer. Für ein komplettes Set sortierst du dagegen direkt nach Nummer.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-basketball-trading-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Parallels, Refractors, Folien- und holografische Sportkarten

Glanz, Farbe und Auflage gemeinsam prüfen, um die richtige Parallel-Version zu wählen.

#### Base, Insert und Parallel

Eine Base-Karte gehört zur Grundserie. Ein Insert bildet meist eine eigene Unterserie. Eine Parallel-Version verändert beispielsweise Farbe, Muster, Folie oder Auflage einer bestimmten Karte. Hersteller verwenden dafür unterschiedliche Namen; nicht jede glänzende Karte ist eine Parallel.

#### Exakte Variante bestimmen

Prüfe Karten- und Setnummer, Vorder- und Rückseite, Farbmuster und mögliche Seriennummer. Angaben wie /99 oder /10 müssen mit der konkreten Checkliste übereinstimmen. Manche Varianten sind unnummeriert; fehlende Seriennummer bedeutet deshalb nicht automatisch Base.

#### Im Scanner korrigieren

Wenn nur die Grundkarte erkannt wird, öffne die Variantenprüfung und wähle einen passenden Katalogeintrag. Vergleiche nach Möglichkeit ein Referenzbild und die Produktliste. Ist keine sichere Zuordnung möglich, behalte „Variante noch nicht bestimmt“ statt eine ähnliche Farbe zu erraten.

#### Praktisches Beispiel

Beispiel: Karten 17/99 und 82/99 können dieselbe Parallel-Ausgabe darstellen. Die erste Zahl ist das konkrete Exemplar; /99 beschreibt die Auflage dieser Variante. Die eigentliche Set-Kartennummer steht separat.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/the-complete-guide-to-types-of-parallels-refractors-and-holographic-hologram-trading-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

## Zustand, Grading & Schutz

Zustand prüfen, Bewertung abwägen und Karten sicher aufbewahren.

### Kartengrading: Einstieg für Anfänger

Grading bewertet den Zustand einer Karte nach den Regeln eines Prüfdienstes.

#### Was wird bewertet?

Typische Kriterien sind Zentrierung, Ecken, Kanten und Oberfläche. Die Bewertung erfolgt nach den Standards des jeweiligen Anbieters. Eine unbeschädigt wirkende Karte erhält nicht automatisch die Höchstnote; kleine Druck- oder Oberflächenfehler können entscheidend sein.

#### Raw oder Slab

„Raw“ bezeichnet eine Karte ohne solche versiegelte Bewertungsverpackung. Ein „Slab“ enthält üblicherweise Karte, Etikett und Zertifikatsnummer. Prüfe die Zertifikatsnummer beim Anbieter und vergleiche Kartendaten sowie gegebenenfalls hinterlegte Bilder.

#### In deiner Sammlung

Speichere Anbieter, Note und Zertifikatsnummer nur nach Abgleich mit der Hülle. Preise einer bewerteten Karte lassen sich nicht ohne Weiteres auf ein unbewertetes Exemplar oder eine andere Note übertragen. Grading garantiert weder einen Preis noch einen späteren Gewinn.

#### Praktisches Beispiel

Beispiel: Eine Raw-Karte und dieselbe Karte in einem PSA-Slab sind getrennte Vergleichsfälle. Auch eine PSA 9 und eine PSA 10 werden separat bewertet; der Zahlenunterschied lässt sich nicht pauschal in einen festen Preisaufschlag umrechnen.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/a-beginners-guide-to-card-grading/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Karten vor dem PSA-Grading selbst einschätzen

Eine sorgfältige Vorprüfung hilft, ungeeignete Grading-Kandidaten auszusortieren.

#### Karte schonend ansehen

Arbeite auf einer sauberen Unterlage mit sauberen, trockenen Händen und halte die Karte an den Kanten. Prüfe sie unter diffusem Licht und aus mehreren Winkeln. Eine Lupe kann helfen, soll aber nicht auf der Oberfläche aufliegen.

#### Vier Bereiche kontrollieren

Betrachte Zentrierung, jede Ecke, sämtliche Kanten und beide Oberflächen. Suche nach Kratzern, Drucklinien, Dellen, Knicken und Verfärbungen. Auch Rückseitenschäden zählen. Notiere Unsicherheiten statt eine gewünschte Note als sicher anzunehmen.

#### Kostenentscheidung treffen

Vergleiche konservative Preisannahmen für mehrere mögliche Noten mit sämtlichen Einreichungskosten. Die Selbstprüfung sagt die PSA-Note nicht verlässlich voraus. Poliere, färbe oder verändere die Karte nicht, um Mängel zu verbergen; das kann die Bewertung beeinflussen.

#### Praktisches Beispiel

Beispiel: Eine mittig gedruckte Karte hat hinten eine kleine Delle. Gute Zentrierung hebt die Delle nicht auf. Dokumentiere beide Merkmale und plane nicht automatisch mit einer Höchstnote.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/how-to-pre-assess-your-trading-cards-for-psa-grading/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Karten professionell bewerten lassen

So bereitest du eine nachvollziehbare und sichere Grading-Einreichung vor.

#### Anbieter und Service wählen

Prüfe beim Anbieter, welche Karten akzeptiert werden, welche Service-Stufen gelten und wie Wertangabe, Versicherung und Rückversand geregelt sind. Gebühren und Bearbeitungszeiten ändern sich. Verwende die aktuellen offiziellen Einreichungsanweisungen.

#### Karten dokumentieren

Erstelle vor dem Versand Fotos und eine Liste mit genauer Identifikation. Verwende die vorgeschriebenen Hüllen und Halter; die Verpackung soll Bewegung und Feuchtigkeit verhindern. Beschrifte oder beklebe die Karte selbst nicht.

#### Nach der Rückkehr

Vergleiche zurückgesandte Karten und Zertifikate mit deiner Liste. Trage Anbieter, Note und Zertifikatsnummer in den VAULT ein. Prüfe anschließend neue Vergleichspreise für genau diese Note. Die Einreichung kann wirtschaftlich auch zu einem Verlust führen.

#### Praktisches Beispiel

Praktischer Ablauf: Karte fotografieren, eindeutig beschreiben, aktuellen Service wählen, nach Anbieteranleitung verpacken, versichert passend zum Wert versenden und den Rücklauf anhand der eigenen Liste kontrollieren.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-card-grading/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Lohnt sich Grading für diese Karte?

Grading lohnt sich nicht bei jeder Karte und nicht bei jeder erreichbaren Note.

#### Zweck bestimmen

Manche Sammler möchten eine persönliche Karte geschützt und dokumentiert haben. Wer auf einen höheren Verkaufserlös hofft, muss anders rechnen. Trenne den persönlichen Nutzen von einer rein wirtschaftlichen Entscheidung.

#### Konservativ kalkulieren

Vergleiche den Raw-Wert mit realistischen Verkaufspreisen nach Bewertung. Ziehe Prüfgebühr, Versand, Versicherung und Verkaufsgebühren ab. Rechne auch ein Szenario mit einer niedrigeren als erhofften Note durch. Ein erwarteter Gewinn nur bei Höchstnote ist riskant.

#### Alternative wählen

Für günstige Karten können passende Hülle und stabiler Halter ausreichen. Bei Zweifeln an Echtheit oder Veränderungen ist fachliche Prüfung wichtiger als eine optimistische Zustandsnote. Ein App-Scan ersetzt weder Echtheitsprüfung noch professionelle Bewertung.

#### Praktisches Beispiel

Rechenbeispiel: 40 € Raw-Wert, 70 € erwarteter Verkauf nach Grading und 35 € Gesamtkosten bedeuten bereits 5 € weniger als ein Raw-Verkauf – noch vor zusätzlichen Verkaufsgebühren.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/should-i-get-this-trading-card-graded/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Beckett und PSA im Vergleich

Bewertungsanbieter unterscheiden sich in Standards, Services und Marktakzeptanz.

#### PSA und Beckett einordnen

PSA und Beckett gehören zu bekannten Bewertungsanbietern. Bezeichnungen und Notensysteme sind anbieterspezifisch. Bei manchen Services werden Teilnoten ausgewiesen; Verfügbarkeit und Bedingungen prüfst du direkt beim jeweiligen Anbieter.

#### Preise passend vergleichen

Eine identische Zahl auf zwei unterschiedlichen Etiketten bedeutet nicht zwangsläufig denselben Marktpreis. Vergleiche Anbieter, Note, genaue Karte und gegebenenfalls Teilnoten. Auch die Nachfrage nach einem bestimmten Slab kann schwanken.

#### Entscheidung treffen

Prüfe Gesamtkosten, akzeptierte Karten, Versand, Versicherung und aktuelle Leistungen. Für die Sammlung können Gestaltung und eigene Vorlieben wichtig sein. Es gibt keinen Anbieter, der für jede Karte automatisch das beste wirtschaftliche Ergebnis liefert.

#### Praktisches Beispiel

Beispiel: Vergleiche eine bestimmte Karte in PSA 9 mit Verkäufen derselben Karte in PSA 9. Ein BGS-9-Verkauf ist ein zusätzlicher eigener Vergleich, kein automatischer Ersatz.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/beckett-vs-psa-a-quick-breakdown/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### PSA-Kartengrading verstehen

PSA-Noten sind Zustandsurteile nach den Kriterien des Anbieters.

#### Note verstehen

PSA verwendet für bewertbare Karten eine Zustandsbewertung nach eigenen Standards. Höhere Zahlen stehen grundsätzlich für einen besseren beurteilten Zustand. Die aktuelle offizielle Skala und Sonderkennzeichnungen findest du beim Anbieter.

#### Zertifikat überprüfen

Vergleiche Zertifikatsnummer, Kartenbeschreibung und gegebenenfalls verfügbare Bilder beim Anbieter mit der vorliegenden Hülle. Prüfe auch den Slab auf Auffälligkeiten. Eine gültige Nummer allein beweist nicht, dass die gezeigte Hülle und Karte echt sind.

#### In der App dokumentieren

Speichere Anbieter, Note und Nummer getrennt von der Kartenvariante. Nutze für den Marktwert Verkäufe genau dieser Ausgabe mit passender Bewertung. Der Service kann weder den späteren Verkaufserlös garantieren noch alle Kaufentscheidungen ersetzen.

#### Praktisches Beispiel

Beispiel: Nummer und Kartenname im Zertifikatsregister passen, das dort hinterlegte Kartenbild zeigt aber eine andere Seriennummer als dein Angebot. Kläre die Abweichung vor dem Kauf.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-psa-card-grading/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Sammelkarten aufbewahren und schützen

Schutz vor Druck, Reibung, Feuchtigkeit und Licht bewahrt den Zustand.

#### Passende Hüllen wählen

Verwende für Sammelkarten geeignete, möglichst PVC-freie Materialien. Eine weiche Innenhülle schützt vor Reibung; ein passender stabiler Halter kann zusätzlichen mechanischen Schutz geben. Zu enge Halter oder das Hineindrücken mit Kraft können Kanten beschädigen.

#### Sicher lagern

Lagere trocken, temperaturstabil und ohne direkte Sonne. Vermeide schwere Lasten auf Karten und überfüllte Ordner. Wähle Formate passend zur Kartendicke, besonders bei dicken Memorabilia-Karten. Kontrolliere Aufbewahrungsorte gelegentlich auf Feuchtigkeit.

#### Transport und Dokumentation

Sichere Karten im Versand gegen Bewegung und Knicken und halte Klebeband von der Karte fern. Fotografiere wertvolle Stücke und sichere eine Bestandskopie. Eine digitale Sammlung ersetzt keine geeignete physische Aufbewahrung oder Versicherung.

#### Praktisches Beispiel

Beispiel: Eine dicke Patch-Karte passt nicht in jeden Standardhalter. Wähle den Halter nach der tatsächlichen Kartendicke und drücke die Karte niemals mit Kraft hinein.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-trading-card-storage-protection/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Zentrierung von Sammelkarten beurteilen

Zentrierung beschreibt die Lage des Druckbilds innerhalb des Kartenformats.

#### Ränder vergleichen

Betrachte den linken und rechten sowie oberen und unteren Rand. Vorder- und Rückseite können unterschiedlich zentriert sein. Bei randlosen oder asymmetrischen Designs ist die Beurteilung schwieriger; ein Rahmen im Motiv muss nicht die Schnittgrenze darstellen.

#### Foto richtig aufnehmen

Fotografiere die Karte gerade von oben und vermeide Perspektivverzerrung. Ein schräges Kamerabild kann ungleiche Ränder vortäuschen. Vergleiche bei Bedarf mit einer sicheren Referenz desselben Designs. Eine App-Rahmenanzeige ist kein geeichtes Messgerät.

#### Bedeutung fürs Grading

Bewertungsanbieter haben eigene Toleranzen und Kriterien. Eine geschätzte Randquote garantiert keine Note, da auch Oberfläche, Ecken und Kanten zählen. Nutze die aktuelle offizielle Beschreibung des gewünschten Prüfdienstes.

#### Praktisches Beispiel

Beispiel: Bei einer Aufnahme von schräg links erscheint der linke Rand anders breit. Richte Kamera und Karte parallel aus, bevor du aus dem Foto auf einen Zentrierungsfehler schließt.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-centering-on-trading-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Drucklinien auf Sammelkarten erkennen

Drucklinien sind mögliche Produktionsmerkmale und keine automatische Kartenvariante.

#### Linien erkennen

Gerade Linien können in Folien- oder Druckschichten sichtbar sein und sich je nach Lichteinfall zeigen. Nicht jede Linie ist eine Drucklinie: Kratzer, Halterreflexe oder Folienmuster können ähnlich aussehen. Untersuche die Karte vorsichtig aus mehreren Winkeln.

#### Zustand dokumentieren

Fotografiere die betreffende Stelle mit weichem seitlichem Licht. Beschreibe sichtbare Merkmale im Verkauf sachlich. Versuche nicht, eine Linie durch Reiben, Polieren oder chemische Behandlung zu entfernen; das kann zusätzliche Schäden verursachen.

#### Wert und Bewertung

Eine Produktionslinie ist nicht automatisch eine wertvolle Fehlprägung oder seltene Sonderausgabe. Ihre Auswirkung auf Grading und Preis hängt von Ausprägung und Anbieter ab. Vergleiche passende Beispiele und hole bei Unsicherheit fachliche Einschätzung ein.

#### Praktisches Beispiel

Beispiel: Eine feine Linie bleibt bei mehreren Lichtwinkeln an derselben Stelle sichtbar. Das ist ein Anlass für eine genaue Zustandsprüfung, aber noch kein Beweis für einen wertvollen Druckfehler.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-print-lines-on-trading-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

## Marktwert, Kaufen & Verkaufen

Vergleichspreise finden, sicher handeln und das Budget im Blick behalten.

### Betrug mit Nachweisfotos und KI-generierten Karten vermeiden

Nachweisbilder helfen beim Kauf, ersetzen aber keine Prüfung des Verkäufers.

#### Was ein Nachweisfoto zeigt

Beim „Coining“ liegt ein Zettel mit Namen und Datum neben der angebotenen Karte. Das soll zeigen, dass der Verkäufer die Karte besitzt. Auch solche Bilder können kopiert oder digital verändert sein. Ein überzeugendes Foto ist deshalb kein alleiniger Echtheitsnachweis.

#### Mehrere Hinweise prüfen

Bitte bei teuren Karten um aktuelle Vorder- und Rückseitenfotos sowie ein kurzes Video mit einer individuell gewünschten Bewegung. Prüfe Bewertungshistorie, frühere Angebote, Preis und die Übereinstimmung von Kartendetails. Eine Zertifikatsnummer kann ebenfalls kopiert sein.

#### Sicher bezahlen

Nutze nachvollziehbare Verkaufsplattformen und deren geeigneten Käuferschutz. Sei vorsichtig bei Zeitdruck und Aufforderungen, außerhalb der Plattform zu bezahlen. Bewahre Angebot, Nachrichten und Zahlungsbeleg auf. Eine Bildanalyse der App kann Betrug nicht ausschließen.

#### Praktisches Beispiel

Beispiel: Ein Verkäufer zeigt einen Namenszettel, lehnt aber ein neues Foto mit einem von dir genannten Stichwort ab. Das beweist noch keinen Betrug, ist bei einem teuren Kauf aber ein Grund, vorerst nicht zu bezahlen.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-avoiding-coined-image-scams-ai-generated-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Große Kartenbestände gefunden oder geerbt: Wert und Gewinn einschätzen

Große Bestände zuerst ordnen und prüfen, bevor du einen Preis festlegst.

#### Bestand vorsortieren

Trenne Sportarten und Spiele, dann Hersteller, Jahrgänge und Sets. Lege auffällige Rookie-Karten, Autogramme, nummerierte Varianten und ältere Karten gesondert ab. Entferne keine Schutzverpackungen, wenn dadurch Schäden entstehen könnten.

#### Stichproben bewerten

Identifiziere wertverdächtige Karten exakt und vergleiche tatsächlich verkaufte gleichartige Exemplare. Ein hoher Angebotspreis ist kein Verkaufspreis. Große Mengen gewöhnlicher Karten lassen sich häufig nur mit einem erheblichen Mengenabschlag verkaufen.

#### Verkaufsweg wählen

Einzelverkäufe lohnen sich eher bei ausreichend wertvollen Karten. Für große Restbestände können Set-Lots, Team-Lots oder ein Gesamtverkauf sinnvoll sein. Dokumentiere Zustand und fehlende Karten. Rechne Versand, Gebühren und deinen Zeitaufwand mit ein.

#### Praktisches Beispiel

Beispiel: Sortiere 1.000 Karten zunächst nach Sport und Jahr. Prüfe die auffälligen Stücke einzeln. Den verbleibenden Bestand bewertest du als Lot, statt einen Einzelkartenpreis mit 1.000 zu multiplizieren.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/found-or-inherited-bulk-trading-cards-guide-to-value-profit/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Auf Whatnot verkaufen: Einstieg für Anfänger

Live-Verkäufe vorbereiten: klare Beschreibung, nachvollziehbare Abläufe und Kostenkontrolle.

#### Vor dem ersten Stream

Informiere dich direkt bei Whatnot über die aktuellen Teilnahmebedingungen und Verkaufsregeln. Sortiere die Karten vorab und halte Hüllen, Versandmaterial und eine Bestandsliste bereit. Zeige Zustand und Besonderheiten in gutem Licht.

#### Angebote transparent machen

Beschreibe genau, welche Karte oder welcher Artikel verkauft wird. Erkläre bei besonderen Verkaufsformaten die Regeln vor dem Kauf und prüfe, ob sie auf der Plattform zulässig sind. Versprich keine garantierten Gewinne oder Kartenwerte.

#### Erlös richtig berechnen

Ziehe Plattform- und Zahlungsgebühren, Verpackung, Versandanteile und Einkaufskosten ab. Die Regeln und Gebühren können sich ändern; dieser Ratgeber nennt deshalb keine festen Sätze. Sichere Zuordnung und pünktlicher Versand sind wichtiger als ein hoher Auktionsrhythmus.

#### Praktisches Beispiel

Rechenbeispiel: 30 € Verkauf minus 15 € Einkauf minus zusammen 6 € Gebühren, Verpackung und eigene Versandkosten ergeben 9 € vor weiteren Kosten und Steuern. Die 6 € sind ein Rechenbeispiel, kein Whatnot-Gebührensatz.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-selling-on-whatnot-for-beginners/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Den Wert deiner Sammelkarten bestimmen

Ein belastbarer Preisvergleich beginnt mit der exakten Identität deiner Karte.

#### Gleiche Karte vergleichen

Jahr, Set, Kartennummer, Parallel und Grading müssen zum Vergleich passen. Vergleiche keine Base-Karte mit einer nummerierten Parallel-Version und keine unbewertete Karte mit einer Höchstnote. Prüfe Bilder und Beschreibung des Verkaufs.

#### Verkäufe statt Wunschpreise

Abgeschlossene, tatsächlich bezahlte Verkäufe sind aussagekräftiger als laufende Angebote. Ein Durchschnitt hängt stark von Zeitraum, Stichprobengröße und Ausreißern ab. Bei wenigen Verkäufen ist auch ein einzelner Vergleichspreis nur ein Anhaltspunkt.

#### Kosten und Währung

Trenne Kartenpreis, Versand, Gebühren und mögliche Einfuhrkosten. Eine Umrechnung in Euro sollte den verwendeten Wechselkurs beziehungsweise Abrufzeitpunkt berücksichtigen. Ein Marktwert ist eine Schätzung und keine Zusage, dass du diesen Betrag beim Verkauf erhältst.

#### Praktisches Beispiel

Rechenbeispiel: Drei geeignete Verkäufe zu 20 €, 25 € und 30 € ergeben einen arithmetischen Durchschnitt von 25 €. Sind es unterschiedliche Parallels oder Zustände, ist dieser Durchschnitt kein brauchbarer Wert für deine Karte.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/determine-the-value-of-your-trading-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Verkaufsfotos mit Namensnachweis erstellen („Coining“)

Ein gutes Nachweisfoto dokumentiert Karte, Verkäufer und Zeitpunkt nachvollziehbar.

#### Foto aufbauen

Lege einen handgeschriebenen Zettel mit Nutzernamen und aktuellem Datum neben die Karte, ohne die Karte zu verdecken. Verwende einen sauberen, ruhigen Hintergrund und indirektes Licht. Persönliche Anschrift oder andere unnötige Daten gehören nicht auf das Foto.

#### Details zeigen

Ergänze scharfe Aufnahmen von Vorderseite, Rückseite, Ecken und sichtbaren Schäden. Bei einem Slab sollten Etikett und Zertifikatsnummer lesbar sein. Beschreibe Mängel zusätzlich im Angebot; ein Nachweisfoto ersetzt keine Zustandsbeschreibung.

#### Grenzen verstehen

Ein Zettel im Bild beweist nicht allein die Echtheit oder einen sicheren Versand. Käufer können um eine individuelle zusätzliche Aufnahme bitten. Nutze für öffentliche Verkaufsfotos ein eigenes Bild; Katalogbilder zeigen nicht den tatsächlichen Zustand deines Exemplars.

#### Praktisches Beispiel

Beispiel für den Zettel: „Verkäufername · 31.10.2026“. Der Zettel liegt neben der Karte. Für einen konkreten Interessenten kannst du dessen gewünschtes Stichwort ergänzen, ohne deine Adresse öffentlich zu zeigen.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/how-to-correctly-coin-your-trading-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Sammelkarten behalten oder verkaufen?

Behalten oder verkaufen: Ziele, Kosten und Unsicherheit bewusst abwägen.

#### Sammlungsziel festlegen

Frage dich, ob die Karte für deine persönliche Sammlung wichtig ist oder vor allem als Handelsobjekt gedacht war. Eine Lieblingskarte muss keinen finanziellen Ertrag liefern. Lege für Verkaufsentscheidungen möglichst vorher Kriterien und ein Budget fest.

#### Markt realistisch betrachten

Spielerleistungen, Verletzungen, neue Produkte und Nachfrage können Preise verändern. Solche Entwicklungen sind nicht zuverlässig vorhersehbar. Vergangene Höchstpreise sind keine Garantie für eine Erholung und seltene Karten können lange ohne Käufer bleiben.

#### Nettoerlös vergleichen

Berechne den voraussichtlichen Verkaufserlös nach Gebühren, Versand und weiteren Kosten. Vergleiche mehrere passende Verkäufe und beachte, wie schnell du verkaufen möchtest. Halte Einkauf und Verkauf getrennt vom angezeigten geschätzten Marktwert fest.

#### Praktisches Beispiel

Beispiel: Du hast 80 € bezahlt und könntest heute 100 € erzielen. Nach 15 € Kosten bleiben 85 € vor weiteren Abgaben. Der sichtbare Preiszuwachs von 20 € entspricht deshalb nicht deinem tatsächlichen Gewinn.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/trading-cards-should-i-hold-or-sell/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

## Pokémon

Vom ersten Sammelziel bis zu Varianten, Echtheit und Spielen.

### Pokémon-Kartengrading für Anfänger

Bei Pokémon zählen konkrete Ausgabe, Sprache und Zustand ebenso wie die Note.

#### Karte exakt bestimmen

Notiere Name, Set, Sammlernummer, Sprache und gegebenenfalls besondere Druckausgabe. Holo- und Reverse-Holo-Versionen dürfen nicht verwechselt werden. Sonderkarten und Promos haben oft eigene Kennzeichnungen und Nummerierungen.

#### Zustand prüfen

Achte auf weiße Stellen an den Kanten, Kratzer auf Folien, Dellen, Knicke und Zentrierung. Untersuche Vorder- und Rückseite. Eine frisch aus dem Booster gezogene Karte kann bereits Produktionsfehler besitzen.

#### Grading abwägen

Vergleiche passende Verkäufe für Sprache, Ausgabe, Anbieter und Note. Addiere alle Kosten und kalkuliere mehrere Notenszenarien. Die für ein Spiel erlaubte Nutzung und die Attraktivität für Sammler sind verschiedene Dinge.

#### Praktisches Beispiel

Beispiel: Eine deutsche Reverse-Holo-Ausgabe darf nicht mit einer englischen Sonderillustration desselben Pokémon bewertet werden. Sprache, Nummer und Folienart müssen vor der Preisprüfung feststehen.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/beginners-guide-to-pokemon-card-grading/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Pokémon-Kartentypen im Überblick

Pokémon-Karten lassen sich nach Spielfunktion und nach Sammlervariante ordnen.

#### Spielfunktionen

Zu den grundlegenden Gruppen gehören Pokémon-, Trainer- und Energiekarten. Pokémon greifen im Spiel an; Trainer unterstützen den Spielablauf, Energie bezahlt typischerweise Angriffskosten. Die genauen Regeln und Untergruppen stehen im aktuellen offiziellen Regelwerk.

#### Sammlervarianten

Eine Karte kann in verschiedenen Illustrationen, Folienausführungen, Sprachen oder Sonderausgaben vorkommen. Seltenheitssymbole und Bezeichnungen unterscheiden sich zwischen Produktgenerationen. „Glänzend“ ist keine eindeutige Seltenheitsklasse.

#### Sauber katalogisieren

Verwende Set und Sammlernummer zusammen mit Sprache und Variante. Sortiere spielbezogene Kategorien getrennt von Zustands- oder Preisangaben. Bei Unklarheiten hilft der Vergleich mit der offiziellen Kartenliste des konkreten Sets.

#### Praktisches Beispiel

Beispiel: „Trainerkarte“ beschreibt die Spielfunktion, „Reverse Holo“ die Ausführung. Die Angaben beantworten unterschiedliche Fragen und können zusammen zu einer Karte gehören.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/complete-guide-to-pokemon-card-types/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Pokémon-Karten sammeln: ausführlicher Einstieg

Eine Pokémon-Sammlung wird mit einem klaren Ziel leichter überschaubar.

#### Sammlungsziel wählen

Du kannst ein Lieblings-Pokémon, einen Illustrator, ein Set, eine Sprache oder ein Budget als Schwerpunkt wählen. Lege fest, ob du nur die nummerierten Standardkarten oder auch zusätzliche Varianten sammeln möchtest.

#### Gezielt einkaufen

Booster bieten Zufall, Einzelkarten bieten Kontrolle über fehlende Motive. Vergleiche Zustand und Ausgabe und kaufe bei nachvollziehbaren Quellen. Ein hoher Preis beweist weder Echtheit noch eine gute langfristige Wertentwicklung.

#### Bestand pflegen

Dokumentiere jede Ausgabe separat und schütze wertvolle Karten passend. Halte Doppelstücke und Wunschliste getrennt. Wenn ein Set mehrere Holo-Versionen besitzt, definiere vorab, welche davon zu deinem persönlichen Komplettziel gehören.

#### Praktisches Beispiel

Beispiel: „Alle Motive meines Lieblings-Pokémon auf Deutsch bis 20 € pro Karte“ ist ein begrenztes Sammelziel. „Jede Pokémon-Karte“ ist dagegen ohne weitere Grenzen kaum planbar.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/an-in-depth-guide-to-pokemon-card-collecting/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Mit welchen Pokémon-TCG-Karten anfangen?

Für den Start brauchst du keinen teuren Boosterbestand.

#### Ein kleines Ziel wählen

Beginne mit einem Lieblingsmotiv, einem erschwinglichen Set-Ausschnitt oder einer Liste bestimmter Pokémon. Ein vollständiges Set mit sämtlichen Sonderillustrationen kann erheblich teurer sein als die Grundserie.

#### Spielen oder sammeln?

Für den Spieleinstieg ist ein geeigneter vorgefertigter Decktyp oft planbarer als zufällige Booster. Für das Sammeln bieten Einzelkarten einen gezielten Einstieg. Prüfe bei Spielprodukten das aktuelle Format und den genauen Packungsinhalt.

#### Erste Käufe absichern

Achte auf Sprache, Zustand, Ausgabe und seriöse Verkäufer. Kaufe zunächst kleine Mengen und lerne die Kennzeichnungen kennen. Plane einfache Hüllen und einen passenden Ordner mit ein, statt das gesamte Budget in Karten zu stecken.

#### Praktisches Beispiel

Beispiel: Für ein spielbares Deck kaufe die benötigte regelgleiche Karte in einer günstigeren Ausgabe. Für eine Motivsammlung kann dagegen genau eine bestimmte Illustration das Ziel sein.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/what-pokemon-tcg-should-i-collect-how-should-i-start/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Pokémon-TCG auf Turnierniveau spielen

Wettbewerbsfähiges Spielen braucht aktuelle Regeln und Übung, nicht nur seltene Karten.

#### Format und Regeln

Informiere dich bei offiziellen Pokémon-TCG-Quellen über aktuelle Formate, Rotation, zulässige Karten und Turnierregeln. Diese Vorgaben ändern sich. Eine ältere starke Karte kann in einem bestimmten Format nicht mehr zugelassen sein.

#### Deckplan verstehen

Ein Deck sollte einen klaren Spielplan und ausreichend Möglichkeiten für einen verlässlichen Start haben. Prüfe, welche Angreifer, Unterstützer und Ressourcen zusammenarbeiten. Eine teure Illustrationsvariante verbessert die Spielwirkung gegenüber derselben regelgleichen Karte nicht.

#### Üben und anpassen

Teste typische Spielsituationen und notiere, weshalb Partien verloren gehen. Achte auf Zeitmanagement, korrekte Abläufe und den Zustand deiner Hüllen. Kaufe gezielt fehlende spielbare Karten, statt für einen bestimmten Deckbaustein auf Booster-Glück zu setzen.

#### Praktisches Beispiel

Beispiel: Wenn dein Deck oft keine Startaktion findet, prüfe seine Konsistenz. Eine seltenere Illustration derselben Karte ändert daran nichts. Analysiere die Verteilung und die Regeln statt nur den Kartenpreis.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-competitive-pokemon-tcg-card-games/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Deine Pokémon-TCG-Karten bewerten

Wertschätzung bei Pokémon setzt die richtige Druckausgabe voraus.

#### Kartendaten aufnehmen

Erfasse Set, Nummer, Sprache, Folienvariante und gegebenenfalls Edition. Vergleiche Sonderillustrationen nicht allein nach dem Pokémon-Namen. Prüfe bei bewerteten Karten außerdem Anbieter, Note und Zertifikatsdaten.

#### Zustand berücksichtigen

Kratzer, weiße Kanten, Knicke und Oberflächenabdrücke können den Preis erheblich beeinflussen. Ein Foto der Vorderseite allein reicht zur Zustandsbewertung nicht aus. Vergleiche möglichst ähnlich erhaltene Exemplare.

#### Preisrahmen bilden

Nutze mehrere passende abgeschlossene Verkäufe, sofern vorhanden. Erkenne Angebote für Kartenpakete, andere Sprachen oder abweichende Zustände als ungeeignete Vergleiche. Dokumentiere Datum und Währung; ein Preis von gestern ist keine feste Zusage für morgen.

#### Praktisches Beispiel

Beispiel: Notiere zum Vergleich „Set, Nummer, Deutsch, Reverse Holo, leicht bespielt“. Entferne aus den Treffern andere Sprachen, Zustände und Ausführungen, bevor du einen Durchschnitt bildest.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/how-to-evaluate-your-pokemon-tcg-trading-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Gefälschte Pokémon-Karten erkennen

Mehrere Merkmale vergleichen – kein einzelner Heimtest beweist Echtheit.

#### Mit einer sicheren Referenz vergleichen

Prüfe Schriftbild, Druckschärfe, Farben, Rückseite, Nummerierung und Folieneffekt gegen eine verlässliche Referenz derselben Ausgabe und Sprache. Echte Karten unterscheiden sich je nach Generation; pauschale Farbregeln können irreführen.

#### Angebot und Herkunft prüfen

Unplausible Packungsinhalte, ungewöhnlich niedrige Preise und widersprüchliche Verkäuferangaben sind Warnzeichen. Auch Kopien können echte Kartennummern und Zertifikatsnummern zeigen. Ein Treffer in einer Bilderkennung beweist deshalb keine Echtheit.

#### Nicht beschädigen

Reiße oder knicke eine fragliche Karte nicht für einen „Test“. Licht- und Materialtests haben Grenzen. Bei wertvollen oder strittigen Exemplaren sind seriöse Fachhändler oder geeignete Prüfdienste die bessere Anlaufstelle.

#### Praktisches Beispiel

Beispiel: Eine angebliche Karte zeigt eine Folierung, die nicht zu ihrer belegten Ausgabe passt. Prüfe dieselbe Ausgabe in einer verlässlichen Referenz, bevor du allein aus einem ähnlichen Namen auf Echtheit schließt.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-identifying-fake-pokemon-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Pokémon-TCG mit kleinem Budget sammeln

Mit einem festen Plan lässt sich auch ein kleines Sammelbudget sinnvoll nutzen.

#### Budget aufteilen

Setze eine monatliche Obergrenze und berücksichtige Versand sowie Schutzmaterial. Ein Lieblingsmotiv oder bestimmte günstige Karten sind oft besser planbar als der Versuch, jede neue Erweiterung vollständig zu sammeln.

#### Einzelkarten und Tausch

Vergleiche Einzelkartenpreise und bündele Bestellungen, wenn das nach Versandkosten tatsächlich günstiger ist. Tausche Doppelstücke nur nach beiderseitig klarer Bewertung von Ausgabe und Zustand. Eine große gemischte Menge ist nicht automatisch ein gutes Angebot.

#### Kaufdruck vermeiden

Limitierte Aktionen und soziale Medien können Zeitdruck erzeugen. Prüfe vor dem Kauf, ob die Karte wirklich zu deinem Ziel gehört. Spieleffekt und teure Sonderillustration sind oft voneinander trennbar; für ein Deck genügt häufig eine günstigere Ausgabe.

#### Praktisches Beispiel

Beispiel: Von 30 € Monatsbudget reservierst du 5 € für Versand und Schutz. Die verbleibenden 25 € setzt du gezielt für deine Wunschliste ein. Das ist planbarer als ein spontaner Booster-Kauf nach jedem Video.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-collecting-pokemon-tcg-on-a-budget/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

## Yu-Gi-Oh! & weitere TCGs

Yu-Gi-Oh!, Magic und One Piece gezielt kennenlernen.

### Preise von Yu-Gi-Oh!-Karten verstehen

Bei Yu-Gi-Oh! entscheidet die genaue Druckfassung stark über den Vergleichspreis.

#### Identität ablesen

Verwende Kartenname, Set-Code, Sprache, Edition und Seltenheitsstufe. Derselbe Kartenname kann über viele Produkte hinweg erneut gedruckt werden. Eine häufige Neuauflage und eine ältere seltene Ausgabe sind nicht derselbe Preisvergleich.

#### Nachfrage einordnen

Spielstärke, aktuelle Formate, Wiederveröffentlichungen und Sammlerinteresse können die Nachfrage beeinflussen. Die offizielle Liste verbotener und limitierter Karten kann sich ändern. Hole aktuelle Regeln beim Herausgeber ein, statt eine alte Deckliste als Maßstab zu verwenden.

#### Verkäufe vergleichen

Suche abgeschlossene Verkäufe derselben Druckfassung und eines ähnlichen Zustands. Trenne Einzelkarten von Playsets oder gemischten Lots. Berücksichtige Versand und Währung und erwarte bei selten gehandelten Ausgaben keine punktgenaue Marktwertschätzung.

#### Praktisches Beispiel

Beispiel: Zwei Drucke mit identischem Kartennamen besitzen unterschiedliche Set-Codes. Der Preis des älteren seltenen Drucks kann nicht auf die häufigere Neuauflage übertragen werden.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-yu-gi-oh-card-prices/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Häufige Begriffe aus Yu-Gi-Oh!

Ein kleines Wörterbuch für den Yu-Gi-Oh!-Einstieg.

#### Kartentypen und Decks

Monster-, Zauber- und Fallenkarten erfüllen unterschiedliche Aufgaben. Main Deck und Extra Deck sind getrennte Bereiche mit eigenen Regeln. Ein Archetyp bezeichnet eine Gruppe von Karten mit typischerweise zusammenhängenden Namen oder Effekten.

#### Häufige Spielbegriffe

„Staple“ meint eine vielseitig verwendbare Karte. „Hand Trap“ ist eine informelle Bezeichnung für bestimmte aus der Hand nutzbare Störeffekte. „Negate“ bezeichnet das Annullieren nach den jeweiligen Regeln. Umgangssprache ersetzt nicht den exakten Kartentext.

#### Sammlerbegriffe

Set-Code, Edition und Seltenheitsstufe identifizieren die Druckfassung. „Reprint“ meint eine Wiederveröffentlichung. Eine Karte mit demselben Namen muss nicht dieselbe Ausgabe oder denselben Wert besitzen. Prüfe Zweifelsfälle in der offiziellen Kartendatenbank.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/a-guide-to-common-terms-for-yu-gi-oh/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Yu-Gi-Oh!: Einführung für Anfänger

Yu-Gi-Oh! lässt sich über Grundregeln und ein überschaubares Deck kennenlernen.

#### Grundidee verstehen

Das Spiel verwendet Monster-, Zauber- und Fallenkarten mit unterschiedlichen Aktionen und Zeitpunkten. Für Deckgrößen, Beschwörungen und Siegbedingungen ist das aktuelle offizielle Regelwerk maßgeblich. Ein Überblick kann die vollständigen Regeln nicht ersetzen.

#### Mit einem Plan starten

Ein geeignetes vorgefertigtes Deck kann Zusammenhänge leichter zeigen als eine zufällige Kartensammlung. Lerne zunächst die eigenen Karten und häufige Abläufe. Ergänze erst danach gezielt fehlende Bausteine.

#### Sammeln und Spielen trennen

Für ein Deck zählt die regelkonforme spielbare Ausgabe; für Sammler können Edition, Sprache und Seltenheit entscheidend sein. Prüfe beim Kauf Format und aktuelle Einschränkungen. Nicht jede seltene Karte ist spielstark, nicht jede spielstarke Karte ist teuer.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/an-introduction-beginners-guide-to-yu-gi-oh/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Universell nützliche Yu-Gi-Oh!-Karten („Staples“)

Staples sind vielseitige Werkzeuge – ihre Eignung hängt vom Format und Deck ab.

#### Was ist eine Staple?

So nennt die Spielgemeinschaft Karten, die in unterschiedlichen Strategien nützlich sein können. Dazu können Such-, Schutz- oder Störeffekte gehören. Es ist keine offizielle Seltenheitsstufe und keine Garantie, dass eine Karte in jedes Deck passt.

#### Aktuelle Zulässigkeit prüfen

Kontrolliere die offizielle Liste verbotener und limitierter Karten sowie das gespielte Format. Region, Turnierart und Regelstand können relevant sein. Eine historische Empfehlung ist keine verlässliche Aussage über die heutige Spielbarkeit.

#### Gezielt auswählen

Prüfe Synergien, verfügbare Plätze und das erwartete Umfeld. Günstigere Druckfassungen können denselben Spieleffekt bieten. Kaufe keine teure Sonderausgabe allein deshalb, weil sie in einer alten Liste als unverzichtbar beschrieben wurde.

#### Konkrete Beispiele zum Kennenlernen

Ash Blossom & Joyous Spring: ein häufig als Hand Trap bezeichneter Störeffekt. Infinite Impermanence: ein Beispiel für eine Karte zum Unterbrechen gegnerischer Effekte. Called by the Grave: ein Beispiel für Interaktion mit Karten im Friedhof. Book of Moon: ein vielseitiges Werkzeug zum Verdecken eines Monsters. Diese Beispiele erklären den Begriff; sie sind keine aktuelle Deckempfehlung und keine Zusage der Zulässigkeit. Lies jeweils den genauen Kartentext und die aktuelle offizielle Verbots- und Limitierungsliste.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/a-list-of-yu-gi-oh-staple-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Yu-Gi-Oh!-Boosterpacks im Überblick

Booster unterscheiden sich nach Produkt und Inhalt; Zufall bleibt Zufall.

#### Produktbeschreibung lesen

Prüfe Set-Name, Sprache, Erscheinungsjahr und die offizielle Beschreibung. Hauptsets, Sonderprodukte und Wiederveröffentlichungen können andere Inhalte und Seltenheitsverteilungen besitzen. Die Packungsbezeichnung allein erklärt nicht alle möglichen Karten.

#### Erwartungen realistisch halten

Ein mögliches seltenes Motiv bedeutet nicht, dass es in einem bestimmten Booster enthalten ist. Ohne veröffentlichte verlässliche Daten sollten keine Trefferwahrscheinlichkeiten angenommen werden. Berechne einen Kauf nicht mit einem garantierten Wiederverkaufsgewinn.

#### Gezielt sammeln

Wer eine bestimmte Karte sucht, kann mit einem Einzelkauf planbarer sein Ziel erreichen. Kaufe verschlossene Ware aus nachvollziehbarer Quelle und achte auf mögliche Manipulationen. Dokumentiere Verpackung und Kaufbeleg bei auffälligen Lieferungen.

#### Beispiele bekannter Booster-Sets

Legend of Blue Eyes White Dragon, Metal Raiders, Invasion of Chaos, Phantom Darkness und Age of Overlord sind Beispiele aus unterschiedlichen Yu-Gi-Oh!-Produktgenerationen. Diese Auswahl ist eine Orientierung, keine vollständige Liste aller veröffentlichten Booster. Originalausgaben und spätere Wiederveröffentlichungen können sich unterscheiden. Prüfe Region, Sprache, Ausgabe und konkrete Produktbeschreibung.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/a-list-of-yu-gi-oh-booster-packs/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Seltene Yu-Gi-Oh!-Karten

Seltenheitsstufe, tatsächliche Verfügbarkeit und Nachfrage sind unterschiedliche Dinge.

#### Druckfassung bestimmen

Lies Set-Code, Sprache, Edition und die Merkmale der Folierung ab. Seltenheitsbezeichnungen können über Produktgenerationen variieren. Zwei Karten mit gleichem Namen, aber anderem Set-Code können sehr unterschiedliche Ausgaben sein.

#### Seltenheit überprüfen

Nutze offizielle Produktinformationen und verlässliche Checklisten. Ein dramatischer Verkäufertext oder ein hoher Angebotspreis ist kein Beleg für eine niedrige Auflage. Auch eine selten gehandelte Karte kann nur wenige Interessenten haben.

#### Zustand und Vergleich

Bei älteren oder empfindlichen Folienkarten sind Kratzer und Kanten besonders wichtig. Vergleiche die gleiche Ausgabe und den gleichen Erhaltungsgrad. Eine sehr gute Note sollte nicht ohne Prüfung aus einem Verkaufsfoto abgeleitet werden.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/a-guide-to-rare-yu-gi-oh-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Magic: The Gathering-Karten identifizieren

Bei Magic identifiziert der Kartenname allein nicht die konkrete Sammlerausgabe.

#### Merkmale ablesen

Verwende Kartenname, Set-Symbol beziehungsweise Set-Code, Sammlernummer, Sprache und Ausführung. Neuauflagen können dasselbe Motiv oder denselben Namen verwenden. Foil, alternative Rahmen und Sonderillustrationen müssen getrennt erfasst werden.

#### Regeln und Identität trennen

Der aktuelle Regeltext kann von älteren Druckfassungen abweichen. Nutze für Regeln die offiziellen Datenbanken und für die Sammlung die sichtbaren Druckmerkmale deiner Ausgabe. Bei doppelseitigen Karten gehören beide Seiten zur Identifikation.

#### Vergleich und Echtheit

Vergleiche genau passende Ausgaben und Zustand. Ungewöhnliche Druckmerkmale sollten mit einer zuverlässigen Referenz geprüft werden. Eine Bilderkennung kann beim Finden helfen, liefert aber keinen abschließenden Echtheitsnachweis.

#### Praktisches Beispiel

Beispiel: Derselbe Magic-Kartenname existiert als regulärer Druck und mit anderer Illustration. Die Regelwirkung kann gleich sein, während Sammlernummer, Preis und Seltenheit verschieden sind.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/guide-to-identifying-magic-the-gathering-mtg-cards/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### One Piece TCG: Einstieg für Anfänger

Beim One Piece TCG ist die genaue Ausgabe ebenso wichtig wie der Charakter.

#### Produkt und Karte erkennen

Notiere Kartenname, Kartenkennzeichnung, Produkt und Sprache. Alternative Illustrationen und Sonderausgaben können bei gleicher Kartenkennung unterschiedliche Sammlervarianten sein. Vergleiche das tatsächliche Bild und die offiziellen Produktlisten.

#### Spiel und Sammlung

Leader und weitere Kartentypen haben unterschiedliche Aufgaben im Deck. Nutze das aktuelle offizielle Regelwerk und die zum Format gehörenden Beschränkungen. Ein optisch selteneres Motiv hat nicht automatisch einen anderen Spieleffekt.

#### Bewusst einkaufen

Starterprodukte können den Spieleinstieg erleichtern, Einzelkarten eine Sammlung gezielt ergänzen. Prüfe Marktvergleiche anhand der gleichen Illustration, Sprache und des Zustands. Bei gefragten Karten sind nachvollziehbare Herkunft und genaue Fotos besonders hilfreich.

#### Praktisches Beispiel

Beispiel: Zwei One-Piece-Karten tragen denselben Code, sehen aber unterschiedlich aus. Prüfe, ob die zweite Illustration eine offiziell gelistete Alternative ist und welche konkrete Ausgabe angeboten wird.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/beginners-guide-to-one-piece-tcg/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.

### Magic: The Gathering – Final Fantasy spielen

Magic-Karten mit Final-Fantasy-Motiven bleiben Teil eines konkreten Magic-Produkts.

#### Ausgabe identifizieren

Prüfe Set, Sammlernummer, Sprache, Rahmen, Illustration und Foil-Ausführung. Unterschiedliche Produkte oder Sonderdrucke können ähnliche Motive besitzen. Der Charaktername allein reicht zur Sammleridentifikation nicht aus.

#### Regeln lernen

Für das Spielen gelten die aktuellen Magic-Regeln und die Zulässigkeit im jeweiligen Format. Lerne Kosten, Kartentypen und die auf der Karte beschriebenen Fähigkeiten. Produktname oder Motivwelt sagen nicht allein, in welchem Turnierformat eine Karte erlaubt ist.

#### Sammeln und Budget

Entscheide, ob du bestimmte Charaktere, Illustrationen oder ein Set sammeln möchtest. Vergleiche identische Druckfassungen und vermeide Kaufentscheidungen allein aufgrund von Vorab-Hype. Aktuelle Produktinhalte und Formatzulässigkeit prüfst du beim offiziellen Herausgeber.

#### Praktisches Beispiel

Beispiel: Eine Final-Fantasy-Illustration sagt allein nichts über die Turnierzulässigkeit. Bestimme die Karte und prüfe das gewünschte Format in einer aktuellen offiziellen Datenquelle.

Originalthema bei COLLECT.Guide: https://www.collect.guide/resources/a-guide-to-playing-magic-the-gathering-final-fantasy/

Eigener deutscher Sideline-Ratgeber. Die verlinkten COLLECT.Guide-Artikel wurden nicht übersetzt oder übernommen.
