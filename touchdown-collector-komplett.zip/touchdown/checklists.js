const escapeHTML=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export class SetChecklists {
  constructor({api,getStatus,onWish}){
    this.api=api;this.getStatus=getStatus;this.onWish=onWish;this.root=null;this.selected=null;this.data=null;this.sets=null;this.skip=0;this.setSkip=0;this.query='';this.year='';this.parallel='';this.filter='missing';this.busy=false;this.error='';this.token=0;this.news=null;this.newsError='';this.autoNews=true;this.newsBusy=false;
    try{this.autoNews=localStorage.getItem('sideline-set-notices')!=='false';}catch{}
    document.addEventListener('visibilitychange',()=>{if(!document.hidden&&this.autoNews&&this.getStatus().scanAvailable)this.checkNews();});
  }
  view(){return '<div id="checklist-body"></div>';}
  mount(root){this.root=root;this.paint();if(this.getStatus().scanAvailable&&!this.busy&&!(this.selected?this.data:this.sets))this.load();}
  invalidate(){this.data=null;}
  start(){if(this.autoNews&&this.getStatus().scanAvailable)this.checkNews();if(!this.timer)this.timer=setInterval(()=>{if(!document.hidden&&this.autoNews&&this.getStatus().scanAvailable)this.checkNews();},3600000);}
  setAutoNews(value){this.autoNews=value;try{localStorage.setItem('sideline-set-notices',String(value));}catch{}if(value&&this.getStatus().scanAvailable)this.checkNews();}
  open(id){this.selected=id;this.data=null;this.parallel='';this.skip=0;this.filter='missing';this.error='';this.token++;this.busy=false;}
  async checkNews(refresh=false,read=false){
    if(this.newsBusy||!this.getStatus().scanAvailable)return;
    this.newsBusy=true;
    try{this.news=await this.api('/api/set-updates',{method:'POST',body:JSON.stringify({refresh,read})});this.newsError='';document.dispatchEvent(new CustomEvent('sideline-set-news',{detail:this.news}));}
    catch(error){this.newsError=error.message;}
    finally{this.newsBusy=false;this.paint();}
  }
  async load(){
    if(this.busy||!this.getStatus().scanAvailable)return;
    const token=++this.token;this.busy=true;this.error='';this.paint();
    try{
      if(this.selected){const data=await this.api('/api/checklist',{method:'POST',body:JSON.stringify({id:this.selected,skip:this.skip,parallelId:this.parallel})});if(token===this.token)this.data=data;}
      else{const sets=await this.api('/api/sets',{method:'POST',body:JSON.stringify({query:this.query,year:this.year,skip:this.setSkip})});if(token===this.token)this.sets=sets;}
    }catch(error){if(token===this.token)this.error=error.message;}
    finally{if(token===this.token){this.busy=false;this.paint();}}
  }
  paint(){
    if(!this.root?.isConnected)return;
    const e=escapeHTML;
    if(!this.getStatus().scanAvailable){this.root.innerHTML='<div class="empty-state"><h3>Deine Checklisten warten auf dich.</h3><p>Hinterlege deinen Cardsight-Schlüssel unter Einstellungen. Danach kannst du Sets durchsuchen und deinen Fortschritt sehen.</p><a class="button button-dark" href="#settings">Zu den Einstellungen</a></div>';return;}
    const notices=this.news?.notices || [];
    const news=`<section class="set-news"><div><span class="eyebrow">NEUES AUS DEM KATALOG</span><h3>${this.news?.newCount?`${this.news.newCount} neu entdeckte Sets`:'Set-Hinweise'}</h3><p>${this.news?.checkedAt?'Zuletzt geprüft: '+e(new Date(this.news.checkedAt).toLocaleString('de-DE')):'Noch nicht geprüft.'} ${this.newsError?e(this.newsError):''}</p></div><button class="button button-secondary button-small" data-cl="news" ${this.newsBusy?'disabled':''}>Jetzt prüfen</button>${notices.length?`<div class="set-notices">${notices.slice().reverse().map(n=>`<button data-cl="set" data-id="${e(n.id)}" class="set-notice ${n.read?'':'unread'}">${e(n.year)} · ${e(n.releaseName)} · ${e(n.name)}${n.read?'':' · NEU'}</button>`).join('')}<button class="text-link" data-cl="read">Hinweise als gelesen markieren</button></div>`:''}<small>Geprüft werden die 100 aktuellen Katalogsets, automatisch höchstens alle 6 Stunden bei geöffneter App. Hinweise bedeuten neu entdeckt seit der letzten Prüfung. Keine Push-Nachrichten bei geschlossener App.</small></section>`;
    let body='';
    if(this.selected){
      const d=this.data;
      body=`<button class="text-link back-to-sets" data-cl="back">← Alle Sets durchsuchen</button>`;
      if(d){
        const p=d.progress;
        const visible=d.cards.filter(c=>this.filter==='all'||(this.filter==='owned'?c.owned:!c.owned));
        body+=`<section class="set-progress"><span class="eyebrow">${e(d.set.year)} · ${e(d.set.releaseName)}</span><h2>${e(d.set.name)}</h2><p>${e(d.set.description)}</p><div class="set-progress-values"><strong>${p.owned} von ${p.total??'?'} Karten</strong><span>${p.percent===null?'Gesamtumfang nicht angegeben':p.percent+' % gesammelt'}</span></div><progress value="${p.percent??0}" max="100" aria-label="Sammelfortschritt"></progress><p>${p.missing===null?'':p.missing+' Karten fehlen. '}Doppelte Exemplare zählen für den Fortschritt nur einmal.</p>${d.unlinkedCards?`<p class="field-hint">Bei ${d.unlinkedCards} älteren Sammlungseinträgen fehlt noch die Set-Zuordnung. Beim Öffnen der passenden Katalogseite werden verknüpfte Karten abgeglichen.</p>`:''}</section><div class="checklist-toolbar"><label>Variante<select id="checklist-parallel"><option value="">Basiskarten</option>${d.parallels.map(p=>`<option value="${e(p.id)}" ${this.parallel===p.id?'selected':''}>${e(p.name)}</option>`).join('')}</select></label><label>Anzeigen<select id="checklist-filter"><option value="all" ${this.filter==='all'?'selected':''}>Alle Karten</option><option value="owned" ${this.filter==='owned'?'selected':''}>Besessene Karten</option><option value="missing" ${this.filter==='missing'?'selected':''}>Fehlende Karten</option></select></label><button class="button button-secondary" data-cl="reload">Abgleichen</button></div><p class="checklist-page-hint">Katalogseite ${Math.floor(d.skip/d.take)+1} · ${visible.length} passende Einträge auf dieser Seite. Besessene Karten sind standardmäßig ausgeblendet. Der Filter gilt für die aktuelle Seite.</p><div class="checklist-rows">${visible.length?visible.map(c=>`<article class="checklist-row ${c.owned?'owned':''}"><div class="checklist-picture"><img src="./api.php?r=image&amp;id=${encodeURIComponent(c.id)}" alt="Kartenbild von ${e(c.player)}" loading="lazy" data-catalog-thumb="true"></div><span class="ownership-symbol" aria-hidden="true">${c.owned?'✓':'○'}</span><strong class="checklist-number">${e(c.number||'—')}</strong><div><h3>${e(c.player)}</h3><p>${e(c.description)}${c.attributes.length?' · '+e(c.attributes.join(', ')):''}</p><small>${c.owned?'Im Besitz · '+c.quantity+' Exemplar(e)':'Fehlt noch'}</small></div>${!c.owned?`<button class="button button-secondary button-small" data-cl="wish" data-id="${e(c.id)}">Merken</button>`:''}</article>`).join(''):'<div class="empty-state"><h3>Keine passenden Karten auf dieser Seite.</h3><p>Wechsle den Filter oder blättere zur nächsten Katalogseite.</p></div>'}</div><div class="checklist-pager"><button class="button button-secondary" data-cl="prev" ${d.skip===0||this.busy?'disabled':''}>← Zurück</button><span>Seite ${Math.floor(d.skip/d.take)+1} von ${Math.max(1,Math.ceil(d.catalogTotal/d.take))}</span><button class="button button-secondary" data-cl="next" ${d.skip+d.take>=d.catalogTotal||this.busy?'disabled':''}>Weiter →</button></div>`;
      }
    }else{
      body=`<form id="set-search-form" class="set-search-form"><label>Set, Spieler oder Release<input name="query" type="search" maxlength="200" value="${e(this.query)}" placeholder="z. B. Panini Prizm"></label><label>Jahr<input name="year" inputmode="numeric" pattern="[0-9]{4}" maxlength="4" value="${e(this.year)}" placeholder="Alle Jahre"></label><button class="button button-dark" type="submit">Sets suchen</button></form><p class="checklist-page-hint">Alle bei Cardsight verfügbaren Kategorien. Suche nach NFL-/NBA-Releases oder wähle ein erkanntes Set direkt aus deiner Karte.</p>`;
      if(this.sets)body+=`<div class="section-heading"><h3>${this.sets.total} Sets gefunden</h3></div><div class="set-grid">${this.sets.sets.map(s=>`<button class="set-tile" data-cl="set" data-id="${e(s.id)}"><span class="eyebrow">${e(s.year)}</span><h3>${e(s.releaseName)}</h3><strong>${e(s.name)}</strong><small>${s.cardCount===null?'Checkliste öffnen':s.cardCount+' Basiskarten · Checkliste öffnen'} →</small></button>`).join('')}</div><div class="checklist-pager"><button class="button button-secondary" data-cl="prev" ${this.setSkip===0||this.busy?'disabled':''}>← Zurück</button><span>Seite ${Math.floor(this.setSkip/20)+1} von ${Math.max(1,Math.ceil(this.sets.total/20))}</span><button class="button button-secondary" data-cl="next" ${this.setSkip+20>=this.sets.total||this.busy?'disabled':''}>Weiter →</button></div>`;
    }
    this.root.innerHTML=news+(this.error?`<div class="error-panel"><h3>Checkliste gerade nicht erreichbar.</h3><p>${e(this.error)}</p><button class="button button-secondary" data-cl="reload">Erneut versuchen</button></div>`:'')+(this.busy?'<p class="loading">Cardsight-Checkliste wird geladen …</p>':'')+body;
    this.root.onclick=event=>{const button=event.target.closest('[data-cl]');if(!button||button.disabled)return;const action=button.dataset.cl;
      if(action==='set'){this.open(button.dataset.id);this.load();}
      if(action==='back'){this.selected=null;this.data=null;this.error='';this.paint();if(!this.sets)this.load();}
      if(action==='prev'||action==='next'){const step=action==='prev'?-1:1;if(this.selected)this.skip=Math.max(0,this.skip+step*50);else this.setSkip=Math.max(0,this.setSkip+step*20);this.load();}
      if(action==='reload')this.load();
      if(action==='news')this.checkNews(true);
      if(action==='read')this.checkNews(false,true);
      if(action==='wish'){const c=this.data.cards.find(c=>c.id===button.dataset.id);this.onWish({player:c.player,number:c.number,year:this.data.set.year,set:[this.data.set.releaseName,this.data.set.name].filter(Boolean).join(' · '),cardsightId:c.id,cardsightSetId:this.data.set.id,parallel:this.data.parallels.find(p=>p.id===this.parallel)?.name||''});}
    };
    this.root.onsubmit=event=>{if(event.target.id!=='set-search-form')return;event.preventDefault();const fields=new FormData(event.target);this.query=fields.get('query');this.year=fields.get('year');this.setSkip=0;this.load();};
    this.root.onchange=event=>{if(event.target.id==='checklist-filter'){this.filter=event.target.value;this.paint();}if(event.target.id==='checklist-parallel'){this.parallel=event.target.value;this.skip=0;this.load();}};
  }
}
