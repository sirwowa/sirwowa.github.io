// Local, conservative image checks. This is a capture aid, not a guarantee of recognition.
const median=values=>{const v=values.slice().sort((a,b)=>a-b);return v.length?v[Math.floor(v.length/2)]:0;};
export function inspectFrame({data,width,height},frame,previous=null){
 const gray=new Float32Array(width*height);for(let i=0;i<gray.length;i++)gray[i]=data[i*4]*.299+data[i*4+1]*.587+data[i*4+2]*.114;
 const at=(x,y)=>gray[Math.max(0,Math.min(height-1,Math.round(y)))*width+Math.max(0,Math.min(width-1,Math.round(x)))];
 const edge=(vertical,expected,start,end)=>{const offsets=[];let count=0;
  for(let p=start;p<end;p+=3){count++;let best=0,offset=0;for(let d=-10;d<=10;d++){const a=vertical?at(expected+d-2,p):at(p,expected+d-2),b=vertical?at(expected+d+2,p):at(p,expected+d+2),v=Math.abs(a-b);if(v>best){best=v;offset=d;}}if(best>22)offsets.push(offset);}
  const center=median(offsets),spread=median(offsets.map(v=>Math.abs(v-center)));return offsets.length/Math.max(1,count)>.68&&Math.abs(center)<=5&&spread<=3;
 };
 const {x,y,width:w,height:h}=frame;
 const aligned=edge(true,x,y+h*.12,y+h*.88)&&edge(true,x+w,y+h*.12,y+h*.88)&&edge(false,y,x+w*.12,x+w*.88)&&edge(false,y+h,x+w*.12,x+w*.88);
 let sum=0,dark=0,clipped=0,gradient=0,lap=0,lap2=0,n=0;const signature=[];
 for(let yy=Math.ceil(y+h*.12);yy<y+h*.88;yy++)for(let xx=Math.ceil(x+w*.12);xx<x+w*.88;xx++){
  const v=at(xx,yy),l=at(xx-1,yy)+at(xx+1,yy)+at(xx,yy-1)+at(xx,yy+1)-4*v;sum+=v;dark+=v<22;const i=(yy*width+xx)*4;clipped+=data[i]>247&&data[i+1]>247&&data[i+2]>247;gradient+=Math.abs(at(xx+1,yy)-v)+Math.abs(at(xx,yy+1)-v);lap+=l;lap2+=l*l;n++;
 }
 for(let row=0;row<12;row++)for(let col=0;col<8;col++)signature.push(at(x+w*(.12+.76*(col+.5)/8),y+h*(.12+.76*(row+.5)/12)));
 const mean=sum/Math.max(n,1),sharpness=lap2/Math.max(n,1)-(lap/Math.max(n,1))**2;
 const motion=previous?.length===signature.length?signature.reduce((v,a,i)=>v+Math.abs(a-previous[i]),0)/signature.length:0;
 const glare=clipped/Math.max(n,1),tooDark=mean<44||dark/Math.max(n,1)>.65,tooBright=mean>228||glare>.2;
 let reason=!aligned?'Alle vier Kartenränder gerade am Rahmen ausrichten':tooDark?'Mehr gleichmäßiges Licht verwenden':tooBright?'Reflexion / Überbelichtung: Karte leicht kippen, direkte Lampe vermeiden':sharpness<65||gradient/Math.max(n,1)<3?'Bild noch unscharf: kurz ruhig halten, Linse prüfen':motion>7?'Karte und Smartphone ruhig halten':'Bild geeignet – ruhig halten';
 return {ready:aligned&&!tooDark&&!tooBright&&sharpness>=65&&gradient/Math.max(n,1)>=3&&motion<=7,aligned,reason,signature,sharpness,glare,motion};
}
