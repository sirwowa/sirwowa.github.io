<?php
declare(strict_types=1);
require __DIR__ . '/_private/bootstrap.php';
security_headers(); start_session();
$error = ''; $config = null; $fatal = false;
try {
    if (PHP_VERSION_ID < 80100) throw new AppError('Bitte im ALL-INKL-KAS PHP 8.1 oder neuer für diese Subdomain einstellen.');
    if (!https_request() && !localhost_request()) throw new AppError('Bitte diese Seite mit https:// öffnen. Die Kamera und die Anmeldung benötigen eine sichere Verbindung.');
    if (!is_writable(__DIR__ . '/_private')) throw new AppError('Der Ordner _private ist nicht beschreibbar. Bitte die Dateirechte im Webspace prüfen.');
    $config = read_private('config');
    if (!$config) {
        $installation = read_private('installation');
        $code = $installation['code'] ?? '';
        if (strlen($code)<16 || str_contains($code,'HIER-EIGENEN')) throw new AppError('Ein Vorbereitungsschritt fehlt: Öffne _private/installation.php in deinem WebFTP oder Texteditor und ersetze HIER-EIGENEN-INSTALLATIONSCODE-EINTRAGEN durch einen selbst gewählten privaten Code mit mindestens 16 Zeichen. Danach diese Seite neu laden.');
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        check_csrf((string)($_POST['csrf'] ?? ''));
        $action = $_POST['action'] ?? '';
        if ($action === 'setup' && !$config) {
            login_rate();
            $installation = read_private('installation');
            if (!$installation || !hash_equals($installation['code'], trim((string)($_POST['installationCode'] ?? '')))) { login_rate(true); throw new AppError('Der Installationscode ist nicht korrekt. Verwende deinen selbst gewählten Code aus _private/installation.php.'); }
            $password = (string)($_POST['password'] ?? '');
            if (!preg_match('/^.{6,200}$/usD',$password)) throw new AppError('Bitte ein Passwort mit mindestens 6 und maximal 200 Zeichen wählen.');
            if ($password !== ($_POST['passwordRepeat'] ?? '')) throw new AppError('Die beiden Passwörter stimmen nicht überein.');
            $apiKey = text_field($_POST['apiKey'] ?? '', 256);
            if ($apiKey && !preg_match('/^[a-zA-Z0-9_-]{16,256}$/D', $apiKey)) throw new AppError('Der Cardsight-Schlüssel hat ein ungültiges Format.');
            $new = ['passwordHash'=>password_hash($password, PASSWORD_DEFAULT),'apiKey'=>$apiKey,'createdAt'=>now_iso()];
            private_transaction('config', function($existing) use($new) { if ($existing) throw new AppError('Die App ist bereits eingerichtet. Bitte anmelden.'); return [$new,null]; });
            login_rate(false, true); login_user();
            header('Location: ./', true, 303); exit;
        }
        if ($action === 'login' && $config) {
            login_rate();
            if (!password_verify((string)($_POST['password'] ?? ''), $config['passwordHash'])) { login_rate(true); throw new AppError('Das Passwort ist nicht korrekt.'); }
            login_rate(false,true);login_user();header('Location: ./',true,303);exit;
        }
        if ($action === 'logout') { $_SESSION=[];session_destroy();header('Location: ./',true,303);exit; }
        throw new AppError('Diese Aktion ist nicht verfügbar. Bitte die Seite neu laden.');
    }
} catch (AppError $e) { $error=$e->getMessage(); if ($_SERVER['REQUEST_METHOD'] !== 'POST') $fatal=true; }
catch (Throwable $e) { error_log('Sideline installation failed: '.get_class($e));$error='Die App konnte nicht gestartet werden. Bitte die Dateirechte und das PHP-Fehlerprotokoll bei ALL-INKL prüfen.';$fatal=true; }
if (!$fatal && $config && authenticated()) {
    $raw=file_get_contents(__DIR__.'/_private/view.php');
    if ($raw===false || !str_starts_with($raw,PRIVATE_PREFIX)) { http_response_code(500);echo 'Die Oberfläche fehlt. Bitte das vollständige ZIP-Paket hochladen.';exit; }
    echo str_replace(['{{CSRF_TOKEN}}','{{BRAND_LOGO}}','{{FAVICON_URL}}'],[h($_SESSION['csrf']),brand_logo_markup(),h(brand_favicon())],substr($raw,strlen(PRIVATE_PREFIX)));exit;
}
$setup = !$config;
?><!doctype html>
<html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="theme-color" content="#020d17"><link rel="manifest" href="./manifest.webmanifest"><link rel="apple-touch-icon" href="./logo.png"><meta name="theme-color" content="#172019"><meta name="robots" content="noindex,nofollow"><title><?= $setup?'Einrichten':'Anmelden' ?> · Touchdown Collector</title><link rel="icon" href="<?= h(brand_favicon()) ?>"><script src="./theme.js?v=10"></script><link rel="stylesheet" href="./style.css?v=10"></head>
<body class="auth-page"><main class="auth-card">
  <a class="brand" href="./"><?= brand_logo_markup() ?></a>
  <button class="icon-button auth-theme-toggle" data-theme-toggle type="button" aria-label="Dunkelmodus aktivieren">☾</button><span class="eyebrow">DEIN PRIVATER COLLECTOR SPACE</span>
  <h1><?= $setup?'Deine Sammlung beginnt hier.':'Zurück auf deinem Spielfeld.' ?></h1>
  <p><?= $setup?'Einmal einrichten. Danach deine Sportkarten direkt im Browser fotografieren, erkennen und sammeln.':'Melde dich an, um deine Sportkarten zu öffnen.' ?></p>
  <?php if($error): ?><p class="auth-error" role="alert"><?= h($error) ?></p><?php endif; ?>
  <?php if(!$fatal): ?>
  <form method="post" action="./index.php" class="auth-form">
    <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="<?= $setup?'setup':'login' ?>">
    <?php if($setup): ?><label>Installationscode<input name="installationCode" required maxlength="200" autocomplete="off" placeholder="Dein Code aus _private/installation.php"></label><?php endif; ?>
    <label><?= $setup?'Dein neues Passwort':'Dein Passwort' ?><input name="password" type="password" required <?= $setup?'minlength="6"':'' ?> maxlength="200" autocomplete="<?= $setup?'new-password':'current-password' ?>" placeholder="<?= $setup?'Mindestens 6 Zeichen':'Passwort eingeben' ?>"></label>
    <?php if($setup): ?>
      <label>Passwort wiederholen<input name="passwordRepeat" type="password" required minlength="6" maxlength="200" autocomplete="new-password"></label>
      <label>Cardsight-API-Schlüssel <small>optional, für die Erkennung</small><input name="apiKey" type="password" maxlength="256" autocomplete="off" placeholder="Sicher auf deinem Server hinterlegen"></label>
      <p class="field-hint">Der Schlüssel bleibt auf deinem Webspace und wird nicht im Browser angezeigt. Du kannst ihn später unter Einstellungen ergänzen oder ersetzen.</p>
      <?php if(!function_exists('curl_init')): ?><p class="auth-error">PHP-cURL ist nicht aktiv. Die Sammlung funktioniert, für die Erkennung muss cURL aktiviert werden.</p><?php endif; ?>
    <?php endif; ?>
    <button class="button button-dark" type="submit"><?= $setup?'Meine Sammlung einrichten':'Sammlung öffnen' ?> →</button>
  </form>
  <?php endif; ?>
  <p class="auth-footer">Deine Karten. Deine Daten. Auf deinem Webspace.</p>
</main></body></html>
