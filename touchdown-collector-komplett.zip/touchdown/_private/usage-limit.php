<?php
declare(strict_types=1);
// Host-compatible, locked technical counter. No reference card catalog is stored.
function quota_month(): string { return gmdate('Y-m'); }
function quota_state(?array $s): array {
    $limit=min(750,max(1,(int)($s['limit']??750)));
    if(($s['month']??'')!==quota_month())return ['month'=>quota_month(),'limit'=>$limit,'local'=>0,'free'=>0,'observed'=>null];
    return array_merge(['local'=>0,'free'=>0,'observed'=>null],$s,['limit'=>$limit]);
}
function quota_effective(array $s): int {
    return max((int)$s['local'],isset($s['floor'])?(int)$s['floor']+max(0,(int)$s['local']-(int)($s['floorLocal']??0)):0,isset($s['observed']['calls'])?(int)$s['observed']['calls']+max(0,(int)$s['local']-(int)$s['observed']['local']):0);
}
function quota_view(?array $state=null): array {
    $s=quota_state($state??read_private('quota'));$used=quota_effective($s);
    return ['month'=>$s['month'],'limit'=>$s['limit'],'used'=>$used,'localAttempts'=>$s['local'],'freeAttempts'=>$s['free'],'remaining'=>max(0,$s['limit']-$used),'warning'=>$used>=$s['limit']?'blocked':($used>=700?'critical':($used>=600?'warning':null)),'providerCalls'=>$s['observed']['calls']??null,'providerCheckedAt'=>$s['observed']['date']??null,'counting'=>'Konservative lokale Sicherheitszählung; kein garantierter Anbieter-Kontostand. Monatswechsel nach UTC.'];
}
function quota_free_path(string $path): bool {
    $path=parse_url($path,PHP_URL_PATH);
    return $path==='/v1/identify/list/sets'||preg_match('~^/v1/identify/check/set/[a-fA-F0-9-]{36}$~D',$path??'')===1;
}
function quota_reserve(string $path): void {
    private_transaction('quota',function($s)use($path){$s=quota_state($s);if(quota_free_path($path))$s['free']++;else{if(quota_effective($s)>=$s['limit'])throw new AppError('Die lokale Monatsgrenze ist erreicht. Weitere gezählte Cardsight-Anfragen sind gesperrt. Anbieterstand bitte im Cardsight-Konto prüfen.',429,['usage'=>quota_view($s)]);$s['local']++;}return[$s,null];});
}
function quota_set_limit(int $limit): array {
    if($limit<1||$limit>750)throw new AppError('Die lokale Obergrenze muss zwischen 1 und 750 liegen.');
    return private_transaction('quota',function($s)use($limit){$s=quota_state($s);$s['limit']=$limit;return[$s,quota_view($s)];});
}
function quota_observe(array $reply,int $anchor,string $month): array {
    if(!isset($reply['calls'])||!is_int($reply['calls'])||$reply['calls']<0)throw new AppError('Cardsight hat keinen gültigen Verbrauch geliefert.',502);
    return private_transaction('quota',function($s)use($reply,$anchor,$month){$s=quota_state($s);if($month!==$s['month'])throw new AppError('Monatswechsel während des Abgleichs. Bitte erneut prüfen.',409);$previous=quota_effective($s);$s['observed']=['calls'=>$reply['calls'],'local'=>$anchor,'date'=>now_iso()];$s['floor']=$previous;$s['floorLocal']=$s['local'];return[$s,quota_view($s)];});
}
function cardsight_rate_gate(): void {
    $deadline=microtime(true)+20;
    do{$wait=private_transaction('rate-slot',function($s){$now=microtime(true);$wait=max(0,(float)($s['next']??0)-$now);return[$wait>0?($s??[]):['next'=>$now+.36],$wait];});if($wait<=0)return;if(microtime(true)>$deadline)throw new AppError('Viele Anfragen gleichzeitig. Bitte kurz warten.',429);usleep((int)(min(.4,$wait)*1000000)+1000);}while(true);
}
