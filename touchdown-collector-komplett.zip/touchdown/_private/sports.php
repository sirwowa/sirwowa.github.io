<?php
declare(strict_types=1);
function sport_name(string $name): string {
    return ['Football'=>'American Football','Soccer'=>'Fußball','Hockey'=>'Eishockey','Ice Hockey'=>'Eishockey','Boxing'=>'Boxen','Wrestling'=>'Wrestling','Racing'=>'Motorsport','Motorsports'=>'Motorsport'][$name]??$name;
}
function supported_segments(string $key): array {
    $cache=read_private('segments-cache');
    if($cache&&$cache['expires']>time())return $cache['segments'];
    $segments=[];$skip=0;
    do{
        $response=cardsight_request('/v1/catalog/segments?'.http_build_query(['take'=>100,'skip'=>$skip,'is_identifiable'=>'true']),$key);
        if(!isset($response['segments'])||!is_array($response['segments']))throw new AppError('Die Sportartenliste konnte nicht geladen werden.',502);
        foreach($response['segments']as $s)if(!empty($s['is_identifiable']))$segments[]=['id'=>$s['id'],'name'=>sport_name(clean_api_text($s['name'])),'providerName'=>clean_api_text($s['name']),'shortname'=>clean_api_text($s['shortname']??'')];
        $skip+=100;
    }while($skip<(int)($response['total_count']??0)&&$skip<1000);
    private_transaction('segments-cache',fn($old)=>[['expires'=>time()+21600,'segments'=>$segments],null]);
    return $segments;
}
function detection_sport(array $card,string $segment,array $segments): array {
    $id=$card['segmentId']??'';
    foreach($segments as $s)if(($id&&$s['id']===$id)||($segment!=='auto'&&($s['id']===$segment||strcasecmp($s['shortname'],$segment)===0)))return ['sport'=>$s['name'],'sportNeedsReview'=>false];
    $known=['football'=>'American Football','basketball'=>'Basketball','baseball'=>'Baseball','hockey'=>'Eishockey','soccer'=>'Fußball','mma'=>'MMA'];
    return ['sport'=>$known[$segment]??'Andere','sportNeedsReview'=>!isset($known[$segment])];
}
