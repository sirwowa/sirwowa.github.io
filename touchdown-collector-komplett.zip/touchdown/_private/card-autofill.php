<?php
declare(strict_types=1);

function full_card_type(string $value,string $sport=''): string {
    if(preg_match('/pok[eé]mon|magic|yu-gi|trading card game/i',$sport))return $value;
    $map=['ROOKIE_CARD'=>'Rookie-Karte','BASE_CARD'=>'Basiskarte','AUTOGRAPH_CARD'=>'Autogrammkarte','MEMORABILIA_CARD'=>'Memorabilia-Karte','SUPER SHORT PRINT'=>'Karte in sehr kurzer Auflage','SUPER_SHORT_PRINT'=>'Karte in sehr kurzer Auflage','SHORT PRINT'=>'Karte in kurzer Auflage','SHORT_PRINT'=>'Karte in kurzer Auflage','SHORTPRINT'=>'Karte in kurzer Auflage','ROOKIE PATCH AUTOGRAPH'=>'Rookie-Karte mit Patch und Autogramm','ROOKIE CARD'=>'Rookie-Karte','BASE CARD'=>'Basiskarte','RPA'=>'Rookie-Karte mit Patch und Autogramm','RC'=>'Rookie-Karte','ROOKIE'=>'Rookie-Karte','AUTO'=>'Autogrammkarte','AU'=>'Autogrammkarte','AUTOGRAPH'=>'Autogrammkarte','AUTOGRAPHED'=>'Autogrammkarte','BASE'=>'Basiskarte','MEM'=>'Memorabilia-Karte','MEMORABILIA'=>'Memorabilia-Karte','RELIC'=>'Memorabilia-Karte','PATCH'=>'Patch-Karte','INSERT'=>'Sonderkarte','PARALLEL'=>'Parallelkarte','SSP'=>'Karte in sehr kurzer Auflage','SP'=>'Karte in kurzer Auflage'];
    $out=[];
    foreach(preg_split('~[,;/|]+~u',$value)as $part){
        $part=trim($part);if($part==='')continue;$key=strtoupper($part);
        if(isset($map[$key])){$out[]=$map[$key];continue;}
        $words=preg_split('/\s+/u',$part);$known=count($words)>1;
        foreach($words as $word)if(!isset($map[strtoupper($word)])){$known=false;break;}
        if($known)foreach($words as $word)$out[]=$map[strtoupper($word)];else $out[]=$part;
    }
    return implode(' / ',array_values(array_unique($out)));
}
function af_jersey(string $value): string {
    $clean=trim(preg_replace('/^(?:#|No\.?|Nr\.?|№)\s*/iu','',trim($value))??$value);
    return preg_match('/^\d{1,3}$/D',$clean)?$clean:$value;
}
function af_catalog_info(array $details): array {
    return array_merge(card_metadata($details),['player'=>clean_api_text($details['name']??''),'year'=>clean_api_text((string)($details['releaseYear']??'')),'number'=>clean_api_text($details['number']??''),'set'=>clean_api_text(implode(' · ',array_filter([$details['releaseName']??'',$details['setName']??''])))]);
}
function af_cache_catalog(string $id,string $key,array $details): array {
    $info=af_catalog_info($details);$name=hash('sha256',$id.'|'.$key);
    private_transaction('card-info-cache',function($all)use($name,$info){$all=is_array($all)?$all:[];$all=array_filter($all,fn($e)=>($e['expires']??0)>time());$all[$name]=['expires'=>time()+600,'info'=>$info];return[array_slice($all,-50,null,true),null];});return $info;
}
function af_catalog(string $id,string $key,?callable $fetch=null): array {
    $entry=read_private('card-info-cache',[])[hash('sha256',$id.'|'.$key)]??null;
    if(($entry['expires']??0)>time())return $entry['info'];
    $details=$fetch?$fetch($id):cardsight_request('/v1/catalog/cards/'.require_uuid($id),$key);
    return af_cache_catalog($id,$key,$details);
}
function af_name_tokens(string $value): array {
    return array_values(array_filter(explode(' ',preg_replace('/\s+/u',' ',trim(preg_replace('/[^\p{L}\p{N}]+/u',' ',normalized($value))??''))??''),fn($x)=>$x!==''&&!in_array($x,['jr','sr','ii','iii','iv'],true)));
}
function af_name_agrees(string $a,string $b): bool {
    $a=af_name_tokens($a);$b=af_name_tokens($b);return count($a)>=2&&count($b)>=2&&end($a)===end($b)&&substr($a[0],0,1)===substr($b[0],0,1);
}
function af_conflict(array $reading,array $card): bool {
    $a=af_name_tokens($reading['player']??'');$b=af_name_tokens($card['player']??'');
    $name=count($a)>=2&&count($b)>=2&&!af_name_agrees($reading['player'],$card['player']);
    $n=fn($s)=>strtolower(preg_replace('/[^\p{L}\p{N}]+/u','',(string)$s)??'');
    return $name||(!empty($reading['number'])&&!empty($card['number'])&&$n($reading['number'])!==$n($card['number']));
}
function af_gemini_photo(string $photo,array $config,?callable $transport=null): array {
    if(empty($config['geminiKey'])||($config['geminiEnabled']??false)!==true)throw new AppError('Gemini ist nicht aktiviert.',503);
    $hash=hash('sha256','metadata-v2|'.$config['geminiKey'].'|'.$photo);$cache=read_private('gemini-photo-cache',[]);$hit=$cache[$hash]??null;
    if(($hit['expires']??0)>time())return $hit['data'];
    $result=gemini_read(['image'=>$photo],$config,$transport);
    private_transaction('gemini-photo-cache',function($all)use($hash,$result){$all=is_array($all)?$all:[];$all=array_filter($all,fn($e)=>($e['expires']??0)>time());$all[$hash]=['expires'=>time()+600,'data'=>$result];return[array_slice($all,-10,null,true),null];});return $result;
}
function af_card(array $input,array $config,?callable $catalogFetch=null,?callable $geminiFetch=null): array {
    $c=$input['card']??null;if(!is_array($c)||array_is_list($c))throw new AppError('Bitte einen Kartenvorschlag übergeben.');
    $fields=['team','jerseyNumber','position','cardType','player','year','number','set','sport'];$card=[];foreach($fields as $field)$card[$field]=text_field($c[$field]??'');
    $card=expand_player_fields($card);$sources=[];$warnings=[];$reading=null;
    $missing=function()use(&$card){return array_values(array_filter(['team','jerseyNumber','position','cardType'],fn($f)=>trim($card[$f]??'')===''));};
    if($missing()&&!empty($c['cardsightId'])){
        $id=require_uuid($c['cardsightId']);
        try{$details=af_catalog($id,$config['apiKey']??'',$catalogFetch);foreach($fields as $field)if($card[$field]===''&&!empty($details[$field])){$card[$field]=$details[$field];$sources[$field]='Cardsight-Katalog';}}
        catch(AppError $e){$warnings[]='Cardsight-Ergänzung nicht verfügbar: '.$e->getMessage();}
    }
    $photo=$input['image']??'';
    if($missing()&&is_string($photo)&&$photo!==''&&!empty($config['geminiKey'])&&($config['geminiEnabled']??false)===true&&($config['geminiAutoFill']??true)===true){
        try{$reply=af_gemini_photo($photo,$config,$geminiFetch);$reading=$reply['reading'];
            if(!af_conflict($reading,$card)&&af_name_agrees($reading['player']??'',$card['player'])){
                foreach(['team','jerseyNumber','position','cardType','year','number','set']as $field)if($card[$field]===''&&!empty($reading[$field])){$card[$field]=$reading[$field];$sources[$field]='Gemini-Fotoabschrift · bitte prüfen';}
            }else{$warnings[]='Fotoabschrift und ausgewählte Karte sind nicht sicher abgeglichen. Keine Fotoangaben automatisch übernommen.';}
        }catch(AppError $e){$warnings[]='Gemini-Ergänzung nicht verfügbar: '.$e->getMessage();}
    }
    $card=expand_player_fields($card);
    $values=array_intersect_key($card,array_flip($fields));
    return ['fields'=>$values,'sources'=>$sources,'missing'=>$missing(),'warnings'=>$warnings,'gemini'=>$reading,'geminiNeedsReview'=>$reading?af_conflict($reading,$card):false,'notice'=>'Kartendaten werden nur ergänzt oder Abkürzungen ausgeschrieben. Fotoabschriften können falsch sein. Unbekannte Werte bleiben offen; keine aktuellen Team-/Roster-Daten werden als historische Kartenangaben übernommen.'];
}
