<?php
declare(strict_types=1);

function checklist_view(array $set,array $page,array $owned,string $parallelId=''): array {
    $parallel=null;
    foreach($set['parallels']??[] as $p)if(($p['id']??'')===$parallelId)$parallel=$p;
    if($parallelId&&!$parallel)throw new AppError('Diese Variante gehört nicht zum gewählten Set.');
    $partial=$parallel&&($parallel['isPartial']??false);
    $applicable=$partial&&isset($parallel['cards'])?array_fill_keys($parallel['cards'],true):null;
    $parallelName=$parallel['name']??'';
    $idsOnPage=array_column($page['cards']??[],'id');
    $matching=array_values(array_filter($owned,fn($c)=>($c['status']??'')!=='Wunschliste'&&normalized($c['parallel']??'')===normalized($parallelName)&&!empty($c['cardsightId'])&&(($c['cardsightSetId']??'')===$set['id']||in_array($c['cardsightId'],$idsOnPage,true))&&(!$applicable||isset($applicable[$c['cardsightId']]))));
    $unique=[];foreach($matching as $c)$unique[$c['cardsightId']]=($unique[$c['cardsightId']]??0)+$c['quantity'];
    $total=$parallel?($partial?($applicable===null?null:count($applicable)):(int)($page['total_count']??$set['cardCount'])):(int)$set['cardCount'];
    $items=[];
    foreach($page['cards']??[] as $row){
        if(!$parallel&&!empty($row['isParallelOnly']))continue;
        if($applicable&&!isset($applicable[$row['id']]))continue;
        if($parallel&&isset($row['parallels'])&&!in_array($parallelId,array_column($row['parallels'],'id'),true))continue;
        $items[]=['id'=>$row['id'],'number'=>clean_api_text($row['number']??''),'player'=>clean_api_text($row['name']??''),'description'=>clean_api_text($row['description']??''),'attributes'=>array_map('clean_api_text',array_slice($row['attributes']??[],0,12)),'owned'=>isset($unique[$row['id']]),'quantity'=>$unique[$row['id']]??0];
    }
    $count=count($unique);
    return ['set'=>['id'=>$set['id'],'name'=>clean_api_text($set['name']),'releaseName'=>clean_api_text($set['releaseName']??''),'year'=>clean_api_text($set['releaseYear']??''),'description'=>clean_api_text($set['description']??'')],'parallels'=>array_map(fn($p)=>['id'=>$p['id'],'name'=>clean_api_text($p['name'])],$set['parallels']??[]),'selectedParallel'=>$parallelId,'progress'=>['owned'=>$count,'total'=>$total,'missing'=>$total===null?null:max(0,$total-$count),'percent'=>$total?round(min(100,$count/$total*100),1):null],'cards'=>$items,'skip'=>$page['skip']??0,'take'=>$page['take']??50,'catalogTotal'=>$page['total_count']??count($items),'unlinkedCards'=>count(array_filter($owned,fn($c)=>($c['status']??'')!=='Wunschliste'&&empty($c['cardsightSetId'])))];
}
function checklist_request(array $input,string $key): array {
    $id=require_uuid($input['id']??'');$skip=max(0,min(1000000,(int)($input['skip']??0)));$parallelId=(string)($input['parallelId']??'');if($parallelId)require_uuid($parallelId);
    $set=cardsight_request('/v1/catalog/sets/'.$id,$key);
    $page=cardsight_request('/v1/catalog/sets/'.$id.'/cards?'.http_build_query(['take'=>50,'skip'=>$skip,'sort'=>'number','order'=>'asc']),$key);
    if(!isset($set['id'],$set['cardCount'],$page['cards'],$page['total_count']))throw new AppError('Unerwartete Checklisten-Antwort von Cardsight.',502);
    // Enrich only the user's own linked cards encountered on this requested page.
    $known=array_fill_keys(array_column($page['cards'],'id'),true);
    $owned=private_transaction('cards',function($rows)use($known,$id){$rows??=[];foreach($rows as &$c)if(isset($known[$c['cardsightId']??''])&&empty($c['cardsightSetId']))$c['cardsightSetId']=$id;unset($c);return[$rows,$rows];});
    return checklist_view($set,$page,$owned,$parallelId);
}
function browse_sets(array $input,string $key): array {
    $query=text_field($input['query']??'');$year=text_field($input['year']??'',4);if($year&&!preg_match('/^\d{4}$/D',$year))throw new AppError('Bitte ein vierstelliges Jahr eingeben.');
    $skip=max(0,min(1000000,(int)($input['skip']??0)));$params=['take'=>20,'skip'=>$skip];if($year)$params['year']=$year;
    if($query){if(strlen($query)<2)throw new AppError('Bitte mindestens zwei Suchzeichen eingeben.');$data=cardsight_request('/v1/catalog/search?'.http_build_query(array_merge($params,['q'=>$query,'type'=>'set'])),$key);$sets=array_map(fn($s)=>['id'=>$s['id'],'name'=>$s['name'],'releaseName'=>$s['releaseName']??'','releaseYear'=>$s['year']??'','cardCount'=>null],$data['results']??[]);}
    else{$data=cardsight_request('/v1/catalog/sets?'.http_build_query(array_merge($params,['sort'=>'year','order'=>'desc'])),$key);$sets=$data['sets']??[];}
    return ['sets'=>array_map(fn($s)=>['id'=>$s['id'],'name'=>clean_api_text($s['name']),'releaseName'=>clean_api_text($s['releaseName']??''),'year'=>clean_api_text($s['releaseYear']??''),'cardCount'=>$s['cardCount']??null],$sets),'total'=>$data['total_count']??count($sets),'skip'=>$skip,'take'=>20];
}
function set_updates(string $key,bool $refresh=false,bool $read=false): array {
    if($read)return private_transaction('set-watch',function($state){$state??=['ids'=>[],'checkedAt'=>null,'notices'=>[]];foreach($state['notices']as &$n)$n['read']=true;unset($n);return[$state,['checkedAt'=>$state['checkedAt'],'notices'=>$state['notices'],'newCount'=>0]];});
    $state=read_private('set-watch');
    if(!$refresh&&$state&&(time()-(strtotime($state['checkedAt'])?:0))<21600)return ['checkedAt'=>$state['checkedAt'],'notices'=>$state['notices'],'newCount'=>count(array_filter($state['notices'],fn($n)=>!$n['read']))];
    $data=cardsight_request('/v1/catalog/sets?take=100&skip=0&sort=year&order=desc',$key);
    if(!isset($data['sets'])||!is_array($data['sets']))throw new AppError('Set-Hinweise sind momentan nicht verfügbar.',502);
    return private_transaction('set-watch',fn($current)=>next_set_watch($current,$data));
}

function next_set_watch(?array $current,array $data): array {
        $known=array_fill_keys($current['ids']??[],true);$notices=$current['notices']??[];$first=$current===null;
        foreach($data['sets']as $s)if(!$first&&!isset($known[$s['id']]))$notices[]=['id'=>$s['id'],'name'=>clean_api_text($s['name']),'releaseName'=>clean_api_text($s['releaseName']??''),'year'=>clean_api_text($s['releaseYear']??''),'observedAt'=>now_iso(),'read'=>false];
        $ids=array_values(array_unique(array_merge($current['ids']??[],array_column($data['sets'],'id'))));$ids=array_slice($ids,-500);
        $notices=array_slice(array_values(array_filter($notices,fn($n)=>(strtotime($n['observedAt'])?:0)>time()-7*86400)),-30);
        $next=['ids'=>$ids,'checkedAt'=>now_iso(),'notices'=>$notices];return[$next,['checkedAt'=>$next['checkedAt'],'notices'=>$notices,'newCount'=>count(array_filter($notices,fn($n)=>!$n['read'])),'baselineCreated'=>$first]];
}
