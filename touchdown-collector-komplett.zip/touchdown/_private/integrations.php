<?php
declare(strict_types=1);
function public_http(string $url,array $headers=[]): array {
    $p=parse_url($url);$allowed=['site.api.espn.com','news.google.com','www.sportschau.de','api.ebay.com'];
    if(($p['scheme']??'')!=='https'||!in_array($p['host']??'',$allowed,true))throw new AppError('Datenquelle nicht unterstützt.');
    $ch=curl_init($url);$body='';curl_setopt_array($ch,[CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>20,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_HTTPHEADER=>array_merge(['Accept: application/json, application/rss+xml;q=0.9','User-Agent: TouchdownCollector/11'],$headers),CURLOPT_WRITEFUNCTION=>function($ch,$chunk)use(&$body){if(strlen($body)+strlen($chunk)>5000000)return 0;$body.=$chunk;return strlen($chunk);}]);
    $ok=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);if($ok===false||$status<200||$status>=300)throw new AppError('Die externe Datenquelle ist momentan nicht erreichbar (HTTP '.$status.').',502);return ['body'=>$body,'status'=>$status];
}
function sports_path(string $league): string {return match($league){'nfl'=>'football/nfl','nba'=>'basketball/nba',default=>throw new AppError('Bitte NFL oder NBA wählen.')};}
function sport_cache(string $name,int $seconds,callable $fetch): array {
    $cache=read_private($name);if($cache&&($cache['expires']??0)>time())return $cache['data'];
    $data=$fetch();private_transaction($name,fn($old)=>[['expires'=>time()+$seconds,'data'=>$data],null]);return $data;
}
function german_game_state(array $event): string {
    $s=$event['status']??[];$state=$s['type']['state']??'pre';if($state==='post')return 'Beendet';if($state!=='in')return 'Noch nicht begonnen';
    return (($s['period']??0)<=4?($s['period']??1).'. Viertel':'Verlängerung').' · '.($s['displayClock']??'');
}
function scoreboard_view(array $json): array {
    $games=[];foreach($json['events']??[] as $event){$c=$event['competitions'][0]??[];$teams=[];foreach($c['competitors']??[]as $t)$teams[]=['id'=>(string)($t['id']??''),'name'=>clean_api_text($t['team']['displayName']??''),'score'=>clean_api_text((string)($t['score']??'0')),'home'=>($t['homeAway']??'')==='home'];
        if(count($teams)!==2)continue;$games[]=['id'=>(string)($event['id']??''),'date'=>$event['date']??'','name'=>clean_api_text($event['name']??''),'state'=>$event['status']['type']['state']??'pre','status'=>german_game_state($event),'teams'=>$teams,'venue'=>clean_api_text($c['venue']['fullName']??'')];}
    return ['games'=>$games,'fetchedAt'=>now_iso(),'source'=>'ESPN'];
}
function german_play(array $play): string {
    $type=normalized($play['type']['text']??'');$map=['passing touchdown'=>'Touchdown durch Pass','rushing touchdown'=>'Touchdown durch Lauf','pass reception'=>'Pass gefangen','pass incompletion'=>'Unvollständiger Pass','fumble'=>'Ball fallen gelassen','safety'=>'Safety','substitution'=>'Spielerwechsel','jumpball'=>'Sprungball','made shot'=>'Wurf getroffen','missed shot'=>'Wurf verfehlt','rush'=>'Laufspiel','sack'=>'Quarterback zu Boden gebracht','punt'=>'Punt','field goal good'=>'Field Goal verwandelt','field goal missed'=>'Field Goal verfehlt','interception'=>'Pass abgefangen','penalty'=>'Strafe','timeout'=>'Auszeit','kickoff'=>'Kickoff','extra point good'=>'Extrapunkt verwandelt','fumble recovery'=>'Fumble aufgenommen','jump shot'=>'Sprungwurf','three point jumper'=>'Dreipunktewurf','layup'=>'Korbleger','dunk'=>'Dunk','free throw'=>'Freiwurf','rebound'=>'Rebound','steal'=>'Ballgewinn','turnover'=>'Ballverlust','foul'=>'Foul','block'=>'Wurf geblockt','end period'=>'Viertel beendet'];
    $label=$map[$type]??null;if(!$label){foreach($map as $key=>$value)if(str_contains($type,$key)){$label=$value;break;}}$label??=str_contains($type,'pass')?'Passspiel':'Neuer Spielzug';
    $players=[];foreach($play['participants']??[]as $p)if(!empty($p['athlete']['displayName']))$players[]=clean_api_text($p['athlete']['displayName']);if($players)$label.=' · '.implode(', ',array_unique($players));
    if(isset($play['statYardage'])&&is_numeric($play['statYardage']))$label.=' · '.$play['statYardage'].' Yards';if(($play['scoreValue']??0)>0)$label.=' · '.$play['scoreValue'].' Punkte';return $label;
}
function plays_view(array $json): array {
    $rows=$json['plays']??$json['drives']['current']['plays']??[];if(!$rows){foreach($json['drives']['previous']??[]as $drive)$rows=array_merge($rows,$drive['plays']??[]);}
    $plays=[];foreach(array_slice($rows,-30)as $p)$plays[]=['id'=>(string)($p['id']??''),'time'=>(($p['period']['number']??'')?($p['period']['number']).'. Viertel · ':'').($p['clock']['displayValue']??''),'text'=>german_play($p)];return ['plays'=>array_reverse($plays),'fetchedAt'=>now_iso(),'source'=>'ESPN','notice'=>'Deutsche Kurzfassungen aus strukturierten Spielereignissen. Daten können verzögert sein.'];
}
function xml_text(string $item,string $tag): string {if(!preg_match('~<'.preg_quote($tag,'~').'\\b[^>]*>(.*?)</'.preg_quote($tag,'~').'>~si',$item,$m))return '';return trim(html_entity_decode(strip_tags(str_replace(['<![CDATA[',']]>'],'',$m[1])),ENT_QUOTES|ENT_XML1,'UTF-8'));}
function news_view(string $xml): array {
    preg_match_all('~<item\b[^>]*>(.*?)</item>~si',$xml,$matches);$items=[];
    foreach(array_slice($matches[1],0,35)as $row){$url=safe_https(xml_text($row,'link'));$title=xml_text($row,'title');if(!$url||!$title)continue;$items[]=['title'=>mb_safe_cut($title,350),'source'=>mb_safe_cut(xml_text($row,'source')?:'Nachrichtenquelle',100),'date'=>xml_text($row,'pubDate'),'url'=>$url];}
    if(!$items)throw new AppError('Die Nachrichtenquelle hat keine lesbaren Meldungen geliefert.',502);return ['items'=>$items,'fetchedAt'=>now_iso(),'source'=>'Google News · deutschsprachige Suche'];
}
function mb_safe_cut(string $s,int $max): string {return preg_replace('/^((?:.|\n){0,'.$max.'}).*$/us','$1',$s)??'';}
function integrations_route(string $route,array $input,array $config): array {
    $league=$input['league']??'nfl';$path=sports_path($league);
    if($route==='live-games')return sport_cache('live-'.$league,8,fn()=>scoreboard_view(json_decode(public_http('https://site.api.espn.com/apis/site/v2/sports/'.$path.'/scoreboard?lang=de&region=de')['body'],true,64,JSON_THROW_ON_ERROR)));
    if($route==='live-plays'){$id=$input['id']??'';if(!is_string($id)||!preg_match('/^\d{1,20}$/D',$id))throw new AppError('Ungültiges Spiel.');return sport_cache('plays-'.$league.'-'.$id,8,fn()=>plays_view(json_decode(public_http('https://site.api.espn.com/apis/site/v2/sports/'.$path.'/summary?event='.$id)['body'],true,64,JSON_THROW_ON_ERROR)));}
    return sport_cache('news-'.$league,300,fn()=>news_view(public_http('https://news.google.com/rss/search?'.http_build_query(['q'=>$league==='nfl'?'NFL American Football':'NBA Basketball','hl'=>'de','gl'=>'DE','ceid'=>'DE:de']))['body']));
}
function ebay_connection(array $config): array {
    $id=$config['ebayClientId']??'';$secret=$config['ebayClientSecret']??'';if(!$id||!$secret)throw new AppError('Bitte AppID und CertID hinterlegen.');
    $ch=curl_init('https://api.ebay.com/identity/v1/oauth2/token');curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>20,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>'grant_type=client_credentials&scope='.rawurlencode('https://api.ebay.com/oauth/api_scope'),CURLOPT_HTTPHEADER=>['Authorization: Basic '.base64_encode($id.':'.$secret),'Content-Type: application/x-www-form-urlencoded'],CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS]);$body=curl_exec($ch);$status=curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);$json=is_string($body)?json_decode($body,true):null;
    if($status!==200||empty($json['access_token']))throw new AppError('eBay-Anmeldung fehlgeschlagen. Zugangsdaten, Produktionsschlüssel und Verbindung prüfen.',502);
    return ['ok'=>true,'message'=>'eBay-Zugangsdaten bestätigt. Das bestätigt noch keinen Zugriff auf abgeschlossene Verkäufe. Inventory Mapping liefert keine Verkaufs-Historie.'];
}
