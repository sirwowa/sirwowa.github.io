<?php
declare(strict_types=1);

function normalized(string $value): string { return strtolower(trim(preg_replace('/\s+/u',' ',$value) ?? $value)); }
function duplicate_cards(array $candidate, array $cards): array {
    return array_values(array_filter($cards, function($c) use($candidate) {
        if (($c['status']??'')==='Wunschliste' || ($candidate['status']??'')==='Wunschliste') return false;
        foreach(['sport','parallel','grader','grade'] as $field) if(normalized((string)($c[$field]??''))!==normalized((string)($candidate[$field]??'')))return false;
        if(!empty($c['cardsightId'])&&!empty($candidate['cardsightId']))return $c['cardsightId']===$candidate['cardsightId'];
        foreach(['player','year','set','number'] as $field)if(empty($c[$field])||empty($candidate[$field])||normalized($c[$field])!==normalized($candidate[$field]))return false;
        return true;
    }));
}
function duplicate_summaries(array $cards): array {
    return array_map(fn($c)=>['id'=>$c['id'],'player'=>$c['player'],'set'=>$c['set'],'year'=>$c['year'],'number'=>$c['number'],'quantity'=>$c['quantity']],$cards);
}
function valid_uuid(string $id): bool { return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iD',$id)===1; }
function require_uuid(mixed $id): string { if(!is_string($id)||!valid_uuid($id))throw new AppError('Ungültige Cardsight-Karten-ID.');return $id; }
function safe_https(mixed $url): ?string {
    if(!is_string($url)||strlen($url)>3000)return null;
    $p=parse_url($url);
    return is_array($p)&&strtolower($p['scheme']??'')==='https'&&!empty($p['host'])&&!isset($p['user'])&&!isset($p['pass'])?$url:null;
}
function median(array $values): ?float {
    if(!$values)return null;sort($values,SORT_NUMERIC);$n=count($values);return round($n%2?$values[intdiv($n,2)]:($values[$n/2-1]+$values[$n/2])/2,2);
}
function select_market_records(array $response,array $card): array {
    $company=trim($card['grader']??'');$grade=trim($card['grade']??'');
    if(!$company&&!$grade)return $response['raw']['records']??[];
    if(!$company||!$grade)throw new AppError('Für passende Preise bitte Grading-Anbieter und Grade vollständig eintragen.',409);
    foreach($response['graded']??[] as $group)if(normalized($group['company_name']??'')===normalized($company))foreach($group['grades']??[] as $g){
        $value=(string)($g['grade_value']??'');
        if(normalized($value)===normalized($grade)||(is_numeric($value)&&is_numeric($grade)&&(float)$value===(float)$grade))return $g['records']??[];
    }
    return [];
}
function clean_market_records(array $records,?string $parallel,bool $active): array {
    $out=[];
    foreach($records as $row){
        if(array_key_exists('parallel_id',$row)&&($row['parallel_id']?:null)!==$parallel)continue;
        $price=$row['price']??null;
        if($price!==null&&(!is_numeric($price)||!is_finite((float)$price)||$price<0))continue;
        $type=$row['listing_type']??null;
        if(!in_array($type,['auction','fixed'],true))continue;
        $out[]=['price'=>$price===null?null:(float)$price,'type'=>$type,'title'=>clean_api_text($row['title']??''),'source'=>clean_api_text($row['source']??''),'date'=>clean_api_text($row[$active?'end_date':'date']??''),'url'=>safe_https($row['url']??null)];
    }
    usort($out,fn($a,$b)=>strcmp($b['date'],$a['date']));return array_slice($out,0,100);
}
function market_snapshot(array $history,array $offers,array $card,?string $parallel,string $parallelName,array $warnings=[]): array {
    $sold=clean_market_records(select_market_records($history,$card),$parallel,false);
    $active=clean_market_records(select_market_records($offers,$card),$parallel,true);
    $auctions=array_values(array_filter($sold,fn($r)=>$r['type']==='auction'&&$r['price']!==null));
    $completed=array_values(array_filter($sold,fn($r)=>$r['price']!==null));
    $fixed=array_values(array_filter($active,fn($r)=>$r['type']==='fixed'&&$r['price']!==null));
    return ['currency'=>'USD','fetchedAt'=>now_iso(),'period'=>'90 Tage','context'=>['parallel'=>$parallelName,'grade'=>trim(($card['grader']??'').' '.($card['grade']??''))?:'Unbewertet'],'salesAverage'=>count($completed)?round(array_sum(array_column($completed,'price'))/count($completed),2):null,'averageCount'=>count($completed),'salesMedian'=>median(array_column($auctions,'price')),'salesCount'=>count($auctions),'lastSale'=>$auctions[0]??null,'askingMedian'=>median(array_column($fixed,'price')),'askingMin'=>$fixed?min(array_column($fixed,'price')):null,'askingCount'=>count($fixed),'sales'=>array_slice($auctions,0,8),'offers'=>array_slice($active,0,8),'warnings'=>$warnings];
}
function load_market(array $card,string $key,bool $force=false): array {
    if(!$key)throw new AppError('Bitte den Cardsight-Schlüssel unter Einstellungen hinterlegen.',503);
    $id=require_uuid($card['cardsightId']??'');
    $cacheKey=hash('sha256',json_encode(['eur-average-v3',$id,$card['parallel']??'',$card['grader']??'',$card['grade']??'',hash('sha256',$key)]));
    $cache=read_private('market-cache',[]);$entry=$cache[$cacheKey]??null;
    if(!$force&&$entry&&$entry['expires']>time())return array_merge($entry['data'],['cached'=>true]);
    $parallel=null;$parallelName='Basiskarte';$name=trim($card['parallel']??'');
    if($name){
        $details=cardsight_request('/v1/catalog/cards/'.$id,$key);
        $matches=array_values(array_filter($details['parallels']??[],fn($p)=>normalized($p['name']??'')===normalized($name)));
        if(count($matches)!==1||!valid_uuid($matches[0]['id']??''))throw new AppError('Die Variante „'.$name.'“ konnte nicht eindeutig zugeordnet werden. Bitte den exakten Cardsight-Parallel-Namen in der Karte eintragen. Es werden keine Preise anderer Varianten angezeigt.',409);
        $parallel=$matches[0]['id'];$parallelName=clean_api_text($matches[0]['name']);
    }
    $query=['parallel_id'=>$parallel??'null','limit'=>100,'listing_type'=>'both'];
    if(empty($card['grader'])&&empty($card['grade']))$query['grade_id']='null';
    elseif(empty($card['grader'])||empty($card['grade']))throw new AppError('Für passende Preise bitte Grading-Anbieter und Grade vollständig eintragen.',409);
    $history=[];$offers=[];$warnings=[];
    try{$history=cardsight_request('/v1/pricing/'.$id.'?'.http_build_query(array_merge($query,['period'=>'90d'])),$key);}catch(AppError $e){$warnings[]='Verkäufe: '.$e->getMessage();}

    if(!$history&&!$offers)throw new AppError(implode(' ',$warnings)?:'Für diese Karte sind keine Marktdaten verfügbar.',502);
    $snapshot=market_snapshot($history,$offers,$card,$parallel,$parallelName,$warnings);
    $fx=usd_eur_rate();$snapshot['averageEur']=$snapshot['salesAverage']===null?null:round($snapshot['salesAverage']*$fx['rate'],2);$snapshot['exchange']=$fx;$snapshot['currency']='EUR';
    // Only short-term performance caching. These records never enter collection backups.
    private_transaction('market-cache',function($all)use($cacheKey,$snapshot){$all=is_array($all)?$all:[];$all=array_filter($all,fn($e)=>$e['expires']>time());$all[$cacheKey]=['expires'=>time()+600,'data'=>$snapshot];return[array_slice($all,-50,null,true),null];});
    return array_merge($snapshot,['cached'=>false]);
}

function usd_eur_rate(): array {
    $cached=read_private('fx-cache');
    if(is_array($cached)&&($cached['expires']??0)>time())return $cached['data'];
    $ch=curl_init('https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json');
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>15,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS]);
    $raw=curl_exec($ch);$status=curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);
    $json=is_string($raw)&&strlen($raw)<100000?json_decode($raw,true):null;
    $rate=$json['usd']['eur']??null;$date=$json['date']??'';$stamp=is_string($date)?strtotime($date):false;
    if($status!==200||!is_numeric($rate)||$rate<=0||$rate>10||!$stamp||$stamp<time()-7*86400||$stamp>time()+86400)throw new AppError('Euro-Wechselkurs gerade nicht verfügbar. Bitte später aktualisieren.',502);
    $data=['rate'=>(float)$rate,'date'=>$date,'source'=>'Currency API / jsDelivr'];
    private_transaction('fx-cache',fn($old)=>[['expires'=>time()+21600,'data'=>$data],null]);return $data;
}

function sleeper_league(string $sport): ?string {
    return match(strtolower(trim($sport))){'american football','nfl'=>'nfl','basketball','nba'=>'nba',default=>null};
}
function sleeper_name(string $name): string {
    $ascii=function_exists('iconv')?iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$name):$name;
    return strtolower(preg_replace('/[^\p{L}\p{N}]/u','',$ascii===false?$name:$ascii));
}
function sleeper_match(array $players,string $name): array {
    $needle=sleeper_name($name);$matches=[];
    foreach($players as $id=>$p){if(!is_array($p))continue;
        $full=trim((string)($p['full_name']??''));if($full==='')$full=trim(($p['first_name']??'').' '.($p['last_name']??''));
        if($needle!==''&&sleeper_name($full)===$needle)$matches[]=['id'=>(string)($p['player_id']??$id),'name'=>$full,'team'=>clean_api_text($p['team']??''),'jerseyNumber'=>isset($p['number'])?clean_api_text((string)$p['number']):'','position'=>clean_api_text($p['position']??'')];
    }
    if(count($matches)!==1)return ['status'=>count($matches)>1?'ambiguous':'not-found','message'=>count($matches)>1?'Mehrere Sleeper-Spieler mit diesem Namen. Keine automatische Zuordnung.':'Kein eindeutiger Sleeper-Spieler gefunden.'];
    return ['status'=>'matched','player'=>$matches[0]];
}
function sleeper_players(string $league): array {
    if(!in_array($league,['nfl','nba'],true))throw new AppError('Sportart wird von dieser Sleeper-Anbindung nicht unterstützt.');
    // Sleeper recommends fetching the complete player list at most once daily.
    return private_transaction('sleeper-'.$league,function($cache)use($league){
        if(is_array($cache)&&($cache['expires']??0)>time())return [$cache,$cache];
        $ch=curl_init('https://api.sleeper.app/v1/players/'.$league);$body='';
        curl_setopt_array($ch,[CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>25,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_WRITEFUNCTION=>function($ch,$chunk)use(&$body){if(strlen($body)+strlen($chunk)>30000000)return 0;$body.=$chunk;return strlen($chunk);}]);
        $ok=curl_exec($ch);$status=curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);
        $raw=$ok!==false&&$status===200?json_decode($body,true):null;
        if(!is_array($raw)||!$raw||array_is_list($raw)){
            $failed=['expires'=>time()+86400,'players'=>[],'checkedAt'=>now_iso(),'error'=>'Sleeper ist derzeit nicht erreichbar oder liefert keine Spielerliste für '.strtoupper($league).'.'];
            return [$failed,$failed];
        }
        $players=[];foreach($raw as $id=>$p)if(is_array($p))$players[(string)$id]=array_intersect_key($p,array_flip(['player_id','full_name','first_name','last_name','team','number','position']));
        $next=['expires'=>time()+86400,'players'=>$players,'checkedAt'=>now_iso()];return [$next,$next];
    });
}
function sleeper_profile(array $card): array {
    $league=sleeper_league($card['sport']??'');
    if(!$league)return ['status'=>'unsupported','message'=>'Aktuelle Sleeper-Daten sind hier nur für NFL und NBA vorgesehen.'];
    try{$cache=sleeper_players($league);}catch(Throwable){return ['status'=>'unavailable','message'=>'Sleeper-Daten konnten nicht geladen werden.'];}
    if(!empty($cache['error']))return ['status'=>'unavailable','message'=>$cache['error'],'checkedAt'=>$cache['checkedAt']];
    return array_merge(sleeper_match($cache['players'],$card['player']??''),['checkedAt'=>$cache['checkedAt'],'league'=>strtoupper($league)]);
}
function apply_sleeper(array $card,array $profile): array {
    if(($profile['status']??'')!=='matched')return $card;
    $fields=[];foreach(['team','jerseyNumber','position']as $key){$value=$profile['player'][$key]??'';$card[$key]=$value;$fields[]=$key;}
    $card['sleeper']=['id'=>$profile['player']['id'],'checkedAt'=>$profile['checkedAt']??now_iso(),'fields'=>$fields];return $card;
}
