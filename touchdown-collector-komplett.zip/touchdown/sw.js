const CACHE='touchdown-static-v11';
const assets=['app-icon-192.png','app-icon-512.png','app-icon-180.png','logo.png','style.css','app.js','capture.js','checklists.js','sorting.js','sports.js','install.js','theme.js','stadium.svg','manifest.webmanifest'];
self.addEventListener('install',event=>{self.skipWaiting();});
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith('touchdown-static-')&&key!==CACHE)await caches.delete(key);await self.clients.claim();})()));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==location.origin||!assets.includes(url.pathname.split('/').pop()))return;
 event.respondWith((async()=>{const cache=await caches.open(CACHE);try{const response=await fetch(event.request);if(response.ok)await cache.put(event.request,response.clone());return response;}catch(error){const cached=await cache.match(event.request);if(cached)return cached;throw error;}})());});
