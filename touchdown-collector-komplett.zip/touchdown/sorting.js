const collator=new Intl.Collator('de',{numeric:true,sensitivity:'base'});
export const sortOptions=[['newest','Zuletzt hinzugefügt'],['collector','Sammler: Jahr → Set → Nummer'],['team','Team → Position'],['name','Spieler A–Z'],['value','Marktwert: höchster zuerst'],['year','Neuestes Jahr']];
export function preferredSort(){try{const sort=localStorage.getItem('touchdown-sort');if(sortOptions.some(([key])=>key===sort))return sort;}catch{}return 'newest';}
export function rememberSort(sort){if(sortOptions.some(([key])=>key===sort))try{localStorage.setItem('touchdown-sort',sort);}catch{}}
const text=value=>String(value??'').trim();
function compareText(a,b){a=text(a);b=text(b);return !a?(!b?0:1):!b?-1:collator.compare(a,b);}
const key=value=>text(value).toLowerCase().replace(/\([^)]*\)/g,'').replace(/[^a-z]/g,'');
const nfl=[['QB','Quarterback'],['RB','Running Back'],['FB','Fullback'],['WR','Wide Receiver'],['TE','Tight End'],['LT','Left Tackle'],['LG','Left Guard'],['C','Center'],['RG','Right Guard'],['RT','Right Tackle'],['OT','Offensive Tackle','T'],['OG','Offensive Guard','G','Guard'],['OL','Offensive Lineman','Offensive Line'],['DT','Defensive Tackle'],['NT','Nose Tackle'],['DE','Defensive End'],['EDGE','Edge Rusher'],['DL','Defensive Lineman','Defensive Line'],['OLB','Outside Linebacker'],['ILB','Inside Linebacker'],['MLB','Middle Linebacker'],['LB','Linebacker'],['CB','Cornerback'],['FS','Free Safety'],['SS','Strong Safety'],['S','Safety'],['DB','Defensive Back'],['DEF','Team Defense'],['KR','Kick Returner'],['PR','Punt Returner'],['K','Kicker','PK','Placekicker'],['P','Punter'],['H','Holder'],['LS','Long Snapper']];
const nba=[['PG','Point Guard'],['SG','Shooting Guard'],['G','Guard'],['SF','Small Forward'],['PF','Power Forward'],['F','Forward'],['C','Center']];
export function positionRank(card){
 const sport=key(card.sport),order=['americanfootball','nfl','football'].includes(sport)?nfl:['basketball','nba'].includes(sport)?nba:[];
 const positions=[text(card.position),...text(card.position).split(/[/,\-]/)].map(key);
 const ranks=positions.map(p=>order.findIndex(group=>group.some(alias=>key(alias)===p))).filter(rank=>rank>=0);
 return ranks.length?Math.min(...ranks):1000;
}
export function compareCards(a,b,sort,marketValue=()=>null){
 const name=()=>compareText(a.player,b.player)||compareText(a.id,b.id);
 const binder=()=>compareText(a.year,b.year)||compareText(a.set,b.set)||compareText(text(a.number).replace(/^#\s*/,''),text(b.number).replace(/^#\s*/,''))||(!text(a.parallel)?(!text(b.parallel)?0:-1):!text(b.parallel)?1:compareText(a.parallel,b.parallel))||name();
 if(sort==='collector')return compareText(a.sport,b.sport)||binder();
 if(sort==='team')return compareText(a.team,b.team)||compareText(a.sport,b.sport)||positionRank(a)-positionRank(b)||compareText(a.player,b.player)||binder();
 if(sort==='name')return name();
 if(sort==='year')return (!text(a.year)||!text(b.year)?compareText(a.year,b.year):compareText(b.year,a.year))||binder();
 if(sort==='value'){const av=marketValue(a),bv=marketValue(b);return (av==null?(bv==null?0:1):bv==null?-1:bv-av)||name();}
 return (!text(a.createdAt)||!text(b.createdAt)?compareText(a.createdAt,b.createdAt):compareText(b.createdAt,a.createdAt))||name();
}
export function sortHint(sort){return sort==='team'?'Teams A–Z · NFL: Quarterback, Running Back, Fullback, Wide Receiver, Tight End, Offensive Line, Defense und Special Teams. NBA: Point Guard bis Center. Unbekannte Teams/Positionen zuletzt. Aktueller Sleeper-Spielerstand.':sort==='collector'?'Ordner-Reihenfolge: Sportart → Jahr (älteste zuerst) → Set → Kartennummer (2 vor 10) → Variante. Basiskarten stehen vor Parallels; fehlende Angaben zuletzt.':'';}
