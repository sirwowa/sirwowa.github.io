<?php
declare(strict_types=1);
require __DIR__.'/_private/bootstrap.php';
security_headers();start_session();header('Content-Type: application/json; charset=utf-8');
try{
 if(!https_request()&&!localhost_request())throw new AppError('Bitte HTTPS verwenden.',403);
 $config=read_private('config');
 if($_SERVER['REQUEST_METHOD']==='GET'){$body=['configured'=>(bool)$config,'csrf'=>$_SESSION['csrf'],'authenticated'=>authenticated()];}
 elseif($_SERVER['REQUEST_METHOD']==='POST'){
  check_csrf($_SERVER['HTTP_X_CSRF_TOKEN']??'');$input=json_body(10000);if(!$config)throw new AppError('Bitte die Web-App zuerst im Browser einrichten.',503);login_rate();
  if(!password_verify((string)($input['password']??''),$config['passwordHash'])){login_rate(true);throw new AppError('Das Passwort ist nicht korrekt.',403);}
  login_rate(false,true);login_user();$body=['ok'=>true,'csrf'=>$_SESSION['csrf']];
 }else throw new AppError('Methode nicht unterstützt.',405);
 echo json_encode($body,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);
}catch(AppError $e){http_response_code($e->status);echo json_encode(['error'=>$e->getMessage()],JSON_UNESCAPED_UNICODE);}catch(Throwable){http_response_code(500);echo json_encode(['error'=>'Anmeldung momentan nicht möglich.']);}
