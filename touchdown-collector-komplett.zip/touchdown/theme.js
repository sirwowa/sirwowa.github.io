(() => {
  const media = matchMedia('(prefers-color-scheme: dark)');
  let preference='system';
  try { const saved=localStorage.getItem('sideline-theme'); if(['light','dark','system'].includes(saved))preference=saved; } catch {}
  function apply() {
    const dark=preference==='dark'||(preference==='system'&&media.matches);
    document.documentElement.dataset.theme=dark?'dark':'light';
    document.querySelectorAll('[data-theme-toggle]').forEach(button=>{
      button.textContent=dark?'☀':'☾';
      button.setAttribute('aria-label',dark?'Hellmodus aktivieren':'Dunkelmodus aktivieren');
      button.title=dark?'Hellmodus':'Dunkelmodus';
    });
    document.dispatchEvent(new CustomEvent('sideline-theme',{detail:{preference,dark}}));
  }
  window.SidelineTheme={getPreference:()=>preference,setPreference(value){if(!['light','dark','system'].includes(value))return;preference=value;try{localStorage.setItem('sideline-theme',value);}catch{}apply();}};
  document.addEventListener('click',event=>{if(event.target.closest('[data-theme-toggle]'))window.SidelineTheme.setPreference(document.documentElement.dataset.theme==='dark'?'light':'dark');});
  media.addEventListener('change',()=>{if(preference==='system')apply();});
  document.addEventListener('DOMContentLoaded',apply);
  apply();
})();
