package de.fourdoubleu.touchdown;
import android.graphics.Bitmap;
final class AutoGate{
 int[] previous,captured;long since=0,lastShot=0;boolean armed=true;int changed=0,blank=0;
 static double difference(int[] a,int[] b){if(a==null||b==null)return 999;double n=0;for(int i=0;i<a.length;i++)n+=Math.abs(a[i]-b[i]);return n/a.length;}
 int[] pixels(Bitmap b){int[] colors=new int[80*112],gray=new int[colors.length];b.getPixels(colors,0,80,0,0,80,112);for(int i=0;i<colors.length;i++)gray[i]=(((colors[i]>>16)&255)*299+((colors[i]>>8)&255)*587+(colors[i]&255)*114)/1000;return gray;}
 boolean ready(int[] g){double sum=0,sq=0;int bright=0;for(int v:g){sum+=v;sq+=v*v;if(v>250)bright++;}double mean=sum/g.length,spread=Math.sqrt(Math.max(0,sq/g.length-mean*mean));int sides=0;for(int side=0;side<4;side++){boolean vertical=side<2;int nominal=side==0?8:side==1?72:side==2?11:101;double best=0;for(int offset=-4;offset<=4;offset++){int n=0,total=0,pos=nominal+offset;for(int k=vertical?16:12;k<(vertical?96:68);k++){int a=vertical?k*80+pos-2:(pos-2)*80+k,b=vertical?k*80+pos+2:(pos+2)*80+k;total++;if(Math.abs(g[a]-g[b])>18)n++;}best=Math.max(best,(double)n/total);}if(best>.45)sides++;}return sides>=2&&spread>22&&mean>22&&mean<240&&(double)bright/g.length<.8;}
 void pause(){previous=null;since=0;}
 void lock(int[] g,long now){captured=g==null?null:g.clone();armed=false;lastShot=now;pause();}
 boolean update(Bitmap b,long now){int[] g=pixels(b);boolean good=ready(g);if(!armed){if(captured==null)captured=g.clone();blank=good?0:blank+1;changed=difference(g,captured)>14?changed+1:0;if(blank>=3||changed>=3){armed=true;pause();blank=changed=0;}else return false;}boolean still=difference(g,previous)<3;previous=g.clone();if(!good||!still){since=0;return false;}if(since==0)since=now;if(now-since>=1500&&now-lastShot>=2000){lock(g,now);return true;}return false;}
}
