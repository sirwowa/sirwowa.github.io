# growfor 12.5.1 – Android-Bridge direkt in der Web-App herunterladen

Im Bereich Mehr → GoPro WLAN-Brücke erscheint jetzt „Bridge-App für Android herunterladen (.apk)“. Der Download ist auch auf der Grow-Unterseite GoPro erreichbar und ohne angelegtes Tagebuch verfügbar. Die APK wird von deinem eigenen Webserver mit Android-MIME-Typ und richtigem Dateinamen ausgeliefert; kein externer Downloadlink nötig. Das feste signierte APK-Paket 0.1-test wird unverändert mitgeliefert.

Android 8 oder neuer. Android muss die Installation bestätigen; die Webseite installiert keine APK unbemerkt. Entwickelt für HERO8 Black; HERO7 Black weiterhin nicht auf realer Hardware geprüft. Kameraverbindung, Hintergrundbetrieb und automatische Bildübertragung bleiben geräteabhängig.

Enthält die Programmdateien aus 12.5. Vorhandene Konten, Grows, Wissensquellen, Kopplungen und das veröffentlichte Drehbuch bleiben unverändert. Diese Installationshilfe importiert oder ersetzt kein Drehbuch.

Getestet: Download aus der tatsächlichen App-Oberfläche, APK-Dateiname, Content-Type, Bytevergleich zur signaturgeprüften APK, Sichtbarkeit des HERO7-Hinweises und Layouts bei 320, 390 und 1280 Pixeln. Offline-Cache auf Version 28 erneuert; die feste APK ist im App-Paket vorgemerkt. Keine reale Android-/GoPro-Installation in dieser Testumgebung.
