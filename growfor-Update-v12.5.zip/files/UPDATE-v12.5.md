# growfor 12.5 – Begleiterwissen und bebilderte Comic-Kapitel

Enthält auch 12.4.1: Desktop-Seitennavigation, passende Karten, Geruchsanzeige und 552 Sorten.

## Begleiterwissen

Neuer Adminpunkt „Begleiterwissen“: eigene Texte, Quellenart, typische Fragen und Suchbegriffe, Quellenadresse, Prüfdatum, Entwurf/Freigabe und Testfragen. Die Wissenssammlung enthält höchstens 50 Quellen / 3 MB Text. Nur freigegebene Quellen sind für angemeldete Testkonten lesbar.

Der Begleiter verwendet eine lokale Wortsuche und gibt Originalstellen mit Quellenangabe wieder. Er trainiert kein KI-Modell, verifiziert keine Fachinhalte und erzeugt keine neue Diagnose. Bestehende Grenzen der Bedienhilfe bleiben bestehen. Keine frei konfigurierbaren Modell-Anweisungen oder ausführbaren Inhalte.

- PDF bis 10 MB / 100 Seiten: Textauszug im Browser, maximal 150.000 Zeichen. Bildscans ohne Textebene benötigen externe OCR. Der Text wird vor Speicherung zur Prüfung angezeigt.
- Excel-Vorlage: title, questions, content, keywords, source_url, reviewed, status. Erster Tabellenreiter, maximal 2 MB; alte Makros/Formeln werden abgewiesen. Import immer als Entwurf, auch wenn die Tabelle published enthält. Keywords werden zusammen mit questions gespeichert.
- Websiteimport: statische öffentliche HTTPS-HTML-/Textseite, bis 2 MB Übertragung. PHP-cURL wird benötigt. Interne IP-Adressen, fremde Ports, Zugangsdaten, Nicht-HTTPS und automatische Weiterleitungen sind ausgeschlossen. Bei Weiterleitung die endgültige Adresse verwenden. Dynamische/Loginseiten gegebenenfalls manuell übernehmen. Ein gespeicherter Link allein wird nicht als eingelesener Inhalt ausgegeben. Kein automatischer Live-Abruf bei jeder Frage.
- Websiteinhalte werden als unvertrauenswürdiger Text verarbeitet, nie als Code/Anweisung ausgeführt. Import zuerst als Entwurf prüfen.
- Globaler Hilfe-Knopf öffnet „Was ist los?“. Antworten aus Wissen nennen ihre Quelle. Nicht passende Fragen erzeugen keine frei erfundene Fachantwort.
- Bibliothek wird im kontogebundenen Offline-Cache mit vorbereitet. Cache-Version 27.

Vorlagen: Begleiter-Wissensvorlage.xlsx und Begleiter-Wissensvorlage.pdf, mit neutralen App-Beispielen, über den Adminbereich und separat verfügbar.

## Comic-Drehbuch

JSON-Drehbücher können nun eine eingebettete Bildsammlung enthalten: Atlas mit neun Kapitelmotiven und bis zu 30 Bildschritte pro Kapitel, Bildherkunft getrennt nach PDF/Illustration. Eingebettete PNG/JPEG/WebP werden geprüft; SVG und externe Bild-URLs sind ausgeschlossen. Maximale JSON-Größe 6 MB, Bildkante maximal 4096 Pixel.

Die separate private Ausgabe „Drehbuch-Comic-mit-Sour.json“ enthält die bereits bereitgestellten neun Comic-Kapitel mit unverändertem Text, neun neuen Sour-Motiven und 27 Bildschritten. Passende Original-Handzeichnungen stammen als Ausschnitte aus der erneut bereitgestellten 25-seitigen Scan-PDF. Für sechs Textschritte wurden neue Sour-Illustrationen anhand der vorhandenen Texte erstellt und als solche gekennzeichnet. Das ist keine vollständige Neuillustration sämtlicher 25 Scan-Seiten.

Bildschritt-Ansicht: Zurück/Weiter, Bildfolge und optionales Vorlesen. Vorlesen hängt von Browser, Gerät und verfügbaren Stimmen ab. Dies sind statische Bildschritte mit Übergängen, keine fotorealistisch animierten Handbewegungen. Download- und Entwurfsexportknöpfe bleiben entfernt; vollständiger Browser-Kopierschutz ist nicht möglich.

Das normale signierte Update enthält keinen privaten Drehbuchinhalt. Die separat gelieferte Einmal-Installationshilfe enthält ihn verschlüsselt, entschlüsselt ihn erst nach Codeeingabe und speichert die neun Comic-Kapitel auf deinem Server. Vorher wird die bisherige Datenbank gesichert. Konten, Grows, sonstige Einstellungen und Serverkonfiguration bleiben erhalten; das veröffentlichte Drehbuch wird durch die autorisierte bebilderte Fassung ersetzt.

## Validierung

Getestet: Quelleneditor, Entwurf/Freigabe, Quellenauszüge, Hilfe-Dialog, PDF- und Excel-Vorlagenimport, Ausschluss unveröffentlichter Einträge, CSRF und nicht angemeldete Zugriffe; Ablehnung interner URLs. Text-PDF wird korrekt eingelesen, Scan-PDF ohne Textebene meldet OCR-Bedarf. Erfolgreicher Live-Webabruf konnte in dieser Testumgebung ohne PHP-cURL nicht geprüft werden; der Fallback wird ausdrücklich gemeldet.

Bebilderte JSON-Datei (rund 4,6 MB) über den tatsächlichen Adminimport veröffentlicht; neun Kapitelmotive und alle 27 Bildschritte geprüft, Originaltexte verglichen, Bildherkunft getestet. Keine Downloadknöpfe im Leser. Smartphone/Desktop ohne horizontales Überlaufen.
