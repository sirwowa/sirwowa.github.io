<?php
if(!isset($db,$account,$a,$in)){http_response_code(404);exit;}
// Server-only administration. No password hashes, API keys or sessions are exported.
if(($account['role']??'')!=='admin')out(['error'=>'Nur für Administratoren.'],403);
if(($_SERVER['REQUEST_METHOD']??'')!=='POST')out(['error'=>'Bitte POST verwenden.'],405);
header('Cache-Control: no-store, private');
$db->exec("CREATE TABLE IF NOT EXISTS admin_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,actor_id INTEGER NOT NULL,action TEXT NOT NULL,entity TEXT NOT NULL,record_key TEXT NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS admin_trash(id INTEGER PRIMARY KEY AUTOINCREMENT,entity TEXT NOT NULL,record_key TEXT NOT NULL,payload TEXT NOT NULL,actor_id INTEGER NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP,restored TEXT)");
if(empty($_SESSION['admin_csrf']))$_SESSION['admin_csrf']=bin2hex(random_bytes(32));
if($a!=='admin_bootstrap'&&(!is_string($in['admin_csrf']??null)||!hash_equals($_SESSION['admin_csrf'],$in['admin_csrf'])))out(['error'=>'Die Admin-Sitzung bitte neu öffnen.'],403);
$entities=['grows'=>'id','entries'=>'id','settings'=>'user_id','strains'=>'id'];
function adminText($v,int $max,bool $empty=false): string {
    if(!is_string($v))out(['error'=>'Ungültiger Text.'],400);
    $v=trim($v);if((!$empty&&$v==='')||strlen($v)>$max*4||!preg_match('//u',$v)||preg_match_all('/./us',$v)>$max)out(['error'=>'Textlänge prüfen (maximal '.$max.' Zeichen).'],400);return $v;
}
function adminId($v): int {if(!is_scalar($v)||!preg_match('/^[1-9][0-9]{0,9}$/D',(string)$v))out(['error'=>'Ungültige Kennung.'],400);return (int)$v;}
function adminUser(PDO $db,int $id): array {$q=$db->prepare('SELECT * FROM users WHERE id=?');$q->execute([$id]);$u=$q->fetch();if(!$u)out(['error'=>'Konto nicht gefunden.'],404);return $u;}
function adminSafeUser(array $u): array {return publicAccount($u)+['disabled'=>(bool)$u['disabled'],'created'=>$u['created'],'auth_version'=>(int)$u['auth_version']];}
function adminRecord(PDO $db,string $entity,int $id): array {
    $keys=['grows'=>'id','entries'=>'id','settings'=>'user_id','strains'=>'id'];if(!isset($keys[$entity]))out(['error'=>'Unbekannter Datenbereich.'],400);
    $q=$db->prepare('SELECT * FROM '.$entity.' WHERE '.$keys[$entity].'=?');$q->execute([$id]);$r=$q->fetch();if(!$r)out(['error'=>'Datensatz nicht gefunden.'],404);
    if($entity==='grows'){$q=$db->prepare('SELECT user_id FROM shares WHERE grow_id=? ORDER BY user_id');$q->execute([$id]);$r['shares']=array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));}return $r;
}
function adminVersion(array $row): string {return hash('sha256',json_encode($row,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE));}
function adminCheckVersion(array $row,array $in): void {if(!hash_equals(adminVersion($row),(string)($in['version']??'')))out(['error'=>'Der Datensatz wurde inzwischen geändert. Deine Eingaben bleiben stehen. Lade die aktuelle Fassung neu und vergleiche sie.','code'=>'admin_conflict'],409);}
function adminLog(PDO $db,int $uid,string $action,string $entity,$id): void {$db->prepare('INSERT INTO admin_audit(actor_id,action,entity,record_key) VALUES(?,?,?,?)')->execute([$uid,$action,$entity,(string)$id]);}
function adminJson($text): string {
    if(!is_string($text)||strlen($text)>10*1024*1024)out(['error'=>'JSON darf höchstens 10 MB groß sein.'],400);
    try{$parsed=json_decode($text,false,128,JSON_THROW_ON_ERROR);}catch(Throwable $e){out(['error'=>'Ungültiges JSON: '.$e->getMessage()],400);}
    if(!is_object($parsed))out(['error'=>'Die Daten müssen ein JSON-Objekt sein.'],400);return json_encode($parsed,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
}
function adminCounts(PDO $db): array {$out=[];foreach(['users','grows','entries','settings','strains','feedback_threads','admin_trash'] as $t)$out[$t]=(int)$db->query('SELECT COUNT(*) FROM '.$t.($t==='admin_trash'?' WHERE restored IS NULL':''))->fetchColumn();return $out;}
$writes=['admin_kb_save','admin_account_save','admin_password_reset','admin_record_save','admin_archive','admin_restore','admin_orchard_save','admin_orchard_species_save','admin_site_save','admin_catalog_save','admin_mail_save','admin_handbook_save','admin_handbook_cleanup'];
if(in_array($a,$writes,true)){
    if(!preg_match('/^[A-Za-z0-9-]{16,80}$/D',(string)($in['client_request_id']??'')))out(['error'=>'Anfragekennung fehlt.'],400);
    beginSyncedWrite($db,$uid,$a,$in);
}
switch($a){
case 'admin_kb_get':
case 'admin_kb_web':
case 'admin_kb_save':kbAdmin($db,$uid,$a,$in);break;
case 'admin_handbook_get':
case 'admin_handbook_pdf_upload':
case 'admin_handbook_cleanup':
case 'admin_handbook_save':handbookAdmin($db,$uid,$a,$in);break;
case 'admin_mail_get':
case 'admin_mail_save':
case 'admin_mail_test':amAdmin($db,$account,$a,$in);break;
case 'admin_update_status':
case 'admin_update_upload':
case 'admin_update_install':
case 'admin_update_rollback':require_once __DIR__.'/update-engine.php';guAction($db,$uid,$a,$in);break;
case 'admin_catalog_get':
case 'admin_catalog_preview':
case 'admin_catalog_save': catalogAdmin($db,$uid,$a,$in);break;
case 'admin_site_get':out(siteSnapshot($db));
case 'admin_site_save':
 $old=siteSnapshot($db);if(!hash_equals($old['version'],(string)($in['version']??'')))out(['error'=>'Die App-Einstellungen wurden inzwischen geändert. Dein Entwurf bleibt erhalten. Bitte neu laden und vergleichen.'],409);$config=siteValidate($in['config']??null);$db->prepare("INSERT OR REPLACE INTO app_settings(setting_key,data) VALUES('appearance',?)")->execute([json_encode($config,JSON_UNESCAPED_UNICODE)]);adminLog($db,$uid,'site_settings','app_settings','appearance');out(['ok'=>1]+siteSnapshot($db));
case 'admin_orchard_species_save':
case 'admin_orchard_list':
case 'admin_orchard_get':
case 'admin_orchard_save': orchardAdmin($db,$uid,$a,$in);break;
case 'admin_bootstrap':
    out(['csrf'=>$_SESSION['admin_csrf'],'counts'=>adminCounts($db),'users'=>array_map('adminSafeUser',$db->query('SELECT * FROM users ORDER BY id')->fetchAll()),'runtime'=>['app'=>'growfor v12.5','php'=>PHP_VERSION,'sqlite'=>$db->query('SELECT sqlite_version()')->fetchColumn(),'max_users'=>MAX_USERS,'database_bytes'=>(int)filesize(__DIR__.'/data/weedys.sqlite')]]);
case 'admin_accounts':out(['users'=>array_map('adminSafeUser',$db->query('SELECT * FROM users ORDER BY id')->fetchAll())]);
case 'admin_account_get':$u=adminSafeUser(adminUser($db,adminId($in['id']??0)));out(['record'=>$u,'version'=>adminVersion($u)]);
case 'admin_account_save':
    $id=adminId($in['id']??0);$old=adminUser($db,$id);adminCheckVersion(adminSafeUser($old),$in);
    $name=adminText($in['name']??'',60);$login=strtolower(adminText($in['login_name']??'',40));$email=strtolower(adminText($in['email']??'',254));$role=$in['role']??'tester';$disabled=empty($in['disabled'])?0:1;
    if(!preg_match('/^[a-z0-9][a-z0-9_.-]{1,39}$/D',$login)||!filter_var($email,FILTER_VALIDATE_EMAIL)||!in_array($role,['admin','tester'],true))out(['error'=>'Anmeldename, E-Mail oder Rolle prüfen. Anmeldename: 2–40 Zeichen (a–z, 0–9, Punkt, Unterstrich, Bindestrich).'],400);
    if($id===$uid&&($disabled||$role!=='admin'))out(['error'=>'Du kannst deinen eigenen Adminzugang nicht sperren oder herabstufen.'],400);
    if($old['role']==='admin'&&($disabled||$role!=='admin')&&(int)$db->query("SELECT COUNT(*) FROM users WHERE role='admin' AND disabled=0")->fetchColumn()<=1)out(['error'=>'Mindestens ein aktiver Administrator muss erhalten bleiben.'],400);
    $q=$db->prepare('SELECT id FROM users WHERE id<>? AND (lower(login_name)=? OR lower(email)=?)');$q->execute([$id,$login,$email]);if($q->fetch())out(['error'=>'Anmeldename oder E-Mail bereits vergeben.'],409);
    if(strtolower($old['email'])!==$email)$db->prepare('UPDATE users SET email_verified_at=NULL WHERE id=?')->execute([$id]);
    // Every account administration change invalidates the target's other sessions.
    $db->prepare('UPDATE users SET name=?,login_name=?,email=?,role=?,disabled=?,auth_version=auth_version+1 WHERE id=?')->execute([$name,$login,$email,$role,$disabled,$id]);
    if($id===$uid)$_SESSION['auth_version']=(int)$old['auth_version']+1;
    adminLog($db,$uid,'account_update','users',$id);out(['ok'=>1,'user'=>adminSafeUser(adminUser($db,$id))]);
case 'admin_password_reset':
    $id=adminId($in['id']??0);$u=adminUser($db,$id);adminCheckVersion(adminSafeUser($u),$in);
    if($id===$uid)out(['error'=>'Das eigene Passwort bitte im Profil mit dem aktuellen Passwort ändern.'],400);
    $pw=$in['temporary_password']??'';if(!is_string($pw)||strlen($pw)<16||strlen($pw)>72)out(['error'=>'Das Übergangspasswort braucht 16 bis 72 Bytes.'],400);
    $db->prepare('UPDATE users SET pass=?,must_change_password=1,auth_version=auth_version+1 WHERE id=?')->execute([password_hash($pw,PASSWORD_DEFAULT),$id]);
    adminLog($db,$uid,'password_reset','users',$id);out(['ok'=>1]);
case 'admin_list':
    $entity=(string)($in['entity']??'grows');$page=max(1,min(100000,(int)($in['page']??1)));$offset=($page-1)*25;$owner=(int)($in['owner']??0);$search=adminText($in['search']??'',100,true);$args=[];$where=[];
    $lists=[
      'grows'=>['grows r LEFT JOIN users u ON u.id=r.user_id','r.id,r.name,u.login_name AS owner,r.user_id,r.updated','r.user_id',"r.name"],
      'entries'=>['entries r LEFT JOIN grows g ON g.id=r.grow_id LEFT JOIN users u ON u.id=r.user_id','r.id,r.grow_id,g.name AS name,u.login_name AS owner,r.user_id,r.day,r.type','r.user_id','r.data'],
      'settings'=>['settings r LEFT JOIN users u ON u.id=r.user_id','r.user_id AS id,u.login_name AS owner,r.user_id','r.user_id','r.data'],
      'strains'=>['strains r LEFT JOIN users u ON u.id=r.user_id',"r.id,u.login_name AS owner,r.user_id,substr(r.data,1,160) AS name",'r.user_id','r.data'],
      'activity'=>['activity r LEFT JOIN users u ON u.id=r.user_id','r.id,r.grow_id,u.login_name AS owner,r.act AS name,r.info,r.ts AS created','r.user_id','r.info'],
      'audit'=>['admin_audit r LEFT JOIN users u ON u.id=r.actor_id','r.id,u.login_name AS owner,r.action AS name,r.entity,r.record_key,r.created','r.actor_id','r.action'],
      'trash'=>['admin_trash r LEFT JOIN users u ON u.id=r.actor_id','r.id,u.login_name AS owner,r.entity,r.record_key,r.created,r.restored','r.actor_id','r.entity']
    ];
    if(!isset($lists[$entity]))out(['error'=>'Unbekannter Datenbereich.'],400);[$from,$cols,$ownerCol,$searchCol]=$lists[$entity];
    if($owner){$where[]=$ownerCol.'=?';$args[]=$owner;}if($search!==''){$where[]=$searchCol.' LIKE ?';$args[]='%'.$search.'%';}
    $w=$where?' WHERE '.implode(' AND ',$where):'';$q=$db->prepare('SELECT COUNT(*) FROM '.$from.$w);$q->execute($args);$count=(int)$q->fetchColumn();
    $q=$db->prepare('SELECT '.$cols.' FROM '.$from.$w.' ORDER BY '.($entity==='settings'?'r.user_id':'r.id').' DESC LIMIT 25 OFFSET '.$offset);$q->execute($args);out(['rows'=>$q->fetchAll(),'total'=>$count,'page'=>$page]);
case 'admin_record_get':
    $entity=(string)($in['entity']??'');$row=adminRecord($db,$entity,adminId($in['id']??0));out(['record'=>$row,'version'=>adminVersion($row)]);
case 'admin_record_save':
    $entity=(string)($in['entity']??'');$id=adminId($in['id']??0);$r=adminRecord($db,$entity,$id);adminCheckVersion($r,$in);$data=adminJson($in['data_json']??'');
    if($entity==='grows'){
      $name=adminText($in['name']??'',100);$owner=adminId($in['user_id']??0);adminUser($db,$owner);$shares=$in['shares']??[];if(!is_array($shares)||count($shares)>MAX_USERS)out(['error'=>'Freigaben prüfen.'],400);$members=[];foreach($shares as $member){$member=adminId($member);adminUser($db,$member);if($member!==$owner)$members[$member]=$member;}
      $db->prepare('UPDATE grows SET user_id=?,name=?,data=?,updated=CURRENT_TIMESTAMP WHERE id=?')->execute([$owner,$name,$data,$id]);if((int)$r['user_id']!==$owner)$db->prepare('UPDATE bridge_devices SET revoked_at=CURRENT_TIMESTAMP WHERE grow_id=? AND revoked_at IS NULL')->execute([$id]);$db->prepare('DELETE FROM shares WHERE grow_id=?')->execute([$id]);$q=$db->prepare('INSERT INTO shares(grow_id,user_id) VALUES(?,?)');foreach($members as $member)$q->execute([$id,$member]);
    }elseif($entity==='entries'){
      $gid=adminId($in['grow_id']??0);adminRecord($db,'grows',$gid);$author=adminId($in['user_id']??0);adminUser($db,$author);$day=(string)($in['day']??'');$date=DateTimeImmutable::createFromFormat('!Y-m-d',$day);if(!$date||$date->format('Y-m-d')!==$day)out(['error'=>'Ungültiges Datum.'],400);$type=(string)(json_decode($data,true)['type']??'');if(strlen($type)>40)out(['error'=>'Eintragstyp zu lang.'],400);
      $db->prepare('UPDATE entries SET grow_id=?,user_id=?,day=?,data=?,type=? WHERE id=?')->execute([$gid,$author,$day,$data,$type,$id]);
    }elseif($entity==='settings')$db->prepare('UPDATE settings SET data=? WHERE user_id=?')->execute([$data,$id]);
    else{$owner=adminId($in['user_id']??0);adminUser($db,$owner);$db->prepare('UPDATE strains SET user_id=?,data=? WHERE id=?')->execute([$owner,$data,$id]);}
    adminLog($db,$uid,'record_update',$entity,$id);out(['ok'=>1,'record'=>adminRecord($db,$entity,$id)]);
case 'admin_archive':
    $entity=(string)($in['entity']??'');if(!in_array($entity,['grows','entries','strains'],true))out(['error'=>'Dieser Bereich kann nicht archiviert werden.'],400);
    $id=adminId($in['id']??0);$r=adminRecord($db,$entity,$id);adminCheckVersion($r,$in);$payload=['record'=>$r,'entries'=>[],'activity'=>[]];
    if($entity==='grows'){foreach(['entries','activity'] as $t){$q=$db->prepare('SELECT * FROM '.$t.' WHERE grow_id=?');$q->execute([$id]);$payload[$t]=$q->fetchAll();}$db->prepare('DELETE FROM entries WHERE grow_id=?')->execute([$id]);$db->prepare('DELETE FROM activity WHERE grow_id=?')->execute([$id]);$db->prepare('DELETE FROM shares WHERE grow_id=?')->execute([$id]);}
    $db->prepare('INSERT INTO admin_trash(entity,record_key,payload,actor_id) VALUES(?,?,?,?)')->execute([$entity,(string)$id,json_encode($payload,JSON_UNESCAPED_UNICODE),$uid]);$trash=(int)$db->lastInsertId();$db->prepare('DELETE FROM '.$entity.' WHERE id=?')->execute([$id]);adminLog($db,$uid,'archive',$entity,$id);out(['ok'=>1,'trash_id'=>$trash]);
case 'admin_restore':
    $tid=adminId($in['id']??0);$q=$db->prepare('SELECT * FROM admin_trash WHERE id=?');$q->execute([$tid]);$t=$q->fetch();if(!$t||$t['restored'])out(['error'=>'Archivierter Datensatz nicht verfügbar.'],409);
    $p=json_decode($t['payload'],true);$entity=$t['entity'];$r=$p['record'];$q=$db->prepare('SELECT id FROM '.$entity.' WHERE id=?');$q->execute([$r['id']]);if($q->fetch())out(['error'=>'Die Kennung ist bereits vorhanden. Nichts wurde überschrieben.'],409);
    adminUser($db,(int)$r['user_id']);if($entity==='entries')adminRecord($db,'grows',(int)$r['grow_id']);
    // Every identifier below comes from a server-created archive, never the request.
    $insert=function($table,$row)use($db){$cols=array_keys($row);$q=$db->prepare('INSERT INTO '.$table.' ('.implode(',',$cols).') VALUES('.implode(',',array_fill(0,count($cols),'?')).')');$q->execute(array_values($row));};
    $shares=$r['shares']??[];unset($r['shares']);$insert($entity,$r);if($entity==='grows'){foreach(['entries','activity'] as $table)foreach($p[$table] as $row)$insert($table,$row);foreach($shares as $member){adminUser($db,(int)$member);$db->prepare('INSERT INTO shares(grow_id,user_id) VALUES(?,?)')->execute([$r['id'],$member]);}}
    $db->prepare('UPDATE admin_trash SET restored=CURRENT_TIMESTAMP WHERE id=?')->execute([$tid]);adminLog($db,$uid,'restore',$entity,$r['id']);out(['ok'=>1]);
case 'admin_export':
    $db->exec('BEGIN');$tables=['users'=>array_map('adminSafeUser',$db->query('SELECT * FROM users ORDER BY id')->fetchAll())];
    foreach(['grows','entries','settings','strains','shares','activity','feedback_threads','feedback_messages','admin_audit','admin_trash','orchard_knowledge','orchard_species','app_settings'] as $table)$tables[$table]=$db->query('SELECT * FROM '.$table)->fetchAll();
    $tables['bridge_devices']=$db->query('SELECT id,user_id,grow_id,issuer_id,name,auth_version,expires_at,revoked_at,last_seen,created FROM bridge_devices')->fetchAll();
    $tables['handbook_assets']=$db->query('SELECT id,name,bytes,checksum,created FROM handbook_assets')->fetchAll();
    $tables['timelapse_frames']=$db->query('SELECT id,grow_id,user_id,frame_key,captured_at,source,bytes,width,height,checksum,created FROM timelapse_frames')->fetchAll();
    foreach($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'c\\_%' ESCAPE '\\'")->fetchAll(PDO::FETCH_COLUMN) as $table){if(preg_match('/^c_[a-z_]+$/D',$table))$tables[$table]=$db->query('SELECT * FROM '.$table)->fetchAll();}
    $db->exec('COMMIT');adminLog($db,$uid,'data_export','all','all');out(['format'=>'growing-admin-data-v1','exported'=>gmdate('c'),'note'=>'Datenexport ohne Passwörter, Passwort-Hashes, Sitzungsschlüssel oder Server-Konfiguration. Zeitrafferfotos nur als Metadaten; Bilder per data/-Sicherung. Kein vollständiger Server-Backup und kein automatischer Import.','tables'=>$tables]);
default:out(['error'=>'Unbekannte Adminfunktion.'],404);
}
