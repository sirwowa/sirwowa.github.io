/* Durable per-account outbox. Retries use server-side idempotency receipts. */
'use strict';
window.GrowingSync=(()=>{
 const SCOPE=new URL('./',location.href).pathname,DB='growing-device-v1:'+SCOPE,READS=new Set(['grows','entries','summary','settings_get','strains_list','shares','feedback_threads','feedback_thread','site_config','catalog_library','kb_library','orchard_library','handbook_library','handbook_pdf','timelapse_grows','timelapse_list','timelapse_photo']);
 const WRITES=new Set(['grow_phase_save','entry_save','settings_save','feedback_send','feedback_reply','timelapse_frame_save']);
 const settingsRefs=new Map();
 let connection=null,flushing=null,serial=0,statusTimer=null;
 const clone=x=>JSON.parse(JSON.stringify(x));
 const uuid=()=>crypto.randomUUID?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(20)),n=>n.toString(16).padStart(2,'0')).join('');
 function open(){if(connection)return connection;connection=new Promise((resolve,reject)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>{for(const name of ['cache','meta','outbox'])r.result.createObjectStore(name,{keyPath:name==='outbox'?'id':'key'})};r.onsuccess=()=>{r.result.onversionchange=()=>{r.result.close();connection=null};resolve(r.result)};r.onerror=()=>reject(new Error('Lokaler Speicher ist nicht verfügbar. Bitte Browsereinstellungen prüfen.'))});return connection}
 async function storage(store,method,value){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(store,method==='get'||method==='getAll'?'readonly':'readwrite'),r=tx.objectStore(store)[method](value);let result;r.onsuccess=()=>{result=r.result};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error||new Error('Lokales Speichern fehlgeschlagen.'));tx.onabort=()=>reject(tx.error||new Error('Lokales Speichern abgebrochen.'))})}
 const active=async()=>((await storage('meta','get','active'))||{}).value||null;
 const notify=()=>{clearTimeout(statusTimer);statusTimer=setTimeout(()=>{dispatchEvent(new Event('growing:sync-state'));updateStatus().catch(()=>{})},20)};
 const cacheKey=(id,a,d={})=>id+':'+a+':'+(d.grow_id??d.thread_id??d.frame_id??d.asset_id??'');
 const putCache=async(id,a,d,value)=>storage('cache','put',{key:cacheKey(id,a,d),value:clone(value)});
 const cached=async(id,a,d)=>((await storage('cache','get',cacheKey(id,a,d)))||{}).value;
 async function assertUser(id){if((await active())?.id!==id||S.user?.id!==id){const e=new Error('Das Konto wurde gewechselt. Bitte die Ansicht neu öffnen.');e.status=409;throw e}}
 async function pending(id){return(await storage('outbox','getAll')).filter(x=>x.user_id===id).sort((a,b)=>a.created-b.created)}
 async function forced(id){return !!((await storage('meta','get','offline:'+id))||{}).value}
 async function raw(a,d={}){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),a==='handbook_pdf'?90000:12000);try{const r=await fetch('api.php?action='+a,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d),signal:controller.signal,cache:'no-store'});let j;try{j=await r.json()}catch{const e=new Error('Server-Antwort ungültig. Lokale Daten bleiben erhalten.');e.status=r.status>=500?r.status:undefined;throw e}if(!r.ok){const e=new Error(j.error||'Serverfehler');e.status=r.status;e.code=j.code;throw e}return j}finally{clearTimeout(timer)}}
 async function migrateLegacy(user){
  try{
   const oldUser=JSON.parse(localStorage.getItem('weedys_c_me')||'null')?.user;
   const old=JSON.parse(localStorage.getItem('weedys_q')||'[]');
   if(!old.length||oldUser?.id!==user.id||oldUser?.email!==user.email)return;
   for(let i=0;i<old.length;i++){
    const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(old[i])+':'+i+':'+user.id));
    const key='legacy-'+Array.from(new Uint8Array(digest),n=>n.toString(16).padStart(2,'0')).join('').slice(0,40);
    if(!await storage('outbox','get',key))await storage('outbox','put',{id:key,user_id:user.id,action:'entry_save',data:{...old[i],client_request_id:key,sync_owner_id:user.id},created:Date.now()*1000+i,error:''});
   }
   localStorage.removeItem('weedys_q');
  }catch(error){throw new Error('Die alte Offline-Warteschlange konnte nicht übernommen werden. Sie wurde nicht gelöscht.')}
 }
 async function markUser(user){const previous=await active();if(previous?.id!==user?.id){settingsRefs.clear();S.settingsVersion=null}await storage('meta','put',{key:'active',value:user?clone(user):null});if(user){await putCache(user.id,'me',{}, {user});await migrateLegacy(user)}notify()}
 async function confirmPhase(id,data,result){const base=await cached(id,'grows',{});if(base?.grows){const grow=base.grows.find(g=>Number(g.id)===Number(data.grow_id));if(grow){grow.data=grow.data||{};grow.data.manual_phase=result.manual_phase;await putCache(id,'grows',{},base);}}}
 async function overlay(id,a,d,result){
  result=clone(result);const queue=await pending(id);
  if(a==='grows')for(const q of queue.filter(x=>x.action==='grow_phase_save')){const g=result.grows.find(g=>Number(g.id)===Number(q.data.grow_id));if(g){g.data=g.data||{};g.data.manual_phase=q.data.phase;}}
  if(a==='settings_get'){const q=queue.filter(x=>x.action==='settings_save').at(-1);if(q)result={data:q.data.data,versionRef:{after_request:q.id}};else if(result.version)result.versionRef={hash:result.version}}
  if(a==='entries')for(const q of queue.filter(x=>x.action==='entry_save'&&Number(x.data.grow_id)===Number(d.grow_id)))result.entries.unshift({id:'local:'+q.id,day:q.data.day,data:q.data.data,uid:id,by:'Du · noch nicht gesendet',pending:true});
  if(a==='summary')for(const q of queue.filter(x=>x.action==='entry_save'))result.entries.unshift({id:'local:'+q.id,grow_id:q.data.grow_id,day:q.data.day,type:q.data.data.type,w:q.data.data.water||'',ml:q.data.data.ml||'',fn:q.data.data.feed_name||'',pending:true});
  if(a==='feedback_threads')for(const q of queue.filter(x=>x.action==='feedback_send'&&!x.data.thread_id))result.threads.unshift({id:'local:'+q.id,subject:q.data.subject,last_message:q.data.body,unread:0,pending:true,owner_name:'Du',updated:new Date(q.created/1000).toISOString()});
  if(a==='feedback_thread')for(const q of queue.filter(x=>['feedback_send','feedback_reply'].includes(x.action)&&Number(x.data.thread_id)===Number(d.thread_id)))result.messages.push({id:'local:'+q.id,body:q.data.body,kind:'message',sender_id:id,sender_name:'Du',created:new Date(q.created/1000).toISOString(),pending:true});
  if(a==='timelapse_list'){for(const q of queue.filter(x=>x.action==='timelapse_frame_save'&&Number(x.data.grow_id)===Number(d.grow_id))){if(result.frames.some(f=>f.frame_key===q.data.frame_key))continue;result.frames.push({id:'local:'+q.id,frame_key:q.data.frame_key,grow_id:q.data.grow_id,user_id:id,captured_at:q.data.captured_at,source:q.data.source,bytes:Math.floor((q.data.photo.length-23)*3/4),pending:true,error:q.error||''})}result.frames.sort((a,b)=>a.captured_at.localeCompare(b.captured_at)||String(a.id).localeCompare(String(b.id)));}
  return result;
 }
 const fingerprint=data=>JSON.stringify(data);
 function bindSettings(ref){S.settingsVersion=ref||null;if(ref)settingsRefs.set(fingerprint(S.set),ref)}
 function followVisibleSettings(){if(!S.user)return;const ref=settingsRefs.get(fingerprint(S.set));if(ref)S.settingsVersion=ref}
 async function confirmSettings(userId,key,data,result){
  if(!result.version)return;
  const ref={hash:result.version};settingsRefs.set(fingerprint(data),ref);
  if(S.user?.id===userId&&fingerprint(S.set)===fingerprint(data))S.settingsVersion=ref;
  const cache=await cached(userId,'settings_get',{});
  if(cache?.versionRef?.after_request===key)await putCache(userId,'settings_get',{}, {...cache,version:result.version,versionRef:ref});
 }
 async function api(a,d={}){
  if(a==='site_config'&&!S.user){try{const r=await raw(a,d);await storage('meta','put',{key:'public-site-config',value:r});return r}catch{const saved=await storage('meta','get','public-site-config');if(saved?.value)return saved.value;throw new Error('App-Einstellungen sind noch nicht offline geladen.')}}
  if(['account_reset_request','account_reset_finish','account_verify_finish'].includes(a))return raw(a,d);
  if(a==='login'){const r=await raw(a,d);await storage('meta','delete','pending-logout');await markUser(r.user);return r}
  if(a==='logout'){try{await raw(a,d);await storage('meta','delete','pending-logout')}catch{await storage('meta','put',{key:'pending-logout',value:true})}await markUser(null);return {ok:1}}
  let user=await active();
  if(a==='me'){
   if((await storage('meta','get','pending-logout'))?.value){try{await raw('logout');await storage('meta','delete','pending-logout')}catch{}return {user:null}}
   if(user&&await forced(user.id)){S.offline=true;return {user}}
   try{const r=await raw(a,d);await markUser(r.user);S.offline=false;return r}catch(error){if(!error.status&&user){S.offline=true;notify();return {user}}throw error}
  }
  user=S.user||user;if(!user)throw new Error('Bitte zuerst online anmelden.');
  const id=user.id,manual=await forced(id);
  if(a==='password_change'){const r=await raw(a,{...d,sync_owner_id:id});await assertUser(id);await markUser(r.user);return r}
  if(a==='entry_delete'&&String(d.id).startsWith('local:')){if(manual||!navigator.onLine)throw new Error('Bitte diesen Eintrag zuerst online synchronisieren. Löschaktionen benötigen eine Verbindung.');const key=String(d.id).slice(6);await flush(true);const receipt=await storage('meta','get','receipt:'+id+':'+key);if(!receipt?.value?.id)throw new Error('Dieser Eintrag ist noch nicht bestätigt. Bitte die Synchronisierung prüfen.');return raw('entry_delete',{id:receipt.value.id,sync_owner_id:id})}
  if(WRITES.has(a)){
   const key=uuid(),data={...clone(d),client_request_id:key,sync_owner_id:id};
   if(a==='settings_save'){const ref=S.settingsVersion;if(ref?.hash)data.settings_base_hash=ref.hash;else if(ref?.after_request)data.settings_after_request=ref.after_request;settingsRefs.set(fingerprint(d.data),{after_request:key})}
   const item={id:key,user_id:id,action:a,data,created:Date.now()*1000+(serial++%1000),error:''};
   await storage('outbox','put',item);notify();
   if(a==='settings_save')await putCache(id,'settings_get',{}, {data:d.data,versionRef:{after_request:key}});
   if(!manual&&navigator.onLine&&(await pending(id)).some(x=>x.created<item.created)){setTimeout(()=>flush().then(()=>flush()).catch(()=>{}),0);return {ok:1,id:'local:'+key,queued:true,thread_id:d.thread_id||null}}
   if(!manual&&navigator.onLine){try{const result=await raw(a,data);if(a==='settings_save')await confirmSettings(id,key,d.data,result);if(a==='grow_phase_save')await confirmPhase(id,d,result);await storage('meta','put',{key:'receipt:'+id+':'+key,value:result});await storage('outbox','delete',key);S.offline=false;notify();return result}catch(error){if(a==='timelapse_frame_save'&&error.status&&error.status<500){item.error=error.message;await storage('outbox','put',item);notify();return {ok:1,id:'local:'+key,queued:true,conflict:true}}if(a==='settings_save'&&(error.code==='settings_conflict'||error.code==='settings_version_required')){item.error=error.message;await storage('outbox','put',item);notify();return {ok:1,id:'local:'+key,queued:true,conflict:true}}if(error.status&&error.status<500){await storage('outbox','delete',key);if(a==='settings_save')settingsRefs.delete(fingerprint(d.data));notify();throw error}}}
   S.offline=true;notify();return {ok:1,id:'local:'+key,queued:true,thread_id:d.thread_id||null};
  }
  if(READS.has(a)){
   if(!manual){try{const r=await raw(a,{...d,sync_owner_id:id});await assertUser(id);await putCache(id,a,d,r);S.offline=false;notify();return overlay(id,a,d,r)}catch(error){if(error.status&&error.status<500)throw error}}
   await assertUser(id);const c=await cached(id,a,d);if(c!==undefined){S.offline=true;notify();return overlay(id,a,d,c)}
   // Empty bases allow the first locally queued note/message to be displayed.
   if(a==='entries'||a==='summary')return overlay(id,a,d,{entries:[]});
   if(a==='timelapse_list')return overlay(id,a,d,{frames:[],total_bytes:0,limit_frames:5000,limit_bytes:536870912});
   if(a==='feedback_threads')return overlay(id,a,d,{threads:[]});
   throw new Error('Diese Ansicht ist noch nicht offline gespeichert. Öffne sie einmal online.');
  }
  if(manual||!navigator.onLine)throw new Error('Für diese Aktion musst du online sein. Deine vorgemerkten Einträge bleiben erhalten.');
  const result=await raw(a,{...d,sync_owner_id:id});await assertUser(id);if(a==='timelapse_frame_delete')await storage('cache','delete',cacheKey(id,'timelapse_photo',{frame_id:d.frame_id}));if(a==='profile_save'&&result.user)await markUser(result.user);S.offline=false;return result;
 }
 async function flushWork(retry=false){
  const user=await active();if(!user||!S.user||S.user.id!==user.id||!navigator.onLine||await forced(user.id))return;
  let remote;try{remote=(await raw('me')).user}catch{return}
  if(!remote||remote.id!==user.id||remote.must_change_password){notify();return}
  S.offline=false;const sent=[];
  for(const item of await pending(user.id)){
   if(item.error&&!retry)continue;
   if((await active())?.id!==user.id)break;
   try{const result=await raw(item.action,item.data);if(item.action==='settings_save')await confirmSettings(user.id,item.id,item.data.data,result);if(item.action==='grow_phase_save')await confirmPhase(user.id,item.data,result);await storage('meta','put',{key:'receipt:'+user.id+':'+item.id,value:result});await storage('outbox','delete',item.id);sent.push({action:item.action,result})}
   catch(error){if(error.status&&error.status<500||error.code==='settings_version_required'){item.error=error.message;await storage('outbox','put',item);if(error.status===401||error.status===403)break}else break}
  }
  if(sent.length){try{if(sent.some(x=>x.action==='grow_phase_save')){const growId=S.g?.id;await loadGrows();if(growId)S.g=S.grows.find(g=>g.id===growId)||null;}await refresh();if(!window.GrowingNavigation?.hasUnsaved())render({keepScroll:true})}catch{}dispatchEvent(new CustomEvent('growing:synced',{detail:{sent}}))}
  notify();
 }
 async function flush(retry=false){if(flushing)return flushing;flushing=(navigator.locks?navigator.locks.request('growing-outbox',()=>flushWork(retry)):flushWork(retry)).finally(()=>{flushing=null});return flushing}
 function activated(worker){return new Promise((resolve,reject)=>{
  if(!worker){reject(new Error('Die App ist noch nicht offline verfügbar.'));return}
  let timer;const cleanup=()=>{clearTimeout(timer);worker.removeEventListener('statechange',check)};
  const check=()=>{if(worker.state==='activated'){cleanup();resolve(worker)}else if(worker.state==='redundant'){cleanup();reject(new Error('Das Offline-Paket konnte nicht vollständig geladen werden. Bitte später online erneut versuchen.'))}};
  worker.addEventListener('statechange',check);timer=setTimeout(()=>{cleanup();reject(new Error('Die Offline-Vorbereitung dauert zu lange. Bitte später erneut versuchen.'))},15000);check();
 })}
 function shellStatus(worker){return new Promise((resolve,reject)=>{
  const channel=new MessageChannel();const finish=()=>{clearTimeout(timer);channel.port1.close();channel.port2.close()};
  const timer=setTimeout(()=>{finish();reject(new Error('Die aktuelle App-Version ist noch nicht vollständig offline verfügbar. Bitte online neu laden.'))},5000);
  channel.port1.onmessage=e=>{finish();resolve(e.data)};
  worker.postMessage({type:'growing:cache-status'},[channel.port2]);
 })}
 async function prepare(){
  if(!('serviceWorker' in navigator)||!isSecureContext)throw new Error('Für einen Offline-Start braucht die App HTTPS und Service-Worker-Unterstützung.');
  if(!S.user)throw new Error('Bitte anmelden.');const id=S.user.id;
  if(await forced(id))throw new Error('Bitte zuerst den manuellen Offline-Modus ausschalten.');
  if(!navigator.onLine)throw new Error('Bitte die Offline-Ansichten bei bestehender Internetverbindung vorbereiten.');
  const me=(await raw('me')).user;if(!me||me.id!==id||me.must_change_password)throw new Error('Bitte zuerst erneut online anmelden. Deine lokalen Einträge bleiben erhalten.');
  const registration=await navigator.serviceWorker.register('sw.js',{updateViaCache:'none'});
  const worker=await activated(registration.installing||registration.waiting||registration.active);
  const status=await shellStatus(worker);
  if(status.version!=='v27'||!status.complete)throw new Error('Das aktuelle App-Paket ist noch nicht vollständig offline gespeichert. Bitte online neu laden und erneut vorbereiten.');
  async function fresh(a,d={}){const result=await raw(a,{...d,sync_owner_id:id});await assertUser(id);await putCache(id,a,d,result);return result}
  const snapshot=await fresh('grows');
  const handbook=await fresh('handbook_library');if(handbook.document?.type==='pdf')await fresh('handbook_pdf',{asset_id:handbook.document.asset_id});
  await Promise.all(['summary','settings_get','strains_list','feedback_threads','orchard_library','site_config','catalog_library','kb_library','handbook_library'].map(a=>fresh(a)));
  for(const g of snapshot.grows){await fresh('entries',{grow_id:g.id});await fresh('shares',{grow_id:g.id})}
  const threads=await fresh('feedback_threads');for(const t of threads.threads)await fresh('feedback_thread',{thread_id:t.id,peek:true});
  if(navigator.storage?.persist)await navigator.storage.persist();notify();
 }
 function downloadBackup(data){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='growing-konfliktsicherung-'+Date.now()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
 async function resolveSettings(){
  if(!S.user||!navigator.onLine)throw new Error('Bitte für die Konfliktprüfung online anmelden.');
  if(window.GrowingNavigation&&!GrowingNavigation.confirmDiscard('Ungespeicherte Formulareingaben verwerfen und den Speicherkonflikt prüfen?'))return;
  const id=S.user.id;let chosen=false;
  const work=async()=>{
   const items=(await pending(id)).filter(x=>x.action==='settings_save');if(!items.length)return;
   const remote=await raw('settings_get',{sync_owner_id:id});await assertUser(id);
   if(!remote.version)throw new Error('Bitte zuerst die aktuellen Serverdateien hochladen. Die lokalen Daten bleiben erhalten.');
   const desired=items.at(-1).data.data,localCount=Array.isArray(desired.expense_ledger)?desired.expense_ledger.length:0,remoteCount=Array.isArray(remote.data.expense_ledger)?remote.data.expense_ledger.length:0;
   downloadBackup({created:new Date().toISOString(),server:remote.data,local:desired,pending:items});
   if(!confirm('Eine Sicherung beider Fassungen wurde zum Download bereitgestellt. Lokal: '+localCount+' Belege; Server: '+remoteCount+' Belege. Die gesamte lokale Einstellungsfassung einschließlich Belegen, Inventar und Figur ersetzt den Serverstand. Wirklich übernehmen?'))return;
   await assertUser(id);const key=uuid(),data={data:clone(desired),client_request_id:key,sync_owner_id:id,settings_base_hash:remote.version};
   await storage('outbox','put',{id:key,user_id:id,action:'settings_save',data,created:Date.now()*1000+(serial++%1000),error:''});
   for(const item of items)await storage('outbox','delete',item.id);
   await putCache(id,'settings_get',{}, {data:desired,versionRef:{after_request:key}});S.set=clone(desired);bindSettings({after_request:key});chosen=true;
  };
  if(navigator.locks)await navigator.locks.request('growing-outbox',work);else await work();
  if(!chosen)return false;await flush(true);notify();return (await pending(id)).some(x=>x.action==='settings_save')?'pending':'saved';
 }
 async function toggle(){if(!S.user)return;const value=!(await forced(S.user.id));await storage('meta','put',{key:'offline:'+S.user.id,value});S.offline=value;notify();if(!value)await flush(true);render({keepScroll:true})}
 async function discard(id){const item=await storage('outbox','get',id);if(item?.user_id!==S.user?.id)return;if(!confirm('Vorgemerkten Eintrag von diesem Gerät entfernen? Bereits vom Server empfangene Einträge werden dadurch nicht gelöscht.'))return;await storage('outbox','delete',id);notify();render({keepScroll:true})}
 async function updateStatus(){let el=document.getElementById('sync-status');if(!el){el=document.createElement('div');el.id='sync-status';el.setAttribute('role','status');el.setAttribute('aria-live','polite');document.getElementById('app')?.before(el)}if(!S.user||S.user.must_change_password){el.hidden=true;return}const q=await pending(S.user.id),manual=await forced(S.user.id),failed=q.filter(x=>x.error).length;el.hidden=!q.length&&!manual&&!S.offline&&navigator.onLine;el.textContent=(manual?'Offline-Modus':(!navigator.onLine||S.offline)?'Offline':'Online')+(q.length?' · '+q.length+' Einträge warten auf Synchronisierung':' · lokal gespeicherte Ansicht')+(failed?' · '+failed+' benötigen deine Prüfung':'')}
 addEventListener('online',()=>flush().catch(()=>{}));addEventListener('focus',()=>flush().catch(()=>{}));document.addEventListener('visibilitychange',()=>{if(!document.hidden)flush().catch(()=>{})});addEventListener('growing:render',()=>{followVisibleSettings();updateStatus().catch(()=>{})});addEventListener('offline',()=>{if(S.user)S.offline=true;notify()});
 setInterval(()=>{if(!document.hidden&&navigator.onLine)active().then(async u=>{if(u&&(await pending(u.id)).length)await flush()}).catch(()=>{})},30000);
 return {api,flush,prepare,toggle,discard,pending,forced,notify,raw,bindSettings,resolveSettings};
})();
