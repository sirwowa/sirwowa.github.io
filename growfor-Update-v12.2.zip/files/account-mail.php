<?php
/* Account recovery via confirmed email. No raw tokens, passwords or mail bodies in logs. */
function amInit(PDO $db): void {
 $db->exec('BEGIN IMMEDIATE');try{
 $cols=array_column($db->query('PRAGMA table_info(users)')->fetchAll(),'name');if(!in_array('email_verified_at',$cols,true))$db->exec('ALTER TABLE users ADD COLUMN email_verified_at TEXT DEFAULT NULL');
 $db->exec('CREATE TABLE IF NOT EXISTS account_tokens(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL,email TEXT NOT NULL,auth_version INTEGER NOT NULL,kind TEXT NOT NULL,expires INTEGER NOT NULL,used INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL)');
 $db->exec('CREATE TABLE IF NOT EXISTS account_mail_limits(scope TEXT NOT NULL,ts INTEGER NOT NULL)');$db->exec('CREATE INDEX IF NOT EXISTS account_mail_limit_idx ON account_mail_limits(scope,ts)');
 $db->exec('CREATE TABLE IF NOT EXISTS account_mail_log(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,kind TEXT NOT NULL,status TEXT NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP)');
 $db->prepare('DELETE FROM account_tokens WHERE expires<?')->execute([time()-86400]);$db->prepare('DELETE FROM account_mail_limits WHERE ts<?')->execute([time()-86400]);$db->exec("DELETE FROM account_mail_log WHERE created<datetime('now','-30 days')");
 $db->exec('COMMIT');}catch(Throwable $e){$db->exec('ROLLBACK');throw $e;}
}
function amEmail(string $email): bool {
 if(!filter_var($email,FILTER_VALIDATE_EMAIL)||preg_match('/[\r\n]/',$email))return false;
 $domain=strtolower(substr(strrchr($email,'@'),1));return !preg_match('/(?:^|\.)(invalid|test|example|localhost)$/D',$domain)&&!in_array($domain,['example.com','example.net','example.org'],true);
}
function amConfig(PDO $db): array {
 $q=$db->prepare("SELECT data FROM app_settings WHERE setting_key='account_mail'");$q->execute();$raw=$q->fetchColumn();$data=$raw?json_decode($raw,true):[];
 return ['config'=>array_replace(['enabled'=>false,'site_url'=>'https://growfor.de','sender'=>'noreply@growfor.de'],is_array($data)?$data:[]),'version'=>hash('sha256',$raw?:'{}'),'transport_available'=>function_exists('mail')];
}
function amTls(): bool {return !empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off';}
function amLimit(PDO $db,array $limits): bool {
 $db->exec('BEGIN IMMEDIATE');try{$allowed=true;foreach($limits as $scope=>$max){$q=$db->prepare('SELECT COUNT(*) FROM account_mail_limits WHERE scope=? AND ts>?');$q->execute([$scope,time()-3600]);if((int)$q->fetchColumn()>=$max)$allowed=false;}
 if($allowed){$q=$db->prepare('INSERT INTO account_mail_limits(scope,ts) VALUES(?,?)');foreach($limits as $scope=>$max)$q->execute([$scope,time()]);}$db->exec('COMMIT');return $allowed;}catch(Throwable $e){$db->exec('ROLLBACK');throw $e;}
}
function amLog(PDO $db,?int $uid,string $kind,bool $sent): void {$db->prepare('INSERT INTO account_mail_log(user_id,kind,status) VALUES(?,?,?)')->execute([$uid,$kind,$sent?'accepted':'failed']);}
function amSend(PDO $db,array $cfg,array $user,string $kind,string $message): bool {
 $ok=false;if(function_exists('mail')&&amEmail($user['email'])&&amEmail($cfg['sender'])){
  $subject=$kind==='verify'?'growfor: E-Mail-Adresse bestaetigen':($kind==='reset'?'growfor: Passwort zuruecksetzen':'growfor: Testmail');
  $headers=['From'=>'growfor <'.$cfg['sender'].'>','MIME-Version'=>'1.0','Content-Type'=>'text/plain; charset=UTF-8'];
  try{$ok=@mail($user['email'],$subject,$message,$headers,'-f'.escapeshellarg($cfg['sender']));}catch(Throwable $e){$ok=false;}
 }amLog($db,(int)$user['id'],$kind,$ok);return $ok;
}
function amIssue(PDO $db,array $user,string $kind,array $cfg): bool {
 $token=bin2hex(random_bytes(32));$hash=hash('sha256',$token);$ttl=$kind==='verify'?86400:1800;
 $db->prepare('INSERT INTO account_tokens(token_hash,user_id,email,auth_version,kind,expires,created) VALUES(?,?,?,?,?,?,?)')->execute([$hash,(int)$user['id'],strtolower($user['email']),(int)$user['auth_version'],$kind,time()+$ttl,time()]);
 $url=rtrim($cfg['site_url'],'/').'/account-access.html?mode='.$kind.'#token='.$token;
 $text=$kind==='verify'?"Bitte bestaetige deine E-Mail-Adresse fuer growfor. Der Link gilt 24 Stunden.\n\n":"Du hast einen Link zum Zuruecksetzen deines growfor-Passworts angefordert. Er gilt 30 Minuten und kann einmal verwendet werden.\n\n";
 $ok=amSend($db,$cfg,$user,$kind,$text.$url."\n\nDein Anmeldename: ".$user['login_name']."\n\nOeffne den Link und bestaetige die Aktion auf der Seite. Falls du das nicht angefordert hast, ignoriere diese Nachricht. Dein Passwort bleibt unveraendert. Gib niemals dein Passwort per E-Mail weiter.\n");
 if(!$ok)$db->prepare('DELETE FROM account_tokens WHERE token_hash=?')->execute([$hash]);return $ok;
}
function amConsume(PDO $db,string $kind,array $input): void {
 $token=$input['token']??'';if(!is_string($token)||!preg_match('/^[a-f0-9]{64}$/D',$token))out(['error'=>'Dieser Link ist ungültig oder abgelaufen. Bitte einen neuen Link anfordern.'],400);
 $next='';if($kind==='reset'){$next=$input['password']??'';$confirm=$input['confirm']??'';if(!is_string($next)||strlen($next)<10||strlen($next)>72||!is_string($confirm)||$confirm!==$next)out(['error'=>'Bitte ein Passwort mit 10 bis 72 Bytes zweimal identisch eingeben.'],400);}
 if(!amLimit($db,['consume-ip:'.$kind.':'.hash('sha256',$_SERVER['REMOTE_ADDR']??'')=>20]))out(['error'=>'Zu viele Versuche. Bitte später erneut versuchen.'],429);
 // Hash before the transaction to avoid holding the write lock while deriving a password hash.
 $newHash=$kind==='reset'?password_hash($next,PASSWORD_DEFAULT):null;$hash=hash('sha256',$token);$db->exec('BEGIN IMMEDIATE');
 try{
  $q=$db->prepare('SELECT t.*,u.email AS current_email,u.auth_version AS current_version,u.disabled,u.email_verified_at FROM account_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=?');$q->execute([$hash]);$r=$q->fetch();$q->closeCursor();
  if(!$r||$r['kind']!==$kind||$r['used']||$r['expires']<time()||$r['disabled']||strtolower($r['current_email'])!==$r['email']||(int)$r['current_version']!==(int)$r['auth_version']||($kind==='reset'&&!$r['email_verified_at'])){$db->exec('ROLLBACK');out(['error'=>'Dieser Link ist ungültig oder abgelaufen. Bitte einen neuen Link anfordern.'],400);}
  if($kind==='verify')$db->prepare('UPDATE users SET email_verified_at=? WHERE id=?')->execute([gmdate('c'),$r['user_id']]);
  else $db->prepare('UPDATE users SET pass=?,must_change_password=0,auth_version=auth_version+1 WHERE id=?')->execute([$newHash,$r['user_id']]);
  $db->prepare('UPDATE account_tokens SET used=1 WHERE token_hash=?')->execute([$hash]);
  if($kind==='reset')$db->prepare('UPDATE account_tokens SET used=1 WHERE user_id=?')->execute([$r['user_id']]);
  $db->exec('COMMIT');out(['ok'=>1]);
 }catch(Throwable $e){if($db->inTransaction())$db->exec('ROLLBACK');throw $e;}
}
function amPublic(PDO $db,string $action,array $input): void {
 if(($_SERVER['REQUEST_METHOD']??'')!=='POST')out(['error'=>'Bitte POST verwenden.'],405);
 if(!amTls())out(['error'=>'Passwort- und E-Mail-Wiederherstellung benötigen HTTPS.'],503);
 $cfg=amConfig($db)['config'];
 if(!$cfg['enabled'])out(['error'=>'E-Mail-Wiederherstellung ist noch nicht eingerichtet. Bitte den Administrator kontaktieren.'],503);
 if($action==='account_reset_finish'){amConsume($db,'reset',$input);return;}
 if($action==='account_verify_finish'){amConsume($db,'verify',$input);return;}
 if(!$cfg['enabled']||!function_exists('mail'))out(['error'=>'E-Mail-Wiederherstellung ist noch nicht eingerichtet. Bitte den Administrator kontaktieren.'],503);
 $email=is_string($input['email']??null)?strtolower(trim($input['email'])):'';
 $ip=hash('sha256',$_SERVER['REMOTE_ADDR']??'');$address=hash('sha256',$email);
 $allowed=amLimit($db,['reset-ip:'.$ip=>8,'reset-address:'.$address=>3]);
 if($allowed&&amEmail($email)){$q=$db->prepare('SELECT * FROM users WHERE lower(email)=? LIMIT 2');$q->execute([$email]);$users=$q->fetchAll();$q->closeCursor();if(count($users)===1&&!$users[0]['disabled']&&!empty($users[0]['email_verified_at']))amIssue($db,$users[0],'reset',$cfg);}
 usleep(200000);out(['ok'=>1,'message'=>'Falls ein aktives Konto mit dieser bestätigten E-Mail-Adresse existiert, erhältst du einen Rücksetzlink. Bitte auch den Spamordner prüfen.']);
}
function amVerifyRequest(PDO $db,array $account): void {
 if(!amTls())out(['error'=>'E-Mail-Bestätigung benötigt HTTPS.'],503);$cfg=amConfig($db)['config'];
 if(!$cfg['enabled']||!function_exists('mail'))out(['error'=>'Der Administrator muss den E-Mail-Versand zuerst einrichten.'],503);
 if(!amEmail($account['email']))out(['error'=>'Bitte zuerst eine echte E-Mail-Adresse im Profil hinterlegen. Platzhalteradressen können nicht verwendet werden.'],400);
 if(!empty($account['email_verified_at']))out(['ok'=>1,'message'=>'Deine E-Mail-Adresse ist bereits bestätigt.']);
 if(!amLimit($db,['verify-user:'.$account['id']=>3]))out(['error'=>'Bitte später erneut versuchen. Maximal drei Bestätigungsmails pro Stunde.'],429);
 if(!amIssue($db,$account,'verify',$cfg))out(['error'=>'Die Bestätigungsmail konnte nicht an den Versand übergeben werden. Bitte den Admin informieren.'],503);out(['ok'=>1,'message'=>'Bestätigungsmail wurde an den Versand übergeben. Bitte Posteingang und Spamordner prüfen.']);
}
function amAdmin(PDO $db,array $account,string $action,array $input): void {
 $snapshot=amConfig($db);
 if($action==='admin_mail_get'){$snapshot['logs']=$db->query('SELECT l.id,l.user_id,u.login_name,l.kind,l.status,l.created FROM account_mail_log l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 30')->fetchAll();out($snapshot);}
 if($action==='admin_mail_save'){
  if(!hash_equals($snapshot['version'],(string)($input['version']??'')))out(['error'=>'Versandeinstellungen wurden inzwischen geändert. Bitte neu laden und vergleichen.'],409);
  $c=$input['config']??null;if(!is_array($c)||array_diff(array_keys($c),['enabled','site_url','sender'])||!is_bool($c['enabled']??null)||!is_string($c['site_url']??null)||!is_string($c['sender']??null))out(['error'=>'Versandeinstellungen prüfen.'],400);
  $url=rtrim(trim($c['site_url']),'/');$sender=strtolower(trim($c['sender']));$parts=parse_url($url);
  if(!filter_var($url,FILTER_VALIDATE_URL)||!is_array($parts)||($parts['scheme']??'')!=='https'||!in_array($parts['host']??'',['growfor.de','www.growfor.de'],true)||isset($parts['user'],$parts['pass'])||isset($parts['user'])||isset($parts['query'])||isset($parts['fragment'])||isset($parts['port'])||str_contains($parts['path']??'','..')||!amEmail($sender)||strtolower(substr(strrchr($sender,'@'),1))!=='growfor.de')out(['error'=>'Bitte eine HTTPS-Adresse auf growfor.de und eine echte Absenderadresse unter @growfor.de verwenden.'],400);
  $config=['enabled'=>$c['enabled'],'site_url'=>$url,'sender'=>$sender];$db->prepare("INSERT OR REPLACE INTO app_settings(setting_key,data) VALUES('account_mail',?)")->execute([json_encode($config,JSON_UNESCAPED_UNICODE)]);adminLog($db,(int)$account['id'],'mail_settings','app_settings','account_mail');out(['ok'=>1]+amConfig($db));
 }
 if(!amTls())out(['error'=>'Versandtest benötigt HTTPS.'],503);
 if(!amEmail($account['email']))out(['error'=>'Bitte eine echte eigene E-Mail-Adresse im Profil hinterlegen.'],400);
 if(!amLimit($db,['test-user:'.$account['id']=>3]))out(['error'=>'Maximal drei Versandtests pro Stunde.'],429);
 $ok=amSend($db,$snapshot['config'],$account,'test',"Das ist eine Testnachricht deiner growfor-Installation.\n\nErst wenn du diese Nachricht tatsaechlich erhalten hast, den E-Mail-Versand im Adminbereich aktivieren. Eine Annahme durch PHP mail() allein bestaetigt keine Zustellung.\n");out(['ok'=>$ok?1:0,'message'=>$ok?'Testmail an den Versand übergeben. Bitte den tatsächlichen Eingang prüfen.':'PHP hat die Testmail nicht angenommen. Bitte Hosting und Absenderpostfach prüfen.']);
}
