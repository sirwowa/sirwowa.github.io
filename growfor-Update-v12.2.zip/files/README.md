# growfor v12.2

Für E-Mail-Bestätigung und Passwortwiederherstellung zuerst `UPDATE-v12.2.md` lesen. Absender: noreply@growfor.de. Versand nach Testmail im Adminbereich aktivieren. Vorhandenes data/ und eigene config.php behalten.

# growfor v12.1

Zuerst `GROWFOR-INSTALLATION.md` für die Installation auf https://growfor.de lesen. Vorhandenes `data/` und eigene `config.php` behalten.

# Aktueller Stand: Growing v12

Für die Installation und die neuen Funktionen zuerst `UPDATE-v12.md` lesen. Vorhandenes `data/` und eigene `config.php` behalten. Die nachfolgende ältere Anleitung bleibt als Hintergrund erhalten.

GROWING – vollständiges Wiederherstellungspaket mit modernisierter Oberfläche

INSTALLATION BEI ALL-INKL
1. Vorhandenen App-Ordner sichern, falls dort noch Dateien oder Daten liegen.
2. ZIP lokal entpacken. Für die AES-verschlüsselte ZIP gegebenenfalls 7-Zip verwenden.
3. Den INHALT des Ordners weedys/ in deinen gewünschten Webordner hochladen.
   Auch die versteckten .htaccess-Dateien übertragen. ZIP und Anleitung gehören nicht ins Webverzeichnis.
4. PHP 8 oder neuer mit PDO_SQLite und HTTPS sind erforderlich.
   Eine MySQL-Datenbank ist nicht nötig. Ob dein Tarif diese Voraussetzungen bereits erfüllt, muss auf dem Hosting geprüft werden.
5. Die Website über HTTPS öffnen. Die lokale SQLite-Datenbank und sechs reservierten Konten werden beim ersten API-Aufruf automatisch erstellt.
6. Zuerst als Admin anmelden und sofort das neue Passwort zweimal eingeben.
   Danach die Testpersonen ihre jeweils eigenen Passwörter setzen lassen.
7. Nach der Einrichtung testen: Login, Logout, Fotos und Offline-Synchronisierung.

KONTEN
Admin: Name Admin ODER E-Mail Waldemar@stiwing.de
Testpersonen: Test1, Test2, Test3, Test4, Test5
Groß-/Kleinschreibung der Anmeldenamen wird ignoriert.
Die Startpasswörter entsprechen dem im Chat vereinbarten Wert.
Für alle sechs Konten wird beim ersten Login ein Passwortwechsel erzwungen.
Das neue Passwort muss mindestens zehn Zeichen haben und zweimal identisch eingegeben werden.
Das alte Startpasswort darf danach nicht mehr funktionieren.
Die offene Registrierung ist gesperrt. Testpersonen brauchen keine E-Mail-Adresse.
Anzeige- und Anmeldenamen sind getrennt; ein geänderter Profilname ändert den Login nicht.
Das Paket enthält keine alte Nutzerdatenbank. Frühere Einträge sind nur aus einem separaten Backup wiederherstellbar.
Die Startpasswörter sind schwach: Einrichtung zeitnah abschließen und die Konten nicht ungenutzt mit Startpasswort online lassen.

DATENSCHUTZ UND SICHERUNG
- data/ enthält nach dem Start Konten und Einträge. Regelmäßig privat sichern.
- .htaccess schützt data/, config.php und accounts.php bei Apache.
- Prüfen: Ein direkter Aufruf von data/weedys.sqlite muss blockiert sein (403 oder 404).
- Niemals data/, Datenbank-Backups oder das entpackte Komplettpaket in ein öffentliches Git-Repository hochladen.
- Keine vorhandene Datenbank durch eine leere Datei ersetzen.
- Die ZIP ist verschlüsselt; der Entpackschlüssel wird ausschließlich im Chat mitgeteilt.

UMFANG UND PRÜFUNG
Das Paket stellt die Dateien aus deiner ursprünglichen ZIP wieder her, ergänzt das visuelle Update
und ersetzt die Kontoeinrichtung. Bestehende Fachinhalte und Berechnungen wurden nicht validiert oder erweitert.
Geprüft werden hier die Authentifizierung, sechs reservierte Konten, Passwortbestätigung,
serverseitiger Erstlogin-Zwang, geschlossene Registrierung und die mobile Darstellung.
ALL-INKL, GoPro, PWA-Installation und echte Offline-Synchronisierung müssen auf dem Zielhosting separat geprüft werden.

DESIGN-REVISION 2
Engere Gestaltung am Referenzbild: dunkle kompakte Karten, limettengrüne Akzente, flache Navigation und gerahmte vorhandene Animation. Keine neue Fotoübersicht. Die angehängte PDF wurde nicht integriert.

REVISION 3 – NAVIGATION UND SOUR
- App-interner Verlauf: Zurück-Pfeil, Browser-Zurück und Rechtswisch nahe dem linken Rand.
- Die äußersten 24 Pixel bleiben für native Browsergesten frei.
- Gesten beginnen nicht auf Eingabefeldern, Links oder Schaltflächen.
- Bei ungespeicherten Formulareingaben wird vor der Zurück-Navigation gefragt.
- Sour ist eine freigestellte, neu gerenderte Variante des gelieferten Maskottchens.
- Vier Einführungsschritte und kontextbezogene, lokale Bedienhinweise; kein Chatbot.
- Die Einführung kann im Profil erneut geöffnet, der Begleiter ausgeblendet werden.
- Keine neue Fotoübersicht und kein PDF-Drehbuch-Import.
- Den vorhandenen data/-Ordner bei Updates unbedingt erhalten.

GROWING – REVISION 4
Die App heißt jetzt Growing. Der Name ist in HTML, App-Metadaten, Manifest und Benutzeroberfläche eingetragen.
Sour ist im Logo, im neuen Homebildschirm-Icon und in der dekorativen Gießszene auf der Anmeldeseite integriert.
Die Gießszene nutzt leichte CSS-Bewegung und animierte Wassertropfen; kein Video und keine anatomische Figurenanimation.
Die Bewegung lässt sich pausieren und respektiert die Geräteeinstellung für reduzierte Bewegung.
Die Tour führt in zehn Schritten durch reale Menüs, hebt Bedienelemente hervor und stellt danach die Ausgangsansicht wieder her.
Sie erstellt keine Tagebücher, verändert keine Nutzerdaten und enthält keine Cannabis-Anbauplanung oder phasenbezogene Anbautipps.
Das Fragefeld beantwortet App-Fragen anhand einer lokalen FAQ. Keine allgemeine KI, kein externer Dienst, kein API-Schlüssel.
Unbekannte Fragen werden als solche benannt. Fragen werden nicht übertragen oder dauerhaft gespeichert.
Vorhandene Datenbankdateien und lokale Speicherkennungen behalten ihre bisherigen Namen, damit bestehende Daten erhalten bleiben.
Falls eine installierte App noch den alten Namen oder das alte Symbol zeigt: Daten sichern, altes Homebildschirm-Symbol entfernen und die Website erneut hinzufügen.
Eine tatsächliche Installation unter iOS oder Android wurde in dieser Umgebung nicht geprüft.

VALIDIERUNG REVISION 4
Browser: responsive Anmeldung (320–1280 Pixel), Animation pausieren, reduzierte Bewegung, echte Menü-Tour mit zehn Schritten,
unveränderter Browser-Verlauf nach der Tour, lokale Antworten, ehrliche Fallback-Antwort und sichere Textdarstellung geprüft.
Manifestname und Icon-Abmessungen 192/512/180/48 geprüft. Neue Assets sind über den Service Worker offline verfügbar.
ALL-INKL, physische Geräte und vollständige Offline-Datensynchronisierung wurden nicht neu Ende zu Ende geprüft.

GROWING – REVISION 5

NEU
- Das Logo im oberen App-Bereich öffnet Sour per Klick, Fingertipp oder Tastatur.
- Neue winkende Sour-Pose, zusätzliche kurze Bewegungen und eine Erfolgsanimation nach der Synchronisierung.
- Die Geräteeinstellung für reduzierte Bewegung wird weiterhin beachtet.
- Beim Speichern, beim Wechsel der Ansicht und beim Zurückgehen beginnt die Seite oben.
- Hintergrund-Synchronisierung ersetzt keine gerade bearbeiteten Formulare.
- Indoor/Outdoor und eine eigene Standortnotiz sind manuelle Tagebuch-Kennzeichnungen.
  Sie verändern keine Berechnungen und enthalten keine Outdoor-Anbauempfehlungen.
- Sortendatenbank, sortenspezifische Charaktere und Anbauempfehlungen wurden nicht erweitert.

PRIVATE TESTNACHRICHTEN
Unter Mehr → Nachricht an Admin (bzw. als Admin: Testfeedback & Antworten) öffnest du die Unterhaltungen.
Testpersonen sehen nur ihre eigenen Nachrichten. Der Admin sieht das Testfeedback und kann in den Unterhaltungen antworten.
Die Bestätigung erscheint erst nach Annahme durch den Server, mit folgendem Wortlaut:
Vielen Dank für deine Nachricht. Sobald ich es Bearbeitet habe melde ich mich. Danke für deine Unterstützung
Diese Bestätigung wird zusätzlich in der Unterhaltung gespeichert.
Offline-Nachrichten stehen zunächst als vorgemerkt auf dem Gerät; die Bestätigung folgt nach der Übertragung.
Neue Antworten werden in der geöffneten App angezeigt. Es gibt keine E-Mail- oder Betriebssystem-Pushnachrichten bei geschlossener App.

OFFLINE & SYNCHRONISIERUNG
1. Einmal online anmelden.
2. Unter Mehr → Offline & Synchronisierung auf Ansichten offline vorbereiten tippen.
3. Tagebucheinträge (einschließlich ihrer eingegebenen Daten), Einstellungen und Nachrichten werden bei Verbindungsverlust lokal vorgemerkt.
4. Bei wiederkehrender Verbindung und gültiger Sitzung sendet die geöffnete App automatisch. Auch beim Start, Zurückkehren in die App und regelmäßig bei geöffneter App wird geprüft.
5. Bei abgelaufener Sitzung erneut online anmelden. Die kontogebundene Warteschlange bleibt erhalten.
6. Der optionale manuelle Offline-Schalter erzwingt Offline-Arbeit. Zum Senden musst du diesen Schalter wieder ausschalten.
7. Neue Konten, neue Tagebücher, Passwortänderungen und reguläre Löschaktionen brauchen eine Verbindung.
8. Ausstehende oder abgelehnte Einträge stehen im Bereich Offline & Synchronisierung. Dort kannst du erneut senden oder nur die lokale Kopie entfernen.
   Bereits auf dem Server empfangene Einträge werden durch Entfernen der lokalen Kopie nicht gelöscht.

Browserdaten nicht löschen, solange Einträge ausstehen. Offline-Daten sind auf diesem Gerät gespeichert und nicht zusätzlich verschlüsselt.
Nutze diese Funktion deshalb auf einem eigenen, vertrauenswürdigen Gerät.
Bei Einstellungen gilt beim Einsatz mehrerer Geräte weiterhin die zuletzt serverseitig gespeicherte Fassung.
Ältere Offline-Einträge werden nur bei passender alter Kontozuordnung automatisch übernommen. Unklare Zuordnungen werden beibehalten und angezeigt.

UPDATE
- Vorher App-Dateien und den kompletten vorhandenen data/-Ordner sichern.
- Inhalt des ZIP-Ordners growing/ in deinen bisherigen App-Ordner hochladen, inklusive versteckter .htaccess-Dateien.
- Den vorhandenen data/-Ordner NICHT löschen oder durch einen leeren Ordner ersetzen.
- Falls config.php eigene Hosting-Einstellungen oder Schlüssel enthält, diese Datei beibehalten. Diese Version verlangt keine neuen Konfigurationswerte.
- Die neuen Datenbanktabellen entstehen automatisch. Keine MySQL-Datenbank, neuen Dienste oder Cronjobs erforderlich.
- Danach einmal online neu laden und Offline-Ansichten erneut vorbereiten.
- Vorhandene Konten und Passwörter bleiben bei erhaltenem data/-Ordner unverändert.
- Bei einer Neuinstallation werden die sechs vereinbarten Konten automatisch erstellt und verlangen beim ersten Login einen Passwortwechsel.

GEPRÜFT
PHP-/SQLite-API: privater Nachrichten-Zugriff, ausschließlich Admin-Antworten, exakte automatische Bestätigung, Lesestatus, Kontozuordnung und idempotente Wiederholungen.
Chromium: Logo-Hilfe, Zurück/Speichern von oben, Testnachrichten und Admin-Antworten, Offline-Neustart, automatische Übertragung von Notizen/Einstellungen/Nachrichten, verlorene Serverantwort ohne Duplikat.
Außerdem: Kontotrennung, Übernahme alter Offline-Einträge nur beim passenden Konto, richtige Reihenfolge vorgemerkter Einstellungen und Erhalt ungespeicherter Eingaben bei Hintergrund-Synchronisierung.
Darstellung zwischen 320 und 1280 Pixeln geprüft. JavaScript- und PHP-Syntax geprüft.
ALL-INKL, echte iOS-/Android-Geräte und Benachrichtigungen außerhalb der geöffneten App wurden nicht live geprüft.

GROWING – REVISION 6

FIGUREN
Im Profil gibt es jetzt „Charakter auswählen“. 35 unterschiedliche dekorative Porträts sind enthalten:
Sour, zwei eigens gestaltete weibliche Figuren namens Purple Punch und Mango Sweet sowie Porträts für die 32 bereits vorhandenen Sortennamen.
Wähle deine Figur manuell oder aktiviere den rein optischen Wechsel passend zum Namen im geöffneten Tagebuch.
Außerhalb eines passenden Tagebuchs bleibt deine persönliche Auswahl aktiv. Die Einstellung lässt sich jederzeit im Profil ändern.
Die Figuren sind Fantasiegestalten. Aussehen und Farben stellen keine botanischen Merkmale, Geruchsstärken oder Anbaueigenschaften dar.
Die lokale Fragehilfe, die Tour und der aufrufbare Begleiter verwenden die ausgewählte Figur und ihren Namen.
Purple Punch und Mango Sweet wurden als Figuren ergänzt, nicht als neue Anbau-Datensätze. Die Sortendatenbank bleibt unverändert bei den bisherigen Einträgen.
Keine neue Cannabis-Anfängerführung, Outdoor-Anbautipps, Geruchsangaben oder sortenspezifischen Gießempfehlungen enthalten.

NEUER KOSTENBEREICH
- Belege und tatsächlich erfasste Beträge, optional nach Tagebuch zugeordnet.
- Direkte Betragseingabe oder Berechnung aus gemessenen kWh, erfassten Litern bzw. einem Anteil eines Einkaufs.
- Bei Anteilen müssen Packungsinhalt und verwendete Menge dieselbe Einheit haben.
- Exakte Dezimalrechnung mit Aufrundung ab einem halben Cent; maximal sechs Nachkommastellen in den Eingaben.
- Deine gespeicherten Strom- und Wasserpreise werden als Preisvorgaben übernommen. Sie lassen sich jederzeit ändern.
- Jeder Beleg speichert seinen eigenen Betrag und seine Rechenangaben. Neue Vorgaben verändern alte Belege nicht.
- Belege lassen sich bearbeiten oder entfernen; Zuordnungsfilter und Monatssumme sind vorhanden.
- Namensvorschläge stammen ausschließlich aus deinen eigenen bisherigen Belegen. Kein Amazon-Katalog und kein Live-Preisvergleich.
- Die Kostenübersicht zählt gespeicherte Belege. Es werden keine Verwendungs- oder Anbaumengen vorgeschlagen.
- Andere vorhandene Prognosefunktionen der ursprünglichen App wurden nicht fachlich überprüft oder erweitert.

DATEN UND OFFLINE
Figurenwahl, Preisvorgaben und Belege liegen in deinen kontoeigenen Einstellungen. Die vorhandene Offline-Warteschlange synchronisiert sie.
Nach dem Update unter Mehr → Offline & Synchronisierung die Ansichten erneut online vorbereiten, damit auch die neuen Bilder auf dem Gerät verfügbar sind.
Ein Tagebuch-Export ist keine vollständige Datenbanksicherung. Für Belege, Einstellungen, Figurenwahl und alle weiteren Daten den kompletten data/-Ordner sichern.
Beim Update data/ unbedingt behalten. Eigene Einstellungen in config.php beibehalten.

VALIDIERUNG
35 Optionen und 34 neue, voneinander unterschiedliche Bilddateien geprüft; ursprüngliche Sortendatensätze nicht erweitert.
Profilwahl, ausgewählter Sprechername und optischer Namensabgleich geprüft.
Cent-Rundung (einschließlich halber Centbeträge), Dezimalkomma, Strom-, Wasser- und Anteilberechnung geprüft.
Übernahme vorhandener Preise, unveränderte alte Belege nach Preisänderung, Bearbeiten und Zuordnungsfilter geprüft.
Offline-Neustart, erhaltene Figur/Belege und Übertragung mit bestätigtem Synchronisierungsereignis und Serverabgleich geprüft.
Anzeige zwischen 320 und 1280 Pixeln geprüft. ALL-INKL und echte iOS-/Android-Geräte wurden nicht live geprüft.
