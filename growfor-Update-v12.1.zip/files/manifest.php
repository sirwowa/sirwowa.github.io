<?php
require __DIR__.'/update-gate.php';
require_once __DIR__.'/site-settings.php';
header('Content-Type: application/manifest+json; charset=utf-8');header('Cache-Control: no-cache');
$config=siteDefaults();try{if(is_file(__DIR__.'/data/weedys.sqlite')){$db=new PDO('sqlite:'.__DIR__.'/data/weedys.sqlite');$config=siteSnapshot($db)['config'];}}catch(Throwable $e){}
$manifest=json_decode(file_get_contents(__DIR__.'/manifest.webmanifest'),true);$manifest['id']='./';$manifest['name']=$config['app_name'];$manifest['short_name']=$config['app_name'];$manifest['description']=$config['slogan'];$manifest['theme_color']=$config['default_theme']==='light'?'#f3f5ed':'#090e0c';$manifest['background_color']=$manifest['theme_color'];echo json_encode($manifest,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
