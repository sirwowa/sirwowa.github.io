/* Navigation and touch gestures. No diary content is stored in browser history. */
'use strict';
(() => {
  const KEY='weedysNavigationV1';
  let current=null, index=0, restoring=false, busy=false, touch=null, approvedBack=null, tourNavigation=false;
  const baselines=new WeakMap();
  const route=()=>({view:S.view,grow:S.g?S.g.id:null,tab:S.tab,creating,
    cms:S.cmsRoute??null,teamRole:S.teamRole??null,sid:S.sid,sadd:S.sadd,rl:S.rl??null,support:S.feedbackThreadId??null});
  const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const signedIn=()=>!!S.user&&!S.user.must_change_password;
  function signature(form){
    const values={};
    for(const el of form.elements){
      if(!el.name||el.type==='search'||['submit','button','reset'].includes(el.type))continue;
      if(el.type==='radio'){if(!(el.name in values))values[el.name]='';if(el.checked)values[el.name]=el.value;continue}
      if(el.type==='checkbox'){(values[el.name]??=[]).push(el.checked?el.value:'');continue}
      if(el.type==='file'){values[el.name]=[...el.files].map(f=>[f.name,f.size,f.lastModified]);continue}
      values[el.name]=el.type==='password'?Boolean(el.value):el.value;
    }
    if(form.id==='avatar-settings'&&!values.companion_id)values.companion_id=S.avatarDraft||S.set.companion_id||'sour';
    return JSON.stringify(values);
  }
  const forms=()=>[...document.querySelectorAll('#app form')].filter(f=>!['auth','first-password'].includes(f.id));
  function remember(){for(const f of forms())if(!baselines.has(f))baselines.set(f,signature(f))}
  const changed=()=>forms().some(f=>baselines.has(f)&&signature(f)!==baselines.get(f));
  const consent=(message='Du hast ungespeicherte Eingaben. Trotzdem zurückgehen?')=>!changed()||confirm(message);
  function addBackButton(){
    if(!signedIn()||index<=0)return;
    const top=document.querySelector('#app .top');
    if(!top||top.querySelector('#back,#statsback,[data-navigation-back]'))return;
    const button=document.createElement('button');button.type='button';
    button.className='nav-back';button.dataset.navigationBack='1';
    button.setAttribute('aria-label','Zurück zur vorherigen Ansicht');
    button.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 6-6 6 6 6"/></svg>';
    top.prepend(button);
  }
  function track(event){
    remember();
    if(restoring||tourNavigation)return;
    if(!signedIn()){
      current=null;index=0;
      history.replaceState({[KEY]:true,index:0,route:null,user:null},'');return;
    }
    const next=route(),changedRoute=current&&!same(next,current);
    if(!current){
      current=next;index=0;
      history.replaceState({[KEY]:true,index,route:next,user:S.user.id},'');
    }else if(!same(next,current)){
      const old=history.state;
      if(old&&old[KEY])history.replaceState({...old,scroll:scrollY},'');
      index++;current=next;
      history.pushState({[KEY]:true,index,route:next,user:S.user.id,scroll:0},'');
    }
    remember();
    addBackButton();
    if((changedRoute&&!event?.detail?.keepScroll)||event?.detail?.resetTop){scrollTo({top:0,behavior:'instant'});requestAnimationFrame(()=>scrollTo({top:0,behavior:'instant'}))}
  }
  function closeOverlay(){
    const overlay=document.querySelector('.ov');
    if(!overlay)return false;
    if(!consent())return true;
    if(overlay.classList.contains('mascot-tour')){
      overlay.querySelector('[data-tour-close]')?.click();return true;
    }
    if(S.sheet){S.sheet=null;render();}else overlay.remove();
    return true;
  }
  function back(){
    if(!signedIn()||busy)return;
    if(closeOverlay())return;
    if(index>0&&consent()){approvedBack=index-1;history.back();}
  }
  window.WeedysBack=back;
  window.GrowingNavigation={
    suspend(){tourNavigation=true},
    resume(trackNow=true){tourNavigation=false;if(trackNow)track()},
    hasUnsaved:changed,
    confirmDiscard:consent
  };
  document.addEventListener('click',e=>{
    const target=e.target.closest('[data-navigation-back],#back,#statsback');
    if(target&&signedIn()&&index>0){e.preventDefault();e.stopImmediatePropagation();back();return}
    const next=e.target.closest('#gostart,#gohome,#gocal,#gocosts,#gosorten,#goprofile,#avatars-open,#support-open,#sync-open,#newgrow,#ledger-cancel,#feedback-list,#gohelp,#goinv,[data-go],[data-tab],[data-open],[data-opencost],[data-gocosts],[data-goprices],[data-ledger-edit],[data-feedback-thread]');
    if(next&&signedIn()&&!consent('Du hast ungespeicherte Eingaben. Diese Ansicht trotzdem verlassen?')){e.preventDefault();e.stopImmediatePropagation()}
  },true);
  addEventListener('beforeunload',e=>{if(changed()){e.preventDefault();e.returnValue=''}});
  addEventListener('popstate',async e=>{
    const state=e.state;
    if(!state||!state[KEY]||!signedIn()||state.user!==S.user.id||!state.route)return;
    if(restoring)return;
    window.GrowingCompanion?.cancelTourForNavigation();
    const approved=approvedBack===state.index;approvedBack=null;
    if(!approved&&!consent()){
      restoring=true;history.go(index-state.index);
      const reset=()=>{restoring=false;removeEventListener('popstate',reset)};
      addEventListener('popstate',reset,{once:true});return;
    }
    busy=true;restoring=true;
    try{
      document.querySelectorAll('.ov').forEach(o=>o.remove());
      const r=state.route;
      if(r.grow){
        const grow=S.grows.find(g=>g.id===r.grow);
        if(grow)await openGrow(r.grow);else{S.g=null;toast('Dieser Eintrag ist nicht mehr verfügbar.');}
      }else S.g=null;
      S.teamRole=r.teamRole;S.view=r.view;S.tab=r.tab;S.sid=r.sid;S.sadd=r.sadd;S.rl=r.rl;
      if(r.view==='support')await window.GrowingSupport?.restore(r.support);
      if(r.view==='admin')await window.GrowingAdminShell?.restore(r.cms);
      creating=!!r.creating;S.sheet=null;S.err='';
      current=r;index=state.index;render();
      scrollTo({top:0,behavior:'instant'});addBackButton();
    }catch(error){S.err=friendly(error.message);render();}
    finally{restoring=false;busy=false;}
  });
  document.addEventListener('touchstart',e=>{
    touch=null;
    if(!signedIn()||e.touches.length!==1||busy)return;
    const t=e.touches[0];
    // The outermost edge belongs to native Safari/Chrome history gestures.
    if(t.clientX<24||t.clientX>88)return;
    if(e.target.closest('input,textarea,select,button,a,[contenteditable="true"],[data-no-swipe]'))return;
    touch={x:t.clientX,y:t.clientY,time:performance.now(),locked:false};
  },{passive:true});
  document.addEventListener('touchmove',e=>{
    if(!touch||e.touches.length!==1){touch=null;return;}
    const dx=e.touches[0].clientX-touch.x,dy=e.touches[0].clientY-touch.y;
    if(!touch.locked&&Math.abs(dy)>18&&Math.abs(dy)>Math.abs(dx)){touch=null;return;}
    if(dx>25&&Math.abs(dx)>Math.abs(dy)*1.8&&(index>0||document.querySelector('.ov'))){
      touch.locked=true;if(e.cancelable)e.preventDefault();
      document.documentElement.classList.add('swipe-back-active');
    }
  },{passive:false});
  document.addEventListener('touchend',e=>{
    document.documentElement.classList.remove('swipe-back-active');
    if(!touch)return;
    const t=e.changedTouches[0],dx=t.clientX-touch.x,dy=Math.abs(t.clientY-touch.y);
    const accepted=touch.locked&&dx>=85&&dy<65&&dx>dy*1.8&&performance.now()-touch.time<1100;
    touch=null;if(accepted)back();
  },{passive:true});
  document.addEventListener('touchcancel',()=>{touch=null;document.documentElement.classList.remove('swipe-back-active')},{passive:true});
  addEventListener('growing:render',track);
  if(document.querySelector('#app .wrap'))track();
})();
