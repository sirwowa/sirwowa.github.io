Growing – Installation und Update

PHP 8 oder neuer mit PDO_SQLite, beschreibbarer App-/data-Ordner und HTTPS sind erforderlich.

GROWING – REVISION 5

NEU
- Das Logo im oberen App-Bereich öffnet Sour per Klick, Fingertipp oder Tastatur.
- Neue winkende Sour-Pose, zusätzliche kurze Bewegungen und eine Erfolgsanimation nach der Synchronisierung.
- Die Geräteeinstellung für reduzierte Bewegung wird weiterhin beachtet.
- Beim Speichern, beim Wechsel der Ansicht und beim Zurückgehen beginnt die Seite oben.
- Hintergrund-Synchronisierung ersetzt keine gerade bearbeiteten Formulare.
- Indoor/Outdoor und eine eigene Standortnotiz sind manuelle Tagebuch-Kennzeichnungen.
  Sie verändern keine Berechnungen und enthalten keine Outdoor-Anbauempfehlungen.
- Sortendatenbank, sortenspezifische Charaktere und Anbauempfehlungen wurden nicht erweitert.

PRIVATE TESTNACHRICHTEN
Unter Mehr → Nachricht an Admin (bzw. als Admin: Testfeedback & Antworten) öffnest du die Unterhaltungen.
Testpersonen sehen nur ihre eigenen Nachrichten. Der Admin sieht das Testfeedback und kann in den Unterhaltungen antworten.
Die Bestätigung erscheint erst nach Annahme durch den Server, mit folgendem Wortlaut:
Vielen Dank für deine Nachricht. Sobald ich es Bearbeitet habe melde ich mich. Danke für deine Unterstützung
Diese Bestätigung wird zusätzlich in der Unterhaltung gespeichert.
Offline-Nachrichten stehen zunächst als vorgemerkt auf dem Gerät; die Bestätigung folgt nach der Übertragung.
Neue Antworten werden in der geöffneten App angezeigt. Es gibt keine E-Mail- oder Betriebssystem-Pushnachrichten bei geschlossener App.

OFFLINE & SYNCHRONISIERUNG
1. Einmal online anmelden.
2. Unter Mehr → Offline & Synchronisierung auf Ansichten offline vorbereiten tippen.
3. Tagebucheinträge (einschließlich ihrer eingegebenen Daten), Einstellungen und Nachrichten werden bei Verbindungsverlust lokal vorgemerkt.
4. Bei wiederkehrender Verbindung und gültiger Sitzung sendet die geöffnete App automatisch. Auch beim Start, Zurückkehren in die App und regelmäßig bei geöffneter App wird geprüft.
5. Bei abgelaufener Sitzung erneut online anmelden. Die kontogebundene Warteschlange bleibt erhalten.
6. Der optionale manuelle Offline-Schalter erzwingt Offline-Arbeit. Zum Senden musst du diesen Schalter wieder ausschalten.
7. Neue Konten, neue Tagebücher, Passwortänderungen und reguläre Löschaktionen brauchen eine Verbindung.
8. Ausstehende oder abgelehnte Einträge stehen im Bereich Offline & Synchronisierung. Dort kannst du erneut senden oder nur die lokale Kopie entfernen.
   Bereits auf dem Server empfangene Einträge werden durch Entfernen der lokalen Kopie nicht gelöscht.

Browserdaten nicht löschen, solange Einträge ausstehen. Offline-Daten sind auf diesem Gerät gespeichert und nicht zusätzlich verschlüsselt.
Nutze diese Funktion deshalb auf einem eigenen, vertrauenswürdigen Gerät.
Bei Einstellungen gilt beim Einsatz mehrerer Geräte weiterhin die zuletzt serverseitig gespeicherte Fassung.
Ältere Offline-Einträge werden nur bei passender alter Kontozuordnung automatisch übernommen. Unklare Zuordnungen werden beibehalten und angezeigt.

UPDATE
- Vorher App-Dateien und den kompletten vorhandenen data/-Ordner sichern.
- Inhalt des ZIP-Ordners growing/ in deinen bisherigen App-Ordner hochladen, inklusive versteckter .htaccess-Dateien.
- Den vorhandenen data/-Ordner NICHT löschen oder durch einen leeren Ordner ersetzen.
- Falls config.php eigene Hosting-Einstellungen oder Schlüssel enthält, diese Datei beibehalten. Diese Version verlangt keine neuen Konfigurationswerte.
- Die neuen Datenbanktabellen entstehen automatisch. Keine MySQL-Datenbank, neuen Dienste oder Cronjobs erforderlich.
- Danach einmal online neu laden und Offline-Ansichten erneut vorbereiten.
- Vorhandene Konten und Passwörter bleiben bei erhaltenem data/-Ordner unverändert.
- Bei einer Neuinstallation werden die sechs vereinbarten Konten automatisch erstellt und verlangen beim ersten Login einen Passwortwechsel.

GEPRÜFT
PHP-/SQLite-API: privater Nachrichten-Zugriff, ausschließlich Admin-Antworten, exakte automatische Bestätigung, Lesestatus, Kontozuordnung und idempotente Wiederholungen.
Chromium: Logo-Hilfe, Zurück/Speichern von oben, Testnachrichten und Admin-Antworten, Offline-Neustart, automatische Übertragung von Notizen/Einstellungen/Nachrichten, verlorene Serverantwort ohne Duplikat.
Außerdem: Kontotrennung, Übernahme alter Offline-Einträge nur beim passenden Konto, richtige Reihenfolge vorgemerkter Einstellungen und Erhalt ungespeicherter Eingaben bei Hintergrund-Synchronisierung.
Darstellung zwischen 320 und 1280 Pixeln geprüft. JavaScript- und PHP-Syntax geprüft.
ALL-INKL, echte iOS-/Android-Geräte und Benachrichtigungen außerhalb der geöffneten App wurden nicht live geprüft.

GROWING – REVISION 6

FIGUREN
Im Profil gibt es jetzt „Charakter auswählen“. 35 unterschiedliche dekorative Porträts sind enthalten:
Sour, zwei eigens gestaltete weibliche Figuren namens Purple Punch und Mango Sweet sowie Porträts für die 32 bereits vorhandenen Sortennamen.
Wähle deine Figur manuell oder aktiviere den rein optischen Wechsel passend zum Namen im geöffneten Tagebuch.
Außerhalb eines passenden Tagebuchs bleibt deine persönliche Auswahl aktiv. Die Einstellung lässt sich jederzeit im Profil ändern.
Die Figuren sind Fantasiegestalten. Aussehen und Farben stellen keine botanischen Merkmale, Geruchsstärken oder Anbaueigenschaften dar.
Die lokale Fragehilfe, die Tour und der aufrufbare Begleiter verwenden die ausgewählte Figur und ihren Namen.
Purple Punch und Mango Sweet wurden als Figuren ergänzt, nicht als neue Anbau-Datensätze. Die Sortendatenbank bleibt unverändert bei den bisherigen Einträgen.
Keine neue Cannabis-Anfängerführung, Outdoor-Anbautipps, Geruchsangaben oder sortenspezifischen Gießempfehlungen enthalten.

NEUER KOSTENBEREICH
- Belege und tatsächlich erfasste Beträge, optional nach Tagebuch zugeordnet.
- Direkte Betragseingabe oder Berechnung aus gemessenen kWh, erfassten Litern bzw. einem Anteil eines Einkaufs.
- Bei Anteilen müssen Packungsinhalt und verwendete Menge dieselbe Einheit haben.
- Exakte Dezimalrechnung mit Aufrundung ab einem halben Cent; maximal sechs Nachkommastellen in den Eingaben.
- Deine gespeicherten Strom- und Wasserpreise werden als Preisvorgaben übernommen. Sie lassen sich jederzeit ändern.
- Jeder Beleg speichert seinen eigenen Betrag und seine Rechenangaben. Neue Vorgaben verändern alte Belege nicht.
- Belege lassen sich bearbeiten oder entfernen; Zuordnungsfilter und Monatssumme sind vorhanden.
- Namensvorschläge stammen ausschließlich aus deinen eigenen bisherigen Belegen. Kein Amazon-Katalog und kein Live-Preisvergleich.
- Die Kostenübersicht zählt gespeicherte Belege. Es werden keine Verwendungs- oder Anbaumengen vorgeschlagen.
- Andere vorhandene Prognosefunktionen der ursprünglichen App wurden nicht fachlich überprüft oder erweitert.

DATEN UND OFFLINE
Figurenwahl, Preisvorgaben und Belege liegen in deinen kontoeigenen Einstellungen. Die vorhandene Offline-Warteschlange synchronisiert sie.
Nach dem Update unter Mehr → Offline & Synchronisierung die Ansichten erneut online vorbereiten, damit auch die neuen Bilder auf dem Gerät verfügbar sind.
Ein Tagebuch-Export ist keine vollständige Datenbanksicherung. Für Belege, Einstellungen, Figurenwahl und alle weiteren Daten den kompletten data/-Ordner sichern.
Beim Update data/ unbedingt behalten. Eigene Einstellungen in config.php beibehalten.

VALIDIERUNG
35 Optionen und 34 neue, voneinander unterschiedliche Bilddateien geprüft; ursprüngliche Sortendatensätze nicht erweitert.
Profilwahl, ausgewählter Sprechername und optischer Namensabgleich geprüft.
Cent-Rundung (einschließlich halber Centbeträge), Dezimalkomma, Strom-, Wasser- und Anteilberechnung geprüft.
Übernahme vorhandener Preise, unveränderte alte Belege nach Preisänderung, Bearbeiten und Zuordnungsfilter geprüft.
Offline-Neustart, erhaltene Figur/Belege und Übertragung mit bestätigtem Synchronisierungsereignis und Serverabgleich geprüft.
Anzeige zwischen 320 und 1280 Pixeln geprüft. ALL-INKL und echte iOS-/Android-Geräte wurden nicht live geprüft.
