<?php
// Generic camera/photo sequences. Images stay inside the protected SQLite database.
function timelapseInit(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS timelapse_frames(id INTEGER PRIMARY KEY AUTOINCREMENT,grow_id INTEGER NOT NULL,user_id INTEGER NOT NULL,frame_key TEXT NOT NULL,captured_at TEXT NOT NULL,source TEXT NOT NULL,data_url TEXT NOT NULL,bytes INTEGER NOT NULL,width INTEGER NOT NULL,height INTEGER NOT NULL,checksum TEXT NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(grow_id,frame_key))");
    $columns=array_column($db->query('PRAGMA table_info(timelapse_frames)')->fetchAll(),'name');if(!in_array('time_basis',$columns,true))$db->exec("ALTER TABLE timelapse_frames ADD COLUMN time_basis TEXT NOT NULL DEFAULT ''");
    $db->exec('CREATE INDEX IF NOT EXISTS ix_timelapse_order ON timelapse_frames(grow_id,captured_at,id)');
}
function timelapseGrow(PDO $db,int $uid,int $id,array $account): array {
    if($account['role']!=='admin')return ownGrow($db,$uid,$id);
    $q=$db->prepare('SELECT * FROM grows WHERE id=?');$q->execute([$id]);$g=$q->fetch();if(!$g)out(['error'=>'Tagebuch nicht gefunden.'],404);return $g;
}
function timelapseAction(PDO $db,int $uid,array $account,string $a,array $in): void {
    if(($_SERVER['REQUEST_METHOD']??'')!=='POST')out(['error'=>'Bitte POST verwenden.'],405);
    if(!str_starts_with(strtolower($_SERVER['CONTENT_TYPE']??''),'application/json'))out(['error'=>'JSON-Anfrage erforderlich.'],415);
    $columns='id,grow_id,user_id,frame_key,captured_at,source,time_basis,bytes,width,height,created';
    if($a==='timelapse_grows'){
        $sql='SELECT g.id,g.name,g.user_id,u.login_name AS owner FROM grows g JOIN users u ON u.id=g.user_id';
        if($account['role']==='admin')$rows=$db->query($sql.' ORDER BY g.id DESC')->fetchAll();
        else{$q=$db->prepare($sql.' WHERE g.user_id=? OR g.id IN (SELECT grow_id FROM shares WHERE user_id=?) ORDER BY g.id DESC');$q->execute([$uid,$uid]);$rows=$q->fetchAll();}out(['grows'=>$rows]);
    }
    if($a==='timelapse_list'){
        $gid=(int)($in['grow_id']??0);$g=timelapseGrow($db,$uid,$gid,$account);$q=$db->prepare('SELECT '.$columns.' FROM timelapse_frames WHERE grow_id=? ORDER BY captured_at,id');$q->execute([$gid]);$rows=$q->fetchAll();out(['grow'=>['id'=>(int)$g['id'],'name'=>$g['name']],'frames'=>$rows,'total_bytes'=>array_sum(array_column($rows,'bytes')),'limit_frames'=>5000,'limit_bytes'=>536870912]);
    }
    if($a==='timelapse_photo'||$a==='timelapse_frame_delete'){
        $q=$db->prepare('SELECT * FROM timelapse_frames WHERE id=?');$q->execute([(int)($in['frame_id']??0)]);$r=$q->fetch();if(!$r)out(['error'=>'Foto nicht gefunden.'],404);$g=timelapseGrow($db,$uid,(int)$r['grow_id'],$account);
        if($a==='timelapse_photo')out(['id'=>(int)$r['id'],'photo'=>$r['data_url']]);
        if($account['role']!=='admin'&&(int)$g['user_id']!==$uid&&(int)$r['user_id']!==$uid)out(['error'=>'Nur der Besitzer oder die aufnehmende Person darf das Foto löschen.'],403);
        $db->prepare('DELETE FROM timelapse_frames WHERE id=?')->execute([(int)$r['id']]);logAct($db,(int)$r['grow_id'],$uid,'timelapse_delete',(string)$r['id']);out(['ok'=>1]);
    }
    if($a!=='timelapse_frame_save')out(['error'=>'Unbekannte Zeitrafferfunktion.'],404);
    $gid=(int)($in['grow_id']??0);timelapseGrow($db,$uid,$gid,$account);
    $key=$in['frame_key']??'';$photo=$in['photo']??'';$source=$in['source']??'';$at=$in['captured_at']??'';
    if(!is_string($key)||!preg_match('/^[A-Za-z0-9-]{16,80}$/D',$key)||!in_array($source,['camera','import','gopro'],true))out(['error'=>'Fotokennung oder Quelle ungültig.'],400);
    if(!is_string($photo)||strlen($photo)>1400000||!str_starts_with($photo,'data:image/jpeg;base64,'))out(['error'=>'Bitte ein JPEG-Foto bis 1 MB verwenden.'],400);
    $bytes=base64_decode(substr($photo,23),true);$size=$bytes===false?false:@getimagesizefromstring($bytes);
    if($bytes===false||strlen($bytes)>1048576||!$size||$size[2]!==IMAGETYPE_JPEG||$size[0]>1600||$size[1]>1600||$size[0]<1||$size[1]<1)out(['error'=>'Das Foto ist kein gültiges JPEG bis 1600 × 1600 Pixel und 1 MB.'],400);
    if(!is_string($at)||!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/D',$at))out(['error'=>'Ungültiger Aufnahmezeitpunkt.'],400);
    try{$date=new DateTimeImmutable($at);$errors=DateTimeImmutable::getLastErrors();if($errors&&($errors['warning_count']||$errors['error_count']))throw new Exception();$at=$date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.v\Z');}catch(Throwable $e){out(['error'=>'Ungültiger Aufnahmezeitpunkt.'],400);}
    if($source==='gopro'&&empty($GLOBALS['bridge_authenticated']))out(['error'=>'GoPro-Quelle benötigt einen gültigen Gerätezugang.'],403);
    $basis=$source==='gopro'&&($in['time_basis']??'')==='camera'?'camera':($source==='gopro'?'received':($source==='import'?'assigned':'device'));
    $hash=hash('sha256',$bytes);$q=$db->prepare('SELECT id,checksum,captured_at,source FROM timelapse_frames WHERE grow_id=? AND frame_key=?');$q->execute([$gid,$key]);$old=$q->fetch();
    if($old){if($old['checksum']!==$hash||$old['captured_at']!==$at||$old['source']!==$source)out(['error'=>'Diese Fotokennung gehört bereits zu einer anderen Aufnahme.'],409);out(['ok'=>1,'id'=>(int)$old['id'],'deduplicated'=>true]);}
    $q=$db->prepare('SELECT COUNT(*) AS n,COALESCE(SUM(bytes),0) AS b FROM timelapse_frames WHERE grow_id=?');$q->execute([$gid]);$totals=$q->fetch();if((int)$totals['n']>=5000||(int)$totals['b']+strlen($bytes)>536870912)out(['error'=>'Das Zeitrafferlimit dieses Tagebuchs ist erreicht (5000 Fotos oder 512 MB). Bitte zuerst sichern und alte Fotos entfernen.'],409);
    $db->prepare('INSERT INTO timelapse_frames(grow_id,user_id,frame_key,captured_at,source,data_url,bytes,width,height,checksum,time_basis) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute([$gid,$uid,$key,$at,$source,$photo,strlen($bytes),$size[0],$size[1],$hash,$basis]);$id=(int)$db->lastInsertId();logAct($db,$gid,$uid,'timelapse_add',$source);out(['ok'=>1,'id'=>$id]);
}
