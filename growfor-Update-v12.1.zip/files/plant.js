'use strict';
/* Realistische Cannabis-Pflanze: mehrschichtiges SVG (Hintergrund, Pflanze mit Wind, Hinweise) */
(function(){
const R=a=>{const x=Math.sin(a*127.1+311.7)*43758.5453;return x-Math.floor(x)};
const f=n=>(+n).toFixed(1);let K=0;
const TONE={a:['gAr','gAl'],b:['gBr','gBl'],y:['gYr','gYl']};
const ANG={3:[0,-38,38],5:[0,-30,30,-62,62],7:[0,-26,26,-52,52,-80,80],9:[0,-24,24,-48,48,-72,72,-98,98]};
const LEN=[1,.9,.78,.58,.4];
function half(len,bend,side){const W=len*.125,N=Math.max(9,Math.round(len/3.1)),w=t=>W*Math.sin(Math.PI*Math.pow(Math.min(1,t),.62)),bx=t=>bend*t*t*len;let d='M0 0';
 for(let i=0;i<N;i++){const t=i/N,t2=(i+.62)/N;d+=`L${f(side*w(t)*.7+bx(t))} ${f(-len*t)}L${f(side*w(t2)*1.05+bx(t2))} ${f(-len*t2)}`}
 return d+`L${f(bend*len)} ${f(-len)}Z`}
function leaflet(len,bend,tone,mini){const c=TONE[tone]||TONE.a,W=len*.125,bx=t=>bend*t*t*len;let o=`<path d="${half(len,bend,1)}" fill="url(#${c[0]})"/><path d="${half(len,bend,-1)}" fill="url(#${c[1]})"/>`;
 o+=`<path d="M0 0`+[.2,.4,.6,.8,1].map(t=>`L${f(bx(t))} ${f(-len*t*.97)}`).join('')+`" stroke="rgba(235,255,225,.6)" stroke-width=".7" fill="none"/>`;
 if(!mini)for(const t of[.22,.4,.58,.74]){const w=W*Math.sin(Math.PI*Math.pow(t+.1,.62))*.85;o+=`<path d="M${f(bx(t))} ${f(-len*t)}L${f(w+bx(t+.14))} ${f(-len*(t+.14))}M${f(bx(t))} ${f(-len*t)}L${f(-w+bx(t+.14))} ${f(-len*(t+.14))}" stroke="rgba(235,255,225,.28)" stroke-width=".4" fill="none"/>`}
 return o+`<path d="${half(len,bend,1)}M0 0" fill="none" stroke="rgba(0,40,15,.55)" stroke-width=".4"/><path d="${half(len,bend,-1)}" fill="none" stroke="rgba(0,40,15,.55)" stroke-width=".4"/>`}
function fan(x,y,rot,size,n,tone,droop,mini){const a=ANG[n];let o=`<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rot)})">`;
 for(let i=a.length-1;i>=0;i--){const ang=a[i],len=size*LEN[Math.ceil(i/2)]*(.93+R(++K)*.14),b=(R(K+3)-.5)*.16+(droop||0)*(ang>0?.1:ang<0?-.1:.04);o+=`<g transform="rotate(${f(ang)}) skewX(${f((R(K+9)-.5)*8)})">${leaflet(len,b,tone,mini)}</g>`}
 return o+'</g>'}
function cola(x,y,len,wid,ripe,seed,tw){const w=t=>wid*Math.sin(Math.PI*Math.pow(t,.72))*(1-.18*t)+wid*.1,N=18;let r='',l='';
 for(let i=0;i<=N;i++){const t=i/N;r+=`L${f(x+w(t))} ${f(y-len*t)}`}for(let i=N;i>=0;i--){const t=i/N;l+=`L${f(x-w(t))} ${f(y-len*t)}`}
 let o=`<path d="M${f(x)} ${f(y)}${r}${l}Z" fill="url(#gBd2)"/>`;
 const M=Math.round(len*wid/8)+8,b=[];for(let i=0;i<M;i++)b.push({t:R(seed+i*5.3)*.96+.03,s:R(seed+i*7.1)<.5?-1:1,off:R(seed+i*3.7)*.8+.08,q:R(seed+i*2.9)});
 b.sort((p,q)=>q.t-p.t);const pc=ripe?['#e0852a','#c96a1d','#f0a54a']:['#f7f3e2','#efe9cf','#fbf8ee'];
 for(const m of b){const cx=x+m.s*w(m.t)*m.off,cy=y-len*m.t,rr=wid*.21*(1-.35*m.t)*(.8+m.q*.5);
  o+=`<circle cx="${f(cx)}" cy="${f(cy)}" r="${f(rr)}" fill="url(#gBd)" stroke="rgba(20,70,20,.35)" stroke-width=".35"/>`;
  for(let h=0;h<(ripe?2:3);h++){const ang=(m.s*(.5+R(seed+h*4+m.q*9)*.9)),dx=Math.sin(ang)*rr*(1.6+R(seed+h)*1.4),dy=-Math.cos(ang*.6)*rr*(1.4+R(seed+h*2)*1.6);o+=`<path d="M${f(cx)} ${f(cy)}q${f(dx*.3)} ${f(dy*.7)} ${f(dx)} ${f(dy)}" stroke="${pc[h%3]}" stroke-width=".8" fill="none" stroke-linecap="round"/>`}
  if(ripe&&m.q>.55){o+=`<circle cx="${f(cx+rr*.3)}" cy="${f(cy-rr*.3)}" r=".7" fill="#fff" opacity=".85"/>`;if(tw&&m.q>.9)tw.push([cx,cy])}}
 return o}
function build(st,p,mini){const tw=[],B=226,rip=st===5;let o='';
 const ST=(h,wd)=>`<path d="M100 ${B} C97 ${f(B-h*.33)} 103 ${f(B-h*.66)} 100 ${f(B-h)}" stroke="url(#gSt)" stroke-width="${f(wd)}" fill="none" stroke-linecap="round"/><path d="M${f(100+wd*.2)} ${B} C${f(97+wd*.2)} ${f(B-h*.33)} ${f(103+wd*.2)} ${f(B-h*.66)} ${f(100+wd*.2)} ${f(B-h)}" stroke="rgba(255,255,230,.28)" stroke-width="${f(wd*.22)}" fill="none"/>`;
 if(st===0){o=`<path d="M64 ${B+2} Q100 ${f(B-8-p*8)} 136 ${B+2}Z" fill="#3b2a1a"/><ellipse cx="100" cy="${f(B-3-p*2)}" rx="8.5" ry="5.8" fill="#a98b5b" transform="rotate(${f(-14+p*22)} 100 ${B-3})"/><path d="M92 ${f(B-3-p*2)}q8 -4 16 0M95 ${f(B-6-p*2)}q5 -2 10 0" stroke="#6b5232" stroke-width=".9" fill="none"/>${p>.45?`<path d="M100 ${B} q-3 9 0 15" stroke="#f3f0dc" stroke-width="1.8" fill="none" stroke-linecap="round"/>`:''}`;return{o,tw}}
 if(st===1){const h=24+p*12,ty=B-h;o=ST(h,2.4)+`<ellipse cx="85" cy="${f(ty+2)}" rx="14" ry="6.5" fill="url(#gAr)" stroke="rgba(0,50,20,.4)" stroke-width=".4" transform="rotate(-16 85 ${f(ty+2)})"/><ellipse cx="115" cy="${f(ty+2)}" rx="14" ry="6.5" fill="url(#gAl)" stroke="rgba(0,50,20,.4)" stroke-width=".4" transform="rotate(16 115 ${f(ty+2)})"/>`+(p>.35?fan(100,ty-1,0,11+p*9,3,'a',0,mini):'');return{o,tw}}
 if(st===6){o=`<line x1="24" y1="20" x2="176" y2="20" stroke="#caa66a" stroke-width="2"/><g class="hg"><rect x="95" y="14" width="10" height="14" rx="2" fill="#d9b07a"/><path d="M100 28 L100 150" stroke="url(#gSt)" stroke-width="3.6" stroke-linecap="round"/>`;
  [[86,112,5],[114,96,5.5],[88,74,4.6],[112,60,4.6]].forEach(([x,y,r],i)=>{o+=`<path d="M100 ${y+8} L${x} ${y}" stroke="#5a9e45" stroke-width="1.6"/><g transform="translate(${x} ${y}) scale(1 -1)">${cola(0,0,r*5.5,r*1.5,1,i*11+3)}</g>`});
  o+=`<g transform="translate(100 156) scale(1 -1)">${cola(0,0,44,11,1,5)}</g>`+fan(100,50,176,12,3,'y',0,mini)+'</g>';return{o,tw}}
 const H=[0,0,54+p*20,94+p*58,146+p*16,158][st],nodes=st===2?2:st===3?4+Math.round(p*3):8,ty=B-H,bk=st===4?.3+.7*p:1;
 let leaves='',br='',bd='';const sw=2.6+st*.8;
 for(let i=0;i<nodes;i++){const t=i/Math.max(1,nodes-1),y=B-H*(.1+.82*t),size=(st===2?25:36)*(1.08-.6*t)*(st===3?.8+p*.3:1),n=t>.75?3:t>.45?5:(st>=3&&t<.2?9:(st>=3?7:5)),ang=100-56*t,pl=size*.5,tone=rip&&t<.42?'y':'a';
  o+=`<ellipse cx="100" cy="${f(y)}" rx="${f(sw*.8)}" ry="${f(sw*.5)}" fill="rgba(60,110,50,.5)"/>`;
  for(const d of[-1,1]){const yy=y+(d>0?-3:0),px=100+d*pl*Math.sin(ang*Math.PI/180),py=yy-pl*Math.cos(ang*Math.PI/180);
   leaves+=`<path d="M100 ${f(yy)} Q${f(100+d*pl*.75)} ${f(yy-pl*.15)} ${f(px)} ${f(py)}" stroke="#5a9e45" stroke-width="1.3" fill="none"/>`+fan(px,py,d*ang*.92,size,n,d<0&&!rip?'b':tone,1-t,mini)}
  if(st>=3&&i>=1&&i<=nodes-3){const d=i%2?-1:1,bl=(14+H*.15)*(1-t*.5),ex=100+d*bl*.95,ey=y-bl*1.15;br+=`<path d="M100 ${f(y)} Q${f(100+d*bl*.5)} ${f(y-bl*.15)} ${f(ex)} ${f(ey)}" stroke="url(#gSt)" stroke-width="1.7" fill="none"/>`;leaves+=fan(ex,ey,d*34,16+(st>=4?5:0),5,'a',.3,mini);if(st>=4)bd+=cola(ex,ey+3,(10+8*bk)*(rip?1.15:1),3.2+3*bk,rip,i*17+2,tw)}
  if(st>=4&&t>.35&&i%2===0)bd+=cola(100+(i%4?6:-6),y,7+6*bk,2.4+2*bk,rip,i*5+1,tw)}
 const top=st>=4?`${fan(86,ty+14,-48,13,3,'a',0,mini)}${fan(114,ty+14,48,13,3,'a',0,mini)}`:fan(100,ty,0,st===2?20:28,5,'a',0,mini)+(st===3?fan(100,ty+14,0,18,5,'b',.4,mini):'');
 o+=ST(H,sw)+br+(mini?`<g>${leaves}</g>`:`<g filter="url(#tex)">${leaves}</g>`)+top+(st>=4?cola(100,ty+16,(14+24*bk)*(rip?1.05:1),5.5+5.5*bk,rip,7,tw):'')+bd;
 if(st>=4)for(let i=0;i<10;i++){const px=100+(R(i*3.1)-.5)*36,py=ty+10+R(i*5.3)*(H*.55);if(rip||R(i)>.4)tw.push([px,py])}
 return{o,tw}}
const DEFS=`<defs><filter id="bl"><feGaussianBlur stdDeviation="2.5"/></filter>
<filter id="tex"><feTurbulence type="fractalNoise" baseFrequency=".75" numOctaves="2" seed="4" result="n"/><feDiffuseLighting in="n" lighting-color="#fff" surfaceScale="1.7" diffuseConstant="1.1" result="L"><feDistantLight azimuth="235" elevation="60"/></feDiffuseLighting><feComposite in="SourceGraphic" in2="L" operator="arithmetic" k1="1.5" k2="0" k3="0" k4="0" result="M"/><feComposite in="M" in2="SourceAlpha" operator="in"/></filter>
<linearGradient id="gAr" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#1f7a38"/><stop offset=".55" stop-color="#3fb257"/><stop offset="1" stop-color="#8be686"/></linearGradient><linearGradient id="gAl" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#135227"/><stop offset=".55" stop-color="#2a8c41"/><stop offset="1" stop-color="#5ec96b"/></linearGradient>
<linearGradient id="gBr" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#17602d"/><stop offset="1" stop-color="#37a04c"/></linearGradient><linearGradient id="gBl" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#0f3c1e"/><stop offset="1" stop-color="#26803a"/></linearGradient>
<linearGradient id="gYr" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#9a8f22"/><stop offset="1" stop-color="#dcd25a"/></linearGradient><linearGradient id="gYl" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#76691a"/><stop offset="1" stop-color="#b9b042"/></linearGradient>
<linearGradient id="gSt" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3f8a3a"/><stop offset=".5" stop-color="#86cb5e"/><stop offset="1" stop-color="#3f8a3a"/></linearGradient>
<radialGradient id="gBd" cx=".38" cy=".32" r=".85"><stop offset="0" stop-color="#d4f07e"/><stop offset=".55" stop-color="#86c64a"/><stop offset="1" stop-color="#3f8a3a"/></radialGradient><linearGradient id="gBd2" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#2d6a2a"/><stop offset="1" stop-color="#5aa63a"/></linearGradient>
<linearGradient id="gPot" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2b302b"/><stop offset=".45" stop-color="#4a514a"/><stop offset="1" stop-color="#232823"/></linearGradient>
<linearGradient id="lc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".5"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>`;
const potSVG=`<ellipse cx="100" cy="260" rx="60" ry="6" fill="rgba(0,0,0,.5)" filter="url(#bl)"/><path d="M50 231 Q47 245 54 257 Q100 265 146 257 Q153 245 150 231Z" fill="url(#gPot)"/><path d="M52 238 Q100 245 148 238M54 247 Q100 254 146 247" stroke="rgba(255,255,255,.08)" stroke-width="1" fill="none"/><ellipse cx="100" cy="231" rx="50" ry="8.5" fill="#241810"/><ellipse cx="100" cy="229.5" rx="47" ry="6.8" fill="#3b2a1a"/>`+Array.from({length:22},(_,i)=>`<circle cx="${f(58+R(i)*84)}" cy="${f(226.5+R(i+40)*6)}" r="${f(.7+R(i+80)*.9)}" fill="${i%3?'#2a1c10':'#ece6d4'}"/>`).join('')+`<ellipse cx="100" cy="231" rx="50" ry="8.5" fill="none" stroke="rgba(255,255,255,.13)" stroke-width="1"/>`;
const NAMES=['Keimung','Keimling','Sämling','Vegetation','Blüte','Reifung','Ernte & Trocknung'];
window.plantSVG=function(st,p,cues,mini){cues=cues||{};const {o,tw}=build(st,p,mini),lamp=mini||st>=6?'':`<path class="beam" d="M72 10 L128 10 L196 228 L4 228Z" fill="url(#lc)"/><rect x="60" y="1" width="80" height="9" rx="4.5" fill="#f6f0ff"/><rect x="64" y="8" width="72" height="3" rx="1.5" fill="#fff" opacity=".9"/>`,vb='viewBox="0 0 200 266"',lab=`role="img" aria-label="Pflanze in Phase ${NAMES[st]}"`;
 const back=DEFS+lamp+(st>=6?'':potSVG);
 if(mini)return`<svg ${vb} ${lab}>${back}${o}</svg>`;
 let c='';if(cues.water)c+=[88,100,112].map((x,i)=>`<path class="drip" style="animation-delay:${i*.5}s" d="M${x} 150 c3 4 3 8 0 8 c-3 0 -3 -4 0 -8z" fill="#5ec8ff"/>`).join('');
 if(cues.defol)c+=`<ellipse class="pulse" cx="100" cy="206" rx="52" ry="14" fill="none" stroke="#ffd166" stroke-width="1.6" stroke-dasharray="5 4"/><text x="152" y="200" font-size="15">✂️</text>`;
 if(cues.trich)c+=`<circle class="pulse" cx="100" cy="68" r="26" fill="none" stroke="#fff" stroke-width="1.5" stroke-dasharray="3 3"/><text x="126" y="52" font-size="15">🔬</text>`;
 if(cues.flip)c+='<text x="148" y="26" font-size="16" class="pulse">💡</text>';if(cues.harvest&&st<6)c+='<text x="128" y="44" font-size="18" class="pulse">✂️</text>';
 c+=tw.slice(0,14).map(([x,y],i)=>`<path class="tw" style="animation-delay:${(i*.37%2.2).toFixed(2)}s" d="M${f(x)} ${f(y-2.4)}L${f(x+.6)} ${f(y-.6)}L${f(x+2.4)} ${f(y)}L${f(x+.6)} ${f(y+.6)}L${f(x)} ${f(y+2.4)}L${f(x-.6)} ${f(y+.6)}L${f(x-2.4)} ${f(y)}L${f(x-.6)} ${f(y-.6)}Z" fill="#fff"/>`).join('');
 return`<div class="pl"><svg ${vb} ${lab}>${back}</svg><div class="gr"><div class="sw${st===6?' hg2':''}"><svg ${vb} aria-hidden="true">${o}</svg></div></div><svg class="fr" ${vb} aria-hidden="true">${c}</svg></div>`};
})();
