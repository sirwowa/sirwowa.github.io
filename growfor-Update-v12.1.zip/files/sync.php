<?php
// Idempotency receipts keep retries from creating duplicate notes/messages.
function initializeSync(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS sync_receipts(user_id INTEGER NOT NULL,request_id TEXT NOT NULL,action TEXT NOT NULL,payload_hash TEXT NOT NULL,response TEXT NOT NULL,PRIMARY KEY(user_id,request_id))");
}
function beginSyncedWrite(PDO $db,int $uid,string $action,array $input): void {
    if(isset($input['sync_owner_id'])&&(int)$input['sync_owner_id']!==$uid)out(['error'=>'Das vorgemerkte Konto stimmt nicht mit der aktuellen Sitzung überein.'],403);
    $key=(string)($input['client_request_id']??'');
    if($key==='')$key=bin2hex(random_bytes(16));
    if(!preg_match('/^[A-Za-z0-9-]{16,80}$/D',$key))out(['error'=>'Ungültige Anfragekennung.'],400);
    $hash=hash('sha256',json_encode($input,JSON_UNESCAPED_UNICODE));
    $db->exec('BEGIN IMMEDIATE');
    $q=$db->prepare('SELECT * FROM sync_receipts WHERE user_id=? AND request_id=?');$q->execute([$uid,$key]);$old=$q->fetch();
    if($old){
        $db->exec('COMMIT');
        if($old['action']!==$action||$old['payload_hash']!==$hash)out(['error'=>'Diese Anfragekennung wurde bereits für andere Daten verwendet.'],409);
        out(json_decode($old['response'],true));
    }
    $GLOBALS['sync_write']=['db'=>$db,'uid'=>$uid,'key'=>$key,'action'=>$action,'hash'=>$hash];
}
function finishSyncedWrite(array $response,int $status): void {
    if(!isset($GLOBALS['sync_write']))return;
    $s=$GLOBALS['sync_write'];unset($GLOBALS['sync_write']);
    if($status>=400){$s['db']->exec('ROLLBACK');return;}
    $s['db']->prepare('INSERT INTO sync_receipts(user_id,request_id,action,payload_hash,response) VALUES(?,?,?,?,?)')->execute([$s['uid'],$s['key'],$s['action'],$s['hash'],json_encode($response,JSON_UNESCAPED_UNICODE)]);
    $s['db']->exec('COMMIT');
}
