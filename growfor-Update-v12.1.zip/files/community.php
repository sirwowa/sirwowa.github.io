<?php
// Community (optional, nur für angemeldete Nutzer dieser Installation). Wird nur von api.php eingebunden.
if (!function_exists('mb_substr')) { function mb_substr($s, $a, $l = null) { return $l === null ? substr($s, $a) : substr($s, $a, $l); } }
if (!defined('COMMUNITY') || COMMUNITY !== '1') out(['error' => 'Die Community ist nicht aktiviert.'], 403);

$db->exec("CREATE TABLE IF NOT EXISTS c_posts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,type TEXT NOT NULL DEFAULT 'post',title TEXT,body TEXT,tags TEXT,anon INTEGER DEFAULT 0,group_id INTEGER DEFAULT 0,status TEXT DEFAULT 'ok',data TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS c_comments(id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER NOT NULL,user_id INTEGER NOT NULL,body TEXT,status TEXT DEFAULT 'ok',created TEXT DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS c_favs(user_id INTEGER NOT NULL,post_id INTEGER NOT NULL,PRIMARY KEY(user_id,post_id))");
$db->exec("CREATE TABLE IF NOT EXISTS c_follows(user_id INTEGER NOT NULL,target INTEGER NOT NULL,PRIMARY KEY(user_id,target))");
$db->exec("CREATE TABLE IF NOT EXISTS c_blocks(user_id INTEGER NOT NULL,target INTEGER NOT NULL,PRIMARY KEY(user_id,target))");
$db->exec("CREATE TABLE IF NOT EXISTS c_reports(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT,item INTEGER,user_id INTEGER,reason TEXT,done INTEGER DEFAULT 0,created TEXT DEFAULT CURRENT_TIMESTAMP)");
$db->exec("CREATE TABLE IF NOT EXISTS c_groups(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,owner INTEGER NOT NULL)");
$db->exec("CREATE TABLE IF NOT EXISTS c_gm(group_id INTEGER NOT NULL,user_id INTEGER NOT NULL,PRIMARY KEY(group_id,user_id))");
$db->exec("CREATE TABLE IF NOT EXISTS c_bans(user_id INTEGER PRIMARY KEY)");
$db->exec("CREATE TABLE IF NOT EXISTS c_rules(user_id INTEGER PRIMARY KEY,ts TEXT DEFAULT CURRENT_TIMESTAMP)");

function c_name($db, $id) {
    $s = $db->prepare('SELECT name,email FROM users WHERE id=?');
    $s->execute([(int)$id]);
    $r = $s->fetch();
    if (!$r) return 'Unbekannt';
    $n = trim((string)$r['name']);
    return $n !== '' ? $n : explode('@', (string)$r['email'])[0];
}
function c_is_admin($db, $uid) {
    $s = $db->prepare('SELECT email FROM users WHERE id=?');
    $s->execute([(int)$uid]);
    $em = strtolower((string)$s->fetchColumn());
    if (defined('ADMIN_EMAIL') && ADMIN_EMAIL !== '') return $em === strtolower(ADMIN_EMAIL);
    return (int)$db->query('SELECT id FROM users ORDER BY id LIMIT 1')->fetchColumn() === (int)$uid;
}
function c_flagged($t) {
    if (preg_match('/(verkauf|zu verkaufen|biete an|tausche|lieferung|versand|telegram|whatsapp|signal|dealer|handeln|preis pro gramm|euro pro gramm|abzugeben|abgabe|kaufe )/iu', $t)) return true;
    return preg_match_all('#https?://#i', $t) > 2;
}
function c_count($db, $table, $where, $params) {
    $s = $db->prepare("SELECT COUNT(*) FROM $table WHERE $where");
    $s->execute($params);
    return (int)$s->fetchColumn();
}

$adm = c_is_admin($db, $uid);
$ban = $db->prepare('SELECT 1 FROM c_bans WHERE user_id=?');
$ban->execute([$uid]);
if ($ban->fetch()) out(['error' => 'Dein Zugang zur Community wurde gesperrt.'], 403);
$rulesOk = c_count($db, 'c_rules', 'user_id=?', [$uid]) > 0;

if ($a === 'c_status') out(['on' => true, 'admin' => $adm, 'rules' => $rulesOk, 'name' => c_name($db, $uid), 'me' => $uid]);
if ($a === 'c_rules') {
    $db->prepare('INSERT OR IGNORE INTO c_rules(user_id) VALUES(?)')->execute([$uid]);
    out(['ok' => 1]);
}
if (!$rulesOk) out(['error' => 'Bitte bestätige zuerst die Community-Regeln.'], 403);

$MG = '(SELECT group_id FROM c_gm WHERE user_id=' . (int)$uid . ')';
$BL = '(SELECT target FROM c_blocks WHERE user_id=' . (int)$uid . ')';
$VIS = "((p.status='ok' AND (p.group_id=0 OR p.group_id IN $MG) AND p.user_id NOT IN $BL) OR p.user_id=" . (int)$uid . ')';

function c_list($db, $uid, $where, $params) {
    $sql = "SELECT p.id,p.user_id,p.type,p.title,p.body,p.tags,p.anon,p.group_id,p.status,p.created,
        (SELECT COUNT(*) FROM c_favs f WHERE f.post_id=p.id) AS favs,
        (SELECT COUNT(*) FROM c_comments c WHERE c.post_id=p.id AND c.status='ok') AS cms,
        (SELECT COUNT(*) FROM c_favs f2 WHERE f2.post_id=p.id AND f2.user_id=" . (int)$uid . ") AS favme,
        (SELECT name FROM c_groups g WHERE g.id=p.group_id) AS gname
        FROM c_posts p WHERE $where ORDER BY p.id DESC LIMIT 60";
    $s = $db->prepare($sql);
    $s->execute($params);
    $out = [];
    foreach ($s->fetchAll() as $r) {
        $own = ((int)$r['user_id'] === (int)$uid);
        $out[] = ['id' => (int)$r['id'], 'type' => $r['type'], 'title' => $r['title'], 'excerpt' => mb_substr((string)$r['body'], 0, 160),
            'tags' => array_values(array_filter(explode(',', (string)$r['tags']))), 'anon' => (int)$r['anon'] === 1,
            'author' => ((int)$r['anon'] === 1 && !$own) ? 'Anonym' : c_name($db, $r['user_id']),
            'author_id' => ((int)$r['anon'] === 1 && !$own) ? 0 : (int)$r['user_id'], 'own' => $own, 'group' => (string)$r['gname'],
            'status' => $r['status'], 'favs' => (int)$r['favs'], 'comments' => (int)$r['cms'], 'fav' => (int)$r['favme'] > 0, 'created' => $r['created']];
    }
    return $out;
}

switch ($a) {
    case 'c_feed':
        $w = [$VIS]; $p = [];
        $type = (string)($in['type'] ?? '');
        if ($type === 'post' || $type === 'q') { $w[] = 'p.type=?'; $p[] = $type; }
        $tag = strtolower(trim((string)($in['tag'] ?? '')));
        if ($tag !== '') { $w[] = "(',' || p.tags || ',') LIKE ?"; $p[] = '%,' . $tag . ',%'; }
        $q = trim((string)($in['q'] ?? ''));
        if ($q !== '') { $w[] = '(p.title LIKE ? OR p.body LIKE ?)'; $p[] = '%' . $q . '%'; $p[] = '%' . $q . '%'; }
        $mode = (string)($in['mode'] ?? 'all');
        if ($mode === 'fav') $w[] = 'p.id IN (SELECT post_id FROM c_favs WHERE user_id=' . (int)$uid . ')';
        if ($mode === 'follow') $w[] = '(p.anon=0 AND p.user_id IN (SELECT target FROM c_follows WHERE user_id=' . (int)$uid . '))';
        if ($mode === 'mine') $w[] = 'p.user_id=' . (int)$uid;
        out(['posts' => c_list($db, $uid, implode(' AND ', $w), $p)]);
    case 'c_get':
        $id = (int)($in['id'] ?? 0);
        $s = $db->prepare("SELECT p.* FROM c_posts p WHERE p.id=? AND $VIS");
        $s->execute([$id]);
        $r = $s->fetch();
        if (!$r && $adm) { $s = $db->prepare('SELECT * FROM c_posts WHERE id=?'); $s->execute([$id]); $r = $s->fetch(); }
        if (!$r) out(['error' => 'Beitrag nicht gefunden.'], 404);
        $own = ((int)$r['user_id'] === (int)$uid);
        $list = c_list($db, $uid, 'p.id=' . $id, []);
        $post = $list ? $list[0] : null;
        if (!$post) out(['error' => 'Beitrag nicht gefunden.'], 404);
        $post['body'] = $r['body'];
        $post['data'] = json_decode((string)$r['data'], true) ?: new stdClass;
        $cs = $db->prepare("SELECT id,user_id,body,created FROM c_comments WHERE post_id=? AND status='ok' AND user_id NOT IN $BL ORDER BY id");
        $cs->execute([$id]);
        $post['comments_list'] = array_map(function ($c) use ($db, $uid) { return ['id' => (int)$c['id'], 'author' => c_name($db, $c['user_id']), 'author_id' => (int)$c['user_id'], 'own' => ((int)$c['user_id'] === (int)$uid), 'body' => $c['body'], 'created' => $c['created']]; }, $cs->fetchAll());
        $post['following'] = ($post['author_id'] > 0) && c_count($db, 'c_follows', 'user_id=? AND target=?', [$uid, $post['author_id']]) > 0;
        out(['post' => $post]);
    case 'c_post':
        if (c_count($db, 'c_posts', "user_id=? AND created>datetime('now','-1 hour')", [$uid]) >= 10) out(['error' => 'Du hast in der letzten Stunde zu viele Beiträge erstellt. Bitte warte etwas.'], 429);
        $type = ((string)($in['type'] ?? 'post') === 'q') ? 'q' : 'post';
        $title = trim(mb_substr((string)($in['title'] ?? ''), 0, 120));
        $body = trim(mb_substr((string)($in['body'] ?? ''), 0, 4000));
        if ($title === '' || $body === '') out(['error' => 'Titel und Text sind nötig.'], 400);
        $tags = [];
        foreach ((array)($in['tags'] ?? []) as $t) { $t = strtolower(preg_replace('/[^a-z0-9äöüß-]/iu', '', (string)$t)); if ($t !== '' && count($tags) < 5) $tags[] = mb_substr($t, 0, 24); }
        $gid = (int)($in['group_id'] ?? 0);
        if ($gid > 0 && c_count($db, 'c_gm', 'group_id=? AND user_id=?', [$gid, $uid]) === 0) out(['error' => 'Du bist nicht in dieser Gruppe.'], 403);
        $data = json_encode($in['report'] ?? new stdClass, JSON_UNESCAPED_UNICODE);
        if (strlen($data) > 2000000) out(['error' => 'Der Bericht ist zu groß (zu viele Fotos).'], 400);
        $status = c_flagged($title . ' ' . $body) ? 'held' : 'ok';
        $db->prepare('INSERT INTO c_posts(user_id,type,title,body,tags,anon,group_id,status,data) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$uid, $type, $title, $body, implode(',', $tags), empty($in['anon']) ? 0 : 1, $gid, $status, $data]);
        out(['id' => (int)$db->lastInsertId(), 'status' => $status]);
    case 'c_comment':
        $pid = (int)($in['post_id'] ?? 0);
        $s = $db->prepare("SELECT p.id FROM c_posts p WHERE p.id=? AND $VIS");
        $s->execute([$pid]);
        if (!$s->fetch()) out(['error' => 'Beitrag nicht gefunden.'], 404);
        if (c_count($db, 'c_comments', "user_id=? AND created>datetime('now','-1 hour')", [$uid]) >= 30) out(['error' => 'Zu viele Kommentare. Bitte warte etwas.'], 429);
        $body = trim(mb_substr((string)($in['body'] ?? ''), 0, 1000));
        if ($body === '') out(['error' => 'Der Kommentar ist leer.'], 400);
        $status = c_flagged($body) ? 'held' : 'ok';
        $db->prepare('INSERT INTO c_comments(post_id,user_id,body,status) VALUES(?,?,?,?)')->execute([$pid, $uid, $body, $status]);
        out(['ok' => 1, 'status' => $status]);
    case 'c_fav':
        $pid = (int)($in['post_id'] ?? 0);
        $has = c_count($db, 'c_favs', 'user_id=? AND post_id=?', [$uid, $pid]) > 0;
        if ($has) $db->prepare('DELETE FROM c_favs WHERE user_id=? AND post_id=?')->execute([$uid, $pid]);
        else $db->prepare('INSERT OR IGNORE INTO c_favs(user_id,post_id) VALUES(?,?)')->execute([$uid, $pid]);
        out(['fav' => !$has, 'count' => c_count($db, 'c_favs', 'post_id=?', [$pid])]);
    case 'c_follow':
        $t = (int)($in['user_id'] ?? 0);
        if ($t <= 0 || $t === (int)$uid) out(['error' => 'Nicht möglich.'], 400);
        $has = c_count($db, 'c_follows', 'user_id=? AND target=?', [$uid, $t]) > 0;
        if ($has) $db->prepare('DELETE FROM c_follows WHERE user_id=? AND target=?')->execute([$uid, $t]);
        else $db->prepare('INSERT OR IGNORE INTO c_follows(user_id,target) VALUES(?,?)')->execute([$uid, $t]);
        out(['following' => !$has]);
    case 'c_block':
        $t = (int)($in['user_id'] ?? 0);
        if ($t <= 0 || $t === (int)$uid) out(['error' => 'Nicht möglich.'], 400);
        $has = c_count($db, 'c_blocks', 'user_id=? AND target=?', [$uid, $t]) > 0;
        if ($has) $db->prepare('DELETE FROM c_blocks WHERE user_id=? AND target=?')->execute([$uid, $t]);
        else { $db->prepare('INSERT OR IGNORE INTO c_blocks(user_id,target) VALUES(?,?)')->execute([$uid, $t]); $db->prepare('DELETE FROM c_follows WHERE user_id=? AND target=?')->execute([$uid, $t]); }
        out(['blocked' => !$has]);
    case 'c_report':
        $kind = ((string)($in['kind'] ?? '') === 'comment') ? 'comment' : 'post';
        $db->prepare('INSERT INTO c_reports(kind,item,user_id,reason) VALUES(?,?,?,?)')->execute([$kind, (int)($in['id'] ?? 0), $uid, mb_substr((string)($in['reason'] ?? ''), 0, 200)]);
        out(['ok' => 1]);
    case 'c_delete':
        $kind = ((string)($in['kind'] ?? '') === 'comment') ? 'comment' : 'post';
        $id = (int)($in['id'] ?? 0);
        $tbl = $kind === 'comment' ? 'c_comments' : 'c_posts';
        $s = $db->prepare("SELECT user_id FROM $tbl WHERE id=?");
        $s->execute([$id]);
        $o = $s->fetchColumn();
        if ($o === false) out(['error' => 'Nicht gefunden.'], 404);
        if ((int)$o !== (int)$uid && !$adm) out(['error' => 'Nicht erlaubt.'], 403);
        if ($kind === 'post') { $db->prepare('DELETE FROM c_comments WHERE post_id=?')->execute([$id]); $db->prepare('DELETE FROM c_favs WHERE post_id=?')->execute([$id]); }
        $db->prepare("DELETE FROM $tbl WHERE id=?")->execute([$id]);
        out(['ok' => 1]);
    case 'c_groups':
        $s = $db->prepare('SELECT g.id,g.name,g.owner FROM c_groups g JOIN c_gm m ON m.group_id=g.id WHERE m.user_id=? ORDER BY g.id');
        $s->execute([$uid]);
        $gs = [];
        foreach ($s->fetchAll() as $g) {
            $ms = $db->prepare('SELECT user_id FROM c_gm WHERE group_id=?');
            $ms->execute([(int)$g['id']]);
            $gs[] = ['id' => (int)$g['id'], 'name' => $g['name'], 'owner' => ((int)$g['owner'] === (int)$uid), 'members' => array_map(function ($m) use ($db) { return c_name($db, $m); }, $ms->fetchAll(PDO::FETCH_COLUMN))];
        }
        out(['groups' => $gs]);
    case 'c_group_create':
        $name = trim(mb_substr((string)($in['name'] ?? ''), 0, 40));
        if ($name === '') out(['error' => 'Bitte einen Namen eingeben.'], 400);
        if (c_count($db, 'c_groups', 'owner=?', [$uid]) >= 10) out(['error' => 'Du kannst höchstens 10 Gruppen anlegen.'], 400);
        $db->prepare('INSERT INTO c_groups(name,owner) VALUES(?,?)')->execute([$name, $uid]);
        $gid = (int)$db->lastInsertId();
        $db->prepare('INSERT OR IGNORE INTO c_gm(group_id,user_id) VALUES(?,?)')->execute([$gid, $uid]);
        out(['id' => $gid]);
    case 'c_group_add':
        $gid = (int)($in['group_id'] ?? 0);
        if (c_count($db, 'c_groups', 'id=? AND owner=?', [$gid, $uid]) === 0) out(['error' => 'Nur der Besitzer kann Mitglieder hinzufügen.'], 403);
        $s = $db->prepare('SELECT id FROM users WHERE email=?');
        $s->execute([strtolower(trim((string)($in['email'] ?? '')))]);
        $tid = (int)$s->fetchColumn();
        if (!$tid) out(['error' => 'Diese E-Mail ist nicht registriert.'], 404);
        $db->prepare('INSERT OR IGNORE INTO c_gm(group_id,user_id) VALUES(?,?)')->execute([$gid, $tid]);
        out(['ok' => 1]);
    case 'c_group_leave':
        $gid = (int)($in['group_id'] ?? 0);
        $db->prepare('DELETE FROM c_gm WHERE group_id=? AND user_id=?')->execute([$gid, $uid]);
        out(['ok' => 1]);
    case 'c_profile':
        $t = (int)($in['user_id'] ?? 0);
        $posts = c_list($db, $uid, "p.user_id=$t AND p.anon=0 AND $VIS", []);
        out(['name' => c_name($db, $t), 'following' => c_count($db, 'c_follows', 'user_id=? AND target=?', [$uid, $t]) > 0, 'blocked' => c_count($db, 'c_blocks', 'user_id=? AND target=?', [$uid, $t]) > 0, 'posts' => $posts]);
    case 'c_admin':
        if (!$adm) out(['error' => 'Nur für Moderatoren.'], 403);
        $rs = $db->query("SELECT id,kind,item,user_id,reason,created FROM c_reports WHERE done=0 ORDER BY id DESC LIMIT 50")->fetchAll();
        $rep = [];
        foreach ($rs as $r) {
            $tbl = $r['kind'] === 'comment' ? 'c_comments' : 'c_posts';
            $s = $db->prepare("SELECT user_id,status," . ($r['kind'] === 'comment' ? 'body' : "title || ' – ' || body") . " AS txt FROM $tbl WHERE id=?");
            $s->execute([(int)$r['item']]);
            $it = $s->fetch();
            $rep[] = ['id' => (int)$r['id'], 'kind' => $r['kind'], 'item' => (int)$r['item'], 'reason' => $r['reason'], 'by' => c_name($db, $r['user_id']), 'text' => $it ? mb_substr((string)$it['txt'], 0, 200) : '(gelöscht)', 'author' => $it ? c_name($db, $it['user_id']) : '', 'status' => $it ? $it['status'] : ''];
        }
        $hp = $db->query("SELECT id,user_id,title,body FROM c_posts WHERE status='held' ORDER BY id DESC LIMIT 30")->fetchAll();
        $hc = $db->query("SELECT id,user_id,body FROM c_comments WHERE status='held' ORDER BY id DESC LIMIT 30")->fetchAll();
        out(['reports' => $rep,
            'held' => array_merge(
                array_map(function ($r) use ($db) { return ['kind' => 'post', 'id' => (int)$r['id'], 'author' => c_name($db, $r['user_id']), 'text' => mb_substr($r['title'] . ' – ' . $r['body'], 0, 200)]; }, $hp),
                array_map(function ($r) use ($db) { return ['kind' => 'comment', 'id' => (int)$r['id'], 'author' => c_name($db, $r['user_id']), 'text' => mb_substr((string)$r['body'], 0, 200)]; }, $hc))]);
    case 'c_admin_act':
        if (!$adm) out(['error' => 'Nur für Moderatoren.'], 403);
        $kind = ((string)($in['kind'] ?? '') === 'comment') ? 'comment' : 'post';
        $id = (int)($in['id'] ?? 0);
        $act = (string)($in['act'] ?? '');
        $tbl = $kind === 'comment' ? 'c_comments' : 'c_posts';
        if ($act === 'ok' || $act === 'hide') $db->prepare("UPDATE $tbl SET status=? WHERE id=?")->execute([$act === 'ok' ? 'ok' : 'hidden', $id]);
        if ($act === 'delete') {
            if ($kind === 'post') { $db->prepare('DELETE FROM c_comments WHERE post_id=?')->execute([$id]); $db->prepare('DELETE FROM c_favs WHERE post_id=?')->execute([$id]); }
            $db->prepare("DELETE FROM $tbl WHERE id=?")->execute([$id]);
        }
        if ($act === 'ban') {
            $s = $db->prepare("SELECT user_id FROM $tbl WHERE id=?");
            $s->execute([$id]);
            $o = (int)$s->fetchColumn();
            if ($o > 0 && $o !== (int)$uid) { $db->prepare('INSERT OR IGNORE INTO c_bans(user_id) VALUES(?)')->execute([$o]); $db->prepare("UPDATE c_posts SET status='hidden' WHERE user_id=?")->execute([$o]); }
        }
        $db->prepare('UPDATE c_reports SET done=1 WHERE kind=? AND item=?')->execute([$kind, $id]);
        out(['ok' => 1]);
    default:
        out(['error' => 'Unbekannte Aktion.'], 404);
}
