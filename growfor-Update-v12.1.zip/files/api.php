<?php
require __DIR__.'/update-gate.php';
require __DIR__.'/config.php';
if(!in_array($_GET['action']??'', ['bridge_upload','bridge_status','site_config'],true)){
 session_set_cookie_params(['lifetime'=>60*60*24*30,'path'=>'/','httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])]);
 session_start();
}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
require_once __DIR__.'/sync.php';
require_once __DIR__.'/orchard.php';
require_once __DIR__.'/timelapse.php';
require_once __DIR__.'/bridge.php';
require_once __DIR__.'/site-settings.php';
require_once __DIR__.'/catalog-admin.php';
function out($d,$c=200){finishSyncedWrite($d,$c);http_response_code($c);echo json_encode($d,JSON_UNESCAPED_UNICODE);exit;}
try{
  $dir=__DIR__.'/data';
  if(!is_dir($dir)){mkdir($dir,0750,true);file_put_contents($dir.'/.htaccess',"Require all denied\n");}
  $db=new PDO('sqlite:'.$dir.'/weedys.sqlite',null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  $db->exec('PRAGMA journal_mode=WAL');
  $db->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,pass TEXT NOT NULL,name TEXT DEFAULT '',created TEXT DEFAULT CURRENT_TIMESTAMP)");
  $db->exec("CREATE TABLE IF NOT EXISTS grows(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,name TEXT NOT NULL,data TEXT,updated TEXT DEFAULT CURRENT_TIMESTAMP)");
  $db->exec("CREATE TABLE IF NOT EXISTS entries(id INTEGER PRIMARY KEY AUTOINCREMENT,grow_id INTEGER NOT NULL,user_id INTEGER NOT NULL,day TEXT NOT NULL,data TEXT,type TEXT DEFAULT '')");
  $c=array_column($db->query('PRAGMA table_info(users)')->fetchAll(),'name');if(!in_array('name',$c))$db->exec("ALTER TABLE users ADD COLUMN name TEXT DEFAULT ''");
  $c=array_column($db->query('PRAGMA table_info(entries)')->fetchAll(),'name');
  if(!in_array('type',$c)){$db->exec("ALTER TABLE entries ADD COLUMN type TEXT DEFAULT ''");$up=$db->prepare('UPDATE entries SET type=? WHERE id=?');foreach($db->query('SELECT id,data FROM entries')->fetchAll() as $r){$up->execute([(json_decode($r['data'],true)['type']??''),$r['id']]);}}
  $db->exec('CREATE INDEX IF NOT EXISTS ix_e_user ON entries(user_id)');
  $db->exec('CREATE TABLE IF NOT EXISTS strains(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,data TEXT)');
  $db->exec('CREATE TABLE IF NOT EXISTS fails(ip TEXT,ts INTEGER)');
  $db->exec('CREATE TABLE IF NOT EXISTS settings(user_id INTEGER PRIMARY KEY,data TEXT)');
  $db->exec('CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY AUTOINCREMENT,grow_id INTEGER NOT NULL,user_id INTEGER NOT NULL,act TEXT,info TEXT,ts TEXT DEFAULT CURRENT_TIMESTAMP)');
  initializeSync($db);
  orchardInit($db);
  timelapseInit($db);
  bridgeInit($db);
  siteInit($db);
  $db->exec("CREATE TABLE IF NOT EXISTS feedback_threads(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,subject TEXT NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP,updated TEXT DEFAULT CURRENT_TIMESTAMP)");
  $db->exec("CREATE TABLE IF NOT EXISTS feedback_messages(id INTEGER PRIMARY KEY AUTOINCREMENT,thread_id INTEGER NOT NULL,sender_id INTEGER,body TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'message',created TEXT DEFAULT CURRENT_TIMESTAMP,read_at TEXT)");
  $db->exec('CREATE INDEX IF NOT EXISTS ix_feedback_thread ON feedback_messages(thread_id,id)');
  $db->exec('CREATE TABLE IF NOT EXISTS shares(grow_id INTEGER NOT NULL,user_id INTEGER NOT NULL,PRIMARY KEY(grow_id,user_id))');
}catch(Throwable $e){out(['error'=>'Speicher nicht möglich. Ist PHP SQLite aktiv und der Ordner beschreibbar?'],500);}

require __DIR__.'/accounts.php';
initializeAccounts($db);
$a=$_GET['action']??'';
$in=($_GET['action']??'')==='admin_update_upload'?$_POST:(json_decode(file_get_contents('php://input'),true)?:[]);
$uid=(int)($_SESSION['uid']??0);

if(in_array($a,['bridge_upload','bridge_status'],true)){
 try{[$device,$deviceUser]=bridgeAuthenticate($db,$in);$deviceUid=(int)$deviceUser['id'];
 if($a==='bridge_status')out(['ok'=>1,'grow_id'=>(int)$device['grow_id'],'device_id'=>(int)$device['id'],'expires_at'=>$device['expires_at']]);
 if(!preg_match('/^[A-Za-z0-9-]{16,80}$/D',(string)($in['client_request_id']??'')))out(['error'=>'Anfragekennung fehlt.'],400);
 $in['grow_id']=(int)$device['grow_id'];$in['sync_owner_id']=$deviceUid;$in['source']='gopro';$GLOBALS['bridge_authenticated']=true;
 beginSyncedWrite($db,$deviceUid,'bridge_upload',$in);$db->prepare('UPDATE bridge_devices SET last_seen=CURRENT_TIMESTAMP WHERE id=?')->execute([(int)$device['id']]);timelapseAction($db,$deviceUid,$deviceUser,'timelapse_frame_save',$in);
 }catch(Throwable $e){out(['error'=>'Geräteübertragung fehlgeschlagen. Bitte später erneut versuchen.'],500);}exit;
}
if($a==='site_config')out(siteSnapshot($db));
if($a==='register')out(['error'=>'Die Registrierung ist geschlossen. Verwende eines der eingerichteten Konten.'],403);
if($a==='login'){
  $login=strtolower(trim((string)($in['login']??$in['email']??'')));
  $pw=(string)($in['password']??'');
  $ip=$_SERVER['REMOTE_ADDR']??'';
  $fc=$db->prepare('SELECT COUNT(*) FROM fails WHERE ip=? AND ts>?');
  $fc->execute([$ip,time()-900]);
  if((int)$fc->fetchColumn()>=8)out(['error'=>'Zu viele Fehlversuche. Bitte in 15 Minuten erneut versuchen.'],429);
  $q=$db->prepare("SELECT * FROM users WHERE lower(login_name)=? OR (role='admin' AND lower(email)=?)");
  $q->execute([$login,$login]);$u=$q->fetch();
  if(!$u||!password_verify($pw,$u['pass'])||!empty($u['disabled'])){
    $db->prepare('INSERT INTO fails(ip,ts) VALUES(?,?)')->execute([$ip,time()]);
    usleep(250000);out(['error'=>'Name oder Passwort stimmt nicht.'],401);
  }
  session_regenerate_id(true);$_SESSION['uid']=(int)$u['id'];$_SESSION['auth_version']=(int)$u['auth_version'];
  $db->prepare('DELETE FROM fails WHERE ip=?')->execute([$ip]);
  out(['user'=>publicAccount($u)]);
}
if($a==='cfg')out(['community'=>(defined('COMMUNITY')&&COMMUNITY==='1'),'impressum'=>(defined('IMPRESSUM_URL')?(string)IMPRESSUM_URL:''),'datenschutz'=>(defined('DATENSCHUTZ_URL')?(string)DATENSCHUTZ_URL:'')]);
if($a==='logout'){session_destroy();out(['ok'=>1]);}
$account=null;
if($uid){
  $q=$db->prepare('SELECT * FROM users WHERE id=?');$q->execute([$uid]);$account=$q->fetch();
  if(!$account||!empty($account['disabled'])||(int)($_SESSION['auth_version']??0)!==(int)$account['auth_version']){session_destroy();$uid=0;$account=null;}
}
if($a==='me')out(['user'=>$account?publicAccount($account):null]);
if(!$uid)out(['error'=>'Nicht angemeldet.'],401);
if(isset($in['sync_owner_id'])&&(int)$in['sync_owner_id']!==$uid)out(['error'=>'Die Sitzung gehört zu einem anderen Konto.'],403);
if($a==='password_change'){
  $current=(string)($in['current_password']??'');
  $next=(string)($in['new_password']??'');
  $confirm=(string)($in['password_confirm']??'');
  if(!password_verify($current,$account['pass']))out(['error'=>'Das bisherige Passwort stimmt nicht.'],403);
  if(strlen($next)<10||strlen($next)>72)out(['error'=>'Bitte ein Passwort mit 10 bis 72 Bytes wählen.'],400);
  if($next!==$confirm)out(['error'=>'Die beiden neuen Passwörter stimmen nicht überein.'],400);
  if(password_verify($next,$account['pass']))out(['error'=>'Bitte ein anderes Passwort als das Startpasswort wählen.'],400);
  $db->prepare('UPDATE users SET pass=?,must_change_password=0,auth_version=auth_version+1 WHERE id=?')->execute([password_hash($next,PASSWORD_DEFAULT),$uid]);
  session_regenerate_id(true);$_SESSION['auth_version']=(int)$account['auth_version']+1;$account['must_change_password']=0;
  out(['user'=>publicAccount($account)]);
}
if((int)$account['must_change_password'])out(['error'=>'Bitte zuerst dein Startpasswort ändern.','must_change_password'=>true],403);
if(in_array($a,['bridge_devices','bridge_create','bridge_revoke'],true)){bridgeSession($db,$uid,$account,$a,$in);exit;}
if($a==='catalog_library'){ $seeds=catalogRead($db,'catalog_seeds');$companions=catalogRead($db,'catalog_companions');out(['seeds'=>array_values(array_filter($seeds['rows'],fn($r)=>!empty($r['active']))),'companions'=>array_values(array_filter($companions['rows'],fn($r)=>!empty($r['active'])))]);}
if($a==='orchard_library')out(orchardLibrary($db));
if(strpos($a,'admin_')===0){try{require __DIR__.'/admin.php';}catch(PDOException $e){out(['error'=>'Daten konnten nicht geändert werden. Möglicherweise besteht ein Zuordnungskonflikt. Bitte die Serverfassung neu laden.'],409);}catch(Throwable $e){out(['error'=>'Die Adminaktion konnte nicht abgeschlossen werden. Bitte erneut versuchen.'],500);}exit;}
if(in_array($a,['grow_phase_save','entry_save','settings_save','feedback_send','feedback_reply','timelapse_frame_save','timelapse_frame_delete'],true))beginSyncedWrite($db,$uid,$a,$in);
if(strpos($a,'timelapse_')===0){try{timelapseAction($db,$uid,$account,$a,$in);}catch(Throwable $e){out(['error'=>'Foto konnte nicht gespeichert werden. Bitte Speicherplatz auf dem Server prüfen und erneut synchronisieren.'],500);}exit;}
if(strpos($a,'feedback_')===0){require __DIR__.'/feedback.php';exit;}
if(strpos($a,'c_')===0){require __DIR__.'/community.php';exit;}
if($a==='diagnose'||$a==='diag_status'){require __DIR__.'/diagnose.php';exit;}
function logAct($db,$gid,$uid,$act,$info){try{$db->prepare('INSERT INTO activity(grow_id,user_id,act,info) VALUES(?,?,?,?)')->execute([(int)$gid,(int)$uid,(string)$act,substr((string)$info,0,120)]);}catch(Throwable $e){}}

function ownGrow($db,$uid,$id){$s=$db->prepare('SELECT * FROM grows WHERE id=? AND (user_id=? OR id IN (SELECT grow_id FROM shares WHERE user_id=?))');$s->execute([$id,$uid,$uid]);$g=$s->fetch();if(!$g)out(['error'=>'Grow nicht gefunden.'],404);return $g;}
function ownerGrow($db,$uid,$id){$s=$db->prepare('SELECT * FROM grows WHERE id=? AND user_id=?');$s->execute([$id,$uid]);$g=$s->fetch();if(!$g)out(['error'=>'Nur der Besitzer darf das.'],403);return $g;}

switch($a){
  case 'grows':
    $s=$db->prepare('SELECT g.id,g.name,g.data,g.user_id,u.name AS un,u.email FROM grows g LEFT JOIN users u ON u.id=g.user_id WHERE g.user_id=? OR g.id IN (SELECT grow_id FROM shares WHERE user_id=?) ORDER BY g.id DESC');$s->execute([$uid,$uid]);
    out(['grows'=>array_map(fn($r)=>['id'=>(int)$r['id'],'name'=>$r['name'],'own'=>((int)$r['user_id']===$uid),'owner'=>(trim((string)$r['un'])?:explode('@',(string)$r['email'])[0]),'data'=>json_decode($r['data'],true)?:new stdClass],$s->fetchAll())]);
  case 'grow_phase_save':
    $id=(int)($in['grow_id']??0);$row=ownerGrow($db,$uid,$id);$data=json_decode($row['data'],true)?:[];$phase=$in['phase']??null;
    if($phase!==null&&(!is_array($phase)||array_diff(array_keys($phase),['stage','progress'])||!is_int($phase['stage']??null)||$phase['stage']<0||$phase['stage']>6||!is_int($phase['progress']??null)||$phase['progress']<0||$phase['progress']>100))out(['error'=>'Phase und Fortschritt bitte prüfen.'],400);
    $data['manual_phase']=$phase===null?null:$phase+['updated_at'=>gmdate('c')];
    $db->prepare('UPDATE grows SET data=?,updated=CURRENT_TIMESTAMP WHERE id=?')->execute([json_encode($data,JSON_UNESCAPED_UNICODE),$id]);logAct($db,$id,$uid,'phase_change',$phase===null?'Automatische Anzeige':'Manuelle Phase '.$phase['stage'].' / '.$phase['progress'].'%');out(['ok'=>1,'manual_phase'=>$data['manual_phase']]);
  case 'grow_save':
    $name=trim($in['name']??'')?:'Mein Grow'; $data=json_encode($in['data']??new stdClass,JSON_UNESCAPED_UNICODE);
    if(!empty($in['id'])){ownGrow($db,$uid,(int)$in['id']);$db->prepare('UPDATE grows SET name=?,data=? WHERE id=?')->execute([$name,$data,(int)$in['id']]);logAct($db,(int)$in['id'],$uid,'grow_edit','');out(['id'=>(int)$in['id']]);}
    $db->prepare('INSERT INTO grows(user_id,name,data) VALUES(?,?,?)')->execute([$uid,$name,$data]);out(['id'=>(int)$db->lastInsertId()]);
  case 'grow_delete':
    ownerGrow($db,$uid,(int)($in['id']??0));
    $db->prepare('DELETE FROM shares WHERE grow_id=?')->execute([(int)$in['id']]);
    $db->prepare('DELETE FROM entries WHERE grow_id=?')->execute([(int)$in['id']]);
    $db->prepare('DELETE FROM timelapse_frames WHERE grow_id=?')->execute([(int)$in['id']]);
    $db->prepare('DELETE FROM grows WHERE id=?')->execute([(int)$in['id']]);out(['ok'=>1]);
  case 'entries':
    ownGrow($db,$uid,(int)($in['grow_id']??0));
    $s=$db->prepare('SELECT e.id,e.day,e.data,e.user_id,u.name,u.email FROM entries e LEFT JOIN users u ON u.id=e.user_id WHERE e.grow_id=? ORDER BY e.day DESC,e.id DESC');$s->execute([(int)$in['grow_id']]);
    out(['entries'=>array_map(fn($r)=>['id'=>(int)$r['id'],'day'=>$r['day'],'by'=>(trim((string)$r['name'])?:explode('@',(string)$r['email'])[0]),'uid'=>(int)$r['user_id'],'data'=>json_decode($r['data'],true)?:new stdClass],$s->fetchAll())]);
  case 'entry_save':
    ownGrow($db,$uid,(int)($in['grow_id']??0));
    $day=preg_match('/^\d{4}-\d{2}-\d{2}$/',$in['day']??'')?$in['day']:date('Y-m-d');
    $db->prepare('INSERT INTO entries(grow_id,user_id,day,data,type) VALUES(?,?,?,?,?)')->execute([(int)$in['grow_id'],$uid,$day,json_encode($in['data']??new stdClass,JSON_UNESCAPED_UNICODE),(is_array($in['data']??null)?(string)($in['data']['type']??''):'')]);
    $nid=(int)$db->lastInsertId();logAct($db,(int)$in['grow_id'],$uid,'entry_add',is_array($in['data']??null)?(string)($in['data']['type']??''):'');
    out(['ok'=>1,'id'=>$nid]);
  case 'summary':
    $s=$db->prepare("SELECT id,grow_id,day,type,CASE WHEN type IN ('water','feed') THEN data ELSE NULL END AS data FROM entries WHERE grow_id IN (SELECT id FROM grows WHERE user_id=?) OR grow_id IN (SELECT grow_id FROM shares WHERE user_id=?) ORDER BY day DESC,id DESC");$s->execute([$uid,$uid]);
    out(['entries'=>array_map(function($r){$d=$r['data']?(json_decode($r['data'],true)?:[]):[];return['id'=>(int)$r['id'],'grow_id'=>(int)$r['grow_id'],'day'=>$r['day'],'type'=>(string)$r['type'],'w'=>$d['water']??'','ml'=>$d['ml']??'','fn'=>$d['feed_name']??''];},$s->fetchAll())]);
  case 'settings_get':
    $s=$db->prepare('SELECT data FROM settings WHERE user_id=?');$s->execute([$uid]);$r=$s->fetchColumn();out(['data'=>$r?(json_decode($r,true)?:new stdClass):new stdClass,'version'=>hash('sha256',$r?:'{}')]);
  case 'settings_save':
    $expected=(string)($in['settings_base_hash']??'');
    if(isset($in['settings_after_request'])){
      $q=$db->prepare("SELECT response FROM sync_receipts WHERE user_id=? AND request_id=? AND action='settings_save'");$q->execute([$uid,(string)$in['settings_after_request']]);$previous=$q->fetchColumn();$expected=(string)((json_decode($previous?:'{}',true)['version'])??'');
      if($expected==='')out(['error'=>'Eine vorherige lokale Änderung ist noch nicht bestätigt. Bitte die lokalen Einstellungen prüfen.','code'=>'settings_conflict'],409);
    }
    if(!preg_match('/^[a-f0-9]{64}$/D',$expected))out(['error'=>'Bitte die App online aktualisieren und die vorgemerkten Einstellungen prüfen. Die lokale Fassung bleibt erhalten.','code'=>'settings_version_required'],503);
    $q=$db->prepare('SELECT data FROM settings WHERE user_id=?');$q->execute([$uid]);$current=$q->fetchColumn();
    if(!hash_equals(hash('sha256',$current?:'{}'),$expected))out(['error'=>'Speicherkonflikt: Auf dem Server gibt es neuere Einstellungen. Deine lokale Fassung bleibt zur Prüfung erhalten.','code'=>'settings_conflict'],409);
    $data=json_encode($in['data']??new stdClass,JSON_UNESCAPED_UNICODE);
    $db->prepare('INSERT OR REPLACE INTO settings(user_id,data) VALUES(?,?)')->execute([$uid,$data]);out(['ok'=>1,'version'=>hash('sha256',$data)]);
  case 'profile_save':
    $s=$db->prepare('SELECT * FROM users WHERE id=?');$s->execute([$uid]);$u=$s->fetch();
    $name=substr(trim($in['name']??''),0,60);$email=strtolower(trim($in['email']??$u['email']));$new=(string)($in['new_password']??'');
    if(!filter_var($email,FILTER_VALIDATE_EMAIL))out(['error'=>'Bitte eine gültige E-Mail eingeben.'],400);
    $hash=$u['pass'];
    if($email!==$u['email']||$new!==''){
      if(!password_verify((string)($in['current_password']??''),$u['pass']))out(['error'=>'Das aktuelle Passwort stimmt nicht.'],403);
      if($email!==$u['email']){$q=$db->prepare('SELECT id FROM users WHERE email=? AND id<>?');$q->execute([$email,$uid]);if($q->fetch())out(['error'=>'Diese E-Mail wird schon verwendet.'],409);}
      if($new!==''&&$new!==(string)($in['password_confirm']??''))out(['error'=>'Bitte das neue Passwort identisch bestätigen.'],400);
      if($new!==''){if(strlen($new)<10||strlen($new)>72)out(['error'=>'Das neue Passwort braucht 10 bis 72 Bytes.'],400);$hash=password_hash($new,PASSWORD_DEFAULT);}
    }
    $db->prepare('UPDATE users SET name=?,email=?,pass=? WHERE id=?')->execute([$name,$email,$hash,$uid]);
    if($new!==''){$db->prepare('UPDATE users SET auth_version=auth_version+1 WHERE id=?')->execute([$uid]);$_SESSION['auth_version']=(int)$account['auth_version']+1;}
    $account['email']=$email;$account['name']=$name;out(['user'=>publicAccount($account)]);
  case 'strains_list':
    $s=$db->query('SELECT s.id,s.user_id,s.data,u.name,u.email FROM strains s LEFT JOIN users u ON u.id=s.user_id ORDER BY s.id');
    out(['strains'=>array_map(function($r)use($uid){$by=trim((string)$r['name'])?:explode('@',(string)$r['email'])[0];return['id'=>(int)$r['id'],'own'=>((int)$r['user_id']===$uid),'by'=>$by,'data'=>json_decode($r['data'],true)?:new stdClass];},$s->fetchAll())]);
  case 'strain_save':
    $d=json_encode($in['data']??new stdClass,JSON_UNESCAPED_UNICODE);
    $db->prepare('INSERT INTO strains(user_id,data) VALUES(?,?)')->execute([$uid,$d]);out(['id'=>(int)$db->lastInsertId()]);
  case 'strain_delete':
    $db->prepare('DELETE FROM strains WHERE id=? AND user_id=?')->execute([(int)($in['id']??0),$uid]);out(['ok'=>1]);
  case 'export':
    $g=$db->prepare('SELECT id,name,data FROM grows WHERE user_id=?');$g->execute([$uid]);
    $e=$db->prepare('SELECT grow_id,day,data FROM entries WHERE grow_id IN (SELECT id FROM grows WHERE user_id=?) ORDER BY day,id');$e->execute([$uid]);
    out(['exported'=>date('c'),'grows'=>array_map(fn($r)=>['id'=>(int)$r['id'],'name'=>$r['name'],'data'=>json_decode($r['data'],true)],$g->fetchAll()),'entries'=>array_map(fn($r)=>['grow_id'=>(int)$r['grow_id'],'day'=>$r['day'],'data'=>json_decode($r['data'],true)],$e->fetchAll())]);
  case 'shares':
    $g=ownGrow($db,$uid,(int)($in['grow_id']??0));
    $s=$db->prepare('SELECT u.id,u.name,u.email FROM shares sh JOIN users u ON u.id=sh.user_id WHERE sh.grow_id=?');$s->execute([(int)$g['id']]);
    out(['owner'=>((int)$g['user_id']===$uid),'members'=>array_map(fn($r)=>['id'=>(int)$r['id'],'name'=>(trim((string)$r['name'])?:explode('@',(string)$r['email'])[0]),'email'=>$r['email']],$s->fetchAll())]);
  case 'activity':
    $g=ownGrow($db,$uid,(int)($in['grow_id']??0));
    $s=$db->prepare('SELECT a.act,a.info,a.ts,u.name,u.email FROM activity a LEFT JOIN users u ON u.id=a.user_id WHERE a.grow_id=? ORDER BY a.id DESC LIMIT 30');$s->execute([(int)$g['id']]);
    out(['items'=>array_map(fn($r)=>['act'=>$r['act'],'info'=>$r['info'],'ts'=>$r['ts'],'by'=>(trim((string)$r['name'])?:explode('@',(string)$r['email'])[0])],$s->fetchAll())]);
  case 'share_add':
    $g=ownerGrow($db,$uid,(int)($in['grow_id']??0));$em=strtolower(trim((string)($in['email']??'')));
    $s=$db->prepare('SELECT id FROM users WHERE email=?');$s->execute([$em]);$tid=(int)$s->fetchColumn();
    if(!$tid)out(['error'=>'Diese E-Mail ist nicht registriert. Dein Kollege muss sich zuerst anmelden.'],404);
    if($tid===$uid)out(['error'=>'Das bist du selbst.'],400);
    $db->prepare('INSERT OR IGNORE INTO shares(grow_id,user_id) VALUES(?,?)')->execute([(int)$g['id'],$tid]);logAct($db,(int)$g['id'],$uid,'share_add',$em);out(['ok'=>1]);
  case 'share_remove':
    $gid=(int)($in['grow_id']??0);$mid=(int)($in['user_id']??0);$g=ownGrow($db,$uid,$gid);
    if((int)$g['user_id']!==$uid&&$mid!==$uid)out(['error'=>'Nicht erlaubt.'],403);
    $db->prepare('DELETE FROM shares WHERE grow_id=? AND user_id=?')->execute([$gid,$mid]);logAct($db,$gid,$uid,'share_remove','');out(['ok'=>1]);
  case 'import':
    $d=is_array($in['data']??null)?$in['data']:[];$map=[];$n=0;
    $gi=$db->prepare('INSERT INTO grows(user_id,name,data) VALUES(?,?,?)');$ei=$db->prepare('INSERT INTO entries(grow_id,user_id,day,data,type) VALUES(?,?,?,?,?)');
    foreach(($d['grows']??[]) as $g){$gi->execute([$uid,(string)($g['name']??'Import'),json_encode($g['data']??new stdClass,JSON_UNESCAPED_UNICODE)]);$map[(int)($g['id']??0)]=(int)$db->lastInsertId();}
    foreach(($d['entries']??[]) as $e){$gid=$map[(int)($e['grow_id']??0)]??0;if(!$gid)continue;$ed=$e['data']??[];$day=preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)($e['day']??''))?$e['day']:date('Y-m-d');$ei->execute([$gid,$uid,$day,json_encode($ed,JSON_UNESCAPED_UNICODE),(is_array($ed)?(string)($ed['type']??''):'')]);$n++;}
    out(['grows'=>count($map),'entries'=>$n]);
  case 'entry_delete':
    $q=$db->prepare('SELECT grow_id,type FROM entries WHERE id=?');$q->execute([(int)($in['id']??0)]);$er=$q->fetch();
    $dl=$db->prepare('DELETE FROM entries WHERE id=? AND (user_id=? OR grow_id IN (SELECT id FROM grows WHERE user_id=?) OR grow_id IN (SELECT grow_id FROM shares WHERE user_id=?))');$dl->execute([(int)($in['id']??0),$uid,$uid,$uid]);if($er&&$dl->rowCount()>0)logAct($db,(int)$er['grow_id'],$uid,'entry_del',(string)$er['type']);out(['ok'=>1]);
  default: out(['error'=>'Unbekannte Aktion.'],404);
}
