<?php
// Revocable, upload-only camera capabilities. Raw tokens are never stored.
function bridgeInit(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS bridge_devices(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,grow_id INTEGER NOT NULL,issuer_id INTEGER NOT NULL,name TEXT NOT NULL,token_hash TEXT UNIQUE NOT NULL,auth_version INTEGER NOT NULL,expires_at TEXT NOT NULL,revoked_at TEXT,last_seen TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP)");
}
function bridgeHttps(): bool {return !empty($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off';}
function bridgeJsonRequest(): void {if(($_SERVER['REQUEST_METHOD']??'')!=='POST')out(['error'=>'POST erforderlich.'],405);if(!str_starts_with(strtolower($_SERVER['CONTENT_TYPE']??''),'application/json'))out(['error'=>'JSON erforderlich.'],415);}
function bridgeOwner(PDO $db,int $uid,array $account,int $gid): array {$q=$db->prepare('SELECT * FROM grows WHERE id=?');$q->execute([$gid]);$g=$q->fetch();if(!$g)out(['error'=>'Tagebuch nicht gefunden.'],404);if((int)$g['user_id']!==$uid&&$account['role']!=='admin')out(['error'=>'Nur Besitzer oder Admin dürfen Gerätezugänge verwalten.'],403);return $g;}
function bridgeSession(PDO $db,int $uid,array $account,string $action,array $in): void {
    bridgeJsonRequest();if(!bridgeHttps())out(['error'=>'Gerätezugänge nur über HTTPS verwalten.'],403);
    if(empty($_SESSION['bridge_csrf']))$_SESSION['bridge_csrf']=bin2hex(random_bytes(32));
    if($action!=='bridge_devices'&&(!is_string($in['bridge_csrf']??null)||!hash_equals($_SESSION['bridge_csrf'],$in['bridge_csrf'])))out(['error'=>'Bitte die Geräteverwaltung neu öffnen.'],403);
    $gid=(int)($in['grow_id']??0);$g=bridgeOwner($db,$uid,$account,$gid);
    if($action==='bridge_devices'){$q=$db->prepare('SELECT d.id,d.name,d.grow_id,d.expires_at,d.revoked_at,d.last_seen,d.created,CASE WHEN d.auth_version=u.auth_version AND u.disabled=0 AND u.must_change_password=0 AND g.user_id=d.user_id THEN 1 ELSE 0 END AS account_valid FROM bridge_devices d JOIN users u ON u.id=d.user_id JOIN grows g ON g.id=d.grow_id WHERE d.grow_id=? ORDER BY d.id DESC');$q->execute([$gid]);out(['devices'=>$q->fetchAll(),'csrf'=>$_SESSION['bridge_csrf'],'grow'=>['id'=>$gid,'name'=>$g['name']]]);}
    if($action==='bridge_create'){
        $name=is_string($in['name']??null)?trim($in['name']):'';$days=(int)($in['days']??30);if($name===''||strlen($name)>160||preg_match_all('/./us',$name)>40||$days<1||$days>90)out(['error'=>'Gerätename (max. 40 Zeichen) und Laufzeit (1–90 Tage) prüfen.'],400);
        $q=$db->prepare('SELECT * FROM users WHERE id=?');$q->execute([(int)$g['user_id']]);$owner=$q->fetch();if(!$owner||$owner['disabled']||$owner['must_change_password'])out(['error'=>'Der Besitzer muss sein Konto zuerst vollständig einrichten.'],400);
        $db->exec('BEGIN IMMEDIATE');$q=$db->prepare('SELECT COUNT(*) FROM bridge_devices WHERE grow_id=? AND revoked_at IS NULL AND expires_at>?');$q->execute([$gid,gmdate('Y-m-d H:i:s')]);if((int)$q->fetchColumn()>=5){$db->exec('ROLLBACK');out(['error'=>'Maximal fünf aktive Geräte je Tagebuch. Alte Zugänge zuerst widerrufen.'],400);}
        $token='gb_'.bin2hex(random_bytes(32));$expires=gmdate('Y-m-d H:i:s',time()+$days*86400);$db->prepare('INSERT INTO bridge_devices(user_id,grow_id,issuer_id,name,token_hash,auth_version,expires_at) VALUES(?,?,?,?,?,?,?)')->execute([(int)$g['user_id'],$gid,$uid,$name,hash('sha256',$token),(int)$owner['auth_version'],$expires]);$id=(int)$db->lastInsertId();$db->exec('COMMIT');
        logAct($db,$gid,$uid,'bridge_pair',$name);out(['id'=>$id,'token'=>$token,'grow_id'=>$gid,'user_id'=>(int)$g['user_id'],'expires_at'=>$expires,'name'=>$name]);
    }
    if($action==='bridge_revoke'){$db->prepare('UPDATE bridge_devices SET revoked_at=CURRENT_TIMESTAMP WHERE id=? AND grow_id=?')->execute([(int)($in['id']??0),$gid]);logAct($db,$gid,$uid,'bridge_revoke',(string)($in['id']??0));out(['ok'=>1]);}
    out(['error'=>'Unbekannte Geräteaktion.'],404);
}
function bridgeAuthenticate(PDO $db,array $in): array {
    bridgeJsonRequest();if(!bridgeHttps())out(['error'=>'HTTPS erforderlich.'],403);$token=$_SERVER['HTTP_X_GROWING_DEVICE']??'';if(!is_string($token)||!preg_match('/^gb_[a-f0-9]{64}$/D',$token))out(['error'=>'Gerätezugang ungültig. Neu koppeln.'],401);
    $q=$db->prepare('SELECT * FROM bridge_devices WHERE token_hash=?');$q->execute([hash('sha256',$token)]);$d=$q->fetch();if(!$d||$d['revoked_at']||$d['expires_at']<=gmdate('Y-m-d H:i:s'))out(['error'=>'Gerätezugang abgelaufen oder widerrufen. Neu koppeln.'],401);
    $q=$db->prepare('SELECT * FROM users WHERE id=?');$q->execute([(int)$d['user_id']]);$u=$q->fetch();$q=$db->prepare('SELECT user_id FROM grows WHERE id=?');$q->execute([(int)$d['grow_id']]);$owner=$q->fetchColumn();
    if(!$u||$u['disabled']||$u['must_change_password']||(int)$u['auth_version']!==(int)$d['auth_version']||(int)$owner!==(int)$u['id'])out(['error'=>'Konto oder Tagebuchzugang geändert. Neu koppeln.'],401);
    if(isset($in['grow_id'])&&(int)$in['grow_id']!==(int)$d['grow_id'])out(['error'=>'Der Gerätezugang gilt für ein anderes Tagebuch.'],403);
    return [$d,$u];
}
