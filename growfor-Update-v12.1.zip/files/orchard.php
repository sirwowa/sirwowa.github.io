<?php
// Separate, editorial fruit/vegetable library. No model, prompts or grow integration.
function orchardInit(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS orchard_knowledge(id INTEGER PRIMARY KEY AUTOINCREMENT,species TEXT NOT NULL,title TEXT NOT NULL,symptoms TEXT NOT NULL DEFAULT '',causes TEXT NOT NULL DEFAULT '',guidance TEXT NOT NULL DEFAULT '',keywords TEXT NOT NULL DEFAULT '',sources TEXT NOT NULL DEFAULT '[]',status TEXT NOT NULL DEFAULT 'draft',author_id INTEGER NOT NULL,reviewed_by INTEGER,reviewed_at TEXT,updated TEXT DEFAULT CURRENT_TIMESTAMP)");
    $db->exec('CREATE INDEX IF NOT EXISTS ix_orchard_species ON orchard_knowledge(status,species)');
}
function orchardCrops(): array {return ['tomato'=>'Tomate','cucumber'=>'Gurke','pepper'=>'Paprika','lettuce'=>'Salat','carrot'=>'Möhre','zucchini'=>'Zucchini','apple'=>'Apfel','pear'=>'Birne','strawberry'=>'Erdbeere','blueberry'=>'Heidelbeere','raspberry'=>'Himbeere','grape'=>'Weintraube'];}
function orchardRow(array $r): array {$r['id']=(int)$r['id'];$r['sources']=json_decode($r['sources'],true)?:[];return $r;}
function orchardLibrary(PDO $db): array {return ['crops'=>orchardCrops(),'articles'=>array_map('orchardRow',$db->query("SELECT id,species,title,symptoms,causes,guidance,keywords,sources,status,reviewed_at,updated FROM orchard_knowledge WHERE status='published' ORDER BY species,title,id")->fetchAll()),'fetched_at'=>gmdate('c')];}
function orchardRecord(PDO $db,int $id): array {$q=$db->prepare('SELECT * FROM orchard_knowledge WHERE id=?');$q->execute([$id]);$r=$q->fetch();if(!$r)out(['error'=>'Wissenseintrag nicht gefunden.'],404);return $r;}
function orchardAdmin(PDO $db,int $uid,string $action,array $in): void {
    if($action==='admin_orchard_list'){
        $page=max(1,min(100000,(int)($in['page']??1)));$where=[];$args=[];
        $species=$in['species']??'';$status=$in['status']??'';
        if($species!==''){if(!is_string($species)||!isset(orchardCrops()[$species]))out(['error'=>'Bitte eine vorhandene Obst- oder Gemüseart wählen.'],400);$where[]='species=?';$args[]=$species;}
        if($status!==''){if(!in_array($status,['draft','published','archived'],true))out(['error'=>'Status prüfen.'],400);$where[]='status=?';$args[]=$status;}
        $search=adminText($in['search']??'',100,true);if($search!==''){$where[]='(title LIKE ? OR keywords LIKE ?)';$args[]='%'.$search.'%';$args[]='%'.$search.'%';}
        $w=$where?' WHERE '.implode(' AND ',$where):'';$q=$db->prepare('SELECT COUNT(*) FROM orchard_knowledge'.$w);$q->execute($args);$count=(int)$q->fetchColumn();
        $q=$db->prepare('SELECT id,species,title,status,updated,reviewed_at FROM orchard_knowledge'.$w.' ORDER BY id DESC LIMIT 25 OFFSET '.(($page-1)*25));$q->execute($args);out(['rows'=>$q->fetchAll(),'total'=>$count,'page'=>$page,'crops'=>orchardCrops()]);
    }
    if($action==='admin_orchard_get'){$r=orchardRecord($db,adminId($in['id']??0));out(['record'=>orchardRow($r),'version'=>adminVersion($r),'crops'=>orchardCrops()]);}
    if($action!=='admin_orchard_save')out(['error'=>'Unbekannte Wissensfunktion.'],404);
    $allowed=['id','version','species','title','symptoms','causes','guidance','keywords','sources','status','reviewed','client_request_id','admin_csrf','sync_owner_id'];
    foreach(array_keys($in) as $k)if(!in_array($k,$allowed,true))out(['error'=>'Nicht unterstütztes Wissensfeld.'],400);
    $id=empty($in['id'])?0:adminId($in['id']);$old=$id?orchardRecord($db,$id):null;if($old)adminCheckVersion($old,$in);
    $species=$in['species']??'';if(!is_string($species)||!isset(orchardCrops()[$species]))out(['error'=>'Bitte eine vorhandene Obst- oder Gemüseart wählen.'],400);
    $title=adminText($in['title']??'',120);$symptoms=adminText($in['symptoms']??'',3000,true);$causes=adminText($in['causes']??'',4000,true);$guidance=adminText($in['guidance']??'',4000,true);$keywords=adminText($in['keywords']??'',300,true);
    $status=$in['status']??'draft';if(!in_array($status,['draft','published','archived'],true))out(['error'=>'Status prüfen.'],400);
    $sources=$in['sources']??[];if(!is_array($sources)||count($sources)>8)out(['error'=>'Maximal acht Quellen angeben.'],400);$clean=[];
    foreach($sources as $source){if(!is_array($source))out(['error'=>'Quelle prüfen.'],400);$label=adminText($source['title']??'',160);$url=adminText($source['url']??'',2000);if(!filter_var($url,FILTER_VALIDATE_URL)||!in_array(strtolower(parse_url($url,PHP_URL_SCHEME)?:''),['http','https'],true)||parse_url($url,PHP_URL_USER)!==null||parse_url($url,PHP_URL_PASS)!==null)out(['error'=>'Quellen brauchen eine gültige HTTP(S)-Adresse ohne Zugangsdaten.'],400);$clean[]=['title'=>$label,'url'=>$url];}
    if($status==='published'){
        if(($in['reviewed']??false)!==true||!$clean||$symptoms===''||$causes===''||$guidance===''||$keywords==='')out(['error'=>'Vor Veröffentlichung: alle Fachfelder, Stichwörter und mindestens eine Quelle ausfüllen und die redaktionelle Prüfung bestätigen.'],400);
        if((!$old||$old['status']!=='published')&&(int)$db->query("SELECT COUNT(*) FROM orchard_knowledge WHERE status='published'")->fetchColumn()>=500)out(['error'=>'Maximal 500 veröffentlichte Einträge. Bitte alte Einträge archivieren.'],400);
    }
    $reviewer=$status==='published'?$uid:null;$reviewed=$status==='published'?gmdate('Y-m-d H:i:s'):null;
    $values=[$species,$title,$symptoms,$causes,$guidance,$keywords,json_encode($clean,JSON_UNESCAPED_UNICODE),$status,$uid,$reviewer,$reviewed];
    if($id){$values[]=$id;$db->prepare('UPDATE orchard_knowledge SET species=?,title=?,symptoms=?,causes=?,guidance=?,keywords=?,sources=?,status=?,author_id=?,reviewed_by=?,reviewed_at=?,updated=CURRENT_TIMESTAMP WHERE id=?')->execute($values);}
    else{$db->prepare('INSERT INTO orchard_knowledge(species,title,symptoms,causes,guidance,keywords,sources,status,author_id,reviewed_by,reviewed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute($values);$id=(int)$db->lastInsertId();}
    adminLog($db,$uid,$old?'knowledge_update':'knowledge_create','orchard_knowledge',$id);$r=orchardRecord($db,$id);out(['ok'=>1,'record'=>orchardRow($r),'version'=>adminVersion($r)]);
}
