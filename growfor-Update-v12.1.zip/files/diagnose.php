<?php
// KI-Foto-Diagnose (optional). Wird nur von api.php eingebunden.
$ai = defined('ANTHROPIC_KEY') && ANTHROPIC_KEY !== '';
if ($a === 'diag_status') out(['ai' => $ai]);
if (!$ai) out(['error' => 'Die KI-Diagnose ist nicht aktiviert.'], 403);
if (!function_exists('curl_init')) out(['error' => 'cURL ist auf dem Server nicht verfügbar.'], 500);

$db->exec('CREATE TABLE IF NOT EXISTS diag_log(user_id INTEGER NOT NULL, ts INTEGER NOT NULL)');
$c = $db->prepare('SELECT COUNT(*) FROM diag_log WHERE user_id=? AND ts>?');
$c->execute([$uid, time() - 86400]);
if ((int)$c->fetchColumn() >= 20) out(['error' => 'Das Tageslimit von 20 Diagnosen ist erreicht.'], 429);

$note = substr((string)($in['note'] ?? ''), 0, 800);
$part = substr((string)($in['part'] ?? ''), 0, 60);
$syms = is_array($in['symptoms'] ?? null) ? implode(', ', array_map('strval', array_slice($in['symptoms'], 0, 16))) : '';
$ctx = is_array($in['ctx'] ?? null) ? json_encode($in['ctx'], JSON_UNESCAPED_UNICODE) : '{}';

$content = [];
$img = (string)($in['image'] ?? '');
if ($img !== '') {
    if (!preg_match('#^data:image/jpeg;base64,([A-Za-z0-9+/=]+)$#', $img, $m)) out(['error' => 'Das Foto hat ein ungültiges Format.'], 400);
    if (strlen($m[1]) > 5000000) out(['error' => 'Das Foto ist zu groß.'], 400);
    $content[] = ['type' => 'image', 'source' => ['type' => 'base64', 'media_type' => 'image/jpeg', 'data' => $m[1]]];
}
$content[] = ['type' => 'text', 'text' => "Bereich: $part\nSymptome: $syms\nBeschreibung: $note\nKontext (Sorte, Phase, Messwerte): $ctx"];

$system = 'Du bist ein hilfreicher Pflanzenberater für den legalen privaten Zimmeranbau in Deutschland. '
    . 'Analysiere Foto und Angaben und nenne auf Deutsch: 1) die wahrscheinlichsten Ursachen (kurz begründet), 2) konkrete Schritte zur Lösung, '
    . '3) worauf man in den nächsten Tagen achten sollte. Antworte knapp (höchstens 250 Wörter), ohne Markdown-Überschriften. '
    . 'Gib keine Hinweise zum Konsum, zum Verkauf oder zur Weitergabe. Weise kurz darauf hin, dass es eine Einschätzung und keine Fachberatung ist.';
$body = json_encode([
    'model' => defined('ANTHROPIC_MODEL') ? ANTHROPIC_MODEL : 'claude-sonnet-5-5',
    'max_tokens' => 700,
    'system' => $system,
    'messages' => [['role' => 'user', 'content' => $content]],
], JSON_UNESCAPED_UNICODE);

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $body,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 60,
    CURLOPT_HTTPHEADER => ['content-type: application/json', 'x-api-key: ' . ANTHROPIC_KEY, 'anthropic-version: 2023-06-01'],
]);
$res = curl_exec($ch);
$code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($res === false || $code === 0) out(['error' => 'Der KI-Dienst ist nicht erreichbar.'], 502);
$j = json_decode($res, true);
if ($code !== 200) {
    $msg = (is_array($j) && isset($j['error']['message'])) ? (string)$j['error']['message'] : 'Unbekannter Fehler';
    out(['error' => 'KI-Dienst: ' . $msg], 502);
}
$text = '';
foreach (($j['content'] ?? []) as $blk) {
    if (($blk['type'] ?? '') === 'text') $text .= $blk['text'];
}
if ($text === '') out(['error' => 'Die KI hat keine Antwort geliefert.'], 502);
$db->prepare('INSERT INTO diag_log(user_id,ts) VALUES(?,?)')->execute([$uid, time()]);
out(['text' => $text]);
