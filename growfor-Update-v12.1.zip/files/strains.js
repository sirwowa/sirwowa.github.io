'use strict';
/* Sorten-Datenbank: typische Richtwerte. Angaben unterscheiden sich je nach Züchter und Phänotyp, bitte mit der Samenpackung abgleichen. */
function normStrain(x){return{b:'Eigene',t:'P',gc:'Hybrid',g:'',l:'',f:[56,63],fs:0,vd:0,y:[300,500],h:[80,150],thc:'–',cbd:'–',d:2,st:1.6,fe:2,mo:2,fl:'–',tp:[],...x}}
const _R=[
['White Widow','Green House Seeds','P','Hybrid','Hybrid (ca. 60 % Sativa)','Brasilianische Sativa × südindische Indica',56,63,0,450,500,90,130,'18–20 %','<1 %',1,1.7,2,2,'Erdig, würzig, leicht süß',['Verzeiht Anfängerfehler und reagiert gut auf Topping und LST.','Sehr harzig: in der Blüte Luftfeuchte unter 50 % halten.']],
['Northern Lights','Sensi Seeds','P','Indica','Indica (ca. 90 %)','Afghani × Thai',49,56,0,500,550,80,100,'16–20 %','<1 %',1,1.3,2,3,'Süß, erdig, harzig',['Kompakt mit wenig Stretch, ideal für niedrige Zelte.','Sehr schimmelrobust, dichte Buds trotzdem gut belüften.']],
['Amnesia Haze','verschiedene Züchter','P','Sativa','Sativa (ca. 80 %)','Jamaikanische und südostasiatische Landrassen × Haze',70,84,0,450,550,130,200,'20–23 %','<1 %',3,2.5,1,3,'Zitrus, erdig, Haze',['Starker Stretch (×2–3): Veg kurz halten oder früh toppen und binden.','Eher niedrig düngen, Hazes reagieren empfindlich auf Überdüngung.','Lange Blüte: nicht zu früh ernten.']],
['OG Kush','verschiedene Züchter','P','Hybrid','Hybrid (Indica-lastig)','Chemdawg × Lemon Thai × Hindu Kush (Herkunft umstritten)',56,63,0,400,500,100,150,'19–24 %','<1 %',2,1.8,2,2,'Kiefer, Zitrus, erdig',['Gute Luftzirkulation nötig, die Buds werden dicht.','Reagiert gut auf Entlaubung und Lollipopping.']],
['Gorilla Glue #4','GG Strains','P','Hybrid','Hybrid','Chem\'s Sister × Sour Dubb × Chocolate Diesel',56,70,0,500,600,100,150,'25–30 %','<1 %',2,1.7,3,2,'Erdig, Kiefer, Diesel',['Sehr harzig und hungrig: ab Blütewoche 3 genug Phosphor und Kalium.','Äste werden schwer, früh stützen.']],
['Girl Scout Cookies','verschiedene Züchter','P','Hybrid','Hybrid (Indica-lastig)','OG Kush × Durban Poison',56,63,0,400,500,100,150,'19–25 %','<1 %',2,1.8,2,2,'Süß, minzig, erdig',['Wächst buschig: Topping und LST für gleichmäßige Colas.','Kühle Nächte in der späten Blüte fördern Farbe und Aroma.']],
['Blue Dream','verschiedene Züchter','P','Hybrid','Hybrid (Sativa-lastig)','Blueberry × Haze',63,70,0,500,600,120,180,'17–24 %','<1 %',1,2,2,3,'Beerig, süß',['Wüchsig und verzeihend, braucht aber Platz nach oben.','SCROG nutzt die Höhe gut aus.']],
['Skunk #1','Sensi Seeds','P','Hybrid','Hybrid','Colombian × Mexican × Afghani',56,63,0,450,550,80,120,'15–18 %','<1 %',1,1.5,2,3,'Skunky, erdig, süß',['Robust und anfängerfreundlich.','Riecht stark: Aktivkohlefilter einplanen.']],
['AK-47','Serious Seeds','P','Hybrid','Hybrid (Sativa-lastig)','Colombian × Mexican × Thai × Afghani',53,63,0,400,500,90,120,'19–20 %','<1 %',1,1.6,2,3,'Erdig, süß, würzig',['Verzeiht Fehler und wird früh reif.','Ab Tag 53 der Blüte die Trichome regelmäßig prüfen.']],
['Jack Herer','Sensi Seeds','P','Sativa','Sativa-lastig','Haze × Northern Lights #5 × Shiva Skunk',56,70,0,450,500,120,180,'18–23 %','<1 %',2,2,2,3,'Kiefer, würzig, Zitrus',['Wächst hoch: früh toppen oder per LST bändigen.','Hohe Luftfeuchte in der Blüte vermeiden.']],
['Super Lemon Haze','Green House Seeds','P','Sativa','Sativa-lastig (ca. 75 %)','Lemon Skunk × Super Silver Haze',63,70,0,500,600,120,180,'20–25 %','<1 %',2,2.5,2,3,'Zitrone, süß',['Stretch ×2–3 einplanen, Lampe flexibel hängen.','Kühlere Spätblüte (20–22 °C) schützt das Zitrus-Aroma.']],
['Critical+','Dinafem','P','Indica','Indica-lastig','Big Bud × Skunk #1',56,63,0,500,600,80,120,'18–20 %','<1 %',1,1.4,2,2,'Süß, erdig',['Sehr ertragreich und kompakt, Äste früh stützen.']],
['Blueberry','DJ Short','P','Indica','Indica-lastig (ca. 80 %)','Purple Thai × Afghani (Angaben variieren)',56,63,0,400,500,90,120,'17–20 %','<1 %',2,1.5,2,2,'Beerig, süß',['Kühle Nächte (16–18 °C) in der Spätblüte bringen blau-violette Färbung.']],
['Wedding Cake','verschiedene Züchter','P','Indica','Indica-lastig','Triangle Kush × Animal Mints',56,63,0,400,500,90,140,'22–27 %','<1 %',2,1.5,2,2,'Vanille, süß, erdig',['Dichte Buds: entlauben und ab Blütewoche 4 Luftfeuchte unter 45 % halten.']],
['Granddaddy Purple','verschiedene Züchter','P','Indica','Indica (ca. 70 %)','Purple Urkle × Big Bud',56,63,0,400,500,90,120,'17–23 %','<1 %',2,1.5,2,3,'Traube, beerig',['Violette Färbung kommt durch kühle Nächte, nicht durch Dünger.']],
['Zkittlez','verschiedene Züchter','P','Indica','Indica-lastig','Grape Ape × Grapefruit',56,63,0,450,500,90,130,'20–23 %','<1 %',2,1.5,2,2,'Fruchtig, süß',['Sehr terpenreich: nicht zu warm trocknen (18–20 °C).']],
['Sour Diesel','verschiedene Züchter','P','Sativa','Sativa-lastig','Chemdawg 91 × Super Skunk (Herkunft umstritten)',70,77,0,450,500,130,190,'19–25 %','<1 %',3,2.5,2,2,'Diesel, Zitrus',['Hoher Stretch und lange Blüte: Platz und Geduld einplanen.','LST oder SCROG halten sie im Zelt.']]];
function _A(n,gc,fs,fmin,fmax,ymin,ymax,hmin,hmax,thc,d,fe,fl,tip){return[n+' Auto','Royal Queen Seeds u. a.','A',gc,gc+', Autoflower','Autoflower-Version (mit Ruderalis gekreuzt), Herkunft siehe '+n,fmin,fmax,fs,ymin,ymax,hmin,hmax,thc,'<1 %',d,1.5,fe,2,fl,[tip,'Lichtzyklus durchgehend 18/6 (bis 20/4), nicht umstellen.','Direkt in den Endtopf (ca. 11 L) säen, Umtopfen bremst Autos aus.','Nur LST und leichte Entlaubung, kein Topping nach Tag 25.']]}
_R.push(_A('White Widow','Hybrid',25,50,60,350,450,70,110,'15–19 %',1,2,'Erdig, würzig','Sehr einsteigerfreundlich.'),
_A('Northern Lights','Indica',25,45,55,350,450,60,100,'15–18 %',1,2,'Süß, erdig','Kompakt und robust.'),
_A('Gorilla Glue','Hybrid',28,50,60,400,500,70,110,'20–24 %',2,3,'Erdig, Diesel','Hungrig: Dünger langsam steigern, Äste stützen.'),
_A('Blue Dream','Hybrid',28,50,60,350,450,80,120,'16–20 %',1,2,'Beerig, süß','Wüchsig, braucht etwas Höhe.'),
_A('Girl Scout Cookies','Hybrid',28,50,60,350,450,70,110,'18–22 %',2,2,'Süß, minzig','Buschig, LST bringt gleichmäßige Buds.'),
_A('Amnesia Haze','Sativa',28,55,65,350,450,90,130,'15–20 %',2,1,'Zitrus, erdig','Empfindlich bei Dünger, lieber etwas weniger geben.'),
_A('Critical+','Indica',25,45,55,400,500,70,100,'15–18 %',1,2,'Süß, erdig','Sehr ertragreich für eine Auto.'),
_A('Blueberry','Indica',25,45,55,300,400,60,90,'14–18 %',2,2,'Beerig, süß','Kompakt, für kleine Zelte geeignet.'),
_A('Zkittlez','Indica',28,50,60,350,450,70,100,'18–22 %',2,2,'Fruchtig, süß','Terpenreich, vorsichtig trocknen.'),
_A('Jack Herer','Sativa',28,50,60,350,450,80,130,'16–20 %',2,2,'Kiefer, würzig','Etwas Höhe einplanen.'),
_A('OG Kush','Hybrid',28,50,60,350,450,70,110,'17–21 %',2,2,'Kiefer, Zitrus','Gute Luftzirkulation in der Blüte.'),
_A('Wedding Cake','Indica',28,50,60,350,450,70,110,'18–22 %',2,2,'Vanille, süß','Dichte Buds: früh entlauben.'),
_A('AK-47','Hybrid',25,45,55,350,450,70,110,'15–19 %',1,2,'Erdig, süß','Verzeiht Fehler, schnell fertig.'));
_R.unshift(
_A('Lemon Cherry Gelato','Hybrid',28,45,56,400,550,70,110,'22–26 %',2,2,'Zitrone, Kirsche, süß','Sehr dichte, harzige Buds: ab Blütewoche 3 Luftfeuchte unter 45 % halten und leicht entlauben.'),
_A('Bubble Kush','Indica',28,49,56,350,450,60,90,'16–22 %',1,2,'Süß, Kaugummi, erdig','Kompakt und robust, ideal für kleine Zelte. Dichte Buds brauchen gute Luftzirkulation.'));
_R[0][5]='Sunset Sherbet × Girl Scout Cookies (Angaben variieren), Autoflower';_R[0][4]='Hybrid, Autoflower';_R[0][14]='<1 %';_R[0].push&&0;
_R[0][20].splice(1,0,'Aroma schützen: kühl und langsam trocknen (18–20 °C), dann gut curen.');
_R[1][5]='Bubble Gum × OG Kush (Angaben variieren), Autoflower';_R[1][4]='Indica-lastig, Autoflower';_R[1][16]=1.4;
const SPECIES=_R.map(r=>normStrain({n:r[0],b:r[1],t:r[2],gc:r[3],g:r[4],l:r[5],f:[r[6],r[7]],fs:r[8],y:[r[9],r[10]],h:[r[11],r[12]],thc:r[13],cbd:r[14],d:r[15],st:r[16],fe:r[17],mo:r[18],fl:r[19],tp:r[20]}));
