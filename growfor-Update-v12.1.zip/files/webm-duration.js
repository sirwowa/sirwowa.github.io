/* Add Duration to seek-head-free MediaRecorder WebM, leaving other layouts intact. */
'use strict';
window.GrowingWebMDuration=async function(blob,frameMs,activeMs){
 if(!blob.type.includes('webm'))return blob;
 try{
  const bytes=new Uint8Array(await blob.arrayBuffer());
  function vint(pos,id=false){if(pos>=bytes.length)throw Error();let len=1,mask=128;while(len<=8&&!(bytes[pos]&mask)){len++;mask>>=1}if(len>8||pos+len>bytes.length||id&&len>4)throw Error();let value=id?bytes[pos]:bytes[pos]&(mask-1),unknown=!id&&value===mask-1,hex=bytes[pos].toString(16).padStart(2,'0');for(let i=1;i<len;i++){value=value*256+bytes[pos+i];unknown=unknown&&bytes[pos+i]===255;hex+=bytes[pos+i].toString(16).padStart(2,'0')}if(!unknown&&!Number.isSafeInteger(value))throw Error();return {len,value,unknown,hex}}
  function element(pos,end){const id=vint(pos,true),size=vint(pos+id.len),data=pos+id.len+size.len,stop=size.unknown?end:data+size.value;if(stop>end||stop<data)throw Error();return {id:id.hex,start:pos,data,end:stop,unknown:size.unknown,sizeStart:pos+id.len,sizeLen:size.len}}
  function children(from,to){const list=[];for(let pos=from;pos<to;){const e=element(pos,to);list.push(e);if(list.length>1000000||e.end<=pos)throw Error();pos=e.end}return list}
  function uint(e){let n=0;for(let i=e.data;i<e.end;i++)n=n*256+bytes[i];return n}
  function sizeBytes(value){let len=1;while(value>=2**(7*len)-1)len++;if(len>7)throw Error();let n=BigInt(value)|(1n<<BigInt(7*len)),out=new Uint8Array(len);for(let i=len-1;i>=0;i--){out[i]=Number(n&255n);n>>=8n}return out}
  const roots=children(0,bytes.length),segment=roots.find(e=>e.id==='18538067');if(!segment)return blob;const parts=children(segment.data,segment.end),info=parts.find(e=>e.id==='1549a966');if(!info||parts.some(e=>e.id==='114d9b74'||e.id==='1c53bb6b'||e.id==='bf'))return blob;const fields=children(info.data,info.end);if(fields.some(e=>e.id==='4489'||e.id==='bf'))return blob;const scale=fields.find(e=>e.id==='2ad7b1'),timeScale=scale?uint(scale):1000000;
  let latest=0;
  function block(e,base){const track=vint(e.data),pos=e.data+track.len;if(pos+2>=e.end)return;let delta=(bytes[pos]<<8)|bytes[pos+1];if(delta&32768)delta-=65536;latest=Math.max(latest,(base+delta)*timeScale/1000000)}
  // Unknown-size clusters can contain the next cluster header in this bounded walk.
  function walkCluster(e){let base=0;for(const child of children(e.data,e.end)){if(['114d9b74','1c53bb6b','bf'].includes(child.id))throw Error();if(child.id==='e7')base=uint(child);else if(child.id==='a3')block(child,base);else if(child.id==='a0'){for(const b of children(child.data,child.end))if(b.id==='a1')block(b,base)}else if(child.id==='1f43b675')walkCluster(child)}}
  for(const p of parts)if(p.id==='1f43b675')walkCluster(p);
  const duration=Math.max(latest+frameMs,activeMs);if(!Number.isFinite(duration)||duration<=0||!timeScale)return blob;
  const value=new Uint8Array(8);new DataView(value.buffer).setFloat64(0,duration*1000000/timeScale,false);
  const addition=new Uint8Array([0x44,0x89,0x88,...value]),newInfoSize=sizeBytes(info.end-info.data+addition.length),delta=addition.length+newInfoSize.length-info.sizeLen;
  const infoBlob=new Blob([bytes.slice(info.start,info.sizeStart),newInfoSize,bytes.slice(info.data,info.end),addition]);
  const segmentHeader=segment.unknown?bytes.slice(segment.start,segment.data):new Blob([bytes.slice(segment.start,segment.sizeStart),sizeBytes(segment.end-segment.data+delta)]);
  return new Blob([bytes.slice(0,segment.start),segmentHeader,bytes.slice(segment.data,info.start),infoBlob,bytes.slice(info.end,segment.end),bytes.slice(segment.end)],{type:blob.type});
 }catch{return blob}
};
