<?php
// Private fixed-account setup; called by api.php. No plaintext passwords stored.
function publicAccount(array $u): array {
    return ['id'=>(int)$u['id'],'email'=>$u['email'],'name'=>$u['name'],
        'login_name'=>$u['login_name'],'role'=>$u['role'],
        'must_change_password'=>(bool)$u['must_change_password']];
}
function initializeAccounts(PDO $db): void {
    $db->exec('BEGIN IMMEDIATE');
    try {
        $columns=array_column($db->query('PRAGMA table_info(users)')->fetchAll(),'name');
        foreach (["login_name TEXT DEFAULT ''", "role TEXT DEFAULT 'tester'", "must_change_password INTEGER NOT NULL DEFAULT 1", "disabled INTEGER NOT NULL DEFAULT 0", "auth_version INTEGER NOT NULL DEFAULT 0"] as $column) {
            $name=explode(' ',$column)[0];
            if(!in_array($name,$columns))$db->exec('ALTER TABLE users ADD COLUMN '.$column);
        }
        if((int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn()===0){
            $accounts=[['waldemar@stiwing.de','Waldemar','admin','admin']];
            for($i=1;$i<MAX_USERS;$i++)$accounts[]=['test'.$i.'@users.invalid','Test'.$i,'test'.$i,'tester'];
            $insert=$db->prepare('INSERT INTO users(email,pass,name,login_name,role,must_change_password) VALUES(?,?,?,?,?,1)');
            foreach($accounts as [$email,$display,$login,$role]){
                $insert->execute([$email,'$2y$12$tqu7T5LA3kybXnXoIWGVZe93U32e1W5XAeVjfwWqvHpJQ41bUykUe',$display,$login,$role]);
            }
        }
        $db->exec('COMMIT');
    }catch(Throwable $e){$db->exec('ROLLBACK');throw $e;}
}
