# Growing v11 – Administrator-Erweiterung

Stand: 5. November 2026. Kein Update wurde auf deinem ALL-INKL-Server ausgeführt.

## Bestehende Installation aktualisieren

1. Den kompletten bestehenden Ordner einschließlich `data/` und deiner `config.php` sichern.
2. Nur die Dateien aus `growing/` in deinen App-Ordner hochladen. **Vorhandenes `data/` und eigene `config.php` nicht ersetzen oder löschen.** Versteckte `.htaccess`-Dateien mit übertragen.
3. Die App online neu öffnen, gegebenenfalls vollständig schließen und erneut öffnen. Der Offline-Cache wird aktualisiert. Erst nach erfolgreichem Online-Aufruf wieder offline verwenden.
4. Als Admin anmelden, Profil → Administration. Links findest du „Samenkatalog“, „Begleiter“ und „App-Einstellungen“.

Die SQLite-Erweiterungen werden automatisch angelegt. Es werden keine bestehenden Passwörter zurückgesetzt. Wenn du dein Adminpasswort vergessen hast, brauchst du einen gesonderten, über deinen Hostingzugang abgesicherten Wiederherstellungsweg.

## Samenkatalog

- Excel-Vorlage im Adminbereich herunterladen. Unterstützt wird `.xlsx`, erstes Tabellenblatt, maximal 2 MB und 1000 Datenzeilen. Entpackte Arbeitsmappen: maximal 12 MB / 300 Einträge.
- Spalten: `name` (Pflicht), `breeder`, `sku`, `stock`, `unit_price`, `source_url`, `active`. Bestand ist ganzzahlig; Preise in Euro. Aktiv: Excel-Wahrheitswert oder ja/nein, true/false, 1/0. Leere optionale Zahlen werden 0, leeres Aktiv-Feld wird Ja.
- Formeln und Makros werden abgelehnt. Excel-Dateien vorab als feste Werte speichern. Alte `.xls`- und `.xlsm`-Dateien werden nicht unterstützt.
- „Import prüfen“ zeigt eine serverseitig geprüfte Vorschau. Danach „Import speichern“. Ohne Speichern ändert sich nichts.
- Duplikate: zuerst Artikelnummer; ohne Artikelnummer Name + Züchter. Vergleich bei ASCII-Buchstaben unabhängig von Groß-/Kleinschreibung; nicht-ASCII-Schreibvarianten bitte vereinheitlichen. Doppelte Zeilen innerhalb der Datei werden abgelehnt.
- Bestehende Einträge entweder überspringen oder vollständig mit den importierten Werten aktualisieren. Andere Einträge bleiben erhalten. Kein automatisches Abrufen von Quellenlinks oder Amazon-Preisen.
- Einzelne Sorten erstellen/bearbeiten/deaktivieren. Kein endgültiges Löschen im Katalogeditor. Deaktivierte Sorten bleiben im Adminbereich erhalten. Der gemeinsame Katalog und seine Bestands-/Preisangaben sind für angemeldete Konten verfügbar; Admin-Änderungen sind protokolliert.
- Aktive Namen erscheinen bei der Tagebuchanlage und im Setup als Vorschläge. Bestehende Tagebücher werden nicht umbenannt. Katalogdaten erzeugen keine Anbauparameter oder Dosierungsvorgaben.

## Begleiter

Sour, Flora und Luna sind im Katalog als Grundprofile bearbeitbar. Zusätzlich lassen sich bis zu insgesamt 40 Profile erstellen. Name, Kurzbeschreibung, aktive Sichtbarkeit, Gestaltung (Sour/Flora/Luna/Purple Punch/Mango Sweet) und App-Fähigkeiten sind einstellbar.

Fähigkeiten: Tagebuch-Assistent, Beobachtungsnotizen, persönliche Erinnerungen, Bedienhilfe/Tour, Kostenübersicht und Obst-/Gemüsebibliothek. Die Auswahl wird im Begleiterteam als funktionsfähige Aktionsauswahl angezeigt. Sie ändert keine Kontoberechtigungen und sperrt keine anderen App-Menüs. Es ist keine KI-Trainingsfunktion und kein freier Programmcode-Editor. Neue eigene Illustrationen/Animationen hochladen wird in dieser Version nicht angeboten.

Die Beschreibung ist sichtbarer Profiltext, kein Systemprompt. Eigene redaktionelle Inhalte für die separate Obst-/Gemüsebibliothek bleiben unter „Obst- & Gemüsewissen“ verwaltbar. Namensfelder in „App-Einstellungen“ sind Grundvorgaben bis zum ersten Speichern des Begleiterkatalogs; danach gelten dessen Namen.

## Weitere Verwaltung

App-Name, Slogan, Akzentfarbe, Designvorgabe und Zusatzmenüs; Konten/Rollen/Sperren; Tagebücher, Einträge und Kontoeinstellungen; Nachrichten; Medien; Gerätezugänge; Papierkorb; Adminprotokoll und Datenexport sind vorhanden. Nicht jede interne Programmregel ist über Formulare veränderbar. Servergeheimnisse und Hostingzugänge gehören nicht in Inhaltsfelder.

Verwaltungsänderungen und Imports benötigen Internet. Bereits geladene veröffentlichte Kataloge können offline gelesen werden; keine offline Warteschlange für Adminänderungen. Gleichzeitige Änderungen werden mit einem Versionskonflikt abgelehnt, statt andere Änderungen still zu überschreiben. Der JSON-Katalogexport ist eine Lesesicherung, kein zusätzlicher JSON-Importweg. Für ein vollständiges Backup `data/` sichern.

## GoPro-Testbrücke im Paket

Die enthaltene optionale Android-Testapp unterstützt Android 8 oder neuer und ist für HERO8 Black vorgesehen. Sie wurde kompiliert und automatisiert geprüft, **nicht mit deiner Kamera oder deinem Smartphone getestet**. Nicht auf die Webhostingfläche hochladen; separat auf Android installieren. Keine offizielle GoPro-App.

Im Zeitrafferbereich „GoPro“ öffnen, für dein Tagebuch einen kurzlebigen Gerätecode erzeugen und in Growing Bridge einfügen. Den Code vertraulich behandeln. Die Web-App muss öffentlich per HTTPS erreichbar sein. Android manuell mit dem GoPro-WLAN verbinden; GoPro eingeschaltet, WLAN aktiv. Die Bridge liest JPEGs, betätigt keinen Auslöser und ändert/löscht nichts auf der Kamera. Aufnahmeintervall daher an der Kamera einstellen; für einen allgemeinen längeren Verlauf ist ein Startwert von 5–10 Minuten praktikabel. Stromversorgung und Speicher beachten. Abfrage alle 15 Sekunden ist ein Übertragungsintervall, kein Aufnahmeintervall.

Sofortübertragung braucht gleichzeitig Internet über Mobilfunk und die ausdrücklich aktivierte Mobilfunkoption. Ansonsten erfolgt Übertragung nach Rückkehr ins Internet, solange die Bridge läuft. Private Warteschlange: höchstens 100 Bilder/50 MB; Aufnahme im Hintergrund wird durch Android/Kamerafirmware begrenzt. Die GoPro kann Downloads während einer Aufnahme verweigern; dann werden Bilder erst später übertragen. Keine Garantie für lückenlosen Dauerbetrieb.

Android-Quellcode liegt separat bei. Build mit JDK 17+ und Android SDK 35 über Gradle-Wrapper. Eigene Release-Signierung über GROWING_KEYSTORE und GROWING_KEY_PASSWORD, Alias growing. Private Signaturschlüssel sind nicht im Download. Eigene neu signierte Builds können die mitgelieferte APK nicht nahtlos aktualisieren. Vor Deinstallation Warteschlange übertragen.
