# Growing v8 – Adminbereich

Aktueller Stand: 5. November 2026. Diese Hinweise ergänzen v7; die drei Begleiter, Eingabestufen und gemeinsamen Preisvorgaben bleiben erhalten.

## Öffnen

Mit deinem bestehenden Adminzugang anmelden. Unter Mehr / Profil erscheint „Adminbereich öffnen“. Ein Testkonto sieht diese Schaltfläche nicht und hat auch über direkte API-Aufrufe keinen Zugriff. Die Verwaltung benötigt eine Onlineverbindung und eine gültige Serversitzung. Adminaktionen werden nicht im Offline-Speicher vorgemerkt.

## Funktionsumfang

- Übersicht: Anzahl der sechs Konten, Tagebücher, Einträge, Unterhaltungen und archivierten Datensätze; App-/PHP-/SQLite-Version und Größe der SQLite-Hauptdatei.
- Konten: Anzeigename, Anmeldename, E-Mail, Rolle und Sperrstatus bearbeiten. Sechs bestehende Konten bleiben reserviert; keine offene Registrierung oder zusätzlichen Konten. Eigener Adminzugang kann nicht gesperrt oder herabgestuft werden.
- Passwort zurücksetzen: Für andere Konten wird ein zufälliges Übergangspasswort erzeugt, das du persönlich weitergibst. Die Person muss beim nächsten Login ein neues Passwort wählen. Alte Passwörter sind nicht lesbar. Das eigene Passwort wird im normalen Profil geändert.
- Daten: Servergespeicherte Tagebücher, Einträge, Kontoeinstellungen und eigene Datensätze aller Konten suchen, nach Konto filtern und bearbeiten. Besitzer, Autor, Zuordnung, Datum und Tagebuch-Freigaben sind bearbeitbar. Einfache Datenfelder haben Eingabefelder; über „Alle Daten bearbeiten (JSON)“ sind auch verschachtelte Einstellungen, Inventar, Belege und Erinnerungen zugänglich. Gültiges Objektformat erhalten. Es werden keine Fachinhalte automatisch erzeugt.
- Papierkorb: Tagebücher einschließlich ihrer Einträge, Freigaben und Aktivität sowie einzelne Einträge und eigene Datensätze archivieren und mit ihren ursprünglichen Kennungen wiederherstellen. Wiederherstellung überschreibt keine vorhandenen Datensätze. Archivierte Daten werden nicht endgültig gelöscht.
- Nachrichten: vorhandenen privaten Testfeedback-Bereich öffnen, Unterhaltungen einsehen und antworten. Nachrichten werden nicht nachträglich umgeschrieben.
- Protokoll: Im Adminbereich durchgeführte Datenänderungen, Kontoverwaltung, Passwort-Resets, Archivierungen, Wiederherstellungen und Exporte einsehen. Keine Passwörter oder Reset-Passwörter im Protokoll.
- Export: JSON-Datei mit App-Daten aller Konten einschließlich Nachrichten, Protokoll und Papierkorb herunterladen. Vorhandene Communitytabellen sind enthalten. Keine Passwort-Hashes, Sitzungsschlüssel, Server-Konfiguration oder geheimen API-Schlüssel aus config.php. Kein vollständiges Server-Backup und kein automatischer Komplettimport. Für vollständige Wiederherstellung App-Verzeichnis, data/ und eigene Konfiguration per FTP privat sichern.

Statische Programmdateien, eingebauter Ausgangskatalog und Server-Konfiguration werden nicht über den Adminbereich bearbeitet. Die vorhandene Community ist weiterhin standardmäßig ausgeschaltet; die Verwaltung aktiviert sie nicht. Cannabis-spezifische Diagnosen, Behandlungsempfehlungen und Anbauanweisungen wurden nicht hinzugefügt.

## Schutz vor Fehlbedienung und unberechtigtem Zugriff

Adminrollen werden auf dem Server geprüft. Schreibzugriffe benötigen Sitzungstoken und Anfragekennung. Mehrfaches Senden derselben Anfrage erzeugt keine zweite Änderung. Veraltete Admin-Bearbeitungsstände werden abgelehnt; der Formularentwurf bleibt erhalten und kann separat heruntergeladen werden. Serverfassung neu laden und anschließend bewusst vergleichen.

Kontoverwaltungsänderungen und Passwort-Resets machen andere bestehende Serversitzungen des betroffenen Kontos ungültig. Eine Kontosperre verhindert neue Serverzugriffe, löscht jedoch keine bereits auf Geräten gespeicherten Offline-Daten. Noch nicht synchronisierte Änderungen bleiben auf dem jeweiligen Gerät, bis die Person sich wieder zulässig anmeldet. Die Testkonten erhalten im Profil einen Hinweis auf die Einsichts- und Bearbeitungsrechte des Administrators.

Das Änderungsprotokoll ist ein App-Protokoll und kein manipulationssicheres externes Audit. Nutzer mit direktem FTP-/Datenbankzugang können Serverdateien und Daten unabhängig von der App ändern. Auch normale Tagebucheingaben und deren bestehende Prognosefunktionen sind kein Gegenstand einer fachlichen Validierung.

## Update bei ALL-INKL

1. Vorher vollständigen App-Ordner einschließlich data/ und eigener config.php privat sichern.
2. AES-verschlüsselte ZIP lokal z.B. mit 7-Zip entpacken. Inhalt von growing/ ins vorhandene App-Verzeichnis übertragen; bisheriger Verzeichnisname darf bleiben.
3. Bestehenden data/-Ordner und eigene config.php unbedingt behalten. Keine Datenbank durch eine leere Datei ersetzen. Das Paket enthält keine Nutzerdatenbank.
4. Alle übrigen Dateien gemeinsam aktualisieren, insbesondere accounts.php, api.php, admin.php, admin.js, sync.php, offline.js, sw.js, index.html und .htaccess. Die Datenbank wird beim nächsten API-Aufruf automatisch um Sperrstatus und Sitzungsprüfung erweitert; bestehende Konten, Passwort-Hashes und App-Daten bleiben erhalten.
5. App-Tabs schließen, online neu öffnen, anmelden. Ansichten unter „Offline & Synchronisierung“ erneut online vorbereiten.
6. Auf dem echten Hosting prüfen: HTTPS, PHP 8+, PDO_SQLite, Schreibzugriff auf data/ und Apache-.htaccess-Schutz. data/weedys.sqlite und der direkte Aufruf von admin.php müssen blockiert sein. Bei einem Update werden die bestehenden Passwörter nicht zurückgesetzt.

Noch nicht eingerichtete Konten besitzen weiterhin die ursprünglich vereinbarten schwachen Startpasswörter. Sie sollten zeitnah eingerichtet oder durch den Admin gesperrt bzw. mit einem neuen Übergangspasswort versehen werden. Diese Version wurde lokal geprüft; eine Installation auf deinem ALL-INKL-Server ist damit nicht erfolgt.
