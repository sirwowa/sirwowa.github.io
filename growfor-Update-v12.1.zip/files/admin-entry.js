/* Separate online administration entrance; permissions remain server enforced. */
'use strict';
(()=>{
 let entered=null,pending=false;const prior=GrowingAdminShell.renderView;
 GrowingAdminShell.renderView=content=>S.user&&S.user.role!=='admin'?'<main class="wrap"><section class="card"><h1>growfor Administration</h1><p>Diese Seite ist ausschließlich für Administratoren.</p><a href="./">Zur App</a><button class="btn alt" id="portal-logout">Abmelden</button></section></main>':prior(content);
 async function update(){document.title='growfor Administration';if(!S.user){entered=null;document.querySelector('#auth')?.closest('.card')?.setAttribute('aria-label','Admin-Anmeldung');return}document.getElementById('portal-logout')?.addEventListener('click',async()=>{await api('logout');location.reload()},{once:true});if(S.user.role!=='admin'||S.user.must_change_password||entered===S.user.id||pending)return;pending=true;try{await GrowingAdminShell.open();entered=S.user.id;if(!document.querySelector('.cms-shell'))render({resetTop:true})}catch(e){S.err=e.message}finally{pending=false}}
 addEventListener('growing:render',update);document.addEventListener('click',e=>{if(e.target.closest('#cms-return-app')){e.preventDefault();e.stopImmediatePropagation();location.href=new URL('./',document.baseURI).href}},true);update();
})();
