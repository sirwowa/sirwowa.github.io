# Growing v10 – CMS-Backend und Kamera/Zeitraffer

Aktueller Stand: 5. November 2026. Ergänzt v9 um ein CMS-artiges Verwaltungsbackend und allgemeine Foto-/Zeitrafferfunktionen. Vorhandene Begleiter, Eingabestufen, Preisvorgaben und Obst-/Gemüsebibliothek bleiben erhalten.

## Adminbereich wie ein CMS bedienen

Als Admin unter Mehr / Profil → „Adminbereich öffnen“ anmelden. Links findest du jetzt eine feste Seitenleiste mit Dashboard, Konten & Rollen, Tagebüchern, Einträgen, Kontoeinstellungen, eigenen Datensätzen, Medien & Zeitraffer, Obst-/Gemüsewissen, Nachrichten, Papierkorb, Adminprotokoll und Export. Die jeweils gewählte Seite ist markiert. „App öffnen“ führt zur normalen Anwendung zurück.

Auf Android und anderen kleinen Bildschirmen öffnet „Menü“ eine einklappbare Seitenleiste. Die übrige Seite ist währenddessen nicht bedienbar; Escape bzw. die Schließen-Schaltfläche schließen das Menü. Browser-Zurück stellt die Verwaltungsseiten und Datensatzeditoren anhand ihrer Kennungen wieder her, ohne Formulardaten im Verlauf zu speichern. Vor dem Verwerfen ungespeicherter Änderungen wird gefragt.

Das Backend gehört direkt zu Growing. Eine WordPress-/Joomla-Installation, deren Erweiterungen oder Themes werden dafür nicht benötigt und nicht mitinstalliert. Die eigentlichen Verwaltungsfunktionen aus v8 bleiben bestehen; geheime Servereinstellungen sind weiterhin nicht im Web-Backend editierbar.

## Android direkt aufnehmen lassen

1. App über HTTPS in einem aktuellen Chrome für Android öffnen und anmelden.
2. Im Tagebuch unter Mehr → „Kamera & Zeitraffer“ oder im Profil den Zeitraffer öffnen. Als Admin kannst du zusätzlich über „Medien & Zeitraffer“ auf die Serien aller Konten zugreifen.
3. Ein Tagebuch wählen und „Android-Kamera öffnen“ drücken. Kamerazugriff erlauben. Audio wird nicht aufgenommen.
4. Einzelfoto aufnehmen oder Intervall (5 bis 86400 Sekunden) und maximale Fotozahl dieser Sitzung (1 bis 1000, Vorgabe 120) einstellen. Die Automatik nimmt das erste Foto sofort auf und danach weitere Bilder im eingestellten Abstand. Verzögerte Zeitschritte werden übersprungen, nicht in einer nachträglichen Serie aufgeholt.
5. App sichtbar und Bildschirm aktiv lassen. Soweit der Browser es unterstützt, wird eine Bildschirm-Wachhaltesperre angefragt. Beim Ausblenden, Sperren, Verlassen der Ansicht oder Erreichen der Seriengrenze wird die Automatik gestoppt. Bei ausgeschalteter Kamera musst du zum Fortsetzen wieder „Kamera aktivieren“ und die Serie erneut starten.

Dies ist keine native Android-Hintergrundkamera und kein unbeaufsichtigt garantierter Langzeitdienst. Das Gerät darf die App weiterhin beenden. Bei fehlgeschlagenem lokalem Speichern bleibt das letzte Bild nur vorübergehend im Arbeitsspeicher; über „Letztes Foto herunterladen“ sichern, bevor du die Kamera schließt.

## GoPro HERO8 Black

Der unterstützte Ablauf ist ein Import von Bilddateien, keine direkte WLAN-/Bluetooth-Steuerung der HERO8:

1. Mit der Kamera eine Zeitraffer-Fotoserie aufnehmen und die Originalbilder behalten. Verwende ein im jeweiligen Kameramodus verfügbares Intervall.
2. Die JPEG-Dateien auf Android übertragen, beispielsweise aus Quik exportieren oder über die Speicherkarte kopieren. Die Web-App überwacht Quik nicht automatisch und liest nicht eigenständig dessen privaten Speicher aus.
3. Im Zeitraffer „GoPro HERO8: Fotos importieren“ öffnen und bis zu 300 JPEG-/PNG-/WebP-Dateien pro Durchgang wählen.
4. Den tatsächlichen Beginn der Serie in deiner lokalen Zeit und das verwendete Kamera-Intervall eingeben. Der Import erlaubt Schritte ab 0,5 Sekunden. Dateinamen werden natürlich sortiert, etwa GOPR1, GOPR2, GOPR10. Der Name muss deshalb die gewünschte Reihenfolge widerspiegeln.
5. Import starten. Zeitpunkte werden aus deinen Angaben zugeordnet und in der App entsprechend markiert. EXIF-Aufnahmezeit wird nicht ausgelesen. Bei Teilfehlern bleiben bereits angenommene Fotos erhalten. Gleiche vorbereitete JPEG-Daten mit identischem Zeitpunkt werden bei erneutem Import desselben Tagebuchs nicht dupliziert.

Fertige GoPro-MP4-Videos, GPR/RAW und HEIC werden nicht in Fotos umgewandelt. Die Quik-Menüs und der reale HERO8-/Android-Transfer wurden hier nicht am Gerät getestet. Die Softwaretests verwenden künstliche Fotodateien und eine simulierte Kamera.

## Allgemeine fotografische Intervallwerte

- Wolken: etwa 5–10 Sekunden als Startwert.
- Sehr langsam veränderliche Motive: etwa 5–30 Minuten als Startwert.
- Eine kurze Testserie aufnehmen und den sichtbaren Bildunterschied prüfen; es gibt kein für alle Motive richtiges Intervall. Dies sind keine pflanzenspezifischen Empfehlungen.
- Beispiel: 24 Stunden, ein Foto alle 5 Minuten → ungefähr 288 Bilder. Bei einer Ziel-Bildrate von 25 Bildern/Sekunde ergibt das etwa 11,5 Sekunden Video.

Der eingebaute Planer berechnet Fotozahl und geschätzte Videolänge. Seine Speicherangabe ist ausdrücklich eine Beispielrechnung mit 200 KB/Bild, keine Vorhersage deiner Kamera-Dateigröße. Er weist auf eine Überschreitung der Seriengrenze hin.

## Vorschau, Export und Grenzen

Die Serie hat eine Einzelbildvorschau mit Bildregler, keine neue Raster-Fotogalerie. Sortierung nach Aufnahmezeitpunkt und danach Kennung. Smartphone-Zeitpunkte stammen von der Geräteuhr; Importzeitpunkte sind manuell zugeordnet.

Beim Videoexport Bereich, Schrittweite und Ziel-Bildrate wählen. Maximal 300 ausgewählte Fotos pro Export halten den Speicherverbrauch im Browser begrenzt. Bei langen Serien automatisch vorgeschlagene Schrittweite nutzen oder mehrere Ausschnitte exportieren. Bilder werden für den Export vorbereitet; danach erscheint „Video herunterladen“.

Der Browser wählt einen unterstützten Encoder, häufig WebM/VP9. MP4 ist nicht garantiert. Ausgabe 1280 × 720, Seitenverhältnisse bleiben erhalten, nötigenfalls mit schwarzen Rändern. Das Browser-Timing kann von der rechnerischen Ziellänge abweichen. Bei unterstütztem WebM-Aufbau wird fehlende Laufzeit-Metadaten ergänzt. Kein FFmpeg und keine Videokonvertierung auf dem ALL-INKL-Server erforderlich. Beim Ausblenden der App oder Verlassen der Seite wird der Export abgebrochen.

Alle importierten und aufgenommenen App-Fotos werden als JPEG auf maximal 1280 Pixel Kantenlänge verkleinert; Originale separat behalten. Einzelne Importdateien dürfen vor der Umwandlung bis 40 MB groß sein. Serverseitig sind bis zu 1 MB und 1600 × 1600 Pixel pro gültigem JPEG zulässig; das Frontend arbeitet kleiner. Je Tagebuch gelten 5000 Fotos oder 512 MiB Bilddaten als Grenze. Base64-Speicherung, SQLite und WAL benötigen zusätzlich Platz; tatsächliche Hosting-Quota beachten.

## Speicherung, Offline und Sicherung

Fotos liegen getrennt von Tagebucheinträgen in timelapse_frames in der geschützten SQLite-Datenbank. Nur Besitzer, freigegebene Konten und Admin erhalten Zugriff. Ein einzelnes Foto darf der Besitzer, sein Uploader oder der Admin löschen. Endgültiges Löschen eines Tagebuchs entfernt auch dessen Zeitrafferfotos. Verschieben in den Admin-Papierkorb lässt die Bilder für die Wiederherstellung erhalten; ohne das zugehörige Tagebuch sind sie nicht abrufbar.

Offline-Aufnahmen werden kontogetrennt in der vorhandenen Warteschlange vorgemerkt und bei gültiger Sitzung mit der geöffneten App synchronisiert. Auch vom Server abgelehnte Fotos bleiben lokal zur Prüfung erhalten. Bei 100 wartenden Zeitrafferfotos nimmt die App keine weiteren auf, bis synchronisiert wurde. Browserdaten nicht löschen, solange Aufnahmen ausstehen. Verlorene Serverantworten erzeugen keine doppelten Bilder.

Offline-Vorschau/Export funktioniert für bereits geladene Bilder bzw. lokal vorgemerkte Aufnahmen. Die Offline-Vorbereitung lädt nicht automatisch alle vorhandenen Fotodaten herunter. Vorbereitung eines ausgewählten Videos lädt seine benötigten Bilder. Nicht synchronisierte Daten können bei Geräteverlust oder gelöschtem Browserspeicher verloren gehen.

Der Admin-JSON-Export enthält von Zeitrafferfotos nur Metadaten, keine Bilddaten. Für die Fotos ist eine konsistente Sicherung der SQLite-Datenbank einschließlich anstehender WAL-Daten notwendig. Vor Sicherung laufende Aufnahmen stoppen und Synchronisierung abschließen; einen konsistenten Hosting-/Datenbank-Backup verwenden. Das komplette data/-Verzeichnis und die eigene Konfiguration weiterhin privat sichern.

## Update bei ALL-INKL

1. Bestehendes App-Verzeichnis, data/ und eigene config.php privat sichern.
2. Verschlüsselte ZIP lokal mit einem AES-fähigen Entpacker öffnen. Inhalt von growing/ ins vorhandene App-Verzeichnis übertragen.
3. Bestehenden data/-Ordner und eigene config.php behalten. Das Paket enthält keine Nutzerdatenbank und setzt keine bestehenden Passwörter zurück.
4. Alle übrigen Dateien gemeinsam aktualisieren, insbesondere api.php, app.js, admin.php, admin.js, timelapse.php, timelapse.js, webm-duration.js, support.js, orchard.js, navigation.js, offline.js, sw.js, index.html, modern.css und .htaccess.
5. App-Tabs schließen, online neu öffnen und Offline-Ansichten neu vorbereiten. Die neue Tabelle wird automatisch angelegt.
6. HTTPS, PDO_SQLite, Schreibzugriff und .htaccess-Schutz auf dem echten Hosting prüfen. Direkter Zugriff auf data/weedys.sqlite muss blockiert bleiben.

Lokal getestet, nicht auf deinem ALL-INKL-Server installiert. Ein Test mit deiner echten HERO8 Black und deinem Android-Gerät steht noch aus.
