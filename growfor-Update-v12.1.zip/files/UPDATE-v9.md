# Growing v9 – getrennte Obst- und Gemüsebibliothek

Aktueller Stand: 5. November 2026. Die Funktionen aus v8 bleiben erhalten. Ergänzt wurde eine eigenständige Wissensverwaltung für Obst und Gemüse. Es handelt sich um eine redaktionell bearbeitbare Bibliothek mit Stichwortsuche, nicht um KI-Training oder eine automatische Diagnose.

## Wissen hinterlegen

1. Mit dem bestehenden Adminzugang anmelden und unter Mehr / Profil den Adminbereich öffnen.
2. „Obst & Gemüse“ → „Neuen Eintrag anlegen“ wählen.
3. Eine der zwölf festen Arten wählen: Tomate, Gurke, Paprika, Salat, Möhre, Zucchini, Apfel, Birne, Erdbeere, Heidelbeere, Himbeere oder Weintraube.
4. Titel, beschriebene Symptome, mögliche Ursachen, Pflegehinweise und passende Suchstichwörter eintragen.
5. Quellen jeweils mit Titel und vollständiger HTTP(S)-Adresse hinterlegen. Bis zu acht Quellen sind möglich. Die App öffnet und prüft diese Inhalte nicht automatisch.
6. Als Entwurf speichern oder nach eigener redaktioneller Prüfung „Veröffentlicht“ wählen und die Prüfbestätigung setzen. Für jede erneute Veröffentlichung ist die Bestätigung erneut erforderlich. Alle Fachfelder, Stichwörter und mindestens eine Quelle müssen ausgefüllt sein.
7. Zum Zurückziehen einen Eintrag bearbeiten und auf „Archiviert“ oder „Entwurf“ setzen. Daten bleiben erhalten; späteres erneutes Veröffentlichen ist möglich. Maximal 500 Einträge können gleichzeitig veröffentlicht sein.

Die Bibliothek startet leer. Es werden keine ungeprüften fachlichen Texte oder Testeinträge mitgeliefert. Die redaktionelle Bestätigung ist eine Erklärung des Admins, keine unabhängige fachliche Verifizierung oder Garantie.

## Benutzung durch die Testpersonen

Unter Mehr / Profil → „Obst & Gemüse · Wissenshilfe“ öffnet sich Floras gesonderte Bibliothek. Pflanzenart wählen und Stichwörter eingeben. Alle Suchwörter müssen im Titel, in den Symptomen oder Stichwörtern eines Eintrags vorkommen. Groß-/Kleinschreibung und diakritische Akzente werden vereinheitlicht, Satzzeichen ignoriert.

Angezeigt werden ausschließlich veröffentlichte Einträge der gewählten Obst- oder Gemüseart mit möglichen Ursachen, hinterlegten Hinweisen und Quellenlinks. Kein Treffer bedeutet „Keine gespeicherte Antwort“; es werden keine Ursachen oder Anweisungen erzeugt. Ein Suchtreffer ist keine bestätigte Diagnose. Die bestehenden Cannabis-Begleiter, Growdaten und deren Fragenfeld werden nicht als Wissensquelle verwendet und nicht mit der neuen Bibliothek verbunden.

## Daten, Offline-Nutzung und Bearbeitungsschutz

- Einträge liegen in der neuen Tabelle orchard_knowledge deiner bestehenden SQLite-Datenbank. Der Admin-Datenexport enthält diese Tabelle. Für eine vollständige Sicherung weiterhin den ganzen data/-Ordner und die eigene Serverkonfiguration privat sichern.
- Nur Administratoren können Einträge lesen, die noch nicht veröffentlicht sind, oder Änderungen speichern. Serverseitige Rolle, Sitzungstoken, Versionsprüfung und idempotente Schreibvorgänge sind vorhanden. Speichern erfordert eine Onlineverbindung.
- Bei einem Versionskonflikt oder ungültigen Angaben bleibt der Formularentwurf erhalten. Du kannst ihn herunterladen und danach bewusst die neue Serverfassung laden.
- Die bereits geladene veröffentlichte Bibliothek ist offline verfügbar, nachdem die Offline-Ansichten vorbereitet wurden. Die Anzeige nennt den Stand des Downloads. Zurückgezogene oder geänderte Texte können auf einem offline befindlichen Gerät noch in der alten Fassung liegen. Online die Bibliothek erneut öffnen oder „Bibliothek aktualisieren“ wählen.
- Die Veröffentlichung und Bearbeitung erscheinen im Adminprotokoll. Es gibt keinen Modellanbieter, keinen neuen API-Schlüssel und keine Übertragung von Fragen an einen KI-Dienst.

## Update bei ALL-INKL

1. Bestehendes App-Verzeichnis einschließlich data/ und eigener config.php privat sichern.
2. ZIP mit einem AES-fähigen Entpacker wie 7-Zip lokal entpacken. Inhalt des Ordners growing/ ins vorhandene App-Verzeichnis übertragen; dessen Name darf bleiben.
3. Bestehenden data/-Ordner und eigene config.php behalten. Das Paket enthält keine Nutzerdatenbank. Keine vorhandene Datenbank ersetzen.
4. Alle übrigen Dateien gemeinsam aktualisieren, insbesondere api.php, admin.php, admin.js, orchard.php, orchard.js, offline.js, sw.js, index.html, modern.css und .htaccess.
5. App-Tabs schließen und online neu öffnen. Die neue Tabelle wird automatisch angelegt; vorhandene Konten und Daten bleiben bestehen. Offline-Ansichten danach erneut vorbereiten.

Die allgemeinen Installationsvoraussetzungen aus v8 gelten weiterhin. Das Update wurde lokal getestet und noch nicht auf deinem ALL-INKL-Server installiert.
