<?php
// Only the thread owner and the administrator may read a feedback thread.
function feedbackThread(PDO $db,int $uid,bool $admin,int $id): array {
    $q=$db->prepare('SELECT t.*,u.name AS owner_name,u.login_name AS owner_login FROM feedback_threads t JOIN users u ON u.id=t.user_id WHERE t.id=?');$q->execute([$id]);$t=$q->fetch();
    if(!$t)out(['error'=>'Nachricht nicht gefunden.'],404);
    if(!$admin&&(int)$t['user_id']!==$uid)out(['error'=>'Kein Zugriff auf diese Unterhaltung.'],403);
    return $t;
}
function feedbackText($value,int $max): string {
    $text=trim((string)$value);
    if($text===''||strlen($text)>$max*4||preg_match_all('/./us',$text)>$max)out(['error'=>'Bitte einen Text mit 1 bis '.$max.' Zeichen eingeben.'],400);
    return $text;
}
$admin=($account['role']==='admin');
$thanks='Vielen Dank für deine Nachricht. Sobald ich es Bearbeitet habe melde ich mich. Danke für deine Unterstützung';
switch($a){
case 'feedback_threads':
    $q=$db->prepare("SELECT t.id,t.user_id,t.subject,t.created,t.updated,u.name AS owner_name,u.login_name AS owner_login,(SELECT body FROM feedback_messages WHERE thread_id=t.id ORDER BY id DESC LIMIT 1) AS last_message,(SELECT COUNT(*) FROM feedback_messages m JOIN users sender ON sender.id=m.sender_id WHERE m.thread_id=t.id AND m.read_at IS NULL AND m.sender_id<>? AND m.kind='message' AND ".($admin?"sender.role<>'admin'":"sender.role='admin'").") AS unread FROM feedback_threads t JOIN users u ON u.id=t.user_id ".($admin?'':'WHERE t.user_id=?')." ORDER BY t.updated DESC,t.id DESC");
    $q->execute($admin?[$uid]:[$uid,$uid]);out(['threads'=>$q->fetchAll()]);
case 'feedback_thread':
    $t=feedbackThread($db,$uid,$admin,(int)($in['thread_id']??0));
    if(empty($in['peek']))$db->prepare("UPDATE feedback_messages SET read_at=CURRENT_TIMESTAMP WHERE thread_id=? AND sender_id<>? AND kind='message'")->execute([(int)$t['id'],$uid]);
    $q=$db->prepare("SELECT m.id,m.body,m.kind,m.created,m.sender_id,u.name AS sender_name,u.login_name AS sender_login,u.role AS sender_role FROM feedback_messages m LEFT JOIN users u ON u.id=m.sender_id WHERE m.thread_id=? ORDER BY m.id");$q->execute([(int)$t['id']]);out(['thread'=>$t,'messages'=>$q->fetchAll()]);
case 'feedback_send':
    if($admin)out(['error'=>'Bitte als Admin in einer bestehenden Unterhaltung antworten.'],403);
    $body=feedbackText($in['body']??'',4000);
    if(!empty($in['thread_id']))$t=feedbackThread($db,$uid,false,(int)$in['thread_id']);
    else{
        $subject=feedbackText($in['subject']??'',120);
        $db->prepare('INSERT INTO feedback_threads(user_id,subject) VALUES(?,?)')->execute([$uid,$subject]);$t=['id'=>(int)$db->lastInsertId()];
    }
    $id=(int)$t['id'];
    $db->prepare("INSERT INTO feedback_messages(thread_id,sender_id,body,kind) VALUES(?,?,?,'message')")->execute([$id,$uid,$body]);$messageId=(int)$db->lastInsertId();
    $db->prepare("INSERT INTO feedback_messages(thread_id,sender_id,body,kind) VALUES(?,NULL,?,'system')")->execute([$id,$thanks]);
    $db->prepare('UPDATE feedback_threads SET updated=CURRENT_TIMESTAMP WHERE id=?')->execute([$id]);
    out(['ok'=>1,'id'=>$messageId,'thread_id'=>$id,'confirmation'=>$thanks]);
case 'feedback_reply':
    if(!$admin)out(['error'=>'Nur der Admin darf diese Antwort senden.'],403);
    $t=feedbackThread($db,$uid,true,(int)($in['thread_id']??0));$body=feedbackText($in['body']??'',4000);
    $db->prepare("INSERT INTO feedback_messages(thread_id,sender_id,body,kind) VALUES(?,?,?,'message')")->execute([(int)$t['id'],$uid,$body]);$id=(int)$db->lastInsertId();
    $db->prepare('UPDATE feedback_threads SET updated=CURRENT_TIMESTAMP WHERE id=?')->execute([(int)$t['id']]);
    out(['ok'=>1,'id'=>$id,'thread_id'=>(int)$t['id']]);
default:out(['error'=>'Unbekannte Nachrichtenfunktion.'],404);
}
