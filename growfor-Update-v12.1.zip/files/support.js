/* Private test feedback: tester ↔ administrator, plus device sync controls. */
'use strict';
(()=>{
 const THANKS='Vielen Dank für deine Nachricht. Sobald ich es Bearbeitet habe melde ich mich. Danke für deine Unterstützung';
 let loading=false,loadedUser=null,poll=null,lastUnread=0,observedUser=null;
 const hasLegacy=()=>{try{return JSON.parse(localStorage.getItem('weedys_q')||'[]').length>0}catch{return false}};
 const isAdmin=()=>S.user?.role==='admin';
 const stamp=x=>{const date=new Date(String(x||'').replace(' ','T')+(String(x||'').includes('Z')?'':'Z'));return isNaN(date)?'':date.toLocaleString('de-DE')};
 async function list(){const r=await api('feedback_threads');S.feedbackList=r.threads||[];loadedUser=S.user?.id;return r}
 async function thread(id){
  S.feedbackThreadId=id;
  if(String(id).startsWith('local:')){const item=(await GrowingSync.pending(S.user.id)).find(x=>'local:'+x.id===id);if(!item){S.feedbackThreadId=null;S.feedbackActive=null;return}S.feedbackActive={thread:{id,subject:item.data.subject,pending:true},messages:[{body:item.data.body,kind:'message',sender_name:'Du',pending:true,created:new Date(item.created/1000).toISOString()}]};return}
  S.feedbackActive=await api('feedback_thread',{thread_id:id});
 }
 async function load(id=null){await list();if(id)await thread(id);else{S.feedbackThreadId=null;S.feedbackActive=null}}
 async function open(){S.g=null;creating=false;S.view='support';await load();}
 const row=t=>`<button class="feedback-thread" data-feedback-thread="${esc(t.id)}"><span><b>${esc(t.subject)}</b><small>${isAdmin()?esc(t.owner_name||t.owner_login)+' · ':''}${t.pending?'Auf diesem Gerät vorgemerkt':esc(stamp(t.updated))}</small><span class="feedback-preview">${esc(t.last_message||'')}</span></span>${Number(t.unread)>0?`<span class="feedback-badge">${Number(t.unread)} neu</span>`:''}</button>`;
 EXTRA.views.support=()=>{
  const active=S.feedbackActive;
  return `<div class="wrap feedback-view"><div class="top"><img class="logoimg" src="logo.png?v=4" alt="growfor-Logo"><div class="hi"><b>${isAdmin()?'Testfeedback verwalten':'Nachrichten an den Admin'}</b><span class="mute">Privat · nur du und der Admin</span></div></div>${S.err?`<div class="err" role="alert">${esc(S.err)}</div>`:''}${S.msg?`<div class="ok" role="status">${esc(S.msg)}</div>`:''}${active?`<button class="btn alt sm" id="feedback-list">‹ Alle Unterhaltungen</button><h2 class="h">${esc(active.thread.subject)}</h2><div class="feedback-messages">${active.messages.map(m=>`<article class="feedback-message ${m.kind==='system'?'system':Number(m.sender_id)===S.user.id?'own':''}"><header><b>${m.kind==='system'?'Automatische Bestätigung':esc(m.sender_name||m.sender_login||'Du')}</b><small>${m.pending?'Noch nicht gesendet':esc(stamp(m.created))}</small></header><p>${esc(m.body)}</p></article>`).join('')}</div>${active.thread.pending?'<div class="alert">Diese Nachricht liegt noch auf deinem Gerät. Nach der Synchronisierung kannst du hier weitere Nachrichten schreiben.</div>':`<form id="feedback-compose" class="card"><label for="feedback-body">${isAdmin()?'Antwort an die Testperson':'Weitere Nachricht an den Admin'}</label><textarea id="feedback-body" name="body" required maxlength="4000" rows="4"></textarea><button class="btn led" type="submit">${isAdmin()?'Antwort senden':'Nachricht senden'}</button></form>`}`:`<p class="mute feedback-intro">${isAdmin()?'Hier liest und beantwortest du Rückmeldungen der Testkonten.':'Melde Fehler oder schicke Ideen zur Verbesserung der App. Andere Testpersonen können deine Nachrichten nicht lesen.'}</p><div class="feedback-inbox">${(S.feedbackList||[]).length?S.feedbackList.map(row).join(''):'<div class="card mute">Noch keine Nachrichten.</div>'}</div>${isAdmin()?'':`<form id="feedback-compose" class="card"><h3>Neue Nachricht</h3><label for="feedback-subject">Betreff<input id="feedback-subject" name="subject" required maxlength="120" placeholder="Zum Beispiel: Fehler beim Speichern"></label><label for="feedback-body">Deine Nachricht<textarea id="feedback-body" name="body" required maxlength="4000" rows="5" placeholder="Was hast du gemacht, was ist passiert und was hattest du erwartet?"></textarea></label><button class="btn led" type="submit">An Admin senden</button></form>`}`}</div>`;
 };
 EXTRA.views.sync=()=>`<div class="wrap"><div class="top"><img class="logoimg" src="logo.png?v=4" alt="growfor-Logo"><div class="hi"><b>Offline & Synchronisierung</b><span class="mute">Lokale Einträge bleiben diesem Konto zugeordnet</span></div></div>${S.err?`<div class="err" role="alert">${esc(S.err)}</div>`:''}${S.msg?`<div class="ok">${esc(S.msg)}</div>`:''}<div class="card"><h3>Ohne Verbindung weiterarbeiten</h3><p class="mute">Tagebucheinträge, Einstellungen und Nachrichten werden lokal vorgemerkt. Sobald du wieder online bist und die App geöffnet ist, werden sie mit deiner gültigen Sitzung gesendet. Neue Konten, neue Tagebücher und Löschaktionen benötigen eine Verbindung. Der manuelle Offline-Schalter hält die App offline, bis du ihn wieder ausschaltest.</p><button class="btn led" id="offline-prepare">Ansichten offline vorbereiten</button><button class="btn alt" id="offline-toggle">Offline-Modus umschalten</button><button class="btn alt" id="sync-retry">Jetzt synchronisieren</button><p class="mute">Vorher einmal online anmelden. Nur auf einem eigenen, vertrauenswürdigen Gerät offline nutzen. Browserdaten nicht löschen, solange Einträge ausstehen. Bei mehreren Geräten gilt für Einstellungen die zuletzt gespeicherte Fassung.</p></div><h3 class="h">Auf diesem Gerät vorgemerkt</h3><div id="sync-pending"><p class="mute">Wird geladen …</p></div></div>`;
 async function showPending(){
  const el=document.getElementById('sync-pending');if(!el||!S.user)return;
  const q=await GrowingSync.pending(S.user.id),manual=await GrowingSync.forced(S.user.id);const b=document.getElementById('offline-toggle');if(b)b.textContent=manual?'Offline-Modus ausschalten':'Offline-Modus einschalten';
  el.innerHTML=(hasLegacy()?'<div class="alert">Es gibt ältere Offline-Einträge, die noch keinem aktuellen Konto zugeordnet wurden. Melde dich online mit dem ursprünglich verwendeten Konto an. Browserdaten nicht löschen.</div>':'')+(q.length?q.map(x=>`<div class="card sync-pending-item"><b>${esc(({timelapse_frame_save:'Zeitrafferfoto',entry_save:'Tagebucheintrag',settings_save:'Einstellungen',feedback_send:'Nachricht an Admin',feedback_reply:'Admin-Antwort'})[x.action]||'Eintrag')}</b><p class="mute">${x.error?esc(x.error):'Wartet auf Übertragung'}</p><button class="btn alt sm" data-discard-pending="${esc(x.id)}">Vom Gerät entfernen</button></div>`).join(''):'<div class="card mute">Alle vorgemerkten Einträge sind übertragen.</div>');
  if(q.some(x=>x.action==='settings_save'&&(x.error||(!x.data.settings_base_hash&&!x.data.settings_after_request))))el.innerHTML+='<div class="card"><h3>Speicherkonflikt prüfen</h3><p class="mute">Neuere Serverdaten werden nicht automatisch überschrieben. Du kannst beide Fassungen sichern und danach bewusst entscheiden, ob die gesamte lokale Einstellungsfassung den Serverstand ersetzen soll.</p><button class="btn alt" id="settings-conflict-resolve" type="button">Lokale Fassung prüfen & sichern</button></div>';
 }
 const prior=EXTRA.profileBtns;
 EXTRA.profileBtns=()=>prior()+`<button class="btn led" id="support-open" style="width:100%;margin-bottom:8px">${isAdmin()?'Testfeedback & Antworten':'Nachricht an Admin'}</button><button class="btn alt" id="sync-open" style="width:100%;margin-bottom:8px">Offline & Synchronisierung</button>`;
 EXTRA.binds.push(on=>{
  on('#support-open','click',()=>run(open));
  on('[data-feedback-thread]','click',e=>run(async()=>{await thread(e.currentTarget.dataset.feedbackThread)}));
  on('#feedback-list','click',()=>run(async()=>{await load()}));
  on('#feedback-compose','submit',e=>{e.preventDefault();if(e.target.dataset.busy)return;e.target.dataset.busy='1';const form=e.target,button=form.querySelector('button[type=submit]');button.disabled=true;const f=formData(form);run(async()=>{
   const body=(f.body||'').trim();if(!body||body.length>4000)throw new Error('Bitte eine Nachricht mit 1 bis 4000 Zeichen eingeben.');
   if(!S.feedbackThreadId&&!(f.subject||'').trim())throw new Error('Bitte einen Betreff eingeben.');
   const result=await api(isAdmin()?'feedback_reply':'feedback_send',{body,...(S.feedbackThreadId?{thread_id:S.feedbackThreadId}:{subject:f.subject.trim()})});
   if(result.queued){S.msg='Auf diesem Gerät vorgemerkt. Die Nachricht wird bei Verbindung automatisch gesendet.';await load(S.feedbackThreadId||String(result.id))}
   else{S.msg=isAdmin()?'Deine Antwort wurde gesendet.':result.confirmation||THANKS;await load(result.thread_id)}
  }).finally(()=>{if(form.isConnected){delete form.dataset.busy;button.disabled=false}})});
  on('#sync-open','click',()=>{S.g=null;S.view='sync';render()});
  on('#offline-prepare','click',()=>run(async()=>{await GrowingSync.prepare();S.msg='App-Hülle und geladene Ansichten sind für Offline-Starts vorbereitet. Nicht alle Funktionen sind offline verfügbar.'}));
  on('#offline-toggle','click',()=>run(()=>GrowingSync.toggle()));
  on('#sync-retry','click',()=>run(()=>GrowingSync.flush(true)));
  if(S.view==='sync')showPending().catch(()=>{});
  if(S.view==='support'&&loadedUser!==S.user?.id&&!loading){loading=true;load(S.feedbackThreadId).then(()=>render({keepScroll:true})).catch(e=>{S.err=e.message;render({keepScroll:true})}).finally(()=>{loading=false})}
 });
 document.addEventListener('click',e=>{if(e.target.closest('#settings-conflict-resolve')){run(async()=>{const result=await GrowingSync.resolveSettings();if(result)S.msg=result==='saved'?'Die geprüfte lokale Fassung wurde gespeichert.':'Es gibt weiterhin einen Konflikt. Die lokale Fassung bleibt erhalten.'});return}const b=e.target.closest('[data-discard-pending]');if(b)run(async()=>{await GrowingSync.discard(b.dataset.discardPending);await showPending()})});
 addEventListener('growing:synced',e=>{
  const sent=e.detail.sent||[];
  if(sent.some(x=>x.action==='feedback_send')){toast(THANKS);if(S.view==='support')S.msg=THANKS}
  if(S.view==='support'&&!window.GrowingNavigation?.hasUnsaved()){let id=S.feedbackThreadId;if(String(id).startsWith('local:'))id=sent.find(x=>x.action==='feedback_send')?.result.thread_id||null;load(id).then(()=>render({keepScroll:true})).catch(()=>{});}
  if(S.view==='sync')showPending().catch(()=>{});
 });
 addEventListener('growing:sync-state',()=>{if(S.view==='sync')showPending().catch(()=>{})});
 async function pollFeedback(){
  if(!S.user||S.user.must_change_password||document.hidden||!navigator.onLine||await GrowingSync.forced(S.user.id))return;
  if(S.view==='support'&&document.querySelector('#feedback-compose textarea')?.value)return;
  try{const r=await api('feedback_threads'),unread=r.threads.reduce((n,t)=>n+Number(t.unread),0);if(unread>lastUnread)toast(isAdmin()?'Neues Testfeedback ist eingegangen.':'Der Admin hat dir geantwortet.');lastUnread=unread;if(S.view==='support'){S.feedbackList=r.threads;if(S.feedbackThreadId&&!String(S.feedbackThreadId).startsWith('local:'))await thread(S.feedbackThreadId);render({keepScroll:true})}}catch{}
 }
 addEventListener('growing:render',()=>{if(observedUser!==S.user?.id){observedUser=S.user?.id;loadedUser=null;lastUnread=0;S.feedbackList=[];S.feedbackActive=null;S.feedbackThreadId=null}if(poll)clearInterval(poll);if(S.user&&!S.user.must_change_password)poll=setInterval(pollFeedback,30000)});
 window.GrowingSupport={open,async restore(id){await load(id)}};
})();
