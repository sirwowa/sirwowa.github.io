# Growing v7 – Begleiterteam und Fehlerkorrekturen

Die Angaben in dieser Datei beschreiben den aktuellen Stand und ersetzen ältere Versionshinweise, soweit sie davon abweichen.

## Drei Begleiter

- Sour (grün): führt durch drei Schritte zum neuen Tagebuch: Name/Startdatum/Sorte/Standort, Eingabestufe, Zusammenfassung und ausdrückliches Anlegen. Kein automatischer Anbauplan. Ohne vorhandenes Tagebuch erscheint der Einstieg nach dem Anmelden automatisch; über „Neuen Grow starten“ ist er jederzeit erreichbar.
- Flora (rosa, weißer Mantel): speichert freie Beobachtungen als Notizen im ausgewählten Tagebuch. Keine Diagnose, automatische Symptomerkennung oder Behandlungsempfehlung.
- Luna (violett): verwaltet selbst eingetragene Aufgaben mit eigenem Termin. Fällige Erinnerungen erscheinen in der geöffneten App; Kalenderexport mit Alarm ist vorhanden. Keine Hintergrund-Push-Nachrichten, keine Berechnung eines Gieß- oder Düngezeitpunkts.
- Logo, schwebender Begleiterknopf und Profil öffnen das Team. Die bisherige lokale App-FAQ und App-Tour bleiben über „Fragen zur App & App-Tour“ erreichbar.
- Die drei Figuren wurden anhand deiner Vorlage neu gerendert. Leichte CSS-Bewegung, pausierbar; „Bewegung reduzieren“ des Geräts wird berücksichtigt.

## Eingabestufen je Tagebuch

- Anfänger: grundlegende Angaben; zusätzliche Messfelder und Messwert-Schnellaktion ausgeblendet.
- Fortgeschritten: zusätzlich u.a. Höhe, Temperatur und Luftfeuchte; kein pH/EC-Eingabefeld.
- Experte: alle vorhandenen Eingabefelder. Zusätzliche Messwerte sind freiwillig.
- Unter Mehr → Setup später änderbar. Bereits gespeicherte, ausgeblendete Angaben werden nicht gelöscht. Alte Auswahl „Profi“ wird als „Experte“ angezeigt.

## Gemeinsame Preise

Unter Kosten → Preisvorgaben ändern einmal Strompreis in €/kWh und Wasserpreis in €/m³ für das eigene Konto eintragen. Alle Tagebücher dieses Kontos erben diese Werte. In einem geöffneten Tagebuch unter Mehr → Kosten kann eine eigene Preisausnahme gespeichert oder auf gemeinsame Preise zurückgestellt werden. Beim Zuordnen eines neuen Belegs wird der passende Preis übernommen; manuell geänderte Preise bleiben erhalten. Ein alter Beleg behält seinen Betrag. Verbrauchsmengen gehören zum jeweiligen Beleg und werden nicht pauschal auf alle Tagebücher kopiert.

## Update bei ALL-INKL

1. Vorher den vollständigen bestehenden App-Ordner einschließlich data/ und eigener config.php privat sichern.
2. Archiv lokal mit einem AES-fähigen Entpacker (z.B. 7-Zip) öffnen. Inhalt des Ordners growing/ ins vorhandene App-Verzeichnis übertragen. Der bisherige Verzeichnisname darf bleiben.
3. Bestehenden data/-Ordner und eigene config.php erhalten. Keine vorhandene Datenbank löschen oder ersetzen. Das Paket enthält ausschließlich data/.htaccess, keine Nutzerdatenbank.
4. Alle anderen App-Dateien gemeinsam aktualisieren, insbesondere api.php, sync.php, offline.js, sw.js, index.html und team.js. Nicht nur einzelne JavaScript-Dateien hochladen.
5. App-Tabs schließen, online neu öffnen und unter Mehr → Offline & Synchronisierung erneut vorbereiten. Ein altes Browserfenster kann noch alte Dateien verwenden.
6. Bei einem Speicherkonflikt bleibt die lokale Fassung vorgemerkt. „Speicherkonflikt prüfen“ bietet beide Fassungen als JSON-Sicherung an. Erst nach ausdrücklicher Bestätigung ersetzt die gesamte lokale Einstellungsfassung den Serverstand. Es gibt keine automatische Zusammenführung. Sicherungsdownload auf dem Gerät kontrollieren.
7. Auf dem echten Hosting HTTPS, PDO_SQLite und .htaccess-Schutz prüfen. Ein direkter Aufruf von data/weedys.sqlite muss 403/404 liefern. Alle noch unbeanspruchten Startkonten zeitnah mit eigenen Passwörtern einrichten.

Vorhandene Konten und Passwörter werden durch dieses Dateiupload-Update nicht zurückgesetzt. Eine vollständige Datensicherung muss den data/-Ordner umfassen; der Tagebuch-Export enthält nicht alle Einstellungen.
