VERSION 1.4: Kameraoberfläche und Trefferprüfung vereinfacht.
Großer runder Auslöser, wenige sichtbare Bedienelemente, Ergebnisse unten.
Details, Varianten und Grading bei Bedarf aufklappen. Erkennungsmodell unverändert.

VERSION 1.3: Zusätzliche CSV-Vorschläge aus dem gemeinsamen Backend.
Import über die Web-App, keine lokale OCR-Identifikation aus CSV allein.

TOUCHDOWN COLLECTOR · NATIVE ANDROID-APP 1.2

Dies ist eine native Android-Anwendung mit Android-Views und Camera2.
Es ist keine WebView-Hülle und es werden keine HTML-Seiten als App-Oberfläche
angezeigt. Die bestehende PHP-Schnittstelle auf deinem ALL-INKL-Webspace bleibt
Backend für Login, eigene Sammlung, Cardsight-Kartenerkennung und Kontingente.
Die APK enthält weder Cardsight-Schlüssel noch Passwort oder Karten-Datenbank.

INSTALLIEREN
1. Das beiliegende Web-Paket Version 15 unter app.4doubleu.de/touchdown/ hochladen.
   Bestehende private Konfiguration und Sammlung behalten. native-login.php ist neu
   und muss neben index.php und api.php hochgeladen werden.
2. Wenn nötig, Website im Browser erstmals mit Installationscode einrichten und
   Cardsight-Schlüssel speichern. Eine bestehende Installation ist weiter nutzbar.
3. touchdown-collector-android.apk auf dein Android-Smartphone herunterladen.
4. APK öffnen, die Installation für diesen Browser/Dateimanager erlauben und
   installieren. Die APK ist signiert; Android/Play Protect kann bei einer neuen,
   direkt verteilten App Hinweise anzeigen. Diese Hinweise nicht als automatische
   Sicherheitsfreigabe durch uns verstehen. Es gibt keinen Play-Store-Eintrag.
5. Touchdown Collector starten, mit dem bisherigen App-Passwort anmelden und den
   Kamerazugriff bei Nutzung des Scanners erlauben. Android ab 8.0 (API 26).
6. Eine Karte ruhig innerhalb des Rahmens halten. Der automatische Modus wartet
   auf ein stabiles Bild. Nach dem Scan Karte entfernen und nächste Karte hinlegen.
   Jeden Vorschlag vor dem Speichern prüfen; bei Duplikaten Meldung bestätigen.
   „Jetzt fotografieren“ bleibt jederzeit als manueller Auslöser verfügbar.

FUNKTIONEN DIESER NATIVEN VERSION
- Native Anmeldung mit Session-Cookie und CSRF-Schutz; gleicher Server/VAULT.
- Native Rückkamera, Rahmen, Auto-Scan, manueller Auslöser und Scan-Animation.
- Lokale Bildruhe-/Rahmenheuristik, Identifikation ausschließlich via Cardsight.
- Keine neuen Scans im Hintergrund. Kamera wird beim Verlassen der App gestoppt.
- VAULT mit eigenen Fotos, Suche, Team-/Positions-, Sammler- und Namenssortierung.
- Große Kartendetails, Wischen/vor/zurück und native Fotoansicht.
- Metadaten, Grading und Zertifikatsnummer aus Cardsight; prüf-/korrigierbar.
- Katalogsuche sowie Nummer/Jahr/Hersteller mit optionalem Spielernamen.
- Korrektur bestehender Katalogzuordnung, Bearbeiten und Löschen eigener Karten.
- Alle Kameratreffer vor dem Speichern prüfen und ausdrücklich bestätigen.
- Duplikatmeldung erhöht den Bestand nicht automatisch.
- Preise und Katalogbilder nur auf Wunsch, Euro-Gesamtwert aus letzten Abrufständen.
- Kontingentanzeige und bewusstes Anbieter-Sync; gemeinsame serverseitige Sperre.
- Cardsight-Schlüssel nur auf dem Server speichern/ändern.
- Produkt-Checklisten mit Base/Parallels/1-of-1, Besitzstatus und Fortschritt.
- Native NFL/NBA-Spielstände (10 s im Vordergrund), Ereignisabruf und deutsche News.
- JSON-Backup über Android-Dateiauswahl exportieren/importieren.
- Optionale verschlüsselte Offline-Kopie eigener Karten/Fotos und Preise auf
  diesem Gerät. Kein automatisches Kopieren der Cardsight-Bilderdatenbank.

GRENZEN
Auto-Scan ist eine Bildruhe-/Rahmenprüfung, keine garantierte lokale Kartenerkennung.
Hintergrund, Reflexionen und Aufnahmequalität können Auslösen/Erkennung verhindern
oder falsch auslösen. Gute Beleuchtung und kontrastreicher ruhiger Untergrund helfen.
Jede an den Server gesendete Erkennung zählt zum Kontingent, auch bei fehlendem
Treffer. Nicht jede Karte oder Parallel-Variante ist im Anbieter-Katalog vorhanden.
Die Native-App 1.2 hat keinen freien Mehrkarten-Zuschnitt und keinen zusätzlichen
lokalen Barcode-Decoder. Die Web-App behält Raster 2/4 und browserabhängige Barcodes.
Bei mehreren erkannten Treffern wird eine Auswahl angeboten; es werden keine
unbelegten Bildkoordinaten oder separaten Kartenfotos erfunden. Die native Kamera
speichert einen Zuschnitt des sichtbaren Rahmens aus der Kameravorschau. Die
Auflösung hängt vom Gerät ab; es wird kein originaler hochauflösender Sensor-
JPEG-Scan garantiert. Galerie-Fotos werden als gewähltes Bild analysiert; bei
mehreren Karten kann das gespeicherte Bild die gesamte Aufnahme enthalten.
Checklisten können viele Anbieteranfragen benötigen und werden bei einer Grenze
abgebrochen. Ein kompletter Katalog ist offline nicht vorhanden. Die News-/Live-
Quellen müssen vom Webserver aus erreichbar sein; das war hier nicht live prüfbar.
Neue Erkennung, neue Katalogdaten, Preise und Live-News benötigen Internet.

OFFLINE
Bei erfolgreicher Anmeldung optional „Verschlüsselten Offline-VAULT auf diesem
Gerät speichern“ aktivieren. Eigene Kartendaten und Fotos werden als AES-GCM-
Datei im privaten App-Speicher abgelegt. Der AES-Schlüssel liegt im Android
Keystore, ein PBKDF2-Passwortprüfwert dient als lokale Zugangssperre. Das Passwort
wird nicht gespeichert. Zugriff über „Offline-VAULT öffnen“ mit dem Passwort vom
Zeitpunkt der Aktivierung. Offline nur lesen; keine neuen Scans/Serveränderungen.
Die Offline-Kopie wird bei späteren Änderungen aktualisiert, solange sie aktiviert
ist. Löschen über Mehr → Offline-Kopie löschen. Android-App-Deinstallation oder
App-Daten-Löschen entfernt sie. Der Web-App-Offline-VAULT ist eine getrennte Kopie.
Keine dieser Kopien ersetzt ein eigenes Backup der Serversammlung.

TESTSTATUS
Java-Code mit offizieller Android-Plattform 35 kompiliert und zu DEX gebaut;
APK-Signaturen v2/v3 verifiziert. Native Auto-Scan-Zustandsmaschine mit synthetischen
Bilddaten geprüft. PHP-Anmeldung/CSRF und Web-Auto-Scan mit lokalen Testdaten geprüft.
Ein echter Android-Geräte-/Emulator-Test und ein echter Kameratest waren hier
nicht verfügbar. APK deshalb vor Nutzung mit der ganzen Sammlung auf dem eigenen
Telefon testen und zuerst ein Server-Backup behalten. Die Android-Oberfläche hat
nicht in jedem Detail dieselben Funktionen wie die bestehende Web-App.

QUELLCODE / EIGENE BUILDS
Dieses Verzeichnis als Android-Studio-Projekt öffnen. AGP 8.7.3 benötigt eine
passende Gradle-Version (8.9) und JDK 17 oder neuer; Android-Plattform 35 und
Build-Tools 35 installieren. Kein Gradle-Wrapper-Binary liegt bei; Android Studio
oder eine vorhandene Gradle-Installation benutzen. „gradle :app:assembleDebug“
erstellt eine lokal anders signierte Debug-Version.
Alternativ build-apk.py mit offiziellem Android-SDK, JDK und Python ausführen:
ANDROID_SDK_ROOT, ANDROID_PLATFORM_JAR, ANDROID_BUILD_TOOLS können Pfade vorgeben.
TOUCHDOWN_KEYSTORE und TOUCHDOWN_KEY_PASSWORD_FILE müssen auf eigene private
Signaturdateien zeigen. Keystore und Key-Passwort müssen gleich sein. Kein
Signaturpasswort und keine privaten Schlüssel gehören in dieses Quellcodepaket.
Die direkt gelieferte APK verwendet einen separat privat aufbewahrten Projekt-
Signaturschlüssel. Für ein Update einer bereits installierten APK wird derselbe
Signaturschlüssel benötigt; eine selbst anders signierte APK ersetzt sie nicht.
Serverdaten bleiben bei einer Neuinstallation erhalten; lokale Offline-Daten
und Anmeldung können bei Deinstallation verloren gehen.

VERSION 1.1: Sammlerwissen mit 41 deutsch übersetzten Themen aus der vom Nutzer
bereitgestellten COLLECT.Guide-Übersichtsseite. Suche und Themenfilter sind
lokal und offline nutzbar; Originalartikel öffnen extern und können englisch
sein. Keine vollständigen Artikel oder konkreten Set-Checklisten in der Datei.

VERSION 1.2: Keine automatische Speicherung, auch nicht bei High. Eigene Aufnahme
und vorgeschlagenen Spieler vergleichen; vorhandene Anbieter-Alternativen können
ausgewählt werden. Ein High-Wert beweist die Identität nicht. Die konkrete
Fehlzuordnung Spieler A zu Spieler B ist ohne Originalfoto noch nicht nachgestellt.
