import {LocalOcr} from './local-ocr.js?v=40';
// Photos are saved first. Identification never blocks the next camera capture.
export class PhotoQueue{
 constructor({api,getCards,onChange,onSaved,onMessage}){Object.assign(this,{api,getCards,onChange,onSaved,onMessage});this.running=false;this.outboxRunning=false;this.recover=new Map();this.ocr=new LocalOcr();}
 async storage(mode,action){return new Promise((resolve,reject)=>{const r=indexedDB.open('sideline-photo-outbox',1);r.onupgradeneeded=()=>r.result.createObjectStore('photos',{keyPath:'token'});r.onerror=()=>reject(r.error);r.onsuccess=()=>{const db=r.result,tx=db.transaction('photos',mode),request=action(tx.objectStore('photos'));let result;request.onsuccess=()=>{result=request.result;};tx.oncomplete=()=>{db.close();resolve(result);};tx.onerror=()=>{db.close();reject(tx.error);};};});}
 async save(image,token=crypto.randomUUID()){
  this.onMessage('Foto speichern …');const entry={image,token,createdAt:new Date().toISOString()};
  // Durably stage before transmitting; the token makes a repeated upload idempotent.
  let durable=false;try{await this.storage('readwrite',s=>s.put(entry));durable=true;}catch{}
  try{const card=await this.api('/api/photo-queue-save',{method:'POST',body:JSON.stringify(entry)});this.recover.delete(token);try{await this.storage('readwrite',s=>s.delete(token));}catch{}this.onSaved(card);this.onMessage('Im VAULT gespeichert');void this.pump();return card;}
  catch(error){this.recover.set(token,entry);this.onMessage(durable?'Auf diesem Gerät gespeichert · Upload folgt bei Verbindung.':'Noch nicht gespeichert · Foto bleibt hier. Erneut versuchen.');if(error.status===401)throw error;return null;}
 }
 async retryUploads(){if(this.outboxRunning)return;this.outboxRunning=true;try{let pending=[];try{pending=await this.storage('readonly',s=>s.getAll());}catch{}for(const p of this.recover.values())if(!pending.some(x=>x.token===p.token))pending.push(p);for(const p of pending){if(document.hidden||!navigator.onLine)break;const c=await this.save(p.image,p.token);if(!c)break;}}finally{this.outboxRunning=false;}}
 async pump(){if(this.running||document.hidden||!navigator.onLine)return;this.running=true;try{while(!document.hidden){const c=this.getCards().find(c=>c.scan?.queueState==='pending'||(c.scan?.queueState==='processing'&&c.scan.leaseUntil*1000<Date.now()));if(!c)break;try{if(!c.scan.localChecked){let text='';try{text=await this.ocr.read(c.image);}catch{}const local=await this.api('/api/photo-queue-local',{method:'POST',body:JSON.stringify({id:c.id,text,version:c.updatedAt})});this.onChange(local);if(local.scan?.queueState!=='pending')continue;}const saved=await this.api('/api/photo-queue-step',{method:'POST',body:JSON.stringify({id:c.id})});this.onChange(saved);}catch{break;}}}finally{this.running=false;}}
 start(){void this.retryUploads();void this.pump();this.timer=setInterval(()=>{void this.pump();},15000);window.addEventListener('online',()=>{void this.retryUploads();void this.pump();});document.addEventListener('visibilitychange',()=>{if(!document.hidden){void this.retryUploads();void this.pump();}});}
}
