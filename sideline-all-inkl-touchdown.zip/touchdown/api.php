<?php
declare(strict_types=1);
require __DIR__ . '/_private/bootstrap.php';
security_headers(); start_session();
header('Content-Type: application/json; charset=utf-8');
function respond(int $status, mixed $body): never { http_response_code($status); echo json_encode($body,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
try {
    if (!https_request() && !localhost_request()) throw new AppError('Bitte die App über HTTPS öffnen.',403);
    $config=read_private('config');
    if (!$config) throw new AppError('Bitte zuerst die Einrichtung auf der Startseite abschließen.',503);
    if (!authenticated()) throw new AppError('Bitte erneut anmelden.',401);
    $method=$_SERVER['REQUEST_METHOD'];
    if ($method==='POST') {
        $override=$_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE']??'POST';
        if (!in_array($override,['POST','PUT','DELETE'],true)) throw new AppError('Methode nicht unterstützt.',405);
        $method=$override;
    }
    if ($method!=='GET') check_csrf($_SERVER['HTTP_X_CSRF_TOKEN']??'');
    $route=trim((string)($_GET['r']??''),'/');
    $key=$config['apiKey']??'';
    if ($method==='GET' && $route==='status') respond(200,['ok'=>true,'scanAvailable'=>(bool)$key&&function_exists('curl_init'),'scanMessage'=>$key?'Bereit für NFL und NBA.':'Bitte deinen Cardsight-Schlüssel unter Einstellungen hinterlegen.','currency'=>'EUR','storage'=>'Geschützter Speicher auf deinem Webspace']);
    if ($method==='POST' && $route==='logout') { $_SESSION=[];session_destroy();respond(200,['ok'=>true]); }
    if ($method==='POST' && $route==='settings') {
        $input=json_body(10000);
        if (!password_verify((string)($input['password']??''),$config['passwordHash'])) throw new AppError('Das Passwort ist nicht korrekt.',403);
        $newKey=text_field($input['apiKey']??'',256);
        if ($newKey && !preg_match('/^[a-zA-Z0-9_-]{16,256}$/D',$newKey)) throw new AppError('Der API-Schlüssel hat ein ungültiges Format.');
        private_transaction('config',fn($c)=>[array_merge($c,['apiKey'=>$newKey]),null]);
        respond(200,['ok'=>true]);
    }
    if ($method==='GET' && ($route==='cards'||$route==='export')) {
        $cards=read_private('cards',[]);
        usort($cards,fn($a,$b)=>strcmp($b['createdAt'],$a['createdAt'])?:strcmp($a['id'],$b['id']));
        if ($route==='export') { header('Content-Disposition: attachment; filename="sideline-sammlung.json"');respond(200,['format'=>'sideline','version'=>1,'exportedAt'=>now_iso(),'cards'=>$cards]); }
        respond(200,$cards);
    }
    if ($method==='POST' && $route==='cards') {
        $card=validate_card(json_body());$card['id']=uuid();$card['createdAt']=$card['updatedAt']=now_iso();
        private_transaction('cards',function($rows) use($card){$rows??=[];$rows[]=$card;return[$rows,null];});
        respond(201,$card);
    }
    if (preg_match('/^cards\/([a-zA-Z0-9-]{1,80})$/D',$route,$matches) && in_array($method,['PUT','DELETE'],true)) {
        $id=$matches[1];$card=$method==='PUT'?validate_card(json_body()):null;
        $result=private_transaction('cards',function($rows) use($id,$card,$method){
            $rows??=[];$index=array_search($id,array_column($rows,'id'),true);
            if($index===false)throw new AppError('Karte nicht gefunden.',404);
            if($method==='DELETE'){array_splice($rows,$index,1);return[$rows,['ok'=>true]];}
            $next=array_merge($card,['id'=>$id,'createdAt'=>$rows[$index]['createdAt'],'updatedAt'=>now_iso()]);$rows[$index]=$next;return[$rows,$next];
        });respond(200,$result);
    }
    if ($method==='POST' && $route==='import') {
        $input=json_body(DATA_LIMIT);
        if (($input['format']??'')!=='sideline'||($input['version']??0)!==1||!isset($input['cards'])||!is_array($input['cards'])||!array_is_list($input['cards'])||count($input['cards'])>1000) throw new AppError('Bitte ein gültiges Sideline-Backup mit maximal 1.000 Einträgen wählen.');
        $validated=[];$ids=[];
        foreach($input['cards']as $row){$card=validate_card($row);$id=$row['id']??uuid();if(!is_string($id)||!preg_match('/^[a-zA-Z0-9-]{1,80}$/D',$id)||isset($ids[$id]))throw new AppError('Ungültige oder doppelte Karten-IDs im Backup.');$ids[$id]=true;$card['id']=$id;$card['createdAt']=$card['updatedAt']=now_iso();$validated[]=$card;}
        $result=private_transaction('cards',function($rows)use($validated){$rows??=[];$existing=array_fill_keys(array_column($rows,'id'),true);$imported=0;$skipped=0;foreach($validated as $card){if(isset($existing[$card['id']])){$skipped++;continue;}$rows[]=$card;$existing[$card['id']]=true;$imported++;}return[$rows,['imported'=>$imported,'skipped'=>$skipped]];});respond(200,$result);
    }
    if ($method==='POST' && in_array($route,['identify','catalog'],true)) {
        $input=json_body();$segment=$input['segment']??'';
        if(!in_array($segment,['football','basketball'],true))throw new AppError('Bitte NFL oder NBA wählen.');
        // Release the PHP session lock while the external service is working.
        session_write_close();
        if($route==='identify'){
            $photo=photo_field($input['image']??'');if(!$photo)throw new AppError('Bitte zuerst ein Kartenfoto wählen.');
            preg_match('~^data:(image/[^;]+);base64,(.+)$~D',$photo,$parts);
            $result=cardsight_request('/v1/identify/card/'.$segment,$key,base64_decode($parts[2],true),$parts[1]);
            if(!isset($result['success'])||!is_bool($result['success']))throw new AppError('Unerwartete Antwort von Cardsight.',502);
            $detections=[];foreach(array_slice($result['detections']??[],0,10)as $d){$mapped=map_detection($d,$segment);if($mapped['matchLevel']!=='none')$detections[]=$mapped;}
            respond(200,['detections'=>$detections,'detectedCount'=>$result['detectedCount']??0,'identifiedCount'=>$result['identifiedCount']??count($detections)]);
        }
        $query=text_field($input['query']??'');if(strlen($query)<2)throw new AppError('Bitte mindestens zwei Suchzeichen eingeben.');
        $result=cardsight_request('/v1/catalog/search?'.http_build_query(['q'=>$query,'type'=>'card','take'=>12,'segment'=>$segment==='football'?'Football':'Basketball']),$key);
        if(!isset($result['results'])||!is_array($result['results']))throw new AppError('Unerwartete Antwort von Cardsight.',502);
        $mapped=[];foreach($result['results']as $c){if(($c['type']??'')!=='card')continue;$mapped[]=['player'=>clean_api_text($c['name']??''),'set'=>clean_api_text(implode(' · ',array_unique(array_filter([$c['releaseName']??'',$c['setName']??''])))),'year'=>clean_api_text($c['year']??''),'number'=>clean_api_text($c['cardNumber']??''),'parallel'=>clean_api_text($c['parallelName']??''),'sport'=>$segment==='football'?'American Football':'Basketball','cardsightId'=>clean_api_text($c['id']??'')];}
        respond(200,['results'=>$mapped,'total'=>$result['total_count']??count($mapped)]);
    }
    throw new AppError('Nicht gefunden.',404);
} catch(AppError $e){respond($e->status,['error'=>$e->getMessage()]);}
catch(Throwable $e){error_log('Sideline request failed: '.get_class($e));respond(500,['error'=>'Ein Serverfehler ist aufgetreten. Bitte das PHP-Fehlerprotokoll prüfen.']);}
