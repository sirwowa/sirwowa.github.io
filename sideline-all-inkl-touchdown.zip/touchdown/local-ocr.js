let libraryPromise;
function library(){return libraryPromise??=new Promise((resolve,reject)=>{if(window.Tesseract)return resolve(window.Tesseract);const script=document.createElement('script');script.src=new URL('./ocr/tesseract.min.js',import.meta.url);script.onload=()=>resolve(window.Tesseract);script.onerror=()=>reject(Error('Lokale Texterkennung konnte nicht geladen werden.'));document.head.append(script);});}
export class LocalOcr{
 async read(photo){let timer;try{return await Promise.race([this.perform(photo),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Lokale Texterkennung dauert zu lange.')),25000);})]);}catch(error){const w=this.worker;this.worker=null;w?.then(worker=>worker.terminate()).catch(()=>{});throw error;}finally{clearTimeout(timer);}}
 async perform(photo){
  const Tesseract=await library();this.worker??=Tesseract.createWorker('eng',1,{workerPath:new URL('./ocr/worker.min.js',import.meta.url).href,corePath:new URL('./ocr/tesseract-core-lstm.js',import.meta.url).href,langPath:new URL('./ocr/lang/',import.meta.url).href,workerBlobURL:false,logger:()=>{}});
  const worker=await this.worker;await worker.setParameters({tessedit_pageseg_mode:'11',preserve_interword_spaces:'1'});
  const image=new Image();await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=reject;image.src=photo;});const scale=Math.min(1,2000/Math.max(image.width,image.height));const canvas=document.createElement('canvas');canvas.width=Math.round(image.width*scale);canvas.height=Math.round(image.height*scale);canvas.getContext('2d').drawImage(image,0,0,canvas.width,canvas.height);
  const {data}=await worker.recognize(canvas);return String(data.text||'').slice(0,8000);
 }
}
