<?php http_response_code(404); exit; ?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#172019"><meta name="description" content="Deine Sportkarten. Deine Sammlung. Sideline – dein persönlicher Card Collector.">
  <meta name="csrf-token" content="{{CSRF_TOKEN}}"><meta name="robots" content="noindex,nofollow"><title>Sideline · Deine Sportkarten</title><link rel="icon" href="./favicon.svg" type="image/svg+xml"><script src="./theme.js?v=2"></script><link rel="stylesheet" href="./style.css?v=2"><script src="./app.js?v=2" type="module"></script>
</head>
<body>
  <aside class="sidebar">
    <a class="brand" href="#overview"><span class="brand-icon">ϟ</span> sideline<span class="brand-dot">.</span></a>
    <span class="workspace-label">DEIN COLLECTOR SPACE</span>
    <nav aria-label="Hauptnavigation">
      <a href="#overview" data-nav="overview"><span data-icon="dashboard"></span>Übersicht</a>
      <a href="#collection" data-nav="collection"><span data-icon="cards"></span>Meine Sammlung<span id="nav-count" class="nav-count">0</span></a>
      <a href="#scan" data-nav="scan"><span data-icon="scan"></span>Karte erfassen</a>
      <a href="#checklists" data-nav="checklists"><span data-icon="cards"></span>Checklisten<span id="set-news-count" class="nav-count" hidden>0</span></a>
      <a href="#wishlist" data-nav="wishlist"><span data-icon="heart"></span>Wunschliste</a>
      <a href="#settings" data-nav="settings" class="mobile-settings"><span data-icon="settings"></span>Einstellungen</a>
    </nav>
    <div class="sidebar-bottom"><div class="private-label"><span class="status-dot"></span> Dein persönlicher Raum</div><a href="#settings" data-nav="settings"><span data-icon="settings"></span>Einstellungen</a><div class="profile"><span class="avatar">DU</span><div><strong>Meine Sammlung</strong><small>Für die Liebe zum Spiel.</small></div></div></div>
  </aside>
  <div class="app-shell">
    <header class="topbar"><span class="breadcrumb">Mein Space <span>/</span> <strong id="page-name">Übersicht</strong></span><div class="topbar-right"><button class="icon-button theme-toggle" type="button" data-theme-toggle aria-label="Dunkelmodus aktivieren">☾</button><form action="./index.php" method="post" class="logout-form"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf" value="{{CSRF_TOKEN}}"><button class="button button-quiet button-small" type="submit">Abmelden</button></form><span class="private-pill"><span data-icon="lock"></span> Deine private Sammlung</span><button class="button button-dark button-small" data-action="add"><span data-icon="plus"></span>Karte hinzufügen</button></div></header>
    <main id="main" tabindex="-1"></main>
    <footer>MADE FOR COLLECTORS. <span>Jede Karte erzählt eine Geschichte.</span></footer>
  </div>
  <dialog id="card-dialog" aria-labelledby="dialog-title">
    <form id="card-form">
      <div class="dialog-heading"><div><span class="eyebrow">DEINE NÄCHSTE ENTDECKUNG</span><h2 id="dialog-title">Karte hinzufügen</h2></div><button type="button" class="icon-button" data-action="close-dialog" aria-label="Schließen"><span data-icon="close"></span></button></div>
      <input type="hidden" name="cardsightId"><input type="hidden" name="cardsightSetId"><div class="form-body"><div class="photo-column"><label class="photo-upload" id="form-photo-label"><input type="file" id="card-photo" accept="image/jpeg,image/png,image/webp"><span id="form-photo-preview"><span data-icon="camera"></span><strong>Kartenfoto hinzufügen</strong><small>JPEG, PNG oder WebP · bis 5 MB</small></span></label><button type="button" class="button button-quiet" id="remove-photo">Foto entfernen</button><p class="field-hint">Tipp: gleichmäßiges Licht und ein gerader Blick auf die Karte machen Details sichtbar.</p></div>
      <div class="fields"><label class="full">Spielername <span class="required">*</span><input name="player" required maxlength="200" placeholder="z. B. Michael Jordan"></label><label>Sportart<select name="sport"><option>Basketball</option><option>Fußball</option><option>American Football</option><option>Baseball</option><option>Eishockey</option><option>MMA</option><option>Boxen</option><option>Wrestling</option><option>Motorsport</option><option>Golf</option><option>Tennis</option><option>Rugby</option><option>Cricket</option><option>Andere</option></select></label><label>Team<input name="team" maxlength="200" placeholder="z. B. Chicago Bulls"></label><label>Jahr / Saison<input name="year" maxlength="9" placeholder="z. B. 2024/25"></label><label>Kartennummer<input name="number" maxlength="200" placeholder="z. B. #23"></label><label class="full">Set / Hersteller<input name="set" maxlength="200" placeholder="z. B. Panini Prizm"></label><label>Parallel / Variante<input name="parallel" maxlength="200" placeholder="z. B. Silver Prizm"></label><label>Zustand<select name="condition"><option>Unbewertet</option><option>Mint</option><option>Near Mint</option><option>Excellent</option><option>Good</option><option>Fair</option></select></label><label>Grading-Anbieter<input name="grader" maxlength="200" placeholder="z. B. PSA, BGS, SGC"></label><label>Grade<input name="grade" maxlength="200" placeholder="z. B. 10"></label><label>Kaufpreis pro Karte (€)<input name="purchasePrice" type="number" min="0" max="1000000000" step="0.01" placeholder="Nicht angegeben"></label><label>Marktwert pro Karte (€)<input name="marketValue" type="number" min="0" max="1000000000" step="0.01" placeholder="Manuell geschätzt"></label><label>Anzahl<input name="quantity" type="number" required min="1" max="10000" value="1"></label><label>Ablage<select name="status"><option>Sammlung</option><option>Wunschliste</option><option>Zum Verkauf</option></select></label><label class="full">Notizen<textarea name="notes" maxlength="4000" rows="2" placeholder="Was macht diese Karte besonders?"></textarea></label><label class="checkbox-label full"><input name="favorite" type="checkbox"> Als Favorit markieren</label></div></div>
      <p id="form-error" class="form-error" role="alert"></p><div class="dialog-footer"><button type="button" class="button button-secondary" data-action="close-dialog">Abbrechen</button><button type="submit" class="button button-dark" id="save-card">Karte speichern <span data-icon="arrow"></span></button></div>
    </form>
  </dialog>
  <dialog id="detail-dialog" aria-label="Kartendetails"></dialog>
  <dialog id="confirm-dialog" aria-labelledby="confirm-title"><div class="confirm-content"><span class="eyebrow">SAMMLUNG VERWALTEN</span><h2 id="confirm-title">Karte löschen?</h2><p>Die Karte und ihr Foto werden aus deiner Sammlung entfernt. Das lässt sich nicht rückgängig machen.</p><div class="confirm-actions"><button class="button button-secondary" id="cancel-delete">Behalten</button><button class="button button-danger" id="confirm-delete">Karte löschen</button></div></div></dialog>
  <dialog id="duplicate-dialog" aria-labelledby="duplicate-title"><div class="duplicate-content"><span class="eyebrow">SCHON IN DEINER SAMMLUNG</span><h2 id="duplicate-title">Diese Karte kennst du schon.</h2><p id="duplicate-description"></p><label class="duplicate-select-label">Vorhandenen Eintrag wählen<select id="duplicate-target"></select></label><p class="field-hint">Du entscheidest, ob du die Anzahl erhöhst oder die Karte als eigenen Eintrag speicherst.</p><p id="duplicate-error" role="alert" class="form-error"></p><div class="duplicate-actions"><button class="button button-dark" data-action="duplicate-increment">Anzahl erhöhen</button><button class="button button-secondary" data-action="duplicate-separate">Als eigenen Eintrag speichern</button><button class="button button-quiet" data-action="duplicate-cancel">Abbrechen</button></div></div></dialog>
  <div id="toast" role="status" class="toast" hidden></div>
  <input type="file" id="backup-input" accept="application/json,.json" hidden>
  <noscript>Bitte aktiviere JavaScript, um deine Sammlung zu verwalten.</noscript>
</body>
</html>
