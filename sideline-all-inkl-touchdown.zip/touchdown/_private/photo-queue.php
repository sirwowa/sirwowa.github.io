<?php
declare(strict_types=1);
function pq_card(string $id): array {foreach(read_private('cards',[])as $c)if(($c['id']??'')===$id)return $c;throw new AppError('Karte nicht gefunden.',404);}
function pq_save(array $input): array {
    $image=photo_field($input['image']??'');if(!$image)throw new AppError('Bitte zuerst ein Foto aufnehmen.');
    $token=text_field($input['token']??'',80);if(!preg_match('/^[a-zA-Z0-9-]{16,80}$/D',$token))throw new AppError('Ungültige Aufnahme-ID.');
    return private_transaction('cards',function($rows)use($image,$token){$rows??=[];foreach($rows as $c)if(($c['scan']['captureToken']??'')===$token)return[$rows,$c];if(count($rows)>=1000)throw new AppError('Maximal 1.000 Karten pro Sammlung.');
        $c=validate_card(['player'=>'Neue Karte','image'=>$image,'sport'=>'Andere','catalogSource'=>'Eigenes Foto']);$c['id']=uuid();$c['createdAt']=$c['updatedAt']=now_iso();$c['scan']=['captureToken'=>$token,'queueState'=>'pending','message'=>'Wird im Hintergrund ergänzt.','attempts'=>0];$rows[]=$c;return[$rows,$c];});
}
function pq_step(string $id,array $config,?callable $identify=null): array {
    $token=bin2hex(random_bytes(16));
    $snapshot=private_transaction('cards',function($rows)use($id,$token){$rows??=[];foreach($rows as &$c)if($c['id']===$id){$s=$c['scan']??[];if(empty($s['localChecked']))throw new AppError('Bitte zuerst den lokalen Checklistenabgleich ausführen.',409);if(!in_array($s['queueState']??'',['pending','processing'],true)||($s['leaseUntil']??0)>time())return[$rows,null];$c['scan']=array_merge($s,['queueState'=>'processing','lease'=>$token,'leaseUntil'=>time()+100]);$copy=$c;unset($c);return[$rows,$copy];}throw new AppError('Karte nicht gefunden.',404);});
    if(!$snapshot)return pq_card($id);
    $state='review';$message='Keine eindeutige Erkennung. Du kannst die Angaben selbst ergänzen.';$proposal=[];$sources=[];$local=[];
    try{
        $r=$identify?$identify($snapshot):pipeline_identify(['image'=>$snapshot['image'],'segment'=>'auto'],$config);$sources=array_slice($r['providers']??[],0,10);
        $candidates=array_values(array_filter($r['detections']??[],fn($c)=>!empty($c['player'])&&($c['matchLevel']??'')==='card'&&!($c['isAlternative']??false)));
        if(count($candidates)===1){$candidate=$candidates[0];if(isset($candidate['serialNumber']))$candidate['serialNumber']=serial_read($candidate['serialNumber']);if(!preg_match('~^\d{4}(?:[-/]\d{2,4})?$~D',(string)($candidate['year']??'')))unset($candidate['year']);foreach(['cardsightId','cardsightSetId','cardsightReleaseId']as $key)if(!valid_uuid($candidate[$key]??''))unset($candidate[$key]);foreach(['player','year','set','number','serialNumber','team','jerseyNumber','position','cardType','parallel','rarity','grader','grade','certNumber','gradingBarcode','sport','cardsightId','cardsightSetId','cardsightReleaseId','localCatalogId','localSetId','catalogSource']as $k)if(is_string($candidate[$k]??null))$proposal[$k]=$candidate[$k];
            // A provider proposal can be filled automatically, but remains visibly unconfirmed.
            if(($candidate['parallelNeedsReview']??false)||!empty($candidate['isParallelOnly']))$proposal['parallel']='';
            $lookup=oc_route('own-catalog-search',['player'=>$candidate['player'],'year'=>$candidate['year']??'','number'=>$candidate['number']??''],$config);$local=array_slice($lookup['results']??[],0,6);
            if(count($local)===1&&oc_norm($local[0]['set'])===oc_norm($candidate['set']??''))foreach(['team','cardType','localCatalogId','localSetId']as $k)if(empty($proposal[$k])&&!empty($local[0][$k]))$proposal[$k]=$local[0][$k];
            $dupes=array_filter(duplicate_cards($candidate,read_private('cards',[])),fn($row)=>$row['id']!==$id);$message=$dupes?'Bereits im VAULT vorhanden · als eigenes Exemplar gespeichert. Angaben prüfen.':'Angaben automatisch ergänzt · bitte am Foto prüfen.';
        }
        $failed=array_values(array_filter($sources,fn($s)=>($s['state']??'')==='failed'));
        if(!$proposal&&$failed){$state='paused';$message='Erkennung später erneut versuchen. Foto ist gespeichert.';}
    }catch(AppError $e){$state='paused';$message=$e->status===429?'Anbieterlimit erreicht. Foto gespeichert; später erneut prüfen.':'Erkennung derzeit nicht verfügbar. Foto gespeichert; später erneut prüfen.';}
    catch(Throwable $e){$state='paused';$message='Erkennung derzeit nicht verfügbar. Foto bleibt gespeichert.';system_error_report($e,$config);}
    return private_transaction('cards',function($rows)use($id,$token,$snapshot,$state,$message,$proposal,$sources,$local){$rows??=[];foreach($rows as &$c)if($c['id']===$id){if(($c['scan']['lease']??'')!==$token)return[$rows,$c];
        if($c['updatedAt']!==$snapshot['updatedAt']){$state='review';$message='Karte zwischenzeitlich bearbeitet. Deine Angaben bleiben erhalten.';$proposal=[];}
        $patch=[];foreach($proposal as $k=>$v)if($v!==''&&(($c[$k]??'')===''||($k==='player'&&$c[$k]==='Neue Karte')||($k==='sport'&&($c[$k]??'')==='Andere')||($k==='catalogSource'&&($c[$k]??'')==='Eigenes Foto')))$patch[$k]=$v;
        if($patch){try{$validated=validate_card(array_merge($c,$patch));$c=array_merge($c,$validated);$c['updatedAt']=now_iso();}catch(AppError){$state='review';$message='Unvollständiger Vorschlag. Foto gespeichert; Angaben selbst ergänzen.';}}
        $c['scan']=array_merge($c['scan'],['queueState'=>$state,'message'=>$message,'attempts'=>($c['scan']['attempts']??0)+1,'leaseUntil'=>0,'lease'=>'','providers'=>$sources,'localMatches'=>$local]);$copy=$c;unset($c);return[$rows,$copy];}throw new AppError('Karte wurde gelöscht.',404);});
}
function pq_retry(string $id): array {return private_transaction('cards',function($rows)use($id){$rows??=[];foreach($rows as &$c)if($c['id']===$id){if(($c['scan']['leaseUntil']??0)>time())throw new AppError('Diese Karte wird bereits geprüft.',409);$c['scan']=array_merge($c['scan']??[],['queueState'=>'pending','message'=>'Erkennung wartet.','leaseUntil'=>0,'localChecked'=>false,'forceRemote'=>true]);$copy=$c;unset($c);return[$rows,$copy];}throw new AppError('Karte nicht gefunden.',404);});}

function pq_local_candidates(string $text): array {
    $n=' '.oc_norm($text).' ';$numberText=' '.oc_norm(preg_replace('~\b\d{1,6}\s*/\s*\d{1,6}\b~',' ',$text)??$text).' ';if(strlen(trim($n))<8)return [];$families=[];
    $catalog=oc_manifest()['products'];$seed=oc_seed()['products'];foreach($seed as $pid=>$entry)if(($entry['product']['source']??'')==='Degree Grading PDF')$catalog[$pid]=$entry['product'];
    foreach($catalog as $id=>$product){
        $year=substr((string)$product['year'],0,4);if(!preg_match('/\b'.preg_quote($year,'/').'\b/',$n))continue;
        $words=array_filter(explode(' ',oc_norm($product['name'])),fn($w)=>strlen($w)>2&&!in_array($w,['panini','topps','football','basketball','american','collection','base','mega','box','set','the','and','nfl'],true)&&!ctype_digit_safe($w));
        if(!$words)continue;$setMatch=false;foreach($words as $w)if(str_contains($n,' '.$w.' ')){$setMatch=true;break;}if(!$setMatch)continue;
        $people=[];foreach($product['players']??[]as $person)if(strlen($person)>4&&str_contains($n,' '.$person.' '))$people[$person]=true;if(!$people)continue;
        $fromPdf=($seed[$id]['product']['source']??'')==='Degree Grading PDF';$data=$fromPdf?read_private('nfl-seed/'.$id,$seed[$id]):oc_rows($id);foreach($data['rows']??[]as $row){if(!isset($people[oc_norm($row['player'])]))continue;$number=oc_norm(ltrim($row['number'],'#'));if($number===''||(!str_contains($numberText,' '.$number.' ')&&!str_contains($numberText,' '.str_replace(' ','',$number).' ')))continue;
            $key=$id.'|'.oc_norm($row['player']).'|'.$number;$families[$key]??=['product'=>$product,'rows'=>[],'variants'=>[]];$families[$key]['rows'][]=$row;
            foreach($data['parallelSections'][$row['sectionId']??'']??[]as $v)$families[$key]['variants'][$v]=$v;
        }
    }
    return array_values($families);
}
function ctype_digit_safe(string $value): bool {return preg_match('/^\d+$/D',$value)===1;}
function pq_local(string $id,string $text,string $version): array {
    $families=pq_local_candidates($text);
    return private_transaction('cards',function($rows)use($id,$text,$version,$families){$rows??=[];foreach($rows as &$c)if($c['id']===$id){
        if(!in_array($c['scan']['queueState']??'',['pending'],true))return[$rows,$c];
        $s=$c['scan'];$s['localChecked']=true;$s['localStatus']=$text===''?'ocr-unavailable':(count($families)===1?'family-match':'no-unique-match');
        if($c['updatedAt']!==$version){$s['queueState']='review';$s['message']='Zwischenzeitlich bearbeitet. Deine Angaben bleiben erhalten.';}
        elseif(count($families)===1){$family=$families[0];$p=$family['product'];$first=$family['rows'][0];
            $patch=['player'=>$first['player'],'year'=>$p['year'],'set'=>$p['name'],'number'=>$first['number'],'catalogSource'=>$p['source'],'sport'=>$p['sport']??'American Football','localSetId'=>$p['id']];
            if(count($family['rows'])===1){$patch['localCatalogId']=$first['id'];foreach(['team','cardType']as $k)if(!empty($first[$k]))$patch[$k]=$first[$k];}
            foreach($patch as $k=>$v)if($v!==''&&(($c[$k]??'')===''||($k==='player'&&$c[$k]==='Neue Karte')||($k==='sport'&&($c[$k]??'')==='Andere')||($k==='catalogSource'&&($c[$k]??'')==='Eigenes Foto')))$c[$k]=$v;
            // Family text does not establish a parallel; no default Base or invented serial.
            $c['updatedAt']=now_iso();$s['queueState']=!empty($s['forceRemote'])?'pending':'review';$s['message']=!empty($s['forceRemote'])?'Lokaler Abgleich abgeschlossen · weitere Ergänzung läuft.':'Lokal mit deiner Checkliste abgeglichen · Parallelvariante am Foto prüfen.';$s['localVariants']=array_values($family['variants']);$s['localMatchCount']=count($family['rows']);$stamps=[];preg_match_all('~\b\d{1,6}\s*/\s*\d{1,6}\b~',$text,$stamps);$serials=array_values(array_unique(array_filter(array_map('serial_read',$stamps[0]??[]))));if(count($serials)===1&&empty($c['serialNumber']))$c['serialNumber']=$serials[0];
        }
        $c['scan']=$s;$copy=$c;unset($c);return[$rows,$copy];}throw new AppError('Karte nicht gefunden.',404);});
}
