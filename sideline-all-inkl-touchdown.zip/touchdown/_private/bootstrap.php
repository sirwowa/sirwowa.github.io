<?php
declare(strict_types=1);

const PRIVATE_PREFIX = "<?php http_response_code(404); exit; ?>\n";
const DATA_LIMIT = 60000000;
final class AppError extends RuntimeException {
    public function __construct(string $message, public int $status = 400, public array $details = []) { parent::__construct($message); }
}
function h(mixed $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function private_path(string $name): string { return __DIR__ . '/' . $name . '.php'; }
function read_private(string $name, mixed $fallback = null): mixed {
    $path = private_path($name);
    if (!is_file($path)) return $fallback;
    $raw = file_get_contents($path);
    if ($raw === false || !str_starts_with($raw, PRIVATE_PREFIX)) throw new AppError('Eine Speicherdatei kann nicht gelesen werden. Bitte aus einem Backup wiederherstellen.', 500);
    return json_decode(substr($raw, strlen(PRIVATE_PREFIX)), true, 64, JSON_THROW_ON_ERROR);
}
function private_transaction(string $name, callable $callback): mixed {
    $handle = fopen(private_path($name . '-lock'), 'c+');
    if (!$handle || !flock($handle, LOCK_EX)) throw new AppError('Der Speicher ist nicht beschreibbar. Bitte die Dateirechte des Ordners _private prüfen.', 503);
    $temp = null;
    try {
        if (fstat($handle)['size'] === 0) { fwrite($handle, PRIVATE_PREFIX); fflush($handle); }
        $current = read_private($name);
        [$next, $result] = $callback($current);
        $bytes = PRIVATE_PREFIX . json_encode($next, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $temp = __DIR__ . '/tmp-' . bin2hex(random_bytes(12)) . '.php';
        if (file_put_contents($temp, $bytes) !== strlen($bytes)) throw new AppError('Speichern fehlgeschlagen. Bitte den freien Webspace prüfen.', 503);
        chmod($temp, 0600);
        if (!rename($temp, private_path($name))) throw new AppError('Die Speicherdatei konnte nicht ersetzt werden.', 503);
        return $result;
    } finally {
        if ($temp && is_file($temp)) unlink($temp);
        flock($handle, LOCK_UN); fclose($handle);
    }
}
function security_headers(): void {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: no-store');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    header('Permissions-Policy: camera=(self), microphone=()');
}
function https_request(): bool { return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int)($_SERVER['SERVER_PORT'] ?? 0) === 443; }
function localhost_request(): bool { return in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1','::1'], true); }
function start_session(): void {
    $base = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
    session_name('sideline_' . substr(hash('sha256', __DIR__), 0, 12));
    session_set_cookie_params(['lifetime'=>0,'path'=>rtrim($base, '/') . '/', 'secure'=>https_request(),'httponly'=>true,'samesite'=>'Strict']);
    ini_set('session.use_strict_mode', '1');
    session_start();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
    if (!empty($_SESSION['last_seen']) && time() - $_SESSION['last_seen'] > 43200) unset($_SESSION['authenticated']);
    if (!empty($_SESSION['authenticated'])) $_SESSION['last_seen'] = time();
}
function check_csrf(string $token): void {
    if (!$token || !hash_equals($_SESSION['csrf'] ?? '', $token)) throw new AppError('Deine Sitzung ist abgelaufen. Bitte die Seite neu laden.', 403);
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    // A no-referrer HTML form navigation can send Origin: null. The unguessable
    // session CSRF token above is still mandatory for every state-changing request.
    if ($origin && $origin !== 'null') {
        $parsed = parse_url($origin);
        $host = ($parsed['host'] ?? '') . (isset($parsed['port']) ? ':' . $parsed['port'] : '');
        if (strtolower($host) !== strtolower($_SERVER['HTTP_HOST'] ?? '')) throw new AppError('Zugriff von einer fremden Website abgelehnt.', 403);
    }
}
function authenticated(): bool { return !empty($_SESSION['authenticated']); }
function login_user(): void {
    session_regenerate_id(true);
    $_SESSION['authenticated'] = true; $_SESSION['last_seen'] = time(); $_SESSION['csrf'] = bin2hex(random_bytes(24));
}
function login_rate(bool $failed = false, bool $clear = false): void {
    private_transaction('attempts', function($all) use ($failed, $clear) {
        $all = is_array($all) ? $all : [];
        $now = time();
        $all = array_filter($all, fn($entry) => $entry['until'] > $now);
        $id = hash('sha256', $_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $entry = $all[$id] ?? ['count'=>0,'until'=>$now+900];
        if (!$clear && $entry['count'] >= 8) throw new AppError('Zu viele Anmeldeversuche. Bitte in 15 Minuten erneut versuchen.', 429);
        if ($failed) { $entry['count']++; $all[$id] = $entry; }
        if ($clear) unset($all[$id]);
        return [array_slice($all, -500, null, true), null];
    });
}
function text_field(mixed $value, int $max = 200): string {
    if (!is_string($value) || strlen($value) > $max * 4 || preg_match('//u', $value) !== 1) throw new AppError('Ein Textfeld ist ungültig oder zu lang.');
    $value = trim($value);
    if (preg_match_all('/./us', $value) > $max) throw new AppError('Ein Textfeld ist zu lang.');
    return $value;
}
function money_field(mixed $value): ?float {
    if ($value === '' || $value === null) return null;
    if ((!is_int($value) && !is_float($value)) || !is_finite((float)$value) || $value < 0 || $value > 1e9) throw new AppError('Bitte einen gültigen Betrag zwischen 0 und 1 Milliarde eingeben.');
    return round((float)$value, 2);
}
function photo_field(mixed $photo): string {
    if ($photo === '' || $photo === null) return '';
    if (!is_string($photo) || strlen($photo) > 7000000 || !preg_match('~^data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$~D', $photo, $parts)) throw new AppError('Bitte ein JPEG-, PNG- oder WebP-Foto bis 5 MB wählen.');
    $bytes = base64_decode($parts[2], true);
    $info = $bytes === false ? false : @getimagesizefromstring($bytes);
    if ($bytes === false || strlen($bytes) > 5*1024*1024 || !$info || $info['mime'] !== 'image/' . $parts[1]) throw new AppError('Das Foto ist ungültig oder größer als 5 MB.');
    return $photo;
}
function validate_card(mixed $input): array {
    if (!is_array($input) || array_is_list($input)) throw new AppError('Ungültige Karte.');
    $c = [];
    foreach (['player','team','set','number','parallel','grader','grade','jerseyNumber','position','cardType','certNumber','gradingBarcode','language','rarity','localCatalogId','localSetId','catalogSource'] as $key) $c[$key] = text_field($input[$key] ?? '');
    if (!$c['player']) throw new AppError('Bitte einen Spielernamen eingeben.');
    $c['notes'] = text_field($input['notes'] ?? '', 4000);
    $c['year'] = text_field($input['year'] ?? '', 9);
    if ($c['year'] && !preg_match('~^\d{4}(?:[-/]\d{2,4})?$~D', $c['year'])) throw new AppError('Jahr bitte als 2024 oder 2024/25 eingeben.');
    $c['cardsightId'] = text_field($input['cardsightId'] ?? '', 80);
    if ($c['cardsightId'] && !preg_match('/^[a-f0-9-]{36}$/iD', $c['cardsightId'])) throw new AppError('Ungültige Cardsight-ID.');
    $c['cardsightReleaseId']=text_field($input['cardsightReleaseId']??'',80);if($c['cardsightReleaseId']&&!preg_match('/^[a-f0-9-]{36}$/iD',$c['cardsightReleaseId']))throw new AppError('Ungültige Release-ID.');
    $c['cardsightSetId'] = text_field($input['cardsightSetId'] ?? '',80);
    if($c['cardsightSetId']&&!preg_match('/^[a-f0-9-]{36}$/iD',$c['cardsightSetId']))throw new AppError('Ungültige Cardsight-Set-ID.');
    $c['sport']=text_field($input['sport']??'Andere',80);
    if(!$c['sport'])throw new AppError('Bitte eine Sportart oder Kategorie angeben.');
    $enums = ['condition'=>['Unbewertet','Mint','Near Mint','Excellent','Good','Fair'],'status'=>['Sammlung','Wunschliste','Zum Verkauf']];
    foreach ($enums as $key=>$allowed) { $c[$key]=$input[$key] ?? $allowed[0]; if (!in_array($c[$key],$allowed,true)) throw new AppError('Ungültiges Feld: ' . $key); }
    foreach (['purchasePrice','marketValue'] as $key) $c[$key] = money_field($input[$key] ?? null);
    $c['quantity'] = $input['quantity'] ?? 1;
    if (!is_int($c['quantity']) || $c['quantity'] < 1 || $c['quantity'] > 10000) throw new AppError('Anzahl muss zwischen 1 und 10.000 liegen.');
    $c['favorite'] = ($input['favorite'] ?? false) === true;
    $c['catalogImage']=($input['catalogImage']??false)===true;
    $c['image'] = photo_field($input['image'] ?? '');
    $c['backImage'] = photo_field($input['backImage'] ?? '');
    return $c;
}
function json_body(int $limit = 16000000): array {
    if (!str_starts_with(strtolower($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) throw new AppError('Content-Type application/json ist erforderlich.', 415);
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > $limit) throw new AppError('Die Anfrage ist zu groß.', 413);
    $raw = file_get_contents('php://input', false, null, 0, $limit+1);
    if ($raw === false || strlen($raw) > $limit) throw new AppError('Die Anfrage ist zu groß.', 413);
    try { $input=json_decode($raw,true,64,JSON_THROW_ON_ERROR); } catch (JsonException) { throw new AppError('Ungültiges JSON.'); }
    if (!is_array($input)) throw new AppError('Ungültige Anfrage.');
    return $input;
}
function uuid(): string {
    $b=random_bytes(16);$b[6]=chr((ord($b[6])&15)|64);$b[8]=chr((ord($b[8])&63)|128);$hex=bin2hex($b);
    return substr($hex,0,8).'-'.substr($hex,8,4).'-'.substr($hex,12,4).'-'.substr($hex,16,4).'-'.substr($hex,20);
}
function now_iso(): string { return gmdate('Y-m-d\TH:i:s') . '.' . substr(explode(' ',microtime())[0],2,3) . 'Z'; }
require_once __DIR__.'/usage-limit.php';
function cardsight_http(string $path, string $key, ?string $bytes = null, ?string $mime = null): array {
    if (!$key) throw new AppError('Bitte den Cardsight-Schlüssel unter Einstellungen hinterlegen.', 503);
    if (!function_exists('curl_init')) throw new AppError('PHP-cURL fehlt. Bitte im Hosting aktivieren.', 503);
    cardsight_rate_gate();
    quota_reserve($path);
    $ch=curl_init('https://api.cardsight.ai'.$path);
    $headers=['X-API-Key: '.$key,'Accept: */*','User-Agent: Sideline/1.0'];
    if ($mime) $headers[]='Content-Type: '.$mime;
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>45,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_HTTPHEADER=>$headers,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS]);
    if ($bytes !== null) curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$bytes]);
    $raw=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$type=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE);$errno=curl_errno($ch);curl_close($ch);
    if ($raw === false) throw new AppError($errno===CURLE_OPERATION_TIMEDOUT?'Cardsight hat zu lange gebraucht. Bitte erneut versuchen.':'Cardsight ist nicht erreichbar. Prüfe ausgehende HTTPS-Verbindungen bei ALL-INKL.',502);
    if ($status<200 || $status>=300) throw new AppError(match($status){401=>'Cardsight hat den API-Schlüssel abgelehnt.',403=>'Dein Cardsight-Zugang erlaubt diese Funktion nicht.',404=>'Für diese Karte liegen die angefragten Cardsight-Daten nicht vor.',429=>'Das Cardsight-Anfragelimit ist erreicht. Bitte später erneut versuchen.',400=>'Cardsight konnte die Anfrage nicht verarbeiten.',default=>'Cardsight ist momentan nicht verfügbar.'},$status===404?404:($status===429?429:502));
    return ['body'=>$raw,'type'=>strtolower(trim(explode(';',$type)[0]))];
}
function cardsight_request(string $path,string $key,?string $bytes=null,?string $mime=null): array {
    $raw=cardsight_http($path,$key,$bytes,$mime)['body'];
    try { $result=json_decode($raw,true,64,JSON_THROW_ON_ERROR); } catch (JsonException) { throw new AppError('Unerwartete Antwort von Cardsight.',502); }
    if (!is_array($result)) throw new AppError('Unerwartete Antwort von Cardsight.',502);
    return $result;
}
function clean_api_text(mixed $v): string { return is_string($v) ? preg_replace('/^((?:.|\n){0,200}).*$/us','$1',$v) ?? '' : ''; }
function map_detection(array $d, string $segment): array {
    $c=$d['card']??[];
    return array_merge(card_metadata($c), ['certNumber'=>clean_api_text($d['grading']['certNumber']??''),'parallelSuggestions'=>array_values(array_map(fn($p)=>['name'=>clean_api_text($p['name']??''),'confidence'=>clean_api_text($p['confidence']??'')],$c['parallelSuggestions']??[])),'parallelNeedsReview'=>empty($c['parallelSuggestions'])||count($c['parallelSuggestions']??[])>1||(!empty($c['parallelSuggestions'])&&($c['parallelSuggestions'][0]['confidence']??'')!=='High'),'player'=>clean_api_text($c['name']??''),'set'=>clean_api_text(implode(' · ',array_unique(array_filter([$c['releaseName']??'',$c['setName']??''])))),'year'=>clean_api_text($c['year']??''),'number'=>clean_api_text($c['number']??''),'parallel'=>clean_api_text($c['parallelSuggestions'][0]['name']??''),'grader'=>clean_api_text($d['grading']['company']['name']??''),'grade'=>clean_api_text($d['grading']['grade']['value']??''),'sport'=>$segment==='football'?'American Football':'Basketball','cardsightId'=>clean_api_text($c['id']??''),'cardsightReleaseId'=>clean_api_text($c['releaseId']??''),'cardsightSetId'=>clean_api_text($c['setId']??''),'confidence'=>in_array($d['confidence']??'', ['High','Medium','Low'],true)?$d['confidence']:'Low','matchLevel'=>!empty($c['id'])?'card':(!empty($c['setId'])?'set':'none')]);
}

function brand_logo_markup(): string {
    if(is_file(dirname(__DIR__).'/logo.png'))return '<img class="brand-logo" src="./logo.png" alt="Touchdown Collector">';
    return '<span class="brand-wordmark">TOUCHDOWN<span>COLLECTOR</span></span>';
}
function brand_favicon(): string { return is_file(dirname(__DIR__).'/logo.png')?'./logo.png':'./favicon.svg'; }

function card_metadata(array $card): array {
    $fields=[];foreach($card['fields']??[] as $f){if(is_array($f))$fields[strtoupper(str_replace([' ','-'],'_', (string)($f['key']??'')))]=clean_api_text($f['value']??'');}
    $get=function(array $keys)use($fields){foreach($keys as $key)if(!empty($fields[$key]))return $fields[$key];return '';};
    $attrs=array_filter($card['attributes']??[],'is_string');
    return ['language'=>$get(['LANGUAGE','LANG']),'rarity'=>$get(['RARITY']),'team'=>$get(['TEAM','TEAM_NAME','CLUB']),'jerseyNumber'=>$get(['JERSEY_NUMBER','JERSEY_NO']),'position'=>$get(['POSITION','PLAYER_POSITION']),'cardType'=>implode(', ',$attrs)];
}
