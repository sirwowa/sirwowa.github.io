import UIKit
import SwiftUI

struct ScannerView: View {
    @EnvironmentObject private var store: SidelineStore
    @Environment(\.scenePhase) private var phase
    @StateObject private var camera = CameraController()
    @State private var candidates: [CardRecord] = []
    @State private var photo: UIImage?
    @State private var reviewing = false
    @State private var catalog = false
    @State private var processing = false
    @State private var active = false
    @State private var status = "Eine Karte in den Rahmen halten"
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                CameraPreview(controller: camera)
                let frame = CameraController.frame(in: geometry.size)
                RoundedRectangle(cornerRadius: 14).stroke(.cyan, lineWidth: 3).frame(width: frame.width, height: frame.height).position(x: frame.midX, y: frame.midY).allowsHitTesting(false)
                VStack(spacing: 12) {
                    Text(status).font(.callout.bold()).padding(10).background(.ultraThinMaterial, in: Capsule()).padding(.top, 12)
                    Spacer()
                    if processing { ProgressView("Karte wird analysiert …").padding().background(.ultraThickMaterial, in: Capsule()) }
                    HStack(spacing: 32) {
                        Button { camera.stop(); catalog = true } label: { Label("Nummer", systemImage: "number").labelStyle(.iconOnly).font(.title2) }.accessibilityLabel("Karte über Nummer suchen").disabled(processing)
                        Button { camera.take() } label: { Circle().fill(.white).frame(width: 68, height: 68).padding(6).overlay(Circle().stroke(.white, lineWidth: 3)) }.accessibilityLabel("Karte fotografieren und erkennen").disabled(!camera.ready || processing || reviewing)
                        Toggle("Auto-Scan", isOn: $camera.automatic).labelsHidden().accessibilityLabel("Auto-Scan")
                    }.padding(16).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24)).padding(.horizontal, 20).padding(.bottom, 12)
                }
            }.background(.black)
                .onAppear { camera.viewport = geometry.size }
                .onChange(of: geometry.size) { _, size in camera.viewport = size }
        }.navigationTitle("Scannen").navigationBarTitleDisplayMode(.inline)
            .onAppear { active = true; camera.onPhoto = { image in photo = image; Task { await identify(image) } }; camera.start() }
            .onDisappear { active = false; camera.stop() }
            .onChange(of: phase) { _, newPhase in if newPhase == .active && active && !catalog { camera.start() } else { camera.stop() } }
            .onChange(of: camera.error) { _, error in if let error { store.message = error; camera.error = nil } }
            .onChange(of: store.message) { _, _ in camera.suspended = processing || reviewing || store.message != nil }
            .sheet(isPresented: $reviewing, onDismiss: reset) { ReviewView(candidates: candidates, photo: photo) { reviewing = false } }
            .sheet(isPresented: $catalog, onDismiss: { if active && phase == .active { camera.start() } }) { CatalogSearchView { record in candidates = [record]; photo = nil; catalog = false; DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { reviewing = true; camera.suspended = true } } }
    }
    @MainActor private func identify(_ image: UIImage) async {
        processing = true; camera.suspended = true; status = "Cardsight sucht deine Karte …"
        defer { processing = false; if !reviewing && store.message == nil { camera.suspended = false } }
        do {
            guard let data = image.jpegData(compressionQuality: 0.94), data.count < 10_000_000 else { throw ServerError(status: 400, message: "Aufnahme zu groß oder nicht lesbar.", isDuplicate: false) }
            let result = try await store.api.request("identify", method: "POST", body: ["segment": "auto", "image": "data:image/jpeg;base64," + data.base64EncodedString()]) as? [String: Any] ?? [:]
            candidates = (result["detections"] as? [[String: Any]] ?? []).map(CardRecord.init)
            guard !candidates.isEmpty else { status = "Kein Treffer · leicht kippen und erneut aufnehmen"; return }
            reviewing = true; status = "Vorschlag gefunden · Karte und Variante prüfen"
            if candidates.contains(where: { $0.text("matchLevel") == "card" }) { store.celebrate(candidates[0].player, saved: false) }
        } catch { store.message = error.localizedDescription; status = "Erneut aufnehmen oder über Nummer suchen" }
    }
    private func reset() { candidates = []; photo = nil; processing = false; camera.suspended = store.message != nil; status = "Nächste Karte in den Rahmen halten" }
}

struct ReviewView: View {
    @EnvironmentObject private var store: SidelineStore
    let candidates: [CardRecord]
    let photo: UIImage?
    let completed: () -> Void
    @State private var draft: CardRecord
    @State private var parallels: [String] = []
    @State private var reference: UIImage?
    @State private var busy = false
    @State private var errorMessage: String?
    @State private var duplicate = false
    @State private var correcting = false
    @State private var explicitBase = false
    @State private var cardVaultChoices: [CardRecord] = []
    @State private var geminiReading: GeminiReading?
    @State private var geminiAcknowledged = false
    @State private var metadataNotice = ""
    private var geminiMismatch: Bool { geminiReading?.conflicts(with: draft) ?? false }
    init(candidates: [CardRecord], photo: UIImage?, completed: @escaping () -> Void) { self.candidates = candidates; self.photo = photo; self.completed = completed; _draft = State(initialValue: candidates.first ?? CardRecord([:])) }
    private func field(_ key: String) -> Binding<String> { Binding(get: { draft.text(key) }, set: { draft.fields[key] = $0; draft.fields["_metadataDone"] = false; geminiReading = nil; geminiAcknowledged = false }) }
    private var valid: Bool { !draft.text("player").isEmpty && (!draft.text("cardsightId").isEmpty || !draft.text("localCatalogId").isEmpty || ["AI CardVault", "Gemini", "TheCardAPI"].contains(draft.text("catalogSource"))) && draft.text("matchLevel") != "set" && draft.fields["sportNeedsReview"] as? Bool != true }
    var body: some View {
        NavigationStack {
            Form {
                if let photo { Section("Dein Kartenfoto") { Image(uiImage: photo).resizable().scaledToFit().frame(maxWidth: .infinity).frame(height: 230) } }
                Section("Vorschlag prüfen") {
                    Text(draft.player).font(.title2.bold()); Text(draft.subtitle)
                    Text("Anbieter: \(draft.text("confidence").isEmpty ? "keine Sicherheitseinstufung" : draft.text("confidence")) · Auch High kann falsch sein. Spieler, Set, Jahr und Nummer selbst vergleichen.").font(.footnote).foregroundStyle(.secondary)
                    if candidates.count > 1 { ForEach(candidates) { candidate in Button(candidate.player + " · " + candidate.subtitle) { draft = candidate; reference = nil; parallels = []; explicitBase = false } } }
                    if let alternatives = draft.fields["alternatives"] as? [[String: Any]], !alternatives.isEmpty { DisclosureGroup("Weitere vorgeschlagene Karten") { ForEach(Array(alternatives.enumerated()), id: \.offset) { _, value in let alternative = CardRecord(value); Button(alternative.player + " · " + alternative.subtitle) { draft = alternative; reference = nil; parallels = []; explicitBase = false } } } }
                    Button("Falscher Treffer? Über Nummer suchen") { correcting = true }
                }
                Section("Kartenangaben automatisch ergänzen") {
                    ForEach([("team", "Verein"), ("jerseyNumber", "Trikotnummer"), ("position", "Position"), ("cardType", "Kartentyp")], id: \.0) { key, title in LabeledContent(title, value: draft.text(key).isEmpty ? "Noch nicht verfügbar" : draft.text(key)) }
                    Text("Verfügbare Daten werden vor dem Speichern automatisch ergänzt und ausgeschrieben. Bei aktiviertem Gemini kann dafür dein Foto an Google gesendet werden. Unbekannte Angaben bleiben offen.").font(.footnote)
                }
                Section("Zweite Bilderkennung · AI CardVault") {
                    if photo != nil { Button("Foto zusätzlich mit AI CardVault erkennen") { Task { await readCardVault() } }.disabled(busy) }
                    Text("Sendet den Fotoausschnitt auf Knopfdruck an AI CardVault. Keine sichere Identitäts- oder Echtheitsbestätigung; auch hohe Anbieterwerte selbst prüfen.").font(.footnote)
                    ForEach(cardVaultChoices) { choice in Button(choice.player + " · " + choice.subtitle) { draft = choice; geminiAcknowledged = false } }
                    if draft.fields["sportNeedsReview"] as? Bool == true {
                        Picker("Sportart bestätigen", selection: Binding(get: { draft.fields["sportNeedsReview"] as? Bool == true ? "" : draft.text("sport") }, set: { draft.fields["sport"] = $0; draft.fields["sportNeedsReview"] = $0.isEmpty; draft.fields["_metadataDone"] = false; geminiReading = nil; geminiAcknowledged = false })) {
                            Text("Bitte wählen").tag(""); ForEach(["American Football", "Basketball", "Baseball", "Eishockey", "Fußball", "Andere"], id: \.self) { Text($0).tag($0) }
                        }
                    }
                }
                Section("Scan+ · Google Gemini") {
                    if photo != nil { Button("Kartentext mit Gemini prüfen") { Task { await readGemini() } }.disabled(busy) }
                    Text("Bei aktivierter automatischer Prüfung wird der Fotoausschnitt an Google gesendet. Gemini muss in den Web-Einstellungen aktiviert sein. KI-Abschrift, kein Katalog- oder Echtheitsnachweis.").font(.footnote)
                    if !metadataNotice.isEmpty { Text(metadataNotice).font(.footnote) }
                    if let geminiReading { Text(geminiReading.description).textSelection(.enabled) }
                    if geminiMismatch { Text("Gemini-Text und Cardsight-Vorschlag weichen ab. Spieler, Jahr, Set, Nummer und Parallelvariante prüfen oder im Katalog korrigieren.").foregroundStyle(.orange); Toggle("Karte und Parallelvariante selbst geprüft", isOn: $geminiAcknowledged) }
                }
                Section("Variante selbst auswählen") {
                    TextField(explicitBase ? "Base bewusst gewählt" : "Variante noch nicht bestimmt", text: field("parallel")).onChange(of: draft.text("parallel")) { _, value in if !value.isEmpty { explicitBase = false } }
                    Text("Eine fehlende Variantenangabe bedeutet nicht automatisch Base. Prüfe Farbe, Muster und Seriennummer.").font(.footnote)
                    Button("Base bewusst wählen") { draft.fields["parallel"] = "Base"; draft.fields["_metadataDone"] = false; geminiReading = nil; geminiAcknowledged = false; explicitBase = true }
                    if !draft.text("cardsightId").isEmpty {
                        Button("Katalogvarianten laden · 1 Anfrage") { Task { await loadParallels() } }.disabled(busy)
                        ForEach(parallels, id: \.self) { name in Button(name) { draft.fields["parallel"] = name; draft.fields["_metadataDone"] = false; geminiReading = nil; geminiAcknowledged = false; explicitBase = false } }
                        Button("Katalogbild zum Vergleichen laden · 1 Anfrage") { Task { busy = true; defer { busy = false }; do { reference = UIImage(data: try await store.api.image(id: draft.text("cardsightId"))); if reference == nil { errorMessage = "Kein Bild verfügbar." } } catch { errorMessage = error.localizedDescription } } }.disabled(busy)
                        if let reference { Image(uiImage: reference).resizable().scaledToFit().frame(maxWidth: .infinity).frame(height: 260) }
                    }
                }
                Section { DisclosureGroup("Grading prüfen") { TextField("Anbieter", text: field("grader")); TextField("Note", text: field("grade")); TextField("Zertifikatsnummer", text: field("certNumber")) } }
                Section {
                    Button { Task { await save() } } label: { HStack { Text("Stimmt · speichern"); if busy { ProgressView() } } }.disabled(busy || !valid || (geminiMismatch && !geminiAcknowledged))
                    Button("Falsch · neue Aufnahme", role: .cancel) { completed() }.disabled(busy)
                    if !valid { Text("Bitte zuerst eine vollständige Karte im Katalog auswählen. Ein reiner Set-Treffer reicht nicht zum Speichern.").font(.footnote) }
                }
            }.navigationTitle("Treffer prüfen").navigationBarTitleDisplayMode(.inline)
                .interactiveDismissDisabled(busy)
                .onChange(of: draft.id) { _, _ in geminiAcknowledged = false; geminiReading = nil }
                .task(id: draft.id) { await prepareMetadata() }
                .sheet(isPresented: $correcting) { CatalogSearchView { value in draft = value; parallels = []; reference = nil; explicitBase = false; correcting = false } }
                .alert(duplicate ? "Karte bereits vorhanden" : "Sideline", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) { Button(duplicate ? "Verstanden · nächste Karte" : "Verstanden") { errorMessage = nil; if duplicate { completed() } } } message: { Text(errorMessage ?? "") }
        }
    }
    @MainActor private func loadParallels() async {
        busy = true; defer { busy = false }
        do { let data = try await store.api.request("parallel-options", method: "POST", body: ["id": draft.text("cardsightId")]) as? [String: Any] ?? [:]; parallels = (data["parallels"] as? [[String: Any]] ?? []).compactMap { $0["name"] as? String } } catch { errorMessage = error.localizedDescription }
    }
    @MainActor private func readCardVault() async {
        guard let bytes = photo?.jpegData(compressionQuality: 0.94) else { return }
        busy = true; defer { busy = false }
        do { let reply = try await store.api.request("cardvault-identify", method: "POST", body: ["image": "data:image/jpeg;base64," + bytes.base64EncodedString()]) as? [String: Any] ?? [:]
            cardVaultChoices = (reply["detections"] as? [[String: Any]] ?? []).map(CardRecord.init)
            if cardVaultChoices.isEmpty { errorMessage = reply["reviewReason"] as? String ?? "AI CardVault hat keine eindeutige Karte gefunden." }
        } catch { errorMessage = error.localizedDescription }
    }
    @MainActor private func readGemini() async {
        guard let bytes = photo?.jpegData(compressionQuality: 0.94) else { return }
        busy = true; defer { busy = false }
        do { let reply = try await store.api.request("gemini-read", method: "POST", body: ["image": "data:image/jpeg;base64," + bytes.base64EncodedString(), "card": draft.fields]) as? [String: Any] ?? [:]
            geminiReading = GeminiReading(json: reply["reading"] as? [String: Any] ?? [:]); geminiAcknowledged = false
        } catch { errorMessage = error.localizedDescription }
    }
    @MainActor private func prepareMetadata() async {
        if draft.fields["_metadataDone"] as? Bool != true {
            busy = true
            do {
                let keys = ["player", "year", "set", "number", "sport", "team", "position", "jerseyNumber", "cardType", "cardsightId", "parallel"]
                let card = Dictionary(uniqueKeysWithValues: keys.map { ($0, draft.text($0)) })
                let bytes = photo?.jpegData(compressionQuality: 0.94)
                let image = bytes.map { "data:image/jpeg;base64," + $0.base64EncodedString() } ?? ""
                let reply = try await store.api.request("autofill-card", method: "POST", body: ["card": card, "image": image]) as? [String: Any] ?? [:]
                metadataNotice = (reply["warnings"] as? [String] ?? []).joined(separator: " ")
                if let fields = reply["fields"] as? [String: String] { for (key, value) in fields { draft.fields[key] = value } }
                if let values = reply["gemini"] as? [String: Any] { geminiAcknowledged = false; geminiReading = GeminiReading(json: values) }
            } catch { errorMessage = "Einzelne Angaben konnten nicht ergänzt werden: " + error.localizedDescription }
            draft.fields["_metadataDone"] = true; busy = false
        }
    }
    @MainActor private func save() async {
        await prepareMetadata()
        if geminiMismatch && !geminiAcknowledged { errorMessage = "Bitte die Abweichung zuerst prüfen."; return }
        draft.fields["geminiNeedsReview"] = geminiMismatch; draft.fields["geminiAcknowledged"] = geminiAcknowledged
        busy = true; defer { busy = false }; duplicate = false
        do { try await store.save(draft, photo: photo); completed() }
        catch let error as ServerError where error.isDuplicate { duplicate = true; errorMessage = "\(draft.player) ist bereits im VAULT. Der Bestand wurde nicht erhöht." }
        catch { errorMessage = error.localizedDescription }
    }
}

struct CatalogSearchView: View {
    @EnvironmentObject private var store: SidelineStore
    @Environment(\.dismiss) private var dismiss
    let selected: (CardRecord) -> Void
    @State private var number = ""
    @State private var year = String(Calendar.current.component(.year, from: Date()))
    @State private var manufacturer = ""
    @State private var player = ""
    @State private var rows: [CardRecord] = []
    @State private var busy = false
    @State private var message = ""
    var body: some View {
        NavigationStack { Form {
            Section("Kartendaten") { TextField("Kartennummer", text: $number); TextField("Jahr", text: $year).keyboardType(.numberPad); TextField("Hersteller, z. B. Topps oder Panini", text: $manufacturer); TextField("Spielername (optional)", text: $player); Button("Im Cardsight-Katalog suchen") { Task { await search() } }.disabled(busy || number.isEmpty || year.count != 4 || manufacturer.isEmpty); Text("Die Suche und das Laden einer Karte verbrauchen Anbieteranfragen.").font(.footnote) }
            if !message.isEmpty { Section { Text(message) } }
            Section("Katalogtreffer") { ForEach(rows) { record in
                VStack(alignment: .leading, spacing: 10) { Text(record.player).font(.headline); Text(record.subtitle).font(.caption)
                    if record.fields["parallelOnly"] as? Bool != true { Button("Karte wählen") { Task { await choose(record, parallel: "") } }.disabled(busy) }
                    if let variants = record.fields["parallels"] as? [[String: Any]] { ForEach(Array(variants.enumerated()), id: \.offset) { _, p in if let name = p["name"] as? String { Button("Variante: " + name) { Task { await choose(record, parallel: name) } }.disabled(busy) } } }
                }
            } }
        }.navigationTitle("Nach Nummer suchen").toolbar { Button("Schließen") { dismiss() } } }
    }
    @MainActor private func search() async {
        busy = true; defer { busy = false }; rows = []
        do { let reply = try await store.api.request("catalog-number", method: "POST", body: ["number": number, "year": year, "manufacturer": manufacturer, "player": player, "skip": 0]) as? [String: Any] ?? [:]; rows = (reply["cards"] as? [[String: Any]] ?? []).map(CardRecord.init); let total = reply["total"] as? Int ?? rows.count; message = "\(rows.count) von \(total) Treffern. Bei mehr als 20 Treffern bitte Hersteller und Spielernamen genauer eingeben." } catch { message = error.localizedDescription }
    }
    @MainActor private func choose(_ record: CardRecord, parallel: String) async {
        busy = true; defer { busy = false }
        if record.text("catalogSource") == "TheCardAPI" { var row = record.fields; row["parallel"] = parallel; row["matchLevel"] = "card"; selected(CardRecord(row)); return }
        do { if var row = try await store.api.request("catalog-card", method: "POST", body: ["id": record.text("cardsightId").isEmpty ? record.id : record.text("cardsightId"), "parallel": parallel, "sport": record.text("sport")]) as? [String: Any] { row["matchLevel"] = "card"; selected(CardRecord(row)) } } catch { message = error.localizedDescription }
    }
}
