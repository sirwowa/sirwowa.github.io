import Foundation

struct GeminiReading {
    let values: [String: String]
    let verification: [String: String]
    init(json: [String: Any]) {
        values = json.compactMapValues { $0 as? String }
        verification = json["verification"] as? [String: String] ?? [:]
    }
    func normalized(_ text: String) -> [String] {
        text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "en_US_POSIX"))
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty && !["jr", "sr", "ii", "iii", "iv"].contains($0) }
    }
    func conflicts(with card: CardRecord) -> Bool {
        let a = normalized(values["player"] ?? ""), b = normalized(card.player)
        let names = a.count >= 2 && b.count >= 2 && (a.last != b.last || !(a.first == b.first || ((a.first?.count == 1 || b.first?.count == 1) && a.first?.first == b.first?.first)))
        let number = normalized(values["number"] ?? ""), other = normalized(card.text("number"))
        let uncertain = !verification.isEmpty && (verification["identity"] != "match" || verification["parallel"] != "match")
        return uncertain || names || (!number.isEmpty && !other.isEmpty && number != other)
    }
    var description: String {
        let labels = [("player", "Spieler"), ("team", "Team"), ("year", "Jahr"), ("number", "Kartennummer"), ("manufacturer", "Hersteller"), ("set", "Set-Aufdruck"), ("parallelHint", "Varianten-Aufdruck"), ("serialNumber", "Seriennummer"), ("notes", "Hinweis"), ("jerseyNumber", "Trikotnummer"), ("position", "Position"), ("cardType", "Kartentyp")]
        let verdict = ["match": "Passt laut Gemini", "mismatch": "Abweichung erkannt", "uncertain": "Nicht sicher bestimmbar"]
        let checks = verification.isEmpty ? "" : "\nKartenprüfung: " + (verdict[verification["identity"] ?? ""] ?? "Unklar") + "\nParallelprüfung: " + (verdict[verification["parallel"] ?? ""] ?? "Unklar") + "\n" + (verification["suggestedParallel"] ?? "") + "\n" + (verification["evidence"] ?? "") + "\n" + (verification["reason"] ?? "")
        return labels.compactMap { key, title in guard let value = values[key], !value.isEmpty else { return nil }; return title + ": " + value }.joined(separator: "\n") + checks
    }
}
