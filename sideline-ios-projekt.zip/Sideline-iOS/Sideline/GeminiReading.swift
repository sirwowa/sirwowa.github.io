import Foundation

struct GeminiReading {
    let values: [String: String]
    func normalized(_ text: String) -> [String] {
        text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "en_US_POSIX"))
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty && !["jr", "sr", "ii", "iii", "iv"].contains($0) }
    }
    func conflicts(with card: CardRecord) -> Bool {
        let a = normalized(values["player"] ?? ""), b = normalized(card.player)
        let names = a.count >= 2 && b.count >= 2 && (a.last != b.last || a.first?.first != b.first?.first)
        let number = normalized(values["number"] ?? ""), other = normalized(card.text("number"))
        return names || (!number.isEmpty && !other.isEmpty && number != other)
    }
    var description: String {
        let labels = [("player", "Spieler"), ("team", "Team"), ("year", "Jahr"), ("number", "Kartennummer"), ("manufacturer", "Hersteller"), ("set", "Set-Aufdruck"), ("parallelHint", "Varianten-Aufdruck"), ("serialNumber", "Seriennummer"), ("notes", "Hinweis")]
        return labels.compactMap { key, title in guard let value = values[key], !value.isEmpty else { return nil }; return title + ": " + value }.joined(separator: "\n")
    }
}
