import UIKit
import SwiftUI
import LocalAuthentication

struct CardRecord: Identifiable {
    let id: String
    var fields: [String: Any]
    init(_ data: [String: Any]) { fields = data; id = data["id"] as? String ?? data["cardsightId"] as? String ?? UUID().uuidString }
    func text(_ key: String) -> String { if let s = fields[key] as? String { return s }; return (fields[key] as? NSNumber)?.stringValue ?? "" }
    var player: String { text("player").isEmpty ? "Karte ohne Namen" : text("player") }
    var subtitle: String { [text("year"), text("set"), text("number"), text("parallel")].filter { !$0.isEmpty }.joined(separator: " · ") }
    var photo: UIImage? { Self.decodeImage(text("image")) }
    static func decodeImage(_ value: String) -> UIImage? { guard value.hasPrefix("data:image/"), let comma = value.firstIndex(of: ","), let data = Data(base64Encoded: String(value[value.index(after: comma)...])) else { return nil }; return UIImage(data: data) }
}

@MainActor final class SidelineStore: ObservableObject {
    let api = APIClient()
    @Published var loggedIn = false
    @Published var offline = false
    @Published var busy = false
    @Published var cards: [CardRecord] = []
    @Published var prices: [String: [String: Any]] = [:]
    @Published var message: String?
    @Published var celebration: String?
    @Published var celebrationSaved = true
    @Published var celebrationID = UUID()
    @Published var keepOffline = false
    @Published var snapshotDate = ""
    var vault: [CardRecord] { cards.filter { $0.text("status") != "Wunschliste" } }
    private var celebrationTask: Task<Void, Never>?
    var snapshotURL: URL { FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("sideline-vault.json") }
    func login(_ password: String) async {
        guard password.count >= 6 else { message = "Bitte mindestens 6 Zeichen eingeben."; return }
        busy = true; defer { busy = false }
        do { try await api.login(password: password); offline = false; try await refresh(); loggedIn = true } catch { message = error.localizedDescription; api.clear() }
    }
    func refresh() async throws {
        let rows = try await api.request("cards") as? [[String: Any]] ?? []
        cards = rows.map(CardRecord.init)
        // Existing EUR valuations only: no paid provider requests on opening the app.
        let saved = try await api.request("market-saved") as? [[String: Any]] ?? []
        prices = Dictionary(saved.compactMap { value in (value["id"] as? String).map { ($0, value) } }, uniquingKeysWith: { _, new in new })
        if keepOffline { try saveOffline() }
    }
    func price(for card: CardRecord) -> Double? {
        guard let value = prices[card.id] else { return nil }
        if let identity = value["valuationIdentity"] as? [String] {
            guard identity == ["cardsightId", "parallel", "grader", "grade"].map({card.text($0)}) else { return nil }
        } else if value["cardUpdatedAt"] as? String != card.text("updatedAt") { return nil }
        return (value["averageEur"] as? NSNumber)?.doubleValue
    }
    func fetchPrice(for card: CardRecord) async {
        guard !offline else { return }; busy = true; defer { busy = false }
        do { if let data = try await api.request("market", method: "POST", body: ["id": card.id, "refresh": true]) as? [String: Any] {
            var entry = data; entry["id"] = card.id; entry["valuationIdentity"] = ["cardsightId", "parallel", "grader", "grade"].map { card.text($0) }; prices[card.id] = entry
            if keepOffline { try saveOffline() }
        } } catch { message = error.localizedDescription }
    }
    func save(_ candidate: CardRecord, photo: UIImage?) async throws {
        var data = candidate.fields
        data["_scanConfirmed"] = true; data["status"] = "Sammlung"; data["quantity"] = 1
        if let photo, let bytes = photo.jpegData(compressionQuality: 0.94) { data["image"] = "data:image/jpeg;base64," + bytes.base64EncodedString(); data["catalogImage"] = false }
        else { data["catalogImage"] = true }
        _ = try await api.request("cards", method: "POST", body: data)
        // A successful POST is the save confirmation. Refresh failure must not invite a duplicate save.
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        celebrate(candidate.player, saved: true)
        do { try await refresh() } catch { message = "Gespeichert. Der VAULT konnte noch nicht neu geladen werden: " + error.localizedDescription }
    }
    func celebrate(_ player: String, saved: Bool) {
        celebrationID = UUID(); celebrationSaved = saved; celebration = player; celebrationTask?.cancel()
        celebrationTask = Task { try? await Task.sleep(for: .milliseconds(2200)); if !Task.isCancelled { celebration = nil } }
    }
    func saveOffline() throws {
        let data: [String: Any] = ["cards": cards.map(\.fields), "prices": Array(prices.values), "date": ISO8601DateFormatter().string(from: Date())]
        let dir = snapshotURL.deletingLastPathComponent(); try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var url = snapshotURL
        try JSONSerialization.data(withJSONObject: data).write(to: url, options: [.atomic, .completeFileProtection])
        var values = URLResourceValues(); values.isExcludedFromBackup = true; try url.setResourceValues(values)
    }
    func openOffline() async {
        busy = true; defer { busy = false }
        do {
            let context = LAContext(); let allowed = try await context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Deinen gespeicherten Sideline-VAULT öffnen")
            guard allowed else { return }
            guard let data = try JSONSerialization.jsonObject(with: Data(contentsOf: snapshotURL)) as? [String: Any] else { throw URLError(.cannotDecodeContentData) }
            cards = (data["cards"] as? [[String: Any]] ?? []).map(CardRecord.init)
            prices = Dictionary((data["prices"] as? [[String: Any]] ?? []).compactMap { p in (p["id"] as? String).map { ($0, p) } }, uniquingKeysWith: { _, new in new })
            snapshotDate = data["date"] as? String ?? ""; offline = true; loggedIn = true
        } catch { message = "Offline-VAULT nicht verfügbar: " + error.localizedDescription }
    }
    func removeOffline() { do { if FileManager.default.fileExists(atPath: snapshotURL.path) { try FileManager.default.removeItem(at: snapshotURL) }; keepOffline = false } catch { message = error.localizedDescription } }
    func logout() async { if !offline { _ = try? await api.request("logout", method: "POST", body: [:]) }; api.clear(); loggedIn = false; cards = []; prices = [:]; offline = false }
}
