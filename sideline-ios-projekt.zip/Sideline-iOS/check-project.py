#!/usr/bin/env python3
"""Resource/configuration checks; not a substitute for Xcode compilation."""
from pathlib import Path
import json, plistlib, re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent
app=root/'Sideline'
project=(root/'Sideline.xcodeproj/project.pbxproj').read_text()
info=plistlib.loads((app/'Info.plist').read_bytes())
assert info['CFBundleDisplayName']=='Sideline'
assert info['NSCameraUsageDescription'] and info['NSFaceIDUsageDescription']
assert 'NSAppTransportSecurity' not in info
assert info['UISupportedInterfaceOrientations']==['UIInterfaceOrientationPortrait']
privacy=plistlib.loads((app/'PrivacyInfo.xcprivacy').read_bytes());assert privacy['NSPrivacyTracking'] is False
sources=list(app.glob('*.swift'));assert len(sources)==6
for path in sources:
 assert f'path = "{path.name}"' in project, f'Missing project source: {path.name}'
 assert 'WKWebView' not in path.read_text(), 'Native app must not be a website wrapper'
assert 'IPHONEOS_DEPLOYMENT_TARGET = 17.0' in project
assert 'path = "Resources/guides.json"' in project
assert len(json.loads((app/'Resources/guides.json').read_text())['items'])==41
for catalog in (app/'Assets.xcassets').glob('*/Contents.json'):
 data=json.loads(catalog.read_text())
 for image in data.get('images',[]):
  assert not image.get('filename') or (catalog.parent/image['filename']).is_file()
scheme=ET.parse(root/'Sideline.xcodeproj/xcshareddata/xcschemes/Sideline.xcscheme')
for ref in scheme.findall('.//BuildableReference'):
 assert ref.attrib['BlueprintIdentifier']+' = { isa = PBXNativeTarget' in project
assert 'APIClient.swift' in project and 'CameraController.swift' in project
print('PASS: project references, native sources, plist/privacy, shared scheme, icons and 41 guides')
print('Xcode compilation, signing and physical-iPhone testing have NOT been performed.')
