<?php
/* Editorial knowledge storage and bounded website import. No model, instructions or code execution. */
function kbSnapshot(PDO $db): array {$q=$db->query("SELECT data FROM app_settings WHERE setting_key='assistant_knowledge'");$raw=$q->fetchColumn()?:'[]';return ['rows'=>json_decode($raw,true,64,JSON_THROW_ON_ERROR),'version'=>hash('sha256',$raw)];}
function kbUrl(string $url): array {
 $p=parse_url($url);$host=strtolower($p['host']??'');
 if(strlen($url)>2000||!filter_var($url,FILTER_VALIDATE_URL)||($p['scheme']??'')!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['fragment'])||isset($p['port'])&&$p['port']!==443||!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/D',$host))throw new RuntimeException('Bitte eine öffentliche HTTPS-Webseite ohne Zugangsdaten und ohne besonderen Port verwenden.');
 return [$host,$p];
}
function kbPublicIp(string $ip): bool {return filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)!==false&&!str_contains($ip,':')&&!preg_match('/^(?:0|100|127|169|192|198|203|224|240|255)\./',$ip);}
function kbWeb(string $url): array {
 [$host]=kbUrl($url);
 if(!function_exists('curl_init'))throw new RuntimeException('Der automatische Webimport benötigt PHP-cURL. Alternativ den Seitentext kopieren oder als Textdatei importieren.');
 $ips=gethostbynamel($host);if(!$ips||count($ips)>12)throw new RuntimeException('Die Webseite konnte nicht aufgelöst werden.');foreach($ips as $ip)if(!kbPublicIp($ip))throw new RuntimeException('Interne und reservierte Netzwerkadressen sind ausgeschlossen.');
 $body='';$c=curl_init($url);curl_setopt_array($c,[CURLOPT_RESOLVE=>[$host.':443:'.$ips[0]],CURLOPT_FOLLOWLOCATION=>false,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>20,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_USERAGENT=>'growfor-SourceImport/1.0',CURLOPT_HTTPHEADER=>['Accept: text/html,text/plain'],CURLOPT_ENCODING=>'',CURLOPT_WRITEFUNCTION=>function($c,$chunk)use(&$body){if(strlen($body)+strlen($chunk)>2000000)return 0;$body.=$chunk;return strlen($chunk);}]);
 $ok=curl_exec($c);$status=curl_getinfo($c,CURLINFO_RESPONSE_CODE);$mime=strtolower(curl_getinfo($c,CURLINFO_CONTENT_TYPE)?:'');curl_close($c);
 if($ok===false)throw new RuntimeException('Webseite nicht erreichbar oder größer als 2 MB. Den Text gegebenenfalls selbst übernehmen.');
 if($status>=300&&$status<400)throw new RuntimeException('Diese Adresse leitet weiter. Bitte die endgültige HTTPS-Adresse aus deinem Browser verwenden.');
 if($status!==200||!preg_match('~^text/(?:html|plain)\b~',$mime))throw new RuntimeException('Nur frei erreichbare HTML- oder Textseiten werden unterstützt.');
 $title='Importierte Webseite';if(preg_match('~<title[^>]*>(.*?)</title>~is',$body,$m))$title=html_entity_decode(strip_tags($m[1]),ENT_QUOTES|ENT_HTML5,'UTF-8');
 if(str_starts_with($mime,'text/html')){$body=preg_replace('~<(script|style|nav|header|footer|form|iframe|svg)\b[^>]*>.*?</\1\s*>~is','',$body);$body=preg_replace('~</(?:p|div|li|h[1-6]|section|article)>|<br\s*/?>~i',"\n\n",$body);$body=html_entity_decode(strip_tags($body),ENT_QUOTES|ENT_HTML5,'UTF-8');}
 $body=trim(preg_replace('/[\t ]+/u',' ',preg_replace('/\n\s*\n\s*\n/u',"\n\n",$body)));if($body===''||strlen($body)>600000||!preg_match('//u',$body))throw new RuntimeException('Kein passender UTF-8-Text gefunden oder Text zu lang. Bitte den Inhalt manuell übernehmen.');
 return ['title'=>trim($title),'content'=>$body,'url'=>$url,'imported_at'=>gmdate('c')];
}
function kbAdmin(PDO $db,int $uid,string $action,array $in): void {
 if($action==='admin_kb_get')out(kbSnapshot($db));
 if($action==='admin_kb_web'){try{out(kbWeb(adminText($in['url']??'',2000)));}catch(RuntimeException $e){out(['error'=>$e->getMessage()],400);}}
 $old=kbSnapshot($db);if(!hash_equals($old['version'],(string)($in['version']??'')))out(['error'=>'Wissen wurde inzwischen geändert. Bitte neu laden. Dein Entwurf bleibt im Formular.'],409);
 $rows=$in['rows']??null;if(!is_array($rows)||!array_is_list($rows)||count($rows)>50)out(['error'=>'Höchstens 50 Quellen.'],400);$result=[];$seen=[];
 foreach($rows as $r){$id=$r['id']??'';if(!is_string($id)||!preg_match('/^[a-zA-Z0-9-]{16,64}$/D',$id)||isset($seen[$id]))out(['error'=>'Ungültige oder doppelte Quellenkennung.'],400);$seen[$id]=true;
  $type=$r['type']??'manual';$status=$r['status']??'draft';if(!in_array($type,['manual','website','pdf'],true)||!in_array($status,['draft','published'],true))out(['error'=>'Quellenart oder Freigabe prüfen.'],400);
  $url=adminText($r['url']??'',2000,true);if($url!=='')try{kbUrl($url);}catch(RuntimeException $e){out(['error'=>$e->getMessage()],400);}
  $reviewed=adminText($r['reviewed']??'',10,true);if($reviewed!==''&&(!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D',$reviewed,$date)||!checkdate((int)$date[2],(int)$date[3],(int)$date[1])))out(['error'=>'Prüfdatum als gültiges Datum eingeben.'],400);
  $result[]=['id'=>$id,'title'=>adminText($r['title']??'',120),'content'=>adminText($r['content']??'',150000),'questions'=>adminText($r['questions']??'',2000,true),'url'=>$url,'type'=>$type,'status'=>$status,'reviewed'=>$reviewed,'updated'=>gmdate('c')];
 }
 $raw=json_encode($result,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);if(strlen($raw)>3000000)out(['error'=>'Die Wissenssammlung darf höchstens 3 MB Text enthalten.'],400);
 $db->prepare("INSERT OR REPLACE INTO app_settings(setting_key,data) VALUES('assistant_knowledge',?)")->execute([$raw]);adminLog($db,$uid,'knowledge_save','assistant_knowledge',count($result));out(['ok'=>1]+kbSnapshot($db));
}
