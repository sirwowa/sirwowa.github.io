# growfor 12.6 – Android-Kamera
Eigene Android-App growfor Kamera · Test, ab Android 8. Fotos werden mit einem widerrufbaren Gerätecode genau einem Grow zugeordnet. Smartphone- und GoPro-Fotos bleiben unterscheidbar. Download unter Mehr → Kamera / GoPro. Bestehende Konten, Grows, Einstellungen und Drehbuch bleiben erhalten.
