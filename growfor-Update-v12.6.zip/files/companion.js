/* Sour: guided app navigation and offline FAQ. No remote AI calls. */
'use strict';
(() => {
  const TOUR='growing-tour-v4-',HIDDEN='weedys-companion-hidden-';
  const get=k=>{try{return localStorage.getItem(k)}catch{return null}};
  const set=(k,v)=>{try{localStorage.setItem(k,v)}catch{}};
  const uid=()=>S.user?.id||'guest';
  const ready=()=>!window.GrowingAdministration&&S.user&&!S.user.must_change_password;
  let timer=null,activeTour=null;
  const faq=[
    [/nachricht|admin|feedback|fehler melden|antwort vom/, 'Öffne „Mehr“ und dann „Nachricht an Admin“. Nur du und der Admin können die Unterhaltung lesen. Offline verfasste Nachrichten bleiben zunächst vorgemerkt. Die automatische Dankesmeldung kommt nach Annahme durch den Server; Antworten findest du in derselben Unterhaltung.'],
    [/outdoor|indoor|standort/, 'Die Kennzeichnung Indoor/Outdoor und deine Standortnotiz sind manuelle Angaben im Tagebuch. Dadurch werden keine Berechnungen an Outdoor-Bedingungen angepasst. Anbauempfehlungen gebe ich nicht.'],
    [/passwort|kennwort|anmeld|einlog|login|konto/, 'Für die Anmeldung nutzt du deinen eingerichteten Namen. Der Admin kann zusätzlich seine E-Mail verwenden. Beim ersten Login musst du das Startpasswort ändern und das neue Passwort zweimal eingeben. Später findest du den Passwortwechsel im Profil.'],
    [/dark|dunkel|hell|design|modus|farbe/, 'Öffne unten „Mehr“ und tippe im Profil auf „Design“. Dort wechselst du zwischen automatisch, hell und dunkel.'],
    [/offline|internet|synchron|verbindung/, 'Öffne unter „Mehr“ den Bereich „Offline & Synchronisierung“ und bereite die Ansichten einmal online vor. Tagebucheinträge, Einstellungen und Nachrichten werden offline auf deinem Gerät vorgemerkt. Bei Verbindung und gültiger Sitzung sendet die geöffnete App sie automatisch. Neue Tagebücher und Löschaktionen brauchen eine Verbindung.'],
    [/kosten|strom|preis|ausgabe|rechn/, 'Öffne unten „Kosten“. Dort erfasst du Belege oder berechnest Kosten aus gemessenem Verbrauch. Preisvorgaben lassen sich jederzeit ändern; alte Belege behalten ihren gespeicherten Betrag. Vorschläge für Namen stammen aus deinen bisherigen Belegen. Es gibt keinen Live-Preisvergleich.'],
    [/inventar|einkauf|bestand/, 'Öffne „Start“ und dann „Inventar“. Dort verwaltest du Artikel und deine Einkaufsliste. Die Tour erklärt die Oberfläche, ohne Produkte oder Mengen zu empfehlen.'],
    [/kalender|datum|termin/, 'Tippe unten auf „Kalender“ und wähle ein Datum. Du kannst so deine Einträge nach Tag ansehen.'],
    [/backup|sicher|export|import|datenrett|gelösch/, 'Im Profil unter „Mehr“ findest du den Tagebuch-Export und den Import. Für eine vollständige Sicherung einschließlich Ausgaben, Einstellungen und Figurenwahl sichere deinen data/-Ordner auf dem Server. Ohne ein vorhandenes Backup kann ich gelöschte Einträge nicht wiederherstellen.'],
    [/install|home|startbildschirm|iphone|android|icon|symbol/, 'Nutze im Profil „Als App auf den Startbildschirm“. Android zeigt abhängig vom Browser eine Installationsauswahl; auf dem iPhone nutzt du in Safari „Teilen“ und „Zum Home-Bildschirm“. Bei einem alten Namen oder Symbol kann Entfernen und erneutes Hinzufügen nötig sein. Sichere vorher deine Daten.'],
    [/zurück|zuruck|wisch|navigation|vorher/, 'Wische nahe dem linken Rand nach rechts, um eine Ansicht zurückzugehen. Die äußersten 24 Pixel bleiben für die native Browser-Geste frei. Auf Eingabefeldern, Links und Buttons beginnt die App-Geste nicht. Alternativ nutzt du den Zurück-Pfeil oben.'],
    [/einführung|einfuhrung|tour|sour|maskottchen|hilfe/, 'Tippe auf „Sour hilft“ und dann auf „App-Tour starten“. Ich zeige dir die tatsächlichen Menüs. Im Profil kannst du mich ausblenden oder wieder aktivieren.'],
    [/notiz|tagebuch|eintrag|messwert/, 'Öffne ein vorhandenes Tagebuch und wechsle zu „Tagebuch“. Über die Plus-Taste öffnest du die Eintragsauswahl. Ich erkläre dir die Bedienung; Werte und Notizen trägst du selbst ein.'],
    [/foto|bild|animation/, 'Die vorhandene Pflanzenanimation bleibt Teil der Detailansicht. Eine zusätzliche Fotoübersicht wurde nicht ergänzt. Bereits vorhandene Fotoeinträge bleiben erhalten.'],
    [/namen|name|growing/, 'Die App heißt growfor. Sour ist dein lokaler Begleiter für Fragen zur Bedienung. Der Anzeigename im Profil ist getrennt von deinem Anmeldenamen.'],
    [/hallo|hey|guten tag|danke/, 'Hey! Ich bin Sour. Frag mich zum Beispiel nach Zurück-Wischen, Kosten, Backups, Dunkelmodus oder der Installation auf deinem Smartphone.']
  ];
  function answer(question){
    const q=question.toLocaleLowerCase('de-DE').trim();
    if(!q)return 'Bitte schreibe zuerst deine Frage.';
    if(/topping|fim(ming)?|trichom|entlaub|nährstoff|naehrstoff|düng|dueng|gieß|giess|bewässer|bewaesser|erntezeit|blütephase|bluetephase|keimung|joint|thc|cannabis.?rezept|anbau|grow.*anleg|ersten grow|phase.*tipp/.test(q))return 'Ich beantworte Fragen zur Bedienung von growfor. Cannabis-Anbauplanung, Anbautipps und Konsumanleitungen gehören nicht zu meinen Antworten. Frag mich zum Beispiel nach Tagebucheinträgen, Kosten oder Backups.';
    if(window.GrowingKnowledge?.has(question))return GrowingKnowledge.result(question);
    const item=faq.find(([pattern])=>pattern.test(q));
    return item?item[1].replace(/Sour/g,window.GrowingAvatars?.current().name||'Sour'):'Dazu habe ich keine verlässliche Antwort in meiner lokalen Bedienhilfe. Ich kann Fragen zu Anmeldung, Tagebuch, Kosten, Inventar, Kalender, Backups, Design, Offline-Nutzung und App-Installation beantworten. Ich bin nicht mit einem KI-Dienst oder dem Internet verbunden.';
  }
  function contextual(){
    if(S.offline)return 'Du bist offline. Die lokale Bedienhilfe bleibt verfügbar. Prüfe später online, ob vorgemerkte Einträge synchronisiert wurden.';
    if(S.view==='profile'&&!S.g)return 'Im Profil verwaltest du deine Kontodaten, das Design und deine Backups.';
    if(S.view==='costs'||(S.g&&S.tab==='costs'))return 'Hier findest du deine Kostenübersicht. Die Berechnungen hängen von deinen eingetragenen Preisen und Mengen ab.';
    if(S.g&&S.tab==='diary')return 'Hier stehen deine bisherigen Einträge. Über die Plus-Taste öffnest du die Eintragsauswahl.';
    return 'Frag mich zur Bedienung oder starte eine Tour durch die tatsächlichen App-Menüs.';
  }
  function dialog(className){
    document.querySelectorAll('.mascot-tour,.companion-panel').forEach(d=>d.close());
    const previous=document.activeElement,d=document.createElement('dialog');
    d.className='ov '+className;d.setAttribute('aria-modal','true');document.body.append(d);
    d.addEventListener('close',()=>{d.remove();if(previous?.isConnected)previous.focus()},{once:true});
    return d;
  }
  const steps=[
    {view:'start',target:'.top',title:'Hey, willkommen bei growfor!',text:'Ich bin Sour. Ich zeige dir die Menüs direkt in deiner App. Du kannst jederzeit pausieren und die Tour später im Profil erneut starten.'},
    {view:'list',target:'.gcard,#newgrow',title:'Deine Tagebücher.',text:'Hier findest du deine angelegten Tagebücher. Die Übersicht zeigt ihren aktuellen Stand. In dieser Tour werden keine Datensätze angelegt oder verändert.'},
    {view:'diary',target:'.day,.fab,#newgrow',title:'Einträge und Notizen.',text:'Im Tagebuch sammelst du deine eigenen Einträge. Wenn bereits ein Tagebuch existiert, öffne ich dessen Eintragsansicht. Ohne vorhandene Daten bleibt die Übersicht sichtbar.'},
    {view:'costs',target:'.card',title:'Kosten im Blick.',text:'Hier findest du deine Kostenübersicht. Deine eingegebenen Preise und Mengen bilden die Grundlage. Prüfe sie, damit die Übersicht zu deinen Ausgaben passt.'},
    {view:'cal',target:'.cg,.card',title:'Dein Kalender.',text:'Wähle im Alltag ein Datum, um Einträge nach Tag anzusehen. Der Kalender bündelt die Informationen aus deinen Tagebüchern.'},
    {view:'inv',target:'.card',title:'Inventar und Einkaufsliste.',text:'Hier verwaltest du deine vorhandenen Artikel und deine Einkaufsliste. Die Tour selbst ergänzt keine Artikel und führt keine Bestellungen aus.'},
    {view:'profile',target:'#theme',title:'Dein Look. Deine Einstellungen.',text:'Im Profil wechselst du zwischen heller und dunkler Darstellung. Du findest hier auch deine Kontodaten und kannst Sour ein- oder ausblenden.'},
    {view:'profile',target:'#export',title:'Ein Backup ist wichtig.',text:'Im Profil kannst du deine Daten exportieren und ein vorhandenes Backup importieren. Sichere zusätzlich den data/-Ordner auf deinem Server.'},
    {view:'profile',target:'#installapp',title:'growfor auf dem Homebildschirm.',text:'Dieser Button erklärt die Installation. Je nach Browser musst du sie bestätigen oder „Zum Home-Bildschirm“ selbst auswählen. HTTPS ist erforderlich.'},
    {view:'start',target:'#companion-launcher',title:'Frag mich zur App.',text:'Tippe auf Sour und schreibe deine Frage ins Fragefeld. Meine lokale Bedienhilfe funktioniert ohne KI-Schlüssel. Zu Anbau- oder Konsumanleitungen gebe ich keine Antworten.'}
  ];
  async function tour(){
    if(!ready()||activeTour)return;
    if(window.GrowingNavigation&&!window.GrowingNavigation.confirmDiscard('Du hast ungespeicherte Eingaben. Für die Tour werden sie verworfen. Tour trotzdem starten?'))return;
    const original={view:S.view,g:S.g,tab:S.tab,entries:S.entries,mem:S.mem,sid:S.sid,sadd:S.sadd,sheet:S.sheet,creating,scroll:scrollY};
    const d=dialog('mascot-tour guided-tour');let step=0,working=false;
    window.GrowingNavigation?.suspend();
    function close(restore=true){
      if(!activeTour)return;
      activeTour=null;set(TOUR+uid(),'done');d.close();
      if(restore){Object.assign(S,{view:original.view,g:original.g,tab:original.tab,entries:original.entries,mem:original.mem,sid:original.sid,sadd:original.sadd,sheet:original.sheet});creating=original.creating;render();scrollTo({top:original.scroll,behavior:'instant'})}
      window.GrowingNavigation?.resume(restore);
    }
    activeTour={close};
    d.addEventListener('cancel',e=>{e.preventDefault();close()});
    d.addEventListener('close',()=>{if(activeTour)close()},{once:true});
    function place(){
      const el=document.querySelector(steps[step].target),spot=d.querySelector('.tour-spotlight');
      if(!spot)return;
      const rect=el?.getBoundingClientRect();
      if(!rect||rect.width===0){spot.hidden=true;return}
      const card=d.querySelector('.guided-card');
      if(card){card.style.top=rect.top>innerHeight*.65?'18px':'auto';card.style.bottom=rect.top>innerHeight*.65?'auto':'18px'}
      spot.hidden=false;
      Object.assign(spot.style,{left:Math.max(5,rect.left-5)+'px',top:Math.max(5,rect.top-5)+'px',width:Math.min(innerWidth-10,rect.width+10)+'px',height:Math.min(innerHeight-10,rect.height+10)+'px'});
    }
    async function draw(){
      if(working||!activeTour)return;working=true;
      try{
        const s=steps[step];S.g=null;creating=false;S.sheet=null;
        if(s.view==='diary'&&S.grows.length){await openGrow(S.grows[0].id);S.tab='diary'}
        else S.view=s.view==='diary'?'list':s.view;
        render();
        const target=document.querySelector(s.target);
        if(target)target.scrollIntoView({block:'center',behavior:'instant'});else scrollTo(0,0);
        d.innerHTML=`<div class="tour-spotlight" aria-hidden="true"></div><div class="sheet guided-card"><button class="tour-close" type="button" data-tour-close aria-label="Tour schließen">×</button><div class="guided-mascot"><img src="${window.GrowingAvatars?.image(step)||'mascot.png'}" alt="${esc(window.GrowingAvatars?.current().name||'Sour')}, dein App-Begleiter" width="96" height="128"></div><p class="eyebrow">growfor ENTDECKEN · ${step+1} / ${steps.length}</p><h2 id="tour-title">${esc(s.title.replace(/Sour/g,window.GrowingAvatars?.current().name||'Sour'))}</h2><p class="tour-copy">${esc(s.text.replace(/Sour/g,window.GrowingAvatars?.current().name||'Sour'))}</p><div class="tour-progress" aria-hidden="true">${steps.map((_,i)=>`<span class="${i===step?'active':''}"></span>`).join('')}</div><div class="tour-actions"><button type="button" class="btn alt" data-tour-prev>${step?'Zurück':'Später'}</button><button type="button" class="btn led" data-tour-next>${step===steps.length-1?'Fertig':'Weiter'}</button></div></div>`;
        d.setAttribute('aria-labelledby','tour-title');
        d.querySelector('[data-tour-close]').onclick=()=>close();
        d.querySelector('[data-tour-prev]').onclick=()=>{if(step){step--;draw()}else close()};
        d.querySelector('[data-tour-next]').onclick=()=>{if(step===steps.length-1)close();else{step++;draw()}};
        place();if(!d.open)d.showModal();d.querySelector('[data-tour-next]').focus();
      }catch(error){close();toast('Die Tour konnte diese Ansicht nicht laden. Bitte später erneut versuchen.')}
      finally{working=false}
    }
    const reposition=()=>place();addEventListener('resize',reposition);
    d.addEventListener('close',()=>removeEventListener('resize',reposition),{once:true});
    await draw();
  }
  function help(){
    if(!ready()||activeTour)return;
    const d=dialog('companion-panel');
    d.innerHTML=`<div class="sheet companion-card"><div class="companion-header"><img class="sour-wave" src="${window.GrowingAvatars?.image(1)||'sour-wave.webp'}" alt="" width="72" height="90"><div><p class="eyebrow">DEIN growfor-BEGLEITER</p><h2 id="companion-title">Was ist los?</h2></div><button class="tour-close" type="button" data-tour-close aria-label="Hilfe schließen">×</button></div><p class="companion-copy">Beschreibe deine Frage. Ich suche in der App-Hilfe und deinen freigegebenen Wissenseinträgen.</p><div class="sour-conversation" role="log" aria-label="Fragen und Antworten" aria-live="polite"></div><form id="sour-question"><label for="sour-question-input">Deine Frage</label><div class="sour-input-row"><input id="sour-question-input" name="question" type="text" maxlength="500" required placeholder="Wie sichere ich meine Daten?" autocomplete="off"><button class="btn led" type="submit">Fragen</button></div></form><div class="sour-suggestions"><button type="button" data-question="Wie geht Zurück-Wischen?">Zurück-Wischen</button><button type="button" data-question="Wie erstelle ich ein Backup?">Backup</button><button type="button" data-question="Wie geht der Dunkelmodus?">Dunkelmodus</button></div><p class="companion-disclaimer">Lokale Textsuche und Bedienhilfe, keine KI-Verbindung. Antworten aus der Wissenssammlung nennen ihre Quelle. Fragen werden nicht an einen KI-Dienst gesendet.</p><button class="btn led" data-companion-tour type="button">App-Tour starten</button><button class="btn alt" data-companion-hide type="button">Begleiter ausblenden</button></div>`;
    d.setAttribute('aria-labelledby','companion-title');
    const input=d.querySelector('[name=question]'),log=d.querySelector('.sour-conversation');
    function ask(q){
      q=q.trim().slice(0,500);if(!q)return;
      for(const [who,text] of [['Du',q],[window.GrowingAvatars?.current().name||'Sour',answer(q)]]){
        const bubble=document.createElement('div');bubble.className=who==='Du'?'sour-bubble user':'sour-bubble';
        const label=document.createElement('b');label.textContent=who;
        const p=document.createElement('p');p.textContent=text;bubble.append(label,p);log.append(bubble);
      }
      while(log.children.length>16)log.firstChild.remove();
      log.scrollTop=log.scrollHeight;input.value='';
    }
    d.querySelector('#sour-question').onsubmit=e=>{e.preventDefault();ask(input.value);input.focus()};
    d.querySelectorAll('[data-question]').forEach(b=>b.onclick=()=>ask(b.dataset.question));
    d.querySelector('[data-tour-close]').onclick=()=>d.close();
    d.querySelector('[data-companion-tour]').onclick=()=>{d.close();tour()};
    d.querySelector('[data-companion-hide]').onclick=()=>{set(HIDDEN+uid(),'1');d.close();update()};d.showModal();
  }
  function update(){
    document.getElementById('companion-launcher')?.remove();clearTimeout(timer);
    const scene=document.querySelector('.watering-scene');
    if(scene){const paused=get('growing-motion-paused')==='1';scene.classList.toggle('is-paused',paused);const b=scene.querySelector('.scene-motion');if(b){b.textContent=paused?'Animation starten':'Animation pausieren';b.setAttribute('aria-pressed',String(paused))}}
    if(!ready())return;
    document.querySelectorAll('#app .top .logoimg').forEach(img=>{img.setAttribute('role','button');img.tabIndex=0;img.setAttribute('aria-label',(window.GrowingAvatars?.current().name||'Sour')+'-Hilfe öffnen');img.title=(window.GrowingAvatars?.current().name||'Sour')+'-Hilfe öffnen'});
    if(S.view!=='avatars'&&get(HIDDEN+uid())!=='1'){
      const b=document.createElement('button');b.type='button';b.id='companion-launcher';b.className='companion-launcher';
      b.setAttribute('aria-label',(window.GrowingAvatars?.current().name||'Sour')+': Frage stellen oder App-Tour starten');
      b.innerHTML=`<img src="${window.GrowingAvatars?.image(0)||'mascot.png'}" alt="" width="58" height="76"><span>Frag ${esc(window.GrowingAvatars?.current().name||'Sour')}</span>`;b.onclick=help;document.body.append(b);
    }
    if(!activeTour&&!get(TOUR+uid()))timer=setTimeout(()=>{if(ready()&&!document.querySelector('.ov,dialog[open]')){if(window.GrowingTeam&&!S.grows.length)GrowingTeam.open('start');else tour()}},900);
  }
  document.addEventListener('click',e=>{const b=e.target.closest('.scene-motion');if(!b)return;const scene=b.closest('.watering-scene');const paused=scene.classList.toggle('is-paused');set('growing-motion-paused',paused?'1':'0');b.textContent=paused?'Animation starten':'Animation pausieren';b.setAttribute('aria-pressed',String(paused))});
  document.addEventListener('click',e=>{if(e.target.closest('#app .top .logoimg')&&ready()){e.preventDefault();help()}});
  document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('#app .top .logoimg')&&ready()){e.preventDefault();help()}});
  addEventListener('growing:synced',()=>{const b=document.getElementById('companion-launcher');if(b){b.classList.remove('sour-celebrate');requestAnimationFrame(()=>b.classList.add('sour-celebrate'))}});
  window.GrowingCompanion={tour,help,answer,cancelTourForNavigation(){activeTour?.close(false)}};
  window.WeedysCompanion=window.GrowingCompanion;
  const previousProfile=EXTRA.profileBtns;
  EXTRA.profileBtns=()=>previousProfile()+`<button class="btn alt" id="companion-settings" style="width:100%;margin-bottom:8px">Begleiter: ${get(HIDDEN+uid())==='1'?'Begleiter aktivieren':'Fragen & App-Tour'}</button>`;
  EXTRA.binds.push(on=>on('#companion-settings','click',()=>{set(HIDDEN+uid(),'0');update();help()}));
  EXTRA.onb=()=>{};addEventListener('growing:render',update);update();
})();
