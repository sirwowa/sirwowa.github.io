<?php
/* Authenticated handbook content. Uploaded PDFs remain private database blobs. */
function handbookInit(PDO $db): void {$db->exec('CREATE TABLE IF NOT EXISTS handbook_assets(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,bytes INTEGER NOT NULL,checksum TEXT NOT NULL UNIQUE,content BLOB NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP)');}
function handbookDefault(): array {return ['type'=>'builtin','title'=>'Joint-Drehbuch'];}
function handbookRead(PDO $db,string $key): array {$q=$db->prepare('SELECT data FROM app_settings WHERE setting_key=?');$q->execute([$key]);$raw=$q->fetchColumn();return ['document'=>$raw?json_decode($raw,true):handbookDefault(),'version'=>hash('sha256',$raw?:'{}')];}
function handbookLibrary(PDO $db): array {return handbookRead($db,'handbook_published');}
function handbookPdf(PDO $db,array $account,array $in): void {
 $id=(int)($in['asset_id']??0);$doc=handbookLibrary($db)['document'];if($account['role']!=='admin'&&($doc['type']!=='pdf'||($doc['asset_id']??0)!==$id))out(['error'=>'Dieses PDF ist nicht veröffentlicht.'],403);
 $q=$db->prepare('SELECT id,name,bytes,checksum,content FROM handbook_assets WHERE id=?');$q->execute([$id]);$row=$q->fetch();if(!$row)out(['error'=>'PDF nicht gefunden.'],404);out(['id'=>(int)$row['id'],'name'=>$row['name'],'bytes'=>(int)$row['bytes'],'checksum'=>$row['checksum'],'data'=>base64_encode($row['content'])]);
}
function handbookArtwork($value,int $count): array {
 if(!is_array($value)||array_diff(array_keys($value),['atlas','step_images','step_origins']))out(['error'=>'Bildformat prüfen.'],400);
 $image=function($s,bool $empty=false): string {if($empty&&$s==='')return '';if(!is_string($s)||strlen($s)>2800000||!preg_match('~^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$~D',$s,$m))out(['error'=>'Nur eingebettete PNG-, JPEG- und WebP-Bilder.'],400);$bytes=base64_decode($m[2],true);$size=is_string($bytes)?@getimagesizefromstring($bytes):false;if(!$size||$size[0]>4096||$size[1]>4096||$size['mime']!=='image/'.$m[1])out(['error'=>'Bild ist ungültig oder größer als 4096 Pixel.'],400);return $s;};
 $frames=$value['step_images']??null;if(!is_array($frames)||!array_is_list($frames)||count($frames)!==$count)out(['error'=>'Bildschritte müssen zur Kapitelliste passen.'],400);$rows=[];foreach($frames as $row){if(!is_array($row)||!array_is_list($row)||count($row)>30)out(['error'=>'Maximal 30 Bildschritte pro Kapitel.'],400);$rows[]=array_map(fn($s)=>$image($s,true),$row);}$result=['atlas'=>$image($value['atlas']??null),'step_images'=>$rows];if(isset($value['step_origins'])){$origins=$value['step_origins'];if(!is_array($origins)||!array_is_list($origins)||count($origins)!==$count)out(['error'=>'Bildquellen prüfen.'],400);foreach($origins as $row)if(!is_array($row)||!array_is_list($row)||count($row)>30||array_diff($row,['pdf','generated','none']))out(['error'=>'Bildquellen prüfen.'],400);$result['step_origins']=$origins;}return $result;
}
function handbookValidate(PDO $db,$value): array {
 if(!is_array($value))out(['error'=>'Drehbuchdaten prüfen.'],400);$type=$value['type']??'';$title=adminText($value['title']??'',120);
 $fields=['builtin'=>['type','title'],'pdf'=>['type','title','asset_id'],'json'=>['type','title','chapters','artwork'],'code'=>['type','title','source']];if(!isset($fields[$type])||array_diff(array_keys($value),$fields[$type]))out(['error'=>'Unbekanntes Drehbuchformat oder Feld.'],400);
 $out=['type'=>$type,'title'=>$title];
 if($type==='pdf'){$id=adminId($value['asset_id']??0);$q=$db->prepare('SELECT id FROM handbook_assets WHERE id=?');$q->execute([$id]);if(!$q->fetch())out(['error'=>'Bitte zuerst ein PDF hochladen.'],400);$out['asset_id']=$id;}
 if($type==='code')$out['source']=adminText($value['source']??'',100000);
 if($type==='json'){$chapters=$value['chapters']??null;if(!is_array($chapters)||!array_is_list($chapters)||count($chapters)<1||count($chapters)>50)out(['error'=>'Ein JSON-Drehbuch braucht 1 bis 50 Kapitel.'],400);$out['chapters']=[];foreach($chapters as $c){if(!is_array($c)||array_diff(array_keys($c),['title','text','steps']))out(['error'=>'Kapitel erlauben nur title, text und steps.'],400);$steps=$c['steps']??[];if(!is_array($steps)||!array_is_list($steps)||count($steps)>30)out(['error'=>'Maximal 30 Schritte pro Kapitel.'],400);$clean=['title'=>adminText($c['title']??'',120),'text'=>adminText($c['text']??'',10000,true),'steps'=>[]];foreach($steps as $step)$clean['steps'][]=adminText($step,2000);$out['chapters'][]=$clean;}}
 if($type==='json'&&isset($value['artwork']))$out['artwork']=handbookArtwork($value['artwork'],count($out['chapters']));
 if(strlen(json_encode($out))>6000000)out(['error'=>'Drehbuchdaten dürfen höchstens 6 MB groß sein.'],400);return $out;
}
function handbookAdmin(PDO $db,int $uid,string $action,array $in): void {
 if($action==='admin_handbook_get'){$draft=handbookRead($db,'handbook_draft');$q=$db->prepare("SELECT data FROM app_settings WHERE setting_key='handbook_draft'");$q->execute();if(!$q->fetchColumn())$draft['document']=handbookLibrary($db)['document'];$draft['published']=handbookLibrary($db);$draft['assets']=$db->query('SELECT id,name,bytes,checksum FROM handbook_assets ORDER BY id DESC')->fetchAll();$draft['upload_max']=ini_get('upload_max_filesize');$draft['post_max']=ini_get('post_max_size');out($draft);}
 if($action==='admin_handbook_pdf_upload'){
  $file=$_FILES['pdf']??null;if(!$file||$file['error']!==UPLOAD_ERR_OK||!is_uploaded_file($file['tmp_name']))out(['error'=>'PDF-Upload fehlgeschlagen. Bitte die Uploadgrenze des Hostings beachten.'],400);
  if($file['size']<10||$file['size']>10*1024*1024||strtolower(pathinfo($file['name'],PATHINFO_EXTENSION))!=='pdf')out(['error'=>'Bitte eine PDF-Datei mit höchstens 10 MB wählen.'],400);
  $data=file_get_contents($file['tmp_name']);if(!str_starts_with($data,'%PDF-')||!str_contains(substr($data,-2048),'%%EOF'))out(['error'=>'Die Datei hat keine gültige PDF-Kennung oder ist unvollständig.'],400);
  $hash=hash('sha256',$data);$q=$db->prepare('SELECT id FROM handbook_assets WHERE checksum=?');$q->execute([$hash]);$id=$q->fetchColumn();$q->closeCursor();
  if(!$id){$db->exec('BEGIN IMMEDIATE');try{if((int)$db->query('SELECT COUNT(*) FROM handbook_assets')->fetchColumn()>=20||(int)$db->query('SELECT COALESCE(SUM(bytes),0) FROM handbook_assets')->fetchColumn()+strlen($data)>100*1024*1024){$db->exec('ROLLBACK');out(['error'=>'PDF-Speicherlimit erreicht. Nicht verwendete PDFs zuerst entfernen.'],400);}$q=$db->prepare('INSERT INTO handbook_assets(name,bytes,checksum,content) VALUES(?,?,?,?)');$q->bindValue(1,adminText(basename($file['name']),180));$q->bindValue(2,strlen($data),PDO::PARAM_INT);$q->bindValue(3,$hash);$q->bindValue(4,$data,PDO::PARAM_LOB);$q->execute();$id=(int)$db->lastInsertId();$db->exec('COMMIT');}catch(Throwable $e){$db->exec('ROLLBACK');throw $e;}}
  adminLog($db,$uid,'handbook_pdf_upload','handbook_assets',$id);out(['ok'=>1,'asset_id'=>(int)$id]);
 }
 if($action==='admin_handbook_cleanup'){
  $used=[];foreach(['handbook_draft','handbook_published'] as $key){$doc=handbookRead($db,$key)['document'];if(($doc['type']??'')==='pdf')$used[]=(int)$doc['asset_id'];}
  $query='DELETE FROM handbook_assets'.($used?' WHERE id NOT IN ('.implode(',',array_fill(0,count($used),'?')).')':'');$q=$db->prepare($query);$q->execute($used);adminLog($db,$uid,'handbook_pdf_cleanup','handbook_assets',$q->rowCount());out(['ok'=>1,'removed'=>$q->rowCount()]);
 }
 $old=handbookRead($db,'handbook_draft');if(!hash_equals($old['version'],(string)($in['version']??'')))out(['error'=>'Das Drehbuch wurde inzwischen geändert. Dein Entwurf bleibt stehen. Bitte vergleichen und neu laden.'],409);
 $doc=handbookValidate($db,$in['document']??null);$publish=$in['publish']??false;if(!is_bool($publish))out(['error'=>'Veröffentlichungsstatus prüfen.'],400);
 $json=json_encode($doc,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);$q=$db->prepare('INSERT OR REPLACE INTO app_settings(setting_key,data) VALUES(?,?)');$q->execute(['handbook_draft',$json]);if($publish)$q->execute(['handbook_published',$json]);adminLog($db,$uid,$publish?'handbook_publish':'handbook_draft','app_settings','handbook');out(['ok'=>1]+handbookRead($db,'handbook_draft'));
}
