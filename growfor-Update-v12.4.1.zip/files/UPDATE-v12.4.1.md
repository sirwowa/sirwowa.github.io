# growfor 12.4.1 – Desktop-Komposition und Comic-Leser

Diese Version enthält die bisherigen Änderungen aus 12.4 einschließlich der 552 Sorten und der Geruchsanzeige.

## Desktop und Smartphone

- Ab 1100 Pixeln feste linke Seitennavigation. Bei geöffnetem Grow sind die allgemeinen Ansichten und dessen Unterseiten getrennt erreichbar.
- Die Growübersicht hat einen eigenen Kopfbereich, kompakte Zusammenfassung, Suche, Statusfilter und passend große Aktionen.
- Growkarten verwenden feste Rasterspalten: zwei ab 1100, drei ab 1440 und vier auf sehr breiten Monitoren. Auch nur eine Karte wird nicht über den ganzen Bildschirm gestreckt.
- Lesebereiche, Formulare und Growdetailansichten erhalten eigene Breiten und Spalten statt einer pauschalen Vergrößerung.
- Smartphone: untere Navigation, einspaltige Growkarten; Tablet: zwei Spalten bei ausreichender Breite. Suchfeld und Statusfilter bleiben auch mobil erreichbar.
- Der Wechsel der Fensterbreite erfolgt per CSS ohne Neuaufbau der Formulare. Ungespeicherte Eingaben bleiben erhalten.
- Originale Bedienelemente werden in der Desktopnavigation weiterverwendet. Der verschiebbare Begleiter bleibt funktionsfähig; die seitliche Navigation wird nicht als untere Bildschirmgrenze interpretiert.

## Drehbuch

- Vorhandene JSON-Kapitel erhalten Comic-Panels mit Papierfläche, Szenenkästen, nummerierten Schritten, Sprechblasen und Kapitelverzeichnis. Der Inhalt wird nicht neu geschrieben.
- Vorhandene Beschreibungen von Bildern werden als Beschreibungen dargestellt; es werden keine neuen Szenenbilder generiert.
- Der Standardleser und die PDF-Ansicht erhalten passende Rahmen und Seitennavigation.
- Die Schaltfläche „Original-PDF herunterladen“ und der Drehbuch-Entwurfsexport wurden entfernt. Die allgemeine leere JSON-Vorlage bleibt als Importhilfe im Admineditor.
- Eigene HTML-Inhalte bleiben im vorhandenen Sandbox-Viewer.
- Ein vollständiger Kopier- oder Extraktionsschutz ist im Browser nicht möglich. Angezeigte Inhalte werden zum Gerät übertragen. Es wird kein solcher Schutz versprochen.
- Private Drehbuchdateien und deren Inhalte werden nicht in das Update aufgenommen; vorhandene Veröffentlichungen in der Datenbank bleiben erhalten.

## Installation und Prüfung

Signiertes Update Build 19 / Version 12.4.1. Upload unter Admin → Updates; alternativ die separat gelieferte FTP-Installationshilfe mit Einmalcode verwenden. Anschließend vollständig neu laden und bei Bedarf das Offline-Paket erneut vorbereiten (Cache 26).

Geprüft: Desktopnavigation und Grow-Unterseiten; Suche/Filter; einzelne und mehrere Karten; Ansichten von 320 bis 2560 Pixeln; Erhalt ungespeicherter Formulare beim Größenwechsel; Original-Comicdatei mit neun Szenen und vollständigem Textvergleich; Kapitelverzeichnis; PDF-Seitenwechsel ohne Downloadschaltfläche. Vorhandene Daten, Konten und Konfiguration werden nicht ersetzt.
