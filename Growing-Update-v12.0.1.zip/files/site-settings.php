<?php
function siteInit(PDO $db): void {$db->exec('CREATE TABLE IF NOT EXISTS app_settings(setting_key TEXT PRIMARY KEY,data TEXT NOT NULL)');}
function siteDefaults(): array {return ['app_name'=>'Growing','slogan'=>'Dein Tagebuch. Dein Überblick.','accent'=>'lime','default_theme'=>'auto','companions'=>['start'=>'Sour','observe'=>'Flora','daily'=>'Luna'],'modules'=>['timelapse'=>true,'orchard'=>true,'bridge'=>true]];}
function siteSnapshot(PDO $db): array {
 $raw=$db->query("SELECT data FROM app_settings WHERE setting_key='appearance'")->fetchColumn();$data=$raw?json_decode($raw,true):null;$config=siteDefaults();
 if(is_array($data)){
  foreach(['app_name'=>32,'slogan'=>120] as $k=>$max)if(is_string($data[$k]??null)&&preg_match('//u',$data[$k])&&preg_match_all('/./us',$data[$k])<=$max&&($k!=='app_name'||trim($data[$k])!==''))$config[$k]=$data[$k];
  if(in_array($data['accent']??null,['lime','mint','blue','violet'],true))$config['accent']=$data['accent'];
  if(in_array($data['default_theme']??null,['auto','dark','light'],true))$config['default_theme']=$data['default_theme'];
  foreach(array_keys($config['companions']) as $k)if(is_string($data['companions'][$k]??null)&&preg_match("/^[\p{L}\p{N} ._'-]{1,24}$/u",$data['companions'][$k]))$config['companions'][$k]=$data['companions'][$k];
  foreach(array_keys($config['modules']) as $k)if(is_bool($data['modules'][$k]??null))$config['modules'][$k]=$data['modules'][$k];
 }
 return ['config'=>$config,'version'=>hash('sha256',$raw?:'{}')];
}
function siteValidate($data): array {
 if(!is_array($data)||array_diff(array_keys($data),array_keys(siteDefaults())))out(['error'=>'Unbekannte oder ungültige App-Einstellung.'],400);
 $name=adminText($data['app_name']??'',32);$slogan=adminText($data['slogan']??'',120,true);$accent=$data['accent']??'';$theme=$data['default_theme']??'';
 if(!in_array($accent,['lime','mint','blue','violet'],true)||!in_array($theme,['auto','dark','light'],true))out(['error'=>'Designvorgabe prüfen.'],400);
 $names=$data['companions']??null;$modules=$data['modules']??null;if(!is_array($names)||array_diff(array_keys($names),['start','observe','daily'])||!is_array($modules)||array_diff(array_keys($modules),['timelapse','orchard','bridge']))out(['error'=>'Begleiter- oder Modulvorgabe prüfen.'],400);
 foreach(['start','observe','daily'] as $k){$names[$k]=adminText($names[$k]??'',24);if(!preg_match("/^[\p{L}\p{N} ._'-]+$/u",$names[$k]))out(['error'=>'Begleiternamen dürfen Buchstaben, Zahlen, Leerzeichen, Punkt, Unterstrich, Apostroph und Bindestrich enthalten.'],400);}
 foreach(['timelapse','orchard','bridge'] as $k)if(!array_key_exists($k,$modules)||!is_bool($modules[$k]))out(['error'=>'Modulschalter müssen Ja/Nein-Werte sein.'],400);
 return ['app_name'=>$name,'slogan'=>$slogan,'accent'=>$accent,'default_theme'=>$theme,'companions'=>$names,'modules'=>$modules];
}
