/* Decorative profile companions; no agronomic properties are inferred. */
'use strict';
(()=>{
 const registry=window.GrowingAvatarData;
 const normalize=s=>String(s||'').toLocaleLowerCase('de-DE').replace(/[^a-z0-9]/g,'');
 function current(){const fallback=registry.find(a=>a.id===S.set?.companion_id)||registry[0];const selected=S.set?.companion_mode==='auto'&&S.g?.data?.strain?(registry.find(a=>normalize(a.name)===normalize(S.g.data.strain))||fallback):fallback;return selected.id==='sour'?{...selected,name:window.GrowingSettings?.name('start')||selected.name}:selected}
 const image=step=>{const a=current();return a.id==='sour'&&step%2?'sour-wave.webp':a.image};
 function cards(query=''){
  const selected=S.set.companion_id||'sour',q=query.toLocaleLowerCase('de-DE').trim();
  return registry.filter(a=>!q||a.name.toLocaleLowerCase('de-DE').includes(q)).map(a=>`<label class="avatar-option"><input type="radio" name="companion_id" value="${a.id}"${a.id===selected?' checked':''}><span><img src="${a.image}" alt="${esc(a.name)} – Fantasiefigur" width="150" height="150" loading="lazy"><b>${esc(a.name)}</b></span></label>`).join('')||'<p class="mute">Keine passende Figur gefunden.</p>';
 }
 EXTRA.views.avatars=()=>`<div class="wrap"><div class="top"><img class="logoimg" src="logo.png?v=4" alt="Growing-Logo"><div class="hi"><b>Deine Begleiter</b><span class="mute">${registry.length} dekorative Figuren zur Auswahl</span></div></div>${S.err?`<div class="err" role="alert">${esc(S.err)}</div>`:''}${S.msg?`<div class="ok" role="status">${esc(S.msg)}</div>`:''}<div class="card"><h2>Wer begleitet dich?</h2><p class="mute">Deine Figur hilft bei der App-Bedienung. Alle Porträts sind Fantasiefiguren.</p></div><form id="avatar-settings"><div class="card"><label>Auswahlmodus<select name="companion_mode"><option value="manual"${S.set.companion_mode!=='auto'?' selected':''}>Meine Auswahl</option><option value="auto"${S.set.companion_mode==='auto'?' selected':''}>Zum Tagebuch passend</option></select></label><p class="mute ledger-hint">Die Automatik ordnet nur nach dem Namen zu. Außerhalb eines passenden Tagebuchs siehst du deine persönliche Auswahl.</p><label>Figur suchen<input id="avatar-search" type="search" placeholder="Purple Punch, Mango Sweet …" autocomplete="off"></label></div><div class="avatar-grid" id="avatar-grid">${cards()}</div><div class="avatar-save"><button class="btn led" type="submit">Auswahl speichern</button></div></form></div>`;
 const prior=EXTRA.profileBtns;
 EXTRA.profileBtns=()=>prior()+`<button class="btn led" id="avatars-open" style="width:100%;margin-bottom:8px">Charakter auswählen · ${esc(current().name)}</button>`;
 EXTRA.binds.push(on=>{
  on('#avatars-open','click',()=>{S.g=null;S.avatarDraft=null;S.view='avatars';render({resetTop:true})});
  on('#avatar-search','input',e=>{const checked=document.querySelector('#avatar-grid input:checked')?.value;if(checked)S.avatarDraft=checked;const grid=document.getElementById('avatar-grid');grid.innerHTML=cards(e.target.value);if(S.avatarDraft){const selected=grid.querySelector(`[value="${S.avatarDraft}"]`);if(selected)selected.checked=true}});
  on('#avatar-settings','submit',e=>{e.preventDefault();const f=formData(e.target),choice=f.companion_id||S.avatarDraft||S.set.companion_id||'sour';run(async()=>{if(!registry.some(a=>a.id===choice))throw Error('Bitte eine verfügbare Figur auswählen.');const next={...S.set,companion_id:choice,companion_mode:f.companion_mode==='auto'?'auto':'manual'};const result=await api('settings_save',{data:next});S.set=next;S.avatarDraft=null;S.msg=result.queued?'Deine Figur ist lokal ausgewählt und wird später synchronisiert.':'Deine Figur ist ausgewählt. Du kannst sie jederzeit im Profil ändern.'})});
 });
 window.GrowingAvatars={registry,current,image};
})();
