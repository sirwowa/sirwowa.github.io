# growfor 12.4 – Sortenkatalog, Geruch und responsive Ansichten

Installation: Diese signierte ZIP unter Admin → Updates hochladen, prüfen und installieren. Danach die App vollständig neu laden. Die vorherigen Verbesserungen aus 12.3.1 (verschiebbarer Begleiter, Comic-JSON-Import) sind enthalten.

- 552 eindeutige Sorten aus Grow_Datenbank_552_Sorten_Geruch_Messwerte.xlsx sind im Paket enthalten. Weitere Excel-Uploads sind dafür nicht notwendig.
- Vorhandene Katalogeinträge werden nach Name und Züchter ergänzt. Bestände, Preise, Artikelnummern, Aktivstatus und eigene Einträge bleiben erhalten. Mehrere Artikel derselben Sorte werden nicht zusammengelegt.
- Originale 35 Sortenfelder werden unverändert als Metadaten erhalten. Nur die Anzeige von „Gring“ wird zu „Gering“ korrigiert; der Originaltext bleibt im Datensatz.
- Geruchsstärke auf allen Growkarten und in der Growdetailansicht, einschließlich bereits vorhandener Grows mit passendem Sortennamen. Ohne eindeutige Angabe erscheint „nicht angegeben“. Dies ist ein Sortenkatalogwert, keine Messung an der Pflanze.
- Neue Sorten erscheinen in der Sortenübersicht, Suche und Auswahl bei der Growanlage. Originalangaben sind im Sortenprofil einsehbar. Neue importierte Sorten ersetzen keine individuell eingestellten Growwerte und erzeugen keine neuen automatischen Zielwerte.
- Der Excel-Import akzeptiert die bisherigen sieben Katalogspalten, die neue Vorlage mit optionalem odor sowie die gelieferten erweiterten Tabellen (22/35 Spalten). Nur das erste Blatt wird importiert; Formeln dort werden abgelehnt. Formeln in nicht importierten Vergleichsblättern blockieren den Import nicht.
- Geruch kann im Admin-Samenkatalog bearbeitet werden. Zusätzliche Originalfelder bleiben beim Bearbeiten und Export erhalten.
- Maximale Kataloggröße: 2000 Einträge. Pro Excel-Upload weiterhin höchstens 1000 Datenzeilen, 35 Spalten, 2 MB. Bei Aktualisierung eines vorhandenen Eintrags bleiben in der hochgeladenen Tabelle nicht enthaltene Bestands- und Preisfelder erhalten.
- Desktop ab 900 Pixeln: gesamte Fensterbreite, automatisch mehrere Growkarten nebeneinander; zweispaltige Growdetailansicht. Smartphone: einspaltig, Touchflächen mindestens 44 Pixel, 16-Pixel-Formularschrift, Bildschirmrandabstände und sichere untere Navigation.
- Gemischte Hell-/Dunkel-Farben auf Geräten mit heller Systemeinstellung korrigiert. Verschiebbarer Begleiter bleibt erhalten.
- Offline-Paket auf Cache-Version 25 erneuert; der Katalog wird über den vorhandenen kontogebundenen Offline-Cache gelesen.

Validierung: Originaldatei mit 552 Zeilen durch Browser-Importer und PHP-Speicherung geprüft; alle 35 Originalfelder verglichen. Frühere 500-Zeilen-Datei und aktualisierte Vorlage geprüft. UI für Suche, Growanlage, Geruchsänderung und Erhalt von Bestand/Preis/Artikelnummer getestet. Viewports 320/390/768/900/1280/1920/2560 Pixel ohne horizontalen Überlauf. Keine JavaScript-Laufzeitfehler. Diese Prüfung bestätigt Datenübernahme und Bedienung, nicht die biologische Richtigkeit der gelieferten Katalogwerte.

Das Paket enthält keine Konten, Passwörter, privaten Tagebucheinträge, Serverkonfiguration oder Datenbank. Der Live-Server wurde nicht verändert.
