/* Imported catalog values are displayed as supplied, never as live measurements. */
'use strict';
window.GrowingSeedProfiles=(()=>{
 const fold=v=>String(v||'').trim().toLocaleLowerCase('de-DE');
 const rows=()=>S.catalog?.seeds||[];
 const lookup=(name,breeder)=>{const found=rows().filter(r=>fold(r.name)===fold(name)&&(!breeder||fold(r.breeder)===fold(breeder)));return found.length===1||found.length>1&&found.every(r=>fold(r.breeder)===fold(found[0].breeder)&&(r.odor||'')===(found[0].odor||''))?found[0]:null};
 function odor(name,breeder){const r=lookup(name,breeder);return r?.odor||''}
 function badge(name,breeder){const text=odor(name,breeder);return `<span class="odor-badge${text?'':' odor-unknown'}" title="Sortenangabe aus dem Katalog, kein gemessener Pflanzenwert"><span aria-hidden="true">◌</span> Geruch: <strong>${esc(text||'nicht angegeben')}</strong></span>`}
 function catalogStrains(existing){const names=new Set(existing.map(r=>fold(r.n)));return rows().filter(r=>!names.has(fold(r.name))).map(r=>({n:r.name,b:r.breeder,gc:(()=>{const g=r.metadata?.genetik_typ||'';return /indica/i.test(g)&&/sativa/i.test(g)?'Hybrid':/indica/i.test(g)?'Indica':/sativa/i.test(g)?'Sativa':'Katalog'})(),t:/auto/i.test(r.metadata?.samen_typ||r.name)?'A':'P',catalogOnly:true}))}
 function card(name,breeder){const r=lookup(name,breeder);if(!r)return '';return `<section class="card seed-profile"><h3>${esc(r.name)}</h3><p class="mute">${esc(r.breeder)}</p>${badge(r.name,r.breeder)}<p class="mute">Importierte Katalogangaben aus deiner Excel-Datei. Keine gemessenen Pflanzenwerte; die Angaben wurden nicht fachlich verifiziert.</p>${Object.keys(r.metadata||{}).length?`<details><summary>Originale Tabellenangaben ansehen</summary><div class="seed-metadata"><table>${Object.entries(r.metadata).map(([k,v])=>`<tr><th scope="row">${esc(k.replaceAll('_',' '))}</th><td>${esc(String(v??'–'))}</td></tr>`).join('')}</table></div></details>`:''}</section>`}
 function updateBadges(){document.querySelectorAll('[data-grow-odor]').forEach(el=>el.innerHTML=badge(el.dataset.growOdor));}
 addEventListener('growing:render',updateBadges);
 return {rows,lookup,odor,badge,card,catalogStrains,updateBadges};
})();
