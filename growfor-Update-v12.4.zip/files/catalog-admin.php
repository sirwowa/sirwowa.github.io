<?php
/* Typed CMS collections; no uploaded code, prompts, credentials or executable formulas. */
function catalogNameKey(array $r): string {
 $fold=fn($v)=>function_exists('mb_strtolower')?mb_strtolower(trim((string)$v),'UTF-8'):strtolower(trim((string)$v));
 return $fold($r['name']??'').'|'.$fold($r['breeder']??'');
}
function catalogBundled(): array {
 static $rows=null;
 if($rows===null){$doc=json_decode(file_get_contents(__DIR__.'/seed-catalog-552.json'),true,64,JSON_THROW_ON_ERROR);$rows=$doc['rows'];}
 return $rows;
}
function catalogRead(PDO $db,string $key): array {
 $q=$db->prepare('SELECT data FROM app_settings WHERE setting_key=?');$q->execute([$key]);$raw=$q->fetchColumn();
  $defaults=[];if($key==='catalog_companions')foreach([['start','Sour',['setup','help']],['observe','Flora',['observations','library']],['daily','Luna',['reminders','costs']]] as [$role,$name,$caps])$defaults[]=['id'=>'builtin-'.$role,'name'=>siteSnapshot($db)['config']['companions'][$role]??$name,'description'=>'','avatar'=>$role,'capabilities'=>$caps,'active'=>true];
 $rows=$raw?json_decode($raw,true):$defaults;
 if($key==='catalog_seeds'){
  // Overlay the bundled catalog without changing stocks, prices, SKUs, active flags or user edits.
  $bundled=catalogBundled();$byName=[];foreach($bundled as $r)$byName[catalogNameKey($r)]=$r;
  $merged=[];$present=[];
  foreach($rows as $r){$id=catalogNameKey($r);$present[$id]=true;$base=$byName[$id]??[];$next=array_replace($base,$r);$next['metadata']=array_replace($base['metadata']??[],$r['metadata']??[]);$merged[]=$next;}
  foreach($bundled as $r)if(!isset($present[catalogNameKey($r)]))$merged[]=$r;
  $rows=$merged;
 }
 return ['rows'=>$rows,'version'=>hash('sha256',($raw?:'[]').($key==='catalog_seeds'?hash_file('sha256',__DIR__.'/seed-catalog-552.json'):''))];
}
function catalogKey(array $r): string {return $r['sku']!==''?'sku:'.strtolower($r['sku']):'name:'.strtolower($r['name']).'|'.strtolower($r['breeder']);}
function catalogSeed($r): array {
 if(!is_array($r)||array_diff(array_keys($r),['name','breeder','sku','stock','unit_price','source_url','active','odor','metadata']))out(['error'=>'Unbekannte Katalogspalten. Erlaubt: name, breeder, sku, stock, unit_price, source_url, active, odor, metadata.'],400);
 $v=[];foreach(['name'=>100,'breeder'=>100,'sku'=>60,'source_url'=>500] as $k=>$len)$v[$k]=adminText($r[$k]??'',$len,$k!=='name');
 if($v['source_url']!==''&&(!filter_var($v['source_url'],FILTER_VALIDATE_URL)||!in_array(strtolower(parse_url($v['source_url'],PHP_URL_SCHEME)??''),['https','http'],true)||parse_url($v['source_url'],PHP_URL_USER)||parse_url($v['source_url'],PHP_URL_PASS)))out(['error'=>'Quellenlink muss eine öffentliche HTTP(S)-Adresse ohne Zugangsdaten sein.'],400);
 $stock=$r['stock']??0;$price=$r['unit_price']??0;
 if(!is_numeric($stock)||(float)$stock!=(int)$stock||$stock<0||$stock>100000||!is_numeric($price)||!is_finite((float)$price)||$price<0||$price>1000000)out(['error'=>'Bestand muss eine ganze Zahl von 0–100000 sein; Einzelpreis 0–1000000 €.'],400);
 $v['odor']=adminText($r['odor']??'',80,true);
 $metadata=$r['metadata']??[];if(!is_array($metadata)||count($metadata)>40)out(['error'=>'Höchstens 40 zusätzliche Sortenfelder.'],400);
 $v['metadata']=[];foreach($metadata as $k=>$value){if(!is_string($k)||!preg_match('/^[a-z][a-z0-9_]{0,59}$/D',$k)||!(is_null($value)||is_string($value)||is_bool($value)||is_int($value)||is_float($value)))out(['error'=>'Ungültige zusätzliche Sortenangabe.'],400);$v['metadata'][$k]=is_string($value)?adminText($value,2000,true):$value;}
 $v['stock']=(int)$stock;$v['unit_price']=round((float)$price,2);$v['active']=$r['active']??true;if(!is_bool($v['active']))out(['error'=>'Aktiv muss Ja oder Nein sein.'],400);return $v;
}
function catalogCompanion($r): array {
 if(!is_array($r)||array_diff(array_keys($r),['id','name','description','avatar','capabilities','active','source']))out(['error'=>'Unbekannte Begleiterfelder.'],400);
 $id=$r['id']??'';if(!is_string($id)||!preg_match('/^[a-zA-Z0-9-]{8,64}$/D',$id))out(['error'=>'Ungültige Begleiterkennung.'],400);
 $avatar=$r['avatar']??'';$allowed=['start','observe','daily','purple-punch','mango-sweet'];if(!in_array($avatar,$allowed,true))out(['error'=>'Bitte eine vorhandene Figur wählen.'],400);
 $caps=$r['capabilities']??[];if(!is_array($caps)||count($caps)>6||array_diff($caps,['setup','observations','reminders','help','costs','library']))out(['error'=>'Ungültige App-Fähigkeit.'],400);
 $active=$r['active']??true;if(!is_bool($active))out(['error'=>'Aktiv muss Ja oder Nein sein.'],400);
 return ['id'=>$id,'name'=>adminText($r['name']??'',40),'description'=>adminText($r['description']??'',200,true),'avatar'=>$avatar,'capabilities'=>array_values(array_unique($caps)),'active'=>$active,'source'=>adminText($r['source']??'',30000,true)];
}
function catalogAdmin(PDO $db,int $uid,string $action,array $in): void {
 $kind=$in['kind']??'';if(!in_array($kind,['seeds','companions'],true))out(['error'=>'Unbekannter Katalog.'],400);$key='catalog_'.$kind;$old=catalogRead($db,$key);
 if($action==='admin_catalog_get')out($old);
 if(!hash_equals($old['version'],(string)($in['version']??'')))out(['error'=>'Der Katalog wurde inzwischen geändert. Bitte neu laden und vergleichen. Dein Entwurf bleibt erhalten.'],409);
 $incoming=$in['rows']??null;$max=$kind==='seeds'?2000:40;if(!is_array($incoming)||count($incoming)>$max||!array_is_list($incoming))out(['error'=>'Bitte höchstens '.$max.' Datensätze übergeben.'],400);
 $rows=[];$seen=[];$provided=[];foreach($incoming as $i=>$r){$r=$kind==='seeds'?catalogSeed($r):catalogCompanion($r);$id=$kind==='seeds'?catalogKey($r):$r['id'];if(isset($seen[$id]))out(['error'=>'Doppelter Datensatz in Zeile '.($i+1).'.'],400);$seen[$id]=true;$provided[$id]=array_fill_keys(array_keys($incoming[$i]),true);$rows[]=$r;}
 $mode=$in['mode']??'replace';if(!in_array($mode,['replace','skip','update'],true)||($kind==='companions'&&$mode!=='replace'))out(['error'=>'Importmodus prüfen.'],400);
 $added=0;$updated=0;$skipped=0;
 if($mode!=='replace'){
  $merged=[];$byName=[];foreach($old['rows'] as $r){$id=catalogKey($r);$merged[$id]=$r;$byName[catalogNameKey($r)][]=$id;}
  foreach($rows as $r){$incomingId=catalogKey($r);$id=$incomingId;
   if(!isset($merged[$id])){$candidates=$byName[catalogNameKey($r)]??[];
    if(count($candidates)===1&&($r['sku']===''||$merged[$candidates[0]]['sku']===''))$id=$candidates[0];
    elseif($r['sku']===''&&count($candidates)>1)out(['error'=>'Mehrere Artikel zu '.$r['name'].'. Bitte eine eindeutige Artikelnummer angeben.'],400);
   }
   if(isset($merged[$id])){if($mode==='skip'){$skipped++;continue;}$updated++;
    $oldRow=$merged[$id];$values=array_intersect_key($r,$provided[$incomingId]);$r=array_replace($oldRow,$values);
    $r['metadata']=array_replace($oldRow['metadata']??[],$values['metadata']??[]);
    if(($values['sku']??null)==='')$r['sku']=$oldRow['sku'];
   }else{$added++;$byName[catalogNameKey($r)][]=$id;}
   $merged[$id]=$r;
  }
  $rows=array_values($merged);if(count($rows)>$max)out(['error'=>'Der Katalog darf insgesamt höchstens '.$max.' Datensätze enthalten.'],400);
 }

 if($action==='admin_catalog_preview')out(['rows'=>$rows,'version'=>$old['version'],'added'=>$added,'updated'=>$updated,'skipped'=>$skipped]);
 $db->prepare('INSERT OR REPLACE INTO app_settings(setting_key,data) VALUES(?,?)')->execute([$key,json_encode($rows,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);adminLog($db,$uid,'catalog_save',$key,count($rows));out(['ok'=>1]+catalogRead($db,$key));
}
