import {setupInstall} from './install.js?v=45';
setupInstall();
const ios=/iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
const standalone=matchMedia('(display-mode: standalone)').matches||navigator.standalone;
const hint=document.getElementById('iphone-device-hint');
if(hint)hint.textContent=standalone?'Du hast Sideline bereits als Web-App geöffnet.':ios?(/CriOS|FxiOS|EdgiOS|OPiOS|GSA|FBAN|FBAV|Instagram/.test(navigator.userAgent)?'Bitte diese Adresse in Safari öffnen. Andere Browser und In-App-Browser zeigen den Safari-Menüpunkt möglicherweise nicht.':'Öffne die Sideline-Startseite und folge den Safari-Schritten unten.'):'Diese Anleitung gilt für Safari auf dem iPhone oder iPad.';
if(standalone){const status=document.getElementById('browser-install-status');if(status)status.textContent='Du nutzt bereits die installierte Web-App.';}
