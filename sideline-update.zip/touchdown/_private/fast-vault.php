<?php
declare(strict_types=1);
function fv_photo_url(string $id,string $side,string $token): string {return './api.php?r=card-photo&id='.rawurlencode($id).'&side='.$side.'&v='.$token;}
function fv_stamp(): string {clearstatcache(true,private_path('cards'));return is_file(private_path('cards'))?filemtime(private_path('cards')).':'.filesize(private_path('cards')):'empty';}
function fv_cache_photo(string $data): string {
 if(!preg_match('~^data:(image/(?:jpeg|png|webp));base64,(.+)$~sD',$data,$m))throw new AppError('Ungültiges gespeichertes Foto.',500);
 $hash=hash('sha256',$data);$dir=__DIR__.'/photo-cache';if(!is_dir($dir)&&!@mkdir($dir,0700))throw new AppError('Foto-Cache ist nicht beschreibbar.',503);$path=$dir.'/'.$hash.'.php';
 if(!is_file($path)){$raw=base64_decode($m[2],true);if($raw===false)throw new AppError('Gespeichertes Foto ist beschädigt.',500);$tmp=$path.'.'.bin2hex(random_bytes(5)).'.php';if(file_put_contents($tmp,PRIVATE_PREFIX.$m[1]."\n".$raw)===false||!@rename($tmp,$path)){@unlink($tmp);throw new AppError('Foto-Cache konnte nicht angelegt werden.',503);}}
 return $hash;
}
function fv_cards(): array {
 $stamp=fv_stamp();$cached=read_private('cards-meta-cache',null);if(is_array($cached)&&($cached['stamp']??'')===$stamp)return $cached['cards'];
 $h=fopen(private_path('cards-meta-build-lock'),'c+');if(!$h||!flock($h,LOCK_EX))throw new AppError('Sammlung wird gerade vorbereitet.',503);if(filesize(private_path('cards-meta-build-lock'))===0)fwrite($h,PRIVATE_PREFIX);
 try{$stamp=fv_stamp();$cached=read_private('cards-meta-cache',null);if(is_array($cached)&&($cached['stamp']??'')===$stamp)return $cached['cards'];$rows=read_private('cards',[]);
 foreach($rows as &$c){$c=expand_player_fields($c);foreach(['image','backImage']as $side)if(str_starts_with($c[$side]??'','data:image/')){$token=fv_cache_photo($c[$side]);$c[$side]=fv_photo_url($c['id'],$side,$token);}}unset($c);
 usort($rows,fn($a,$b)=>strcmp($b['createdAt'],$a['createdAt'])?:strcmp($a['id'],$b['id']));
 if(fv_stamp()===$stamp)private_transaction('cards-meta-cache',fn()=>[['stamp'=>$stamp,'cards'=>$rows],null]);return $rows;
 }finally{flock($h,LOCK_UN);fclose($h);}
}
function fv_serve(string $id,string $side,string $token): never {
 if(!preg_match('/^[a-zA-Z0-9-]{1,80}$/D',$id)||!in_array($side,['image','backImage'],true)||!preg_match('/^[a-f0-9]{64}$/D',$token))throw new AppError('Foto nicht gefunden.',404);
 $expected=fv_photo_url($id,$side,$token);$found=false;foreach(fv_cards() as $c)if($c['id']===$id&&($c[$side]??'')===$expected){$found=true;break;}if(!$found)throw new AppError('Foto nicht gefunden.',404);
 $path=__DIR__.'/photo-cache/'.$token.'.php';$f=@fopen($path,'rb');if(!$f)throw new AppError('Foto nicht gefunden.',404);$prefix=fread($f,strlen(PRIVATE_PREFIX));$mime=trim(fgets($f,80));if($prefix!==PRIVATE_PREFIX||!in_array($mime,['image/jpeg','image/png','image/webp'],true)){fclose($f);throw new AppError('Foto-Cache beschädigt.',500);}
 if(($_GET['thumb']??'')==='1'){
  $thumb=__DIR__.'/photo-cache/'.$token.'-thumb.php';
  if(!is_file($thumb)&&function_exists('imagecreatefromstring')){try{$raw=stream_get_contents($f);$im=@imagecreatefromstring($raw);if($im){$w=imagesx($im);$h=imagesy($im);$scale=min(1,640/max($w,$h));$small=imagecreatetruecolor(max(1,(int)round($w*$scale)),max(1,(int)round($h*$scale)));imagefill($small,0,0,imagecolorallocate($small,7,19,30));imagecopyresampled($small,$im,0,0,0,0,imagesx($small),imagesy($small),$w,$h);ob_start();imagejpeg($small,null,86);$jpeg=ob_get_clean();imagedestroy($im);imagedestroy($small);if(is_string($jpeg)&&$jpeg!=='')file_put_contents($thumb,PRIVATE_PREFIX."image/jpeg\n".$jpeg);}}catch(Throwable){}fseek($f,strlen(PRIVATE_PREFIX)+strlen($mime)+1);}
  if(is_file($thumb)){fclose($f);$f=fopen($thumb,'rb');fseek($f,strlen(PRIVATE_PREFIX));$mime=trim(fgets($f,80));}
 }
 header('Content-Type: '.$mime);header('Cache-Control: private, max-age=86400');header('X-Content-Type-Options: nosniff');fpassthru($f);fclose($f);exit;
}
