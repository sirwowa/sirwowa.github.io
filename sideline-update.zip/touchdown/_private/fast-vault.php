<?php
declare(strict_types=1);
function fv_photo_url(string $id,string $side,string $token): string {return './api.php?r=card-photo&id='.rawurlencode($id).'&side='.$side.'&v='.$token;}
function fv_stamp(): string {clearstatcache(true,private_path('cards'));return is_file(private_path('cards'))?filemtime(private_path('cards')).':'.filesize(private_path('cards')):'empty';}
function fv_cache_photo(string $data): string {
 if(!preg_match('~^data:(image/(?:jpeg|png|webp));base64,(.+)$~sD',$data,$m))throw new AppError('Ungültiges gespeichertes Foto.',500);
 $hash=hash('sha256',$data);$dir=__DIR__.'/photo-cache';if(!is_dir($dir)&&!@mkdir($dir,0700))throw new AppError('Foto-Cache ist nicht beschreibbar.',503);$path=$dir.'/'.$hash.'.php';
 if(!is_file($path)){$raw=base64_decode($m[2],true);if($raw===false)throw new AppError('Gespeichertes Foto ist beschädigt.',500);$tmp=$path.'.'.bin2hex(random_bytes(5)).'.php';if(file_put_contents($tmp,PRIVATE_PREFIX.$m[1]."\n".$raw)===false||!@rename($tmp,$path)){@unlink($tmp);throw new AppError('Foto-Cache konnte nicht angelegt werden.',503);}}
 return $hash;
}
function fv_cards(): array {
 $stamp=fv_stamp();$cached=read_private('cards-meta-cache',null);if(is_array($cached)&&($cached['stamp']??'')===$stamp)return $cached['cards'];
 $h=fopen(private_path('cards-meta-build-lock'),'c+');if(!$h||!flock($h,LOCK_EX))throw new AppError('Sammlung wird gerade vorbereitet.',503);if(filesize(private_path('cards-meta-build-lock'))===0)fwrite($h,PRIVATE_PREFIX);
 try{$stamp=fv_stamp();$cached=read_private('cards-meta-cache',null);if(is_array($cached)&&($cached['stamp']??'')===$stamp)return $cached['cards'];$rows=read_private('cards',[]);
 foreach($rows as &$c){$c=expand_player_fields($c);foreach(['image','backImage']as $side)if(str_starts_with($c[$side]??'','data:image/')){$token=fv_cache_photo($c[$side]);$c[$side]=fv_photo_url($c['id'],$side,$token);}}unset($c);
 usort($rows,fn($a,$b)=>strcmp($b['createdAt'],$a['createdAt'])?:strcmp($a['id'],$b['id']));
 if(fv_stamp()===$stamp)private_transaction('cards-meta-cache',fn()=>[['stamp'=>$stamp,'cards'=>$rows],null]);return $rows;
 }finally{flock($h,LOCK_UN);fclose($h);}
}
function fv_serve(string $id,string $side,string $token): never {
 if(!preg_match('/^[a-zA-Z0-9-]{1,80}$/D',$id)||!in_array($side,['image','backImage'],true)||!preg_match('/^[a-f0-9]{64}$/D',$token))throw new AppError('Foto nicht gefunden.',404);
 $expected=fv_photo_url($id,$side,$token);$permanent=false;$found=false;foreach(fv_cards() as $c)if($c['id']===$id&&($c[$side]??'')===$expected){$found=true;$permanent=($c['_storedPhotos'][$side]??'')===$token;break;}if(!$found)throw new AppError('Foto nicht gefunden.',404);
 $path=__DIR__.($permanent?'/card-photos/':'/photo-cache/').$token.'.php';$f=@fopen($path,'rb');if(!$f)throw new AppError('Foto nicht gefunden.',404);$prefix=fread($f,strlen(PRIVATE_PREFIX));$mime=trim(fgets($f,80));if($prefix!==PRIVATE_PREFIX||!in_array($mime,['image/jpeg','image/png','image/webp'],true)){fclose($f);throw new AppError('Foto-Cache beschädigt.',500);}
 if(($_GET['thumb']??'')==='1'){
  $thumbDir=__DIR__.'/photo-cache';if(!is_dir($thumbDir))@mkdir($thumbDir,0700);$thumb=$thumbDir.'/'.$token.'-thumb.php';
  if(!is_file($thumb)&&function_exists('imagecreatefromstring')){try{$raw=stream_get_contents($f);$im=@imagecreatefromstring($raw);if($im){$w=imagesx($im);$h=imagesy($im);$scale=min(1,640/max($w,$h));$small=imagecreatetruecolor(max(1,(int)round($w*$scale)),max(1,(int)round($h*$scale)));imagefill($small,0,0,imagecolorallocate($small,7,19,30));imagecopyresampled($small,$im,0,0,0,0,imagesx($small),imagesy($small),$w,$h);ob_start();imagejpeg($small,null,86);$jpeg=ob_get_clean();imagedestroy($im);imagedestroy($small);if(is_string($jpeg)&&$jpeg!=='')file_put_contents($thumb,PRIVATE_PREFIX."image/jpeg\n".$jpeg);}}catch(Throwable){}fseek($f,strlen(PRIVATE_PREFIX)+strlen($mime)+1);}
  if(is_file($thumb)){fclose($f);$f=fopen($thumb,'rb');fseek($f,strlen(PRIVATE_PREFIX));$mime=trim(fgets($f,80));}
 }
 while(ob_get_level()>0)ob_end_clean();header('Content-Type: '.$mime);header('Cache-Control: private, max-age=86400');header('X-Content-Type-Options: nosniff');fpassthru($f);fclose($f);exit;
}

function fv_store_card_photos(array $card): array {
 if(empty($card['id']))return $card;
 foreach(['image','backImage']as $side){$data=$card[$side]??'';if(!is_string($data)||!str_starts_with($data,'data:image/'))continue;
  photo_field($data);preg_match('~^data:(image/(?:jpeg|png|webp));base64,(.+)$~sD',$data,$m);$hash=hash('sha256',$data);$dir=__DIR__.'/card-photos';if(!is_dir($dir)&&!@mkdir($dir,0700)&&!is_dir($dir))throw new AppError('Der private Fotoordner kann nicht angelegt werden.',503);$path=$dir.'/'.$hash.'.php';
  if(!is_file($path)){$bytes=PRIVATE_PREFIX.$m[1]."\n".base64_decode($m[2],true);$tmp=$path.'.'.bin2hex(random_bytes(6)).'.php';if(file_put_contents($tmp,$bytes)!==strlen($bytes)||!@chmod($tmp,0600)||!@rename($tmp,$path)){@unlink($tmp);throw new AppError('Das eigene Foto konnte nicht gespeichert werden.',503);}}
  $card['_storedPhotos'][$side]=$hash;$card[$side]=fv_photo_url($card['id'],$side,$hash);
 }
 return $card;
}
function fv_own_reference(array $input,string $side): ?string {
 $url=$input[$side]??'';$id=$input['id']??'';if(!is_string($url)||!is_string($id)||!str_starts_with($url,'./api.php?r=card-photo&'))return null;
 foreach(read_private('cards',[])as $c)if($c['id']===$id&&($c[$side]??'')===$url&&isset($c['_storedPhotos'][$side]))return $url;
 return null;
}
function fv_inline_card(array $card): array {
 foreach(['image','backImage']as $side){$hash=$card['_storedPhotos'][$side]??'';if(!$hash||($card[$side]??'')!==fv_photo_url($card['id'],$side,$hash))continue;if(!preg_match('/^[a-f0-9]{64}$/D',$hash))throw new AppError('Ungültiger privater Fotoverweis.',500);$p=__DIR__.'/card-photos/'.$hash.'.php';$raw=@file_get_contents($p);if(!is_string($raw)||!str_starts_with($raw,PRIVATE_PREFIX))throw new AppError('Ein eigenes Foto fehlt im privaten Fotoordner.',500);$offset=strpos($raw,"\n",strlen(PRIVATE_PREFIX));if($offset===false)throw new AppError('Das gespeicherte Foto ist beschädigt.',500);$mime=substr($raw,strlen(PRIVATE_PREFIX),$offset-strlen(PRIVATE_PREFIX));if(!in_array($mime,['image/jpeg','image/png','image/webp'],true))throw new AppError('Ungültiges eigenes Foto.',500);$card[$side]='data:'.$mime.';base64,'.base64_encode(substr($raw,$offset+1));}
 unset($card['_storedPhotos']);return $card;
}

// Private, opt-in photo pack import.

function vi_norm(mixed $v): string {return strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/',' ',(string)$v)));}
function vi_variant(array $c): string {return vi_norm(str_replace('(Nutzerangabe)','',(string)($c['parallel']??'')));}
function vi_version(array $c): string {return hash('sha256',json_encode($c,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES));}
function vi_fingerprint(array $c): string {$v=[];foreach(['player','year','set','number','parallel','serialNumber','sport','team','jerseyNumber','position','cardType']as $f)$v[]=$c[$f]??'';foreach(['image','backImage']as $f)$v[]=str_starts_with($c[$f]??'','data:image/')?hash('sha256',$c[$f]):($c['_storedPhotos'][$f]??'');return hash('sha256',json_encode($v,JSON_THROW_ON_ERROR));}
function vi_family(array $c): string {$set=explode('·',$c['set']??'')[0];return trim(preg_replace('/\b(?:panini|topps|football|multi sport|collection|20\d\d)\b/','',vi_norm($set)));}
function vi_candidates(array $c,array $rows): array {
 $out=[];foreach($rows as $r){if(($r['status']??'')==='Wunschliste'||vi_norm($r['player']??'')!==vi_norm($c['player'])||vi_family($r)!==vi_family($c))continue;
  $serial=serial_identity($c['serialNumber']??'');$sameSerial=$serial!==''&&$serial===serial_identity($r['serialNumber']??'');$sameNumber=vi_norm($r['number']??'')===vi_norm($c['number']);
  $sameYear=($r['year']??'')===$c['year'];$sameVariant=vi_variant($r)===vi_variant($c)&&$serial===serial_identity($r['serialNumber']??'');$sameSet=vi_norm($r['set']??'')===vi_norm($c['set']??'');$sameGrade=vi_norm(($r['grader']??'').' '.($r['grade']??''))===vi_norm(($c['grader']??'').' '.($c['grade']??''));
  $out[]=['id'=>$r['id'],'player'=>$r['player'],'set'=>$r['set'],'year'=>$r['year']??'','version'=>vi_version($r),'number'=>$r['number'],'parallel'=>$r['parallel'],'serialNumber'=>$r['serialNumber']??'','exact'=>($sameNumber||$sameSerial)&&$sameYear&&$sameGrade&&$sameVariant&&(($sameSerial&&vi_variant($c)!=='')||($sameSet&&!empty($c['parallelConfirmed'])))];
 }return $out;
}
function vi_preview(array $input): array {
 $items=$input['items']??null;if(!is_array($items)||!array_is_list($items)||count($items)>100)throw new AppError('Bitte höchstens 100 Karten pro Vorschau auswählen.');$rows=read_private('cards',[]);$out=[];
 foreach($items as $item){$key=text_field($item['key']??'',80);if(!preg_match('/^[a-f0-9-]{36}$/D',$key))throw new AppError('Ungültige Paket-Kartenkennung.');$card=validate_card($item['card']??null);$prior=array_values(array_filter($rows,fn($r)=>($r['_vaultImportKey']??'')===$key));$matches=vi_candidates($card,$rows);foreach($prior as $previous)if(!in_array($previous['id'],array_column($matches,'id'),true))$matches[]=['id'=>$previous['id'],'player'=>$previous['player'],'set'=>$previous['set'],'year'=>$previous['year'],'version'=>vi_version($previous),'number'=>$previous['number'],'parallel'=>$previous['parallel'],'serialNumber'=>$previous['serialNumber']??'','exact'=>false];$exact=array_values(array_filter($matches,fn($r)=>$r['exact']));$out[]=['key'=>$key,'matches'=>$matches,'decision'=>$prior?'skip':(count($exact)===1?'merge':($matches?'skip':'create')),'targetId'=>$prior?($prior[0]['id']):(count($exact)===1?$exact[0]['id']:''),'alreadyImported'=>(bool)$prior];}
 return ['items'=>$out];
}
function vi_apply(array $input): array {
 $key=text_field($input['key']??'',80);if(!preg_match('/^[a-f0-9-]{36}$/D',$key))throw new AppError('Ungültige Paket-Kartenkennung.');$card=validate_card($input['card']??null);if(!$card['image']||!$card['backImage'])throw new AppError('Für diesen Foto-Import werden Vorder- und Rückseite benötigt.');$decision=$input['decision']??'';$target=text_field($input['targetId']??'',80);$targetVersion=text_field($input['targetVersion']??'',80);if(!in_array($decision,['create','separate','merge'],true))throw new AppError('Bitte eine gültige Zuordnung wählen.');
 $digest=hash('sha256',json_encode($card,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES));
 return private_transaction('cards',function($rows)use($card,$key,$digest,$decision,$target,$targetVersion){$rows??=[];foreach($rows as $r)if(($r['_vaultImportKey']??'')===$key&&($r['_vaultImportHash']??'')===$digest&&($r['_vaultImportFingerprint']??'')===vi_fingerprint($r))return[$rows,['id'=>$r['id'],'action'=>'skipped']];
  if($decision==='merge'){$index=array_search($target,array_column($rows,'id'),true);if($index===false)throw new AppError('Die ausgewählte VAULT-Karte existiert nicht mehr.',409);$old=$rows[$index];if($targetVersion===''||vi_version($old)!==$targetVersion)throw new AppError('Die Zielkarte wurde zwischenzeitlich geändert. Bitte die Zuordnung erneut prüfen.',409);$next=$old;
   foreach(['player','year','set','number','parallel','serialNumber','team','jerseyNumber','position','cardType','sport','catalogSource']as $k)if($card[$k]!=='')$next[$k]=$card[$k];
   foreach(['cardsightId','cardsightSetId','cardsightReleaseId','localCatalogId','localSetId']as $k)$next[$k]='';$next['year']=$card['year'];$next['parallel']=$card['parallel'];$next['parallelConfirmed']=$card['parallelConfirmed'];$next['image']=$card['image'];$next['backImage']=$card['backImage'];$next['catalogImage']=false;$next['notes']=substr(trim(($old['notes']??'')."\n".$card['notes']),0,4000);$next['notes']=rtrim($next['notes']);while(!preg_match('//u',$next['notes']))$next['notes']=substr($next['notes'],0,-1);$next['updatedAt']=now_iso();
   if(isset($next['scan']))$next['scan']=array_merge($next['scan'],['queueState'=>'done','lease'=>'','leaseUntil'=>0,'message'=>'']);$next['_vaultImportFingerprint']=vi_fingerprint($next);$next['_vaultImportKey']=$key;$next['_vaultImportHash']=$digest;$rows[$index]=$next;return[$rows,['id'=>$next['id'],'action'=>'updated']];
  }
  $matches=vi_candidates($card,$rows);if($decision==='create'&&array_filter($matches,fn($m)=>$m['exact']||(($m['year']??'')===$card['year']&&vi_norm($m['number'])===vi_norm($card['number']))||(serial_identity($card['serialNumber'])!==''&&serial_identity($m['serialNumber'])===serial_identity($card['serialNumber']))))throw new AppError('Passende Karte inzwischen vorhanden. Bitte Vorschau erneut prüfen oder bewusst als weiteres Exemplar anlegen.',409);
  $card['id']=uuid();$card['createdAt']=$card['updatedAt']=now_iso();$card['_vaultImportFingerprint']=vi_fingerprint($card);$card['_vaultImportKey']=$key;$card['_vaultImportHash']=$digest;$rows[]=$card;return[$rows,['id'=>$card['id'],'action'=>'created']];
 });
}

// Signed program descriptor + authenticated encrypted owner-only photo delivery.
function vb_descriptor(): ?array {
 $path=dirname(__DIR__).'/vault-photo-bundle.json';if(!is_file($path))return null;
 try{$d=json_decode(file_get_contents($path),true,32,JSON_THROW_ON_ERROR);}catch(Throwable){throw new AppError('Das vorbereitete Fotopaket ist beschädigt.',503);}
 if(($d['format']??'')!=='sideline-encrypted-vault-v1'||!preg_match('/^[a-f0-9-]{36}$/D',$d['id']??'')||!is_array($d['files']??null)||count($d['files'])!==($d['count']??0)||$d['count']>100||$d['count']<1||($d['baseUrl']??'')!=='https://raw.githubusercontent.com/sirwowa/sirwowa.github.io/main/sideline-vault-data/'.$d['id'].'/')throw new AppError('Ungültiges vorbereitetes Fotopaket.',503);
 foreach($d['files']as $f)if(!preg_match('/^[a-f0-9]{40}\.bin$/D',$f['name']??'')||!preg_match('/^[a-f0-9]{64}$/D',$f['sha256']??'')||!is_int($f['bytes']??null)||$f['bytes']<29||$f['bytes']>16000000)throw new AppError('Ungültiger verschlüsselter Fotoverweis.',503);
 return $d;
}
function vb_key(array $d,array $config): ?string {
 if(!function_exists('openssl_decrypt')||!function_exists('hash_hkdf'))return null;
 foreach(['apiKey','geminiKey','externalCardApiKey','externalCardVaultKey']as $field){$secret=trim((string)($config[$field]??''));if($secret==='')continue;foreach($d['keySlots']??[]as $slot){$salt=base64_decode($slot['salt']??'',true);$nonce=base64_decode($slot['nonce']??'',true);$wrapped=base64_decode($slot['wrapped']??'',true);if($salt===false||strlen($salt)!==16||$nonce===false||strlen($nonce)!==12||$wrapped===false||strlen($wrapped)!==48)continue;$derived=hash_hkdf('sha256',$secret,32,'sideline-vault-wrap-v1',$salt);$key=openssl_decrypt(substr($wrapped,0,-16),'aes-256-gcm',$derived,OPENSSL_RAW_DATA,$nonce,substr($wrapped,-16),$d['id']);if(is_string($key)&&strlen($key)===32)return $key;}}
 return null;
}
function vb_status(array $config): array {
 $d=vb_descriptor();if(!$d)return ['available'=>false,'total'=>0,'completed'=>0,'done'=>true];$state=read_private('vault-bundle-progress',[]);$done=($state['id']??'')===$d['id']?min($d['count'],(int)($state['completed']??0)):0;
 return ['available'=>vb_key($d,$config)!==null,'total'=>$d['count'],'completed'=>$done,'done'=>$done===$d['count']];
}
function vb_download(string $url,int $length): string {
 if(!function_exists('curl_init'))throw new AppError('Das Hosting benötigt PHP-cURL für die automatische Fotoübernahme.',503);
 $ch=curl_init($url);$raw='';curl_setopt_array($ch,[CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>25,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_HTTPHEADER=>['Accept: application/octet-stream'],CURLOPT_WRITEFUNCTION=>static function($ch,$chunk)use(&$raw,$length){if(strlen($raw)+strlen($chunk)>$length)return 0;$raw.=$chunk;return strlen($chunk);}]);$ok=curl_exec($ch);$status=curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);if($ok===false||$status!==200||strlen($raw)!==$length)throw new AppError('Die Fotoübernahme pausiert wegen der Verbindung. Sie wird beim nächsten Öffnen fortgesetzt.',503);return $raw;
}
function vb_decode(array $d,int $index,string $key,string $raw): array {
 $f=$d['files'][$index];if(strlen($raw)!==$f['bytes']||!hash_equals($f['sha256'],hash('sha256',$raw)))throw new AppError('Die Foto-Prüfsumme stimmt nicht. Es wurde nichts übernommen.',503);
 $plain=openssl_decrypt(substr($raw,12,-16),'aes-256-gcm',$key,OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,-16),'sideline-vault:'.$d['id'].':'.$index);
 if(!is_string($plain)||substr($plain,0,4)!=='SLV1'||strlen($plain)<8)throw new AppError('Das persönliche Fotopaket konnte nicht geprüft werden.',503);
 $n=unpack('Nsize',substr($plain,4,4))['size'];if($n<2||$n>100000||strlen($plain)<8+$n)throw new AppError('Ungültige Foto-Metadaten.',503);$h=json_decode(substr($plain,8,$n),true,32,JSON_THROW_ON_ERROR);$a=$h['frontLength']??0;$b=$h['backLength']??0;$ref=$h['referenceLength']??0;
 if(!is_int($a)||!is_int($b)||!is_int($ref)||$a<1||$b<1||$ref<0||max($a,$b,$ref)>5242880||strlen($plain)!==8+$n+$a+$b+$ref||!preg_match('/^[a-f0-9-]{36}$/D',$h['key']??''))throw new AppError('Ungültige Fotoabmessungen im Paket.',503);
 $h['card']['image']='data:image/webp;base64,'.base64_encode(substr($plain,8+$n,$a));$h['card']['backImage']='data:image/webp;base64,'.base64_encode(substr($plain,8+$n+$a,$b));$h['reference']=$ref?substr($plain,-$ref):'';return $h;
}
function vb_step(array $config,?callable $transport=null): array {
 $d=vb_descriptor();if(!$d)return vb_status($config);$key=vb_key($d,$config);if($key===null)throw new AppError('Bitte einen deiner bisherigen Cardsight-, Gemini-, TheCardAPI- oder CardVault-Schlüssel in den Einstellungen hinterlegen. Damit wird dein persönliches Fotopaket automatisch freigeschaltet.',409);
 $lock=fopen(private_path('vault-bundle-operation-lock'),'c+');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new AppError('Die Fotoübernahme läuft bereits auf einem anderen Gerät.',409);if(filesize(private_path('vault-bundle-operation-lock'))===0)fwrite($lock,PRIVATE_PREFIX);
 try{$state=read_private('vault-bundle-progress',[]);$i=($state['id']??'')===$d['id']?(int)($state['completed']??0):0;if($i>=$d['count'])return vb_status($config);$f=$d['files'][$i];$raw=($transport??'vb_download')($d['baseUrl'].$f['name'],$f['bytes']);$item=vb_decode($d,$i,$key,$raw);$rows=read_private('cards',[]);$prior=array_values(array_filter($rows,fn($c)=>($c['_vaultImportKey']??'')===$item['key']));
  if(!$prior){$card=validate_card($item['card']);$matches=vi_candidates($card,$rows);$exact=array_values(array_filter($matches,fn($m)=>$m['exact']));
   // Correct a unique unconfirmed identity, but never overwrite another confirmed variant.
   if(!$exact&&count($matches)===1){$m=$matches[0];$old=$rows[array_search($m['id'],array_column($rows,'id'),true)];$compatible=empty($old['parallelConfirmed'])||vi_variant($old)===vi_variant($card);$serialCompatible=serial_identity($old['serialNumber']??'')===serial_identity($card['serialNumber']);if($compatible&&$serialCompatible&&$m['year']===$card['year']&&vi_norm($m['number'])===vi_norm($card['number'])&&vi_norm(($old['grader']??'').' '.($old['grade']??''))===vi_norm(($card['grader']??'').' '.($card['grade']??'')))$exact=[$m];}
   $match=count($exact)===1?$exact[0]:null;$result=vi_apply(['key'=>$item['key'],'card'=>$item['card'],'decision'=>$match?'merge':($matches?'separate':'create'),'targetId'=>$match['id']??'','targetVersion'=>$match['version']??'']);
  }
  if($item['reference']!==''){$dir=__DIR__.'/vault-retouch-references';if(!is_dir($dir)&&!@mkdir($dir,0700)&&!is_dir($dir))throw new AppError('Die Originalreferenz konnte nicht gesichert werden.',503);$path=$dir.'/'.$item['key'].'.php';$bytes=PRIVATE_PREFIX."image/webp\n".$item['reference'];if(!is_file($path)||!hash_equals(hash('sha256',$bytes),hash_file('sha256',$path))){$tmp=$path.'.'.bin2hex(random_bytes(5)).'.php';if(file_put_contents($tmp,$bytes,LOCK_EX)!==strlen($bytes)||!@chmod($tmp,0600)||!@rename($tmp,$path)){@unlink($tmp);throw new AppError('Die Originalreferenz konnte nicht vollständig gesichert werden.',503);}}}
  private_transaction('vault-bundle-progress',fn()=>[['id'=>$d['id'],'completed'=>$i+1,'updatedAt'=>now_iso()],null]);return vb_status($config);
 }finally{flock($lock,LOCK_UN);fclose($lock);}
}
