<?php
declare(strict_types=1);
const SIDELINE_UPDATE_PUBLIC_KEY = <<<'KEY'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEApUuAyGEucAa0RnhOUPbd
Mn2QieCaRa4/mzphteVtg1QqMlf9sb4v/tEboQo7rJ8gW2Ck0MwDbL8qAejeNa4B
v5YSaEow4eu4opLzwzVPR5LBiTZ3ah5Wg4KunGYuliPGTSLhAEQYDlM619BP/QEq
B7MHVX7eWd9xrVC/n47gItr1Jxvluv7iDvDuiFBbUf7FlNLZ0JcBSfu+sNpWBBHi
J+++H5GP4zrI6/QUQUL8E5iq6ya30iXIcvcKpoVRog/GZmnvirhXX4n04XXDRJOL
h0NwE0kIswik5FpXqRTiHKv/LHW5tBS4DYaNu+HJPhvHCY91hjU2/6J4zzGQJfkv
outyZqWxVffcuedcSaYYLALkpCd9vw2oFclDHC0tMH9nGb/jkZRMs0s/9H71g9Fo
KK+/4lJgU2GsREnX25jvXeE/fbQpaSdTieD1QjYz49LvLZLKBEfcLFwf8dkw25Ph
m7sgowY3oenfERcKXsvQdYufwI2ke5VJe3lUlDw6UC2hAgMBAAE=
-----END PUBLIC KEY-----
KEY;
function su_error(string $message): never {throw new AppError($message,400);}
function su_path(string $path): bool {
 if($path===''||strlen($path)>220||str_contains($path,'\\')||str_starts_with($path,'/')||str_contains($path,'//')||preg_match('/[\x00-\x1f:]/',$path))return false;
 foreach(explode('/',$path) as $part)if($part===''||$part==='.'||$part==='..')return false;
 if(!str_starts_with($path,'touchdown/'))return false;
 $p=substr($path,10);
 if(str_starts_with($p,'_private/'))return in_array(substr($p,9),['.htaccess','bootstrap.php','features.php','checklists.php','sports.php','view.php','integrations.php','usage-limit.php','own-catalog.php','gemini.php','thecardapi.php','card-autofill.php','cardvault.php','nflverse.php','nflverse-data.php','nfl-card-seed.php','nfl-seed-index.php','nfl-catalog.php','card-pipeline.php','manual-sync.php','photo-queue.php','ki-scan.php','ebay-fallback.php','ximilar.php','auto-market.php','cardloader.php','updater.php','fast-vault.php'],true)||preg_match('~^_private/nfl-seed/[a-f0-9]{24}\.php$~D',$p)===1;
 return !str_contains($p,'/.')&&preg_match('~^(?:[a-zA-Z0-9_-]+/)*[a-zA-Z0-9_.-]+\.(?:php|js|css|json|html|svg|png|jpg|webp|txt|wasm|gz|webmanifest)$~D',$p)===1||in_array($p,['.htaccess','.user.ini'],true);
}
/* Read only ordinary stored/deflated ZIPs. No extraction to paths from the archive. */
function su_zip(string $file): array {
 $size=filesize($file);if($size===false||$size<22||$size>33554432)su_error('Bitte eine vollständige Update-ZIP bis 32 MB auswählen.');
 $raw=file_get_contents($file);$end=strrpos($raw,"PK\x05\x06");if($end===false||$end<strlen($raw)-65557||$end+22>strlen($raw))su_error('Die ZIP-Datei ist unvollständig.');
 $e=unpack('vdisk/vstart/vcountDisk/vcount/Vlength/Voffset/vcomment',substr($raw,$end+4,18));
 if($e['disk']||$e['start']||$e['count']!==$e['countDisk']||$e['count']>800||$e['count']<3||$e['offset']+$e['length']!==$end||$end+22+$e['comment']!==strlen($raw))su_error('Dieses ZIP-Format wird nicht unterstützt.');
 $pos=$e['offset'];$entries=[];$total=0;
 for($i=0;$i<$e['count'];$i++){
  if(substr($raw,$pos,4)!=="PK\x01\x02"||$pos+46>$end)su_error('Die ZIP-Struktur ist beschädigt.');
  $h=unpack('vmade/vneed/vflags/vmethod/vtime/vdate/Vcrc/Vcompressed/Vsize/vname/vextra/vcomment/vdisk/vinternal/Vexternal/Voffset',substr($raw,$pos+4,42));
  $name=substr($raw,$pos+46,$h['name']);$pos+=46+$h['name']+$h['extra']+$h['comment'];
  $mode=($h['external']>>16)&0170000;
  if($pos>$end||isset($entries[$name])||$h['disk']||($h['flags']&1)||!in_array($h['method'],[0,8],true)||$h['size']>50000000||($mode!==0&&$mode!==0100000)||$h['offset']+30>$e['offset'])su_error('Die ZIP enthält unzulässige Einträge.');
  $total+=$h['size'];if($total>200000000)su_error('Das entpackte Update ist zu groß.');
  if(substr($raw,$h['offset'],4)!=="PK\x03\x04")su_error('Ein ZIP-Eintrag fehlt.');
  $local=unpack('vneed/vflags/vmethod/vtime/vdate/Vcrc/Vcompressed/Vsize/vname/vextra',substr($raw,$h['offset']+4,26));
  $start=$h['offset']+30+$local['name']+$local['extra'];
  if(substr($raw,$h['offset']+30,$local['name'])!==$name||$local['method']!==$h['method']||($local['flags']&1)||$start+$h['compressed']>$e['offset'])su_error('ZIP-Einträge stimmen nicht überein.');
  $entries[$name]=['start'=>$start,'length'=>$h['compressed'],'size'=>$h['size'],'method'=>$h['method']];
 }
 if($pos!==$end)su_error('Das ZIP-Verzeichnis ist beschädigt.');
 return ['raw'=>$raw,'entries'=>$entries];
}
function su_bytes(array $zip,string $name): string {
 $entry=$zip['entries'][$name]??null;if(!$entry)su_error('Eine erforderliche Update-Datei fehlt.');
 $bytes=substr($zip['raw'],$entry['start'],$entry['length']);if($entry['method']===8)$bytes=@gzinflate($bytes,$entry['size']+1);
 if(!is_string($bytes)||strlen($bytes)!==$entry['size'])su_error('Eine Update-Datei ist beschädigt.');return $bytes;
}
function su_validate(string $file): array {
 if(!function_exists('openssl_verify')||!function_exists('gzinflate'))throw new AppError('PHP benötigt OpenSSL und zlib für Updates.',503);
 $zip=su_zip($file);$manifest=su_bytes($zip,'sideline-update-manifest.json');$sig=base64_decode(trim(su_bytes($zip,'sideline-update-signature.txt')),true);
 if($sig===false||openssl_verify($manifest,$sig,SIDELINE_UPDATE_PUBLIC_KEY,OPENSSL_ALGO_SHA256)!==1)su_error('Diese Datei ist kein unverändertes, signiertes Sideline-Update.');
 try{$m=json_decode($manifest,true,32,JSON_THROW_ON_ERROR);}catch(JsonException){su_error('Das Update-Verzeichnis ist ungültig.');}
 if(($m['app']??'')!=='sideline'||($m['schema']??0)!==1||!is_int($m['build']??null)||!is_array($m['files']??null)||count($m['files'])<20||count($m['files'])>700)su_error('Das Paket passt nicht zu Sideline.');
 if($m['build']<(int)SIDELINE_BUILD)su_error('Dieses Paket ist älter als deine installierte Version.');
 foreach(['touchdown/api.php','touchdown/_private/bootstrap.php','touchdown/_private/updater.php','touchdown/app.js','touchdown/sw.js'] as $required)if(!isset($m['files'][$required]))su_error('Das Update ist nicht vollständig.');
 foreach($m['files'] as $name=>$hash){if(!is_string($name)||!su_path($name)||!is_string($hash)||!preg_match('/^[a-f0-9]{64}$/D',$hash))su_error('Das Update versucht geschützte Dateien zu verändern.');if(!hash_equals($hash,hash('sha256',su_bytes($zip,$name))))su_error('Eine Update-Datei stimmt nicht mit ihrer Signatur überein.');}
 foreach(array_keys($zip['entries']) as $name){if(str_starts_with($name,'touchdown/')&&!isset($m['files'][$name]))su_error('Die ZIP enthält eine nicht freigegebene Programmdatei.');if(!str_starts_with($name,'touchdown/')&&!in_array($name,['sideline-update-manifest.json','sideline-update-signature.txt'],true)&&!preg_match('~^(?:[A-Z0-9-]+\.txt|CHECKLISTEN/[a-zA-Z0-9_.-]+\.(?:zip|csv))$~D',$name))su_error('Die ZIP enthält unerwartete Dateien.');}
 return ['manifest'=>$m,'zip'=>$zip];
}
function su_target(string $root,string $name): string {
 if(!su_path($name))su_error('Ungültiger Update-Pfad.');$relative=substr($name,10);$parts=explode('/',$relative);$p=rtrim($root,'/');
 foreach($parts as $part){$p.='/'.$part;if(is_link($p))su_error('Ein Update-Ziel ist eine Verknüpfung. Bitte Dateistruktur prüfen.');}
 return $p;
}
function su_apply(string $file,?string $root=null,?callable $injectFailure=null): array {
 $root??=dirname(__DIR__);$v=su_validate($file);$m=$v['manifest'];$lock=fopen($root.'/_private/update-operation-lock.php','c+');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new AppError('Ein Update läuft bereits. Bitte kurz warten.',409);
 if(filesize($root.'/_private/update-operation-lock.php')===0)fwrite($lock,PRIVATE_PREFIX);
 $work=$root.'/_private/update-work-'.bin2hex(random_bytes(8));$written=[];$created=[];$backup=[];$keepWork=false;
 try{
  if(!@mkdir($work,0700))throw new AppError('Der Server kann keine Update-Sicherung anlegen.',503);
  foreach($m['files'] as $name=>$hash){$target=su_target($root,$name);$parent=dirname($target);if(!is_dir($parent)){if(!@mkdir($parent,0755,true))throw new AppError('Ein Update-Ordner ist nicht beschreibbar.',503);$created[]=$parent;}
   if(!is_writable($parent)||(is_file($target)&&!is_writable($target))||is_dir($target))throw new AppError('Programmdateien sind nicht beschreibbar. Bitte die Dateirechte im Hosting prüfen.',503);
   $before=is_file($target)?file_get_contents($target):null;if($before===false)throw new AppError('Eine Programmdatei konnte nicht gesichert werden.',503);
   $key=hash('sha256',$name);if(file_put_contents($work.'/'.$key.'.php',PRIVATE_PREFIX.json_encode(['name'=>$name,'before'=>$before===null?null:base64_encode($before),'mode'=>is_file($target)?(fileperms($target)&0777):0644,'after'=>base64_encode(su_bytes($v['zip'],$name))],JSON_THROW_ON_ERROR))===false)throw new AppError('Die Update-Sicherung ist fehlgeschlagen.',503);
   $backup[$name]=$key;
  }
  $names=array_keys($backup);usort($names,fn($a,$b)=>(str_ends_with($a,'/bootstrap.php')?2:(str_ends_with($a,'.php')?1:0))<=>(str_ends_with($b,'/bootstrap.php')?2:(str_ends_with($b,'.php')?1:0)));
  foreach($names as $name){$target=su_target($root,$name);$item=json_decode(substr(file_get_contents($work.'/'.$backup[$name].'.php'),strlen(PRIVATE_PREFIX)),true,32,JSON_THROW_ON_ERROR);$bytes=base64_decode($item['after'],true);$tmp=dirname($target).'/.sideline-update-'.bin2hex(random_bytes(6)).'.tmp';
   if(file_put_contents($tmp,$bytes)===false||!@chmod($tmp,is_file($target)?(fileperms($target)&0777):0644)||!@rename($tmp,$target)){@unlink($tmp);throw new RuntimeException('Update write failed');}$written[]=$name;if(function_exists('opcache_invalidate')&&str_ends_with($target,'.php'))@opcache_invalidate($target,true);if($injectFailure)$injectFailure(count($written));
  }
  $receipt=['build'=>$m['build'],'at'=>gmdate('c'),'files'=>count($written)];file_put_contents($work.'/receipt.php',PRIVATE_PREFIX.json_encode($receipt,JSON_THROW_ON_ERROR));
  return ['ok'=>true]+$receipt;
 }catch(Throwable $e){
  $failed=false;foreach(array_reverse($written) as $name){try{$target=su_target($root,$name);$item=json_decode(substr(file_get_contents($work.'/'.$backup[$name].'.php'),strlen(PRIVATE_PREFIX)),true,32,JSON_THROW_ON_ERROR);if($item['before']===null){if(!@unlink($target))$failed=true;}else{$tmp=dirname($target).'/.sideline-restore-'.bin2hex(random_bytes(6)).'.tmp';if(file_put_contents($tmp,base64_decode($item['before'],true))===false||!@chmod($tmp,$item['mode'])||!@rename($tmp,$target)){$failed=true;@unlink($tmp);}if(function_exists('opcache_invalidate'))@opcache_invalidate($target,true);}}catch(Throwable){$failed=true;}}
  if($failed){$keepWork=true;throw new AppError('Das Update wurde unterbrochen; die automatische Wiederherstellung war nicht vollständig. Bitte das geprüfte Komplettpaket per Hosting-Dateimanager/FTP aufspielen. Deine Sammlung wurde vom Update nicht verändert.',503);}
  if($e instanceof AppError)throw $e;throw new AppError('Update abgebrochen. Die bisherigen Programmdateien wurden wiederhergestellt.',503);
 }finally{flock($lock,LOCK_UN);fclose($lock);if(!$keepWork&&is_dir($work)){foreach(scandir($work) as $entry)if($entry!=='.'&&$entry!=='..')@unlink($work.'/'.$entry);@rmdir($work);}}
}
function su_limit(string $raw): int {$n=(int)$raw;return $n*match(strtolower(substr(trim($raw),-1))){'g'=>1073741824,'m'=>1048576,'k'=>1024,default=>1};}
function su_status(): array {return ['build'=>SIDELINE_BUILD,'available'=>function_exists('openssl_verify')&&function_exists('gzinflate')&&is_writable(dirname(__DIR__))&&is_writable(__DIR__),'maxBytes'=>min(33554432,(su_limit(ini_get('upload_max_filesize'))?:33554432),(su_limit(ini_get('post_max_size'))?:33619968)-65536)];}
