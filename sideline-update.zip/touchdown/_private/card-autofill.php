<?php
declare(strict_types=1);

function full_card_type(string $value,string $sport=''): string {
    if(preg_match('/pok[eé]mon|magic|yu-gi|trading card game/i',$sport))return $value;
    $map=['ROOKIE_CARD'=>'Rookie-Karte','BASE_CARD'=>'Basiskarte','AUTOGRAPH_CARD'=>'Autogrammkarte','MEMORABILIA_CARD'=>'Memorabilia-Karte','SUPER SHORT PRINT'=>'Karte in sehr kurzer Auflage','SUPER_SHORT_PRINT'=>'Karte in sehr kurzer Auflage','SHORT PRINT'=>'Karte in kurzer Auflage','SHORT_PRINT'=>'Karte in kurzer Auflage','SHORTPRINT'=>'Karte in kurzer Auflage','ROOKIE PATCH AUTOGRAPH'=>'Rookie-Karte mit Patch und Autogramm','ROOKIE CARD'=>'Rookie-Karte','BASE CARD'=>'Basiskarte','RPA'=>'Rookie-Karte mit Patch und Autogramm','RC'=>'Rookie-Karte','ROOKIE'=>'Rookie-Karte','AUTO'=>'Autogrammkarte','AU'=>'Autogrammkarte','AUTOGRAPH'=>'Autogrammkarte','AUTOGRAPHED'=>'Autogrammkarte','BASE'=>'Basiskarte','MEM'=>'Memorabilia-Karte','MEMORABILIA'=>'Memorabilia-Karte','RELIC'=>'Memorabilia-Karte','PATCH'=>'Patch-Karte','INSERT'=>'Sonderkarte','PARALLEL'=>'Parallelkarte','SSP'=>'Karte in sehr kurzer Auflage','SP'=>'Karte in kurzer Auflage'];
    $out=[];
    foreach(preg_split('~[,;/|]+~u',$value)as $part){
        $part=trim($part);if($part==='')continue;$key=strtoupper($part);
        if(isset($map[$key])){$out[]=$map[$key];continue;}
        $words=preg_split('/\s+/u',$part);$known=count($words)>1;
        foreach($words as $word)if(!isset($map[strtoupper($word)])){$known=false;break;}
        if($known)foreach($words as $word)$out[]=$map[strtoupper($word)];else $out[]=$part;
    }
    return implode(' / ',array_values(array_unique($out)));
}
function af_jersey(string $value): string {
    $clean=trim(preg_replace('/^(?:#|No\.?|Nr\.?|№)\s*/iu','',trim($value))??$value);
    return preg_match('/^\d{1,3}$/D',$clean)?$clean:$value;
}
function af_parallel_candidates(array $parallels,array $card=[],int $maximum=120): array {
    $items=[];foreach($parallels as $p){if(!is_array($p))continue;$name=clean_api_text($p['name']??'');if($name==='')continue;$n=$p['numberedTo']??null;$items[$name]=['name'=>$name,'numberedTo'=>is_numeric($n)&&(float)$n===(float)(int)$n&&(int)$n>0?(int)$n:null];}
    $serial=$card['serialNumber']??'';$limit=preg_match('~^\s*\d+\s*/\s*(\d+)\s*$~D',$serial,$m)?(int)$m[1]:0;$selected=$card['parallel']??'';
    $items=array_values($items);usort($items,fn($a,$b)=>(int)($b['name']===$selected)<=>(int)($a['name']===$selected) ?: ($limit?((int)($b['numberedTo']===$limit)<=>(int)($a['numberedTo']===$limit)):0) ?: (($a['numberedTo']??PHP_INT_MAX)<=>($b['numberedTo']??PHP_INT_MAX)) ?: strcasecmp($a['name'],$b['name']));return array_slice($items,0,$maximum);
}
function af_catalog_info(array $details): array {
    $limits=[];foreach($details['parallels']??[]as $p)if(!empty($p['name'])&&is_numeric($p['numberedTo']??null)&&(int)$p['numberedTo']>0)$limits[normalized(clean_api_text($p['name']))]=(int)$p['numberedTo'];
    return array_merge(['parallelLimits'=>$limits,'parallelCandidates'=>af_parallel_candidates($details['parallels']??[],[],1000)],card_metadata($details),['player'=>clean_api_text($details['name']??''),'year'=>clean_api_text((string)($details['releaseYear']??'')),'number'=>clean_api_text($details['number']??''),'set'=>clean_api_text(implode(' · ',array_filter([$details['releaseName']??'',$details['setName']??''])))]);
}
function af_cache_catalog(string $id,string $key,array $details): array {
    $info=af_catalog_info($details);$name=hash('sha256','catalog-v31|'.$id.'|'.$key);
    private_transaction('card-info-cache',function($all)use($name,$info){$all=is_array($all)?$all:[];$all=array_filter($all,fn($e)=>($e['expires']??0)>time());$all[$name]=['expires'=>time()+600,'info'=>$info];return[array_slice($all,-50,null,true),null];});return $info;
}
function af_catalog(string $id,string $key,?callable $fetch=null): array {
    $entry=read_private('card-info-cache',[])[hash('sha256','catalog-v31|'.$id.'|'.$key)]??null;
    if(($entry['expires']??0)>time())return $entry['info'];
    $details=$fetch?$fetch($id):cardsight_request('/v1/catalog/cards/'.require_uuid($id),$key);
    return af_cache_catalog($id,$key,$details);
}
function af_name_tokens(string $value): array {
    return array_values(array_filter(explode(' ',preg_replace('/\s+/u',' ',trim(preg_replace('/[^\p{L}\p{N}]+/u',' ',normalized($value))??''))??''),fn($x)=>$x!==''&&!in_array($x,['jr','sr','ii','iii','iv'],true)));
}
function af_name_agrees(string $a,string $b): bool {
    $a=af_name_tokens($a);$b=af_name_tokens($b);return count($a)>=2&&count($b)>=2&&end($a)===end($b)&&($a[0]===$b[0]||((strlen($a[0])===1||strlen($b[0])===1)&&substr($a[0],0,1)===substr($b[0],0,1)));
}
function af_conflict(array $reading,array $card): bool {
    $a=af_name_tokens($reading['player']??'');$b=af_name_tokens($card['player']??'');
    $name=count($a)>=2&&count($b)>=2&&!af_name_agrees($reading['player'],$card['player']);
    $n=fn($s)=>strtolower(preg_replace('/[^\p{L}\p{N}]+/u','',(string)$s)??'');
    $v=$reading['verification']??null;
    $year=!empty($reading['year'])&&!empty($card['year'])&&$reading['year']!==substr($card['year'],0,4);
    $serial=!empty($reading['serialNumber'])&&!empty($card['serialNumber'])&&serial_identity($reading['serialNumber'])!==serial_identity($card['serialNumber']);
    $limit=!empty($reading['serialNumber'])&&!empty($card['printRun'])&&(int)explode('/',serial_field($reading['serialNumber']))[1]!== (int)$card['printRun'];
    return $serial||$limit||$year||(is_array($v)&&(($v['identity']??'')!=='match'||($v['parallel']??'')!=='match'))||$name||(!empty($reading['number'])&&!empty($card['number'])&&$n($reading['number'])!==$n($card['number']));
}
function af_gemini_photo(string $photo,array $config,?callable $transport=null,array $card=[],string $backImage=''): array {
    if(empty($config['geminiKey'])||($config['geminiEnabled']??false)!==true)throw new AppError('Gemini ist nicht aktiviert.',503);
    $hash=hash('sha256','verification-v31|'.$config['geminiKey'].'|'.$photo.'|'.$backImage.'|'.json_encode(gemini_card_context($card)));$cache=read_private('gemini-photo-cache',[]);$hit=$cache[$hash]??null;
    if(($hit['expires']??0)>time())return $hit['data'];
    $delay=(float)(gemini_usage()['next']??0)-microtime(true);if($delay>0&&$delay<=2){if(!function_exists('usleep'))throw new AppError('Bitte kurz warten und die Gemini-Prüfung erneut starten.',429);usleep((int)ceil($delay*1000000));}
    $result=gemini_read(['image'=>$photo,'backImage'=>$backImage,'card'=>$card],$config,$transport);
    private_transaction('gemini-photo-cache',function($all)use($hash,$result){$all=is_array($all)?$all:[];$all=array_filter($all,fn($e)=>($e['expires']??0)>time());$all[$hash]=['expires'=>time()+600,'data'=>$result];return[array_slice($all,-10,null,true),null];});return $result;
}
function af_card(array $input,array $config,?callable $catalogFetch=null,?callable $geminiFetch=null): array {
    $GLOBALS['sidelineProviderDeadline']??=microtime(true)+40;
    $stage=$input['stage']??'final';if(!in_array($stage,['prepare','final'],true))throw new AppError('Ungültige Prüfphase.');
    $c=$input['card']??null;if(is_array($c)&&!empty($c['id'])&&function_exists('fv_inline_card')){foreach(read_private('cards',[])as $own)if($own['id']===$c['id']){foreach(['image','backImage']as $side){$incoming=$input[$side]??'';if($incoming===''||$incoming===($own[$side]??'')){$hydrated??=fv_inline_card($own);$input[$side]=$hydrated[$side]??'';}}break;}}if(!is_array($c)||array_is_list($c))throw new AppError('Bitte einen Kartenvorschlag übergeben.');
    $fields=['team','jerseyNumber','position','cardType','player','year','number','set','sport','parallel','serialNumber','printRun'];$card=[];foreach($fields as $field)$card[$field]=text_field($c[$field]??'');
    $card=expand_player_fields($card);$sources=[];foreach(['team','jerseyNumber','position','cardType']as $f){$source=$c['_metadataSources'][$f]??null;if(is_string($source)&&str_starts_with($source,'nflverse'))$sources[$f]=text_field($source);}$warnings=[];$reading=null;
    $missing=function()use(&$card){return array_values(array_filter(['team','jerseyNumber','position','cardType'],fn($f)=>trim($card[$f]??'')===''));};
    $parallelCandidates=[];
    if(($missing()||($card['parallel']!==''&&$card['printRun']==='')||($stage==='final'&&!empty($input['image'])&&!empty($config['geminiKey'])&&($config['geminiEnabled']??false)===true))&&!empty($c['cardsightId'])){
        $id=require_uuid($c['cardsightId']);
        try{$details=af_catalog($id,$config['apiKey']??'',$catalogFetch);$parallelCandidates=af_parallel_candidates($details['parallelCandidates']??[],$card);if(isset($details['parallelLimits'][normalized($card['parallel'])]))$card['printRun']=(string)$details['parallelLimits'][normalized($card['parallel'])];foreach($fields as $field)if($card[$field]===''&&isset($details[$field])&&$details[$field]!==''){$card[$field]=$details[$field];$sources[$field]='Cardsight-Katalog';}}
        catch(AppError $e){$warnings[]='Cardsight-Ergänzung nicht verfügbar: '.$e->getMessage();}
    }
    if($missing()&&function_exists('nv_match')){$profile=nv_match($card);foreach($profile['fields']??[]as $field=>$value)if($card[$field]===''){$card[$field]=$value;$sources[$field]=$profile['source'];}if(!empty($profile['message']))$warnings[]=$profile['message'];}
    $photo=$input['image']??'';
    if($stage==='final'&&is_string($photo)&&$photo!==''&&!empty($config['geminiKey'])&&($config['geminiEnabled']??false)===true&&(($config['geminiAutoFill']??true)===true||($input['forceGemini']??false)===true)){
        try{$comparison=$card;$comparison['parallelCandidates']=$parallelCandidates;$reply=af_gemini_photo($photo,$config,$geminiFetch,$comparison,photo_field($input['backImage']??''));$reading=$reply['reading'];
            if(af_name_agrees($reading['player']??'',$card['player'])&&!af_conflict(array_diff_key($reading,['verification'=>true]),$card)&&(!isset($reading['verification'])||$reading['verification']['identity']==='match')){
                // Visible card facts outrank a provisional season-roster inference,
                // but never replace existing user/catalog fields.
                if(!empty($reading['team'])&&str_starts_with($sources['team']??'','nflverse')&&nv_name(sleeper_full_team($reading['team'],'nfl'))!==nv_name($card['team'])&&str_starts_with($sources['jerseyNumber']??'','nflverse')&&empty($reading['jerseyNumber'])){$card['jerseyNumber']='';unset($sources['jerseyNumber']);}
                foreach(['team','jerseyNumber','position','cardType','year','number','set','serialNumber']as $field){$provisional=in_array($field,['team','jerseyNumber'],true)&&str_starts_with($sources[$field]??'','nflverse');if(($card[$field]===''||$provisional)&&isset($reading[$field])&&$reading[$field]!==''){$card[$field]=$reading[$field];$sources[$field]='Gemini-Kartenprüfung · bitte prüfen';}}

            }else{$warnings[]='Fotoabschrift und ausgewählte Karte sind nicht sicher abgeglichen. Keine Fotoangaben automatisch übernommen.';}
        }catch(AppError $e){$warnings[]='Gemini-Ergänzung nicht verfügbar: '.$e->getMessage();}
    }
    $state=empty($config['geminiKey'])?'not-configured':(($config['geminiEnabled']??false)!==true?'disabled':(($config['geminiAutoFill']??true)!==true&&($input['forceGemini']??false)!==true?'opted-out':(!is_string($photo)||$photo===''?'no-photo':($stage==='prepare'?'pending-final':($reading?'checked':'failed')))));
    if($state==='not-configured')$warnings[]='Gemini-Schlüssel fehlt. Unter Einstellungen → Gemini eintragen und aktivieren. Das öffentliche Update enthält keine Schlüssel.';
    elseif($state==='disabled'||$state==='opted-out')$warnings[]='Automatische Gemini-Prüfung ist ausgeschaltet. Unter Einstellungen → Gemini aktivieren.';
    elseif($state==='no-photo')$warnings[]='Für die Gemini-Prüfung wird ein gespeichertes eigenes Kartenfoto benötigt.';
    if(!empty($reading['serialNumber'])&&!empty($card['printRun'])&&(int)explode('/',$reading['serialNumber'])[1]!== (int)$card['printRun'])$warnings[]='Die gelesene Nummerierung '.$reading['serialNumber'].' passt nicht zur Auflage /'.$card['printRun'].' der ausgewählten Parallelvariante. Bitte Variante und Stempel prüfen.';
    if($reading&&!isset($reading['verification']))$warnings[]='Gemini hat nur Text geliefert, aber keine vollständige Identitäts- und Variantenprüfung. Bitte selbst prüfen.';
    if($reading&&isset($reading['verification'])&&$reading['verification']['parallel']==='uncertain')$warnings[]='Die Parallelvariante ist auf diesem Foto nicht sicher bestimmbar. Variante selbst auswählen und prüfen.';
    if($state==='pending-final')$warnings[]='Gemini prüft die ausgewählte Karte und Variante abschließend vor dem Speichern.';
    $card=expand_player_fields($card);
    $values=array_intersect_key($card,array_flip($fields));
    return ['stage'=>$stage,'geminiState'=>$state,'fields'=>$values,'sources'=>$sources,'missing'=>$missing(),'warnings'=>$warnings,'gemini'=>$reading,'geminiNeedsReview'=>$reading?(!isset($reading['verification'])||trim($reading['verification']['evidence']??'')===''||trim($reading['player']??'')===''||(($reading['number']??'')===''&&($reading['set']??'')==='')||af_conflict($reading,$card)):($stage==='final'&&$state==='failed'),'nflverse'=>function_exists('nv_status')?nv_status():null,'notice'=>'Kartendaten werden nur ergänzt oder Abkürzungen ausgeschrieben. Fotoabschriften können falsch sein. NFLverse ergänzt saisonbezogene Kaderdaten. Unbekannte oder mehrdeutige Werte bleiben offen; keine aktuellen Teams werden blind auf alte Karten übertragen.'];
}
