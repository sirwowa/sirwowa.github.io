<?php
declare(strict_types=1);
function nc_years(): array {return range(2024,(int)gmdate('Y'));}
function nc_status(): array {
    $products=array_filter(oc_manifest()['products'],fn($p)=>in_array((int)$p['year'],nc_years(),true));$j=read_private('nfl-sync',null);
    return ['products'=>count($products),'cards'=>array_sum(array_column($products,'count')),'years'=>nc_years(),'completeForProvider'=>($j['phase']??'')==='done'&&empty($j['skippedUnknownSport']),'globalComplete'=>false,'job'=>$j,'usage'=>quota_view(),'notice'=>'Lokaler NFL-/American-Football-Katalog. Die CSV-Grundlage ist unvollständig; der abrufbare Cardsight-Katalog kann fortlaufend ergänzt werden. Keine Garantie für alle weltweit erschienenen Karten oder Varianten.'];
}
function nc_start(array $config): array {
    if(empty($config['apiKey']))throw new AppError('Für den vollständigen Anbieter-Import bitte den Cardsight-Schlüssel auf dem Server speichern.',503);
    private_transaction('nfl-sync',function($old){if($old&&($old['phase']??'')!=='done')return[$old,null];return[['phase'=>'segments','years'=>nc_years(),'yearIndex'=>0,'releaseSkip'=>0,'pageDone'=>false,'releases'=>[],'sets'=>[],'activeRelease'=>null,'activeSet'=>null,'cardSkip'=>0,'processedReleases'=>0,'importedSets'=>0,'importedRows'=>0,'skippedReleases'=>0,'skippedUnknownSport'=>0,'paused'=>false,'error'=>'','startedAt'=>now_iso(),'updatedAt'=>now_iso()],null];});return nc_status();
}
function nc_save_page(array $set,array $release,array $page,int $skip): int {
    $id=substr(hash('sha256','cardsight-set-'.$set['id']),0,24);$p=['id'=>$id,'name'=>trim(clean_api_text($release['name']??'').' · '.clean_api_text($set['name']??''),' ·'),'year'=>(string)$release['year'],'brand'=>clean_api_text($release['manufacturerName']??''),'source'=>'Cardsight','sourceNote'=>'Vom eingerichteten Cardsight-Katalog übernommen; keine Garantie für die Abdeckung außerhalb dieses Anbieters.','cardsightSetId'=>$set['id'],'cardsightReleaseId'=>$release['id']];
    $count=private_transaction('own-product-'.$id,function($old)use($id,$p,$page,$skip,$set){$rows=$skip===0?[]:($old['rows']??[]);$seen=array_fill_keys(array_column($rows,'id'),true);$added=0;
        foreach($page['cards']as $c){if(!is_array($c)||!valid_uuid($c['id']??''))continue;$rowId='own-'.substr(hash('sha256',$id.'|'.$c['id']),0,32);if(isset($seen[$rowId]))continue;$seen[$rowId]=true;$row=array_merge(card_metadata($c),['id'=>$rowId,'cardsightId'=>$c['id'],'cardsightSetId'=>$set['id'],'cardsightReleaseId'=>$p['cardsightReleaseId'],'subset'=>clean_api_text($set['name']??''),'number'=>clean_api_text($c['number']??''),'player'=>clean_api_text($c['name']??''),'parallel'=>'','isParallelOnly'=>($c['isParallelOnly']??false)===true,'parallels'=>$c['parallels']??[]]);if($row['player']==='')continue;$rows[]=$row;$added++;}
        $p['count']=count($rows);$p['players']=array_values(array_unique(array_map(fn($r)=>oc_norm($r['player']),$rows)));return[['product'=>$p,'rows'=>$rows,'parallelLists'=>$set['parallels']??[],'sourceComplete'=>$skip+count($page['cards'])>=(int)$page['total_count']],$added];});
    $saved=read_private('own-product-'.$id)['product'];private_transaction('own-index',function($all)use($id,$saved){$all??=['products'=>[]];$all['products'][$id]=$saved;return[$all,null];});return $count;
}
function nc_step(array $config,?callable $transport=null): array {
    $key=$config['apiKey']??'';if(!$key&&$transport===null)throw new AppError('Cardsight-Schlüssel fehlt.',503);
    $fetch=$transport??fn($path)=>cardsight_request($path,$key);
    private_transaction('nfl-sync',function($j)use($fetch){
        if(!$j)throw new AppError('Bitte den NFL-Katalogimport zuerst starten.');if(($j['phase']??'')==='done')return[$j,null];$j['paused']=false;$j['error']='';
        try{
            if($j['phase']==='segments'){$d=$fetch('/v1/catalog/segments?take=100&skip=0');$matches=array_values(array_filter($d['segments']??[],fn($s)=>in_array(strtolower($s['shortname']??$s['name']??''),['football','american football','nfl'],true)));if(count($matches)!==1)throw new AppError('NFL-/Football-Kategorie beim Anbieter nicht eindeutig. Import nicht gestartet.',502);$j['segmentId']=$matches[0]['id'];$j['phase']='releases';}
            elseif($j['phase']==='releases'){$year=$j['years'][$j['yearIndex']];$d=$fetch('/v1/catalog/releases?'.http_build_query(['year'=>$year,'take'=>100,'skip'=>$j['releaseSkip']]));if(!is_array($d['releases']??null)||(!is_numeric($d['total_count']??null)||(int)$d['total_count']<0))throw new AppError('Ungültige Produktliste. Import bleibt fortsetzbar.',502);$j['releases']=array_values(array_filter($d['releases'],fn($r)=>valid_uuid($r['id']??'')));$j['releaseSkip']+=count($d['releases']);$j['pageDone']=$j['releaseSkip']>=(int)$d['total_count']||!$d['releases'];$j['phase']='release';}
            elseif($j['phase']==='release'){
                if(!$j['releases']){if($j['pageDone']){$j['yearIndex']++;$j['releaseSkip']=0;}$j['phase']=$j['yearIndex']>=count($j['years'])?'done':'releases';}
                else{$id=$j['releases'][0]['id'];$r=$fetch('/v1/catalog/releases/'.require_uuid($id));if(isset($r['id'])&&$r['id']!==$id)throw new AppError('Produkt-ID stimmt nicht mit der Anfrage überein.',502);$r['id']=$id;$r['year']=(int)($r['year']??$j['years'][$j['yearIndex']]);$sport=($r['segmentId']??'')===$j['segmentId']||in_array(strtolower($r['segmentName']??''),['football','american football','nfl'],true);$unknown=empty($r['segmentId'])&&empty($r['segmentName']);$future=!empty($r['releaseDate'])&&(strtotime($r['releaseDate'])?:0)>time();
                    if(!$sport||!in_array($r['year'],$j['years'],true)||$future){array_shift($j['releases']);$j['skippedReleases']++;if($unknown)$j['skippedUnknownSport']++;}
                    else{if(!is_array($r['sets']??null))throw new AppError('Produkt ohne lesbare Set-Liste. Import bleibt fortsetzbar.',502);$j['activeRelease']=$r;$j['sets']=array_values(array_filter($r['sets']??[],fn($s)=>valid_uuid($s['id']??'')));$j['phase']='set';}$j['processedReleases']++;}
            }
            elseif($j['phase']==='set'){
                if(!$j['sets']){array_shift($j['releases']);$j['activeRelease']=null;$j['phase']='release';}
                else{$s=$fetch('/v1/catalog/sets/'.require_uuid($j['sets'][0]['id']));if(!valid_uuid($s['id']??''))throw new AppError('Ungültige Set-Antwort.',502);$j['activeSet']=$s;$j['cardSkip']=0;$j['phase']='cards';}
            }
            elseif($j['phase']==='cards'){$id=require_uuid($j['activeSet']['id']);$d=$fetch('/v1/catalog/sets/'.$id.'/cards?'.http_build_query(['take'=>100,'skip'=>$j['cardSkip'],'sort'=>'number','order'=>'asc']));if(!is_array($d['cards']??null)||(!is_numeric($d['total_count']??null)||(int)$d['total_count']<0))throw new AppError('Ungültige Kartenliste. Import bleibt fortsetzbar.',502);$j['importedRows']+=nc_save_page($j['activeSet'],$j['activeRelease'],$d,$j['cardSkip']);$j['cardSkip']+=count($d['cards']);if($j['cardSkip']>=(int)$d['total_count']||!$d['cards']){$j['importedSets']++;array_shift($j['sets']);$j['activeSet']=null;$j['phase']='set';}}
        }catch(AppError $e){$j['paused']=true;$j['error']=$e->getMessage();$j['errorStatus']=$e->status;}
        $j['updatedAt']=now_iso();return[$j,null];
    });return nc_status();
}
function nc_route(string $route,array $input,array $config): array {
    if($route==='nfl-catalog-sync-start')return nc_start($config);if($route==='nfl-catalog-sync-step')return nc_step($config);
    if($route==='nfl-catalog-status')return nc_status();
    if($route==='nfl-catalog-card'){$id=text_field($input['productId']??'');$data=oc_rows($id);foreach($data['rows']as $r)if(($r['id']??'')===($input['rowId']??''))return oc_card($r,$data['product']);throw new AppError('Katalogkarte nicht gefunden.',404);}
    if($route==='nfl-catalog-rows'){$id=text_field($input['productId']??'');$d=oc_rows($id);$skip=max(0,(int)($input['skip']??0));return ['product'=>$d['product']??null,'rows'=>array_slice($d['rows'],$skip,100),'parallelLists'=>$d['parallelLists']??[],'total'=>count($d['rows']),'skip'=>$skip];}
    $year=text_field($input['year']??'');$q=oc_norm(text_field($input['query']??''));$out=[];foreach(oc_manifest()['products']as $p)if(in_array((int)$p['year'],nc_years(),true)&&(!$year||$p['year']===$year)&&(!$q||str_contains(oc_norm($p['name']),$q))){unset($p['players']);$out[]=$p;}usort($out,fn($a,$b)=>strcmp($b['year'],$a['year'])?:strcmp($a['name'],$b['name']));return ['products'=>$out,'total'=>count($out),'coverage'=>nc_status()];
}
