<?php
declare(strict_types=1);
function am_norm(string $s): string {return trim(preg_replace('/[^\p{L}\p{N}]+/u',' ',normalized($s))??'');}
function am_key(array $c): string {return hash('sha256','ebay-offer-mean-v42|'.json_encode(array_map(fn($k)=>(string)($c[$k]??''),['id','player','year','set','number','parallel','grader','grade','cardsightId','sport','condition','language','rarity','cardType','serialNumber','parallelConfirmed']),JSON_THROW_ON_ERROR));}
function am_resolve(array $card,array $config,?callable $fetch=null): ?array {
    foreach(['player','year','set','number']as $key)if(empty($card[$key]))return null;
    $params=['q'=>tca_query($card),'type'=>'card','take'=>12];$sport=sleeper_league($card['sport']??'');if($sport)$params['segment']=$sport==='nfl'?'football':'basketball';
    $reply=$fetch?$fetch($params):cardsight_request('/v1/catalog/search?'.http_build_query($params),$config['apiKey']??'');$matches=[];
    foreach($reply['results']??[]as $r){if(($r['type']??'')!=='card'||!valid_uuid($r['id']??''))continue;
        $set=implode(' · ',array_unique(array_filter([$r['releaseName']??'',$r['setName']??''])));
        if(am_norm(clean_api_text($r['name']??''))!==am_norm($card['player'])||am_norm(clean_api_text($r['year']??$r['releaseYear']??''))!==am_norm($card['year'])||am_norm(clean_api_text($r['cardNumber']??$r['number']??''))!==am_norm($card['number'])||am_norm($set)!==am_norm($card['set']))continue;
        // Resolve the card family only. load_market independently validates the selected parallel.
        $matches[$r['id']]=$r['id'];
    }
    if(count($matches)!==1)return null;return array_merge($card,['cardsightId'=>array_values($matches)[0]]);
}
function am_sales_match(array $row,array $card): bool {
    if(empty($card['parallel']))return false; // Empty means undetermined, never silently Base.
    foreach(['year','number']as $key)if(empty($card[$key])||am_norm($row[$key]??'')!==am_norm($card[$key]))return false;
    if(count($row['reviewedNames']??[])!==1||am_norm($row['reviewedNames'][0])!==am_norm($card['player']??''))return false;
    // The structured sale set must include the exact named variant. A query/title alone is not proof.
    if(am_norm($row['set']??'')!==am_norm(($card['set']??'').' '.$card['parallel']))return false;
    foreach(['grader','grade']as $key)if(am_norm($row[$key]??'')!==am_norm($card[$key]??''))return false;
    if(!empty($card['serialNumber'])){$n=explode('/',$card['serialNumber']);if(($row['printRun']??null)!==(int)($n[1]??0))return false;}
    return true;
}
function am_tca(array $card,array $config,?callable $transport=null,?callable $fx=null): ?array {
    foreach(['player','year','set','number','parallel']as $key)if(empty($card[$key]))return null;
    $from=max('2026-08-01',gmdate('Y-m-d',time()-90*86400));$query=['q'=>tca_query($card),'platform'=>'ebay','limit'=>20,'date_from'=>$from,'date_to'=>gmdate('Y-m-d'),'sort'=>'date_desc','graded'=>empty($card['grader'])?'false':'true'];if(!empty($card['grader'])){$query['grader']=$card['grader'];$query['grade']=$card['grade']??'';}
    $reply=tca_request('sales',$query,$config,$transport);$rows=array_values(array_filter(tca_sales_rows($reply,$from),fn($r)=>am_sales_match($r,$card)));if(!$rows)return null;
    $sum=0;$rates=[];foreach($rows as $r){$cur=$r['currency'];$rates[$cur]??=$fx?$fx($cur):tca_fx($cur);$rate=$rates[$cur]['rate']??null;if(!is_numeric($rate)||!is_finite((float)$rate)||$rate<=0)throw new AppError('Kein gültiger Euro-Wechselkurs.',502);$sum+=$r['price']*$rate;}
    return ['averageEur'=>round($sum/count($rows),2),'averageCount'=>count($rows),'source'=>'TheCardAPI','marketplace'=>'eBay','priceKind'=>'thecardapi-auto-average','exchangeRates'=>$rates,'context'=>['parallel'=>$card['parallel'],'grade'=>trim(($card['grader']??'').' '.($card['grade']??''))?:'Unbewertet'],'notice'=>'eBay-Verkaufspreise über TheCardAPI: automatischer Euro-Durchschnitt bestätigter Verkäufe mit exakt passenden strukturierten Angaben. Keine reine Titelsuche, keine Angebotspreise. Abdeckung und Zeitraum sind tarifabhängig.'];
}
function automatic_market(array $card,array $config,bool $force=false,array $adapters=[]): array {
    $fingerprint=am_key($card);$cached=read_private('auto-market-cache',[])[$fingerprint]??null;if(!$force&&($cached['expires']??0)>time())return array_merge($cached['data'],['cached'=>true]);
    $data=null;$messages=[];$resolvedId='';
    if(!empty($config['ebayClientId'])&&!empty($config['ebayClientSecret']))try{if(!function_exists('eb_offer_market'))throw new AppError('eBay-Preismodul fehlt.',503);$data=eb_offer_market($card,$config,$adapters['ebay']??null,$adapters['fx']??null);if(!$data)$messages[]='Keine ausreichend passenden eBay-Angebote.';}catch(AppError $e){$messages[]=$e->getMessage();}
    else $messages[]='eBay-Zugang noch nicht eingerichtet.';
    $data??=['averageEur'=>null,'source'=>'','priceKind'=>'unavailable','context'=>['parallel'=>($card['parallel']??'')?:'Variante offen','grade'=>trim(($card['grader']??'').' '.($card['grade']??''))?:'Unbewertet']];
    if(!is_numeric($data['averageEur']??null)||!is_finite((float)$data['averageEur'])||$data['averageEur']<0)$data['averageEur']=null;
    $data=array_merge($data,['id'=>$card['id'],'currency'=>'EUR','fetchedAt'=>now_iso(),'resolvedCardsightId'=>$resolvedId,'valuationIdentity'=>array_map(fn($k)=>(string)($card[$k]??''),['cardsightId','parallel','grader','grade']),'valuationDetailKeys'=>['player','year','set','number','sport','serialNumber','condition','language','rarity','cardType'],'valuationDetails'=>array_map(fn($k)=>(string)($card[$k]??''),['player','year','set','number','sport','serialNumber','condition','language','rarity','cardType']),'valuationCardVersion'=>$card['updatedAt'],'warnings'=>array_merge($data['warnings']??[],$messages)]);
    if($data['averageEur']===null)$data['notice']='Preis nicht verfügbar';private_transaction('price-diagnostics',function($rows)use($card,$messages,$data){$rows=is_array($rows)?$rows:[];$rows[$card['id']]=['at'=>now_iso(),'source'=>'eBay','messages'=>$messages,'matchedOffers'=>$data['averageCount']??0];return[array_slice($rows,-1000,null,true),null];});
    $current=tca_card($card['id']);if(am_key($current)!==$fingerprint)throw new AppError('Die Karte wurde während der Preisabfrage geändert. Bitte erneut abrufen.',409);
    private_transaction('auto-market-cache',function($rows)use($fingerprint,$data){$rows=is_array($rows)?$rows:[];$rows=array_filter($rows,fn($r)=>($r['expires']??0)>time());$rows[$fingerprint]=['expires'=>time()+($data['averageEur']===null?900:86400),'data'=>$data];return[array_slice($rows,-1000,null,true),null];});
    if($data['averageEur']!==null)private_transaction('valuations',function($rows)use($card,$data){$rows??=[];$rows[$card['id']]=$data;return[array_slice($rows,-1000,null,true),null];});
    return $data;
}

function am_record_history(array $card,array $data): void {
 if(($data['priceKind']??'')!=='ebay-offer-average'||($data['currency']??'')!=='EUR'||!is_numeric($data['averageEur']??null)||!is_finite((float)$data['averageEur'])||$data['averageEur']<0)return;
 $time=strtotime($data['fetchedAt']??'');if($time===false||$time>time()+300)return;
 $id=$card['id'];$key=am_key($card);$day=gmdate('Y-m-d',$time);
 private_transaction('price-history',function($all)use($id,$key,$day,$data,$time){$all=is_array($all)?$all:[];$entry=$all[$id]??[];if(($entry['identity']??'')!==$key)$entry=['identity'=>$key,'points'=>[]];if(isset($entry['points'][$day])&&strtotime($entry['points'][$day]['at'])>$time)return[$all,null];$entry['points'][$day]=['at'=>gmdate('c',$time),'eur'=>(float)$data['averageEur'],'count'=>max(0,(int)($data['averageCount']??0))];ksort($entry['points']);$entry['points']=array_slice($entry['points'],-366,null,true);$all[$id]=$entry;return[array_slice($all,-750,null,true),null];});
}
function am_research(): array {
 $cards=read_private('cards',[]);$all=read_private('price-history',[]);$out=[];$preferences=read_private('research-notes',[]);$notes=[];
 foreach($cards as $c){$entry=$all[$c['id']]??null;if($entry&&($entry['identity']??'')===am_key($c))$out[$c['id']]=array_values($entry['points']??[]);if(isset($preferences[$c['id']]))$notes[$c['id']]=$preferences[$c['id']];}
 return ['history'=>$out,'notes'=>$notes,'basis'=>'eBay-Angebotsmittelwert ohne Versand','retention'=>366];
}
function am_research_save(array $input): array {
 $id=text_field($input['id']??'',80);tca_card($id);$entry=['watch'=>($input['watch']??false)===true,'thesis'=>text_field($input['thesis']??'',1500),'risk'=>text_field($input['risk']??'',1500),'review'=>text_field($input['review']??'',10),'target'=>null,'at'=>now_iso()];
 if($entry['review']!==''&&!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$entry['review']))throw new AppError('Bitte ein gültiges Prüfdatum wählen.');
 if(isset($input['target'])&&$input['target']!==''){if(!is_numeric($input['target'])||!is_finite((float)$input['target'])||(float)$input['target']<0||(float)$input['target']>1000000000)throw new AppError('Bitte eine gültige Eurogrenze wählen.');$entry['target']=(float)$input['target'];}
 private_transaction('research-notes',function($rows)use($id,$entry){$rows=is_array($rows)?$rows:[];$rows[$id]=$entry;return[array_slice($rows,-1000,null,true),null];});return $entry;
}
