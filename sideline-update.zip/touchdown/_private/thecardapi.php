<?php
declare(strict_types=1);

function tca_status(array $config): array {
    $s=read_private('thecardapi-usage',[]);if(($s['day']??'')!==gmdate('Y-m-d'))$s=[];
    return ['configured'=>!empty($config['externalCardApiKey']),'provider'=>'TheCardAPI','salesReserved'=>(int)($s['sales']??0),'catalogReserved'=>(int)($s['catalog']??0),'salesLimit'=>500,'catalogLimit'=>200,'day'=>gmdate('Y-m-d'),'counting'=>'Konservativ reservierte Datensätze pro UTC-Tag, getrennt vom Anbieterbudget.'];
}
function tca_reserve(string $pool,int $take): void {
    $limit=$pool==='sales'?500:200;
    private_transaction('thecardapi-usage',function($s)use($pool,$take,$limit){if(($s['day']??'')!==gmdate('Y-m-d'))$s=['day'=>gmdate('Y-m-d'),'sales'=>0,'catalog'=>0,'next'=>0];
        if((int)$s[$pool]+$take>$limit)throw new AppError('Die lokale TheCardAPI-Tagesgrenze ist erreicht. Morgen erneut versuchen.',429);
        if((float)($s['next']??0)>microtime(true))throw new AppError('Bitte kurz warten, bevor du TheCardAPI erneut abfragst.',429);
        $s[$pool]+=$take;$s['next']=microtime(true)+1;return[$s,null];
    });
}
function tca_request(string $kind,array $query,array $config,?callable $transport=null): array {
    if(empty($config['externalCardApiKey']))throw new AppError('Bitte den TheCardAPI-Schlüssel in den Einstellungen hinterlegen.',503);
    if(!in_array($kind,['sales','catalog'],true))throw new AppError('Ungültige TheCardAPI-Funktion.');
    $limit=$query['limit']??20;if(!is_int($limit)||$limit<1||$limit>20)throw new AppError('Pro Anfrage sind höchstens 20 Datensätze möglich.');
    tca_reserve($kind==='sales'?'sales':'catalog',$limit);
    $base=$kind==='sales'?'https://thecardapi.com/api/v1/market/sales':'https://www.thecardapi.com/api/v1/catalog';
    $header=$kind==='sales'?'x-market-api-key':'x-api-key';
    if($transport!==null)$reply=$transport($kind,$query,$header);
    else{
        if(!function_exists('curl_init'))throw new AppError('PHP-cURL fehlt.',503);
        $ch=curl_init($base.'?'.http_build_query($query));$raw='';
        curl_setopt_array($ch,[CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>25,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_HTTPHEADER=>[$header.': '.$config['externalCardApiKey'],'Accept: application/json'],CURLOPT_WRITEFUNCTION=>static function($ch,$chunk)use(&$raw){if(strlen($raw)+strlen($chunk)>3000000)return 0;$raw.=$chunk;return strlen($chunk);}]);
        $ok=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);
        if($ok===false)throw new AppError('TheCardAPI ist momentan nicht erreichbar. Gespeicherte Preise bleiben erhalten.',502);
        if($status<200||$status>=300)throw new AppError(match($status){401=>'TheCardAPI hat den Schlüssel abgelehnt.',403=>'Dein TheCardAPI-Tarif erlaubt diese Funktion nicht. Katalogzugriff kann einen gesonderten Tarif benötigen.',422,400=>'TheCardAPI hat die Suchparameter abgelehnt. Bitte die Suche anpassen.',429=>'Das TheCardAPI-Tageskontingent ist erreicht.',default=>'TheCardAPI hat keine erfolgreiche Antwort geliefert.'},$status===429?429:($status===403?403:502));
        try{$reply=json_decode($raw,true,64,JSON_THROW_ON_ERROR);}catch(JsonException){throw new AppError('TheCardAPI hat kein gültiges JSON geliefert.',502);}
    }
    if(!is_array($reply)||!isset($reply['data'])||!is_array($reply['data'])||!array_is_list($reply['data'])||count($reply['data'])>20)throw new AppError('Unerwartetes TheCardAPI-Antwortformat.',502);
    return $reply;
}
function tca_card(string $id): array {foreach(read_private('cards',[])as $c)if(($c['id']??'')===$id)return expand_player_fields($c);throw new AppError('Karte nicht gefunden.',404);}
function tca_valuation_keys(): array {return ['player','year','set','number','cardType','condition','sport','language','rarity','team'];}
function tca_identity(array $card): string {return hash('sha256',json_encode(array_map(fn($k)=>(string)($card[$k]??''),['id','updatedAt','player','year','set','number','parallel','grader','grade']),JSON_THROW_ON_ERROR));}
function tca_query(array $card): string {
    $terms=[];foreach(['player','year','set','number','parallel']as $key){$v=trim((string)($card[$key]??''));$v=preg_replace('/[^\p{L}\p{N}\s-]/u',' ',$v)??'';$v=trim(preg_replace('/\s+/u',' ',$v)??'');if($v!=='')$terms[]=$key==='player'?'"'.$v.'"':$v;}
    return mb_safe_cut(implode(' ',$terms),400);
}
function tca_sales_rows(array $reply,string $dateFrom): array {
    $out=[];foreach($reply['data']as $r){
        if(!is_array($r)||!is_string($r['platform']??null)||!in_array($r['listing_type']??'', ['auction','fixed_price','best_offer'],true)||strtolower(trim((string)($r['platform']??'')))!=='ebay'||($r['price_confirmed']??null)!==true)continue;
        $price=$r['price']??null;if(!is_numeric($price)||!is_finite((float)$price)||(float)$price<0)continue;
        $currency=is_string($r['currency']??null)?strtoupper($r['currency']):'';if(!in_array($currency,['EUR','USD','GBP','CAD','AUD','JPY','CHF','CNY','HKD','SGD','NZD'],true))continue;
        $date=is_string($r['sale_date']??null)?$r['sale_date']:'';if(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$date)||!checkdate((int)substr($date,5,2),(int)substr($date,8,2),(int)substr($date,0,4))||$date<$dateFrom||$date>gmdate('Y-m-d')||$date<'2026-08-01')continue;
        $id=clean_api_text(is_string($r['id']??null)||is_int($r['id']??null)?(string)$r['id']:'');if($id===''||isset($out[$id]))continue;
        $names=[];$people=$r['player_identity']['players']??[];if(!is_array($people))$people=[];foreach($people as $person)if(is_string($person['name']??null))$names[]=clean_api_text($person['name']);
        $out[$id]=['id'=>$id,'title'=>clean_api_text($r['title']??''),'price'=>(float)$price,'currency'=>$currency,'date'=>$date,'listingType'=>clean_api_text($r['listing_type']??''),'url'=>safe_https($r['listing_url']??null),'year'=>clean_api_text(is_string($r['year']??null)||is_int($r['year']??null)?(string)$r['year']:''),'number'=>clean_api_text($r['card_number']??''),'set'=>clean_api_text($r['card_set']??''),'grader'=>clean_api_text($r['grader']??''),'grade'=>clean_api_text($r['grade']??''),'printRun'=>is_int($r['print_run']??null)?$r['print_run']:null,'reviewedNames'=>array_slice($names,0,4)];
    }
    return array_values($out);
}
function tca_sales_search(array $input,array $config,?callable $transport=null): array {
    $card=tca_card(text_field($input['id']??'',80));$query=trim(text_field($input['query']??'',400));if($query==='')$query=tca_query($card);
    if(strlen($query)<4)throw new AppError('Bitte die Suchangaben ergänzen (mindestens vier Zeichen).');
    $cursor=text_field($input['cursor']??'',2000);$from=max('2026-08-01',gmdate('Y-m-d',time()-90*86400));
    $params=['q'=>$query,'platform'=>'ebay','limit'=>20,'date_from'=>$from,'date_to'=>gmdate('Y-m-d'),'sort'=>'date_desc'];
    if(!empty($card['grader'])&&!empty($card['grade'])){$params['graded']='true';$params['grader']=$card['grader'];$params['grade']=$card['grade'];}elseif(empty($card['grader'])&&empty($card['grade']))$params['graded']='false';
    if($cursor!=='')$params['cursor']=$cursor;
    $reply=tca_request('sales',$params,$config,$transport);$rows=tca_sales_rows($reply,$from);$token=bin2hex(random_bytes(16));
    private_transaction('thecardapi-comparisons',function($all)use($token,$rows,$card){$all=is_array($all)?$all:[];$all=array_filter($all,fn($x)=>($x['expires']??0)>time());$all[$token]=['expires'=>time()+900,'cardId'=>$card['id'],'identity'=>tca_identity($card),'rows'=>$rows];return[array_slice($all,-20,null,true),null];});
    $next=$reply['pagination']['next_cursor']??null;if(!is_string($next)||strlen($next)>2000)$next=null;
    return ['token'=>$token,'rows'=>$rows,'nextCursor'=>$next,'query'=>$query,'usage'=>tca_status($config),'coverage'=>['from'=>clean_api_text($reply['meta']['coverage_date_from']??''),'to'=>clean_api_text($reply['meta']['coverage_date_to']??'')],'notice'=>'Nur von TheCardAPI als bestätigt gemeldete eBay-Endpreise. Keine unbekannten Best-Offer-Preise oder Angebotspreise. Treffer sind nicht automatisch deiner exakten Kartenvariante zugeordnet. Zeitraum und Vollständigkeit hängen vom Tarif ab.'];
}
function tca_fx(string $currency): array {
    if($currency==='EUR')return ['rate'=>1.0,'date'=>gmdate('Y-m-d'),'source'=>'EUR unverändert'];
    if($currency==='USD')return usd_eur_rate();
    if(!in_array($currency,['GBP','CAD','AUD','JPY','CHF','CNY','HKD','SGD','NZD'],true))throw new AppError('Nicht unterstützte Vergleichswährung.');
    $cache=read_private('thecardapi-fx-'.strtolower($currency));if(($cache['expires']??0)>time())return $cache['data'];
    $lower=strtolower($currency);$body=public_http('https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/'.$lower.'.json')['body'];
    try{$json=json_decode($body,true,32,JSON_THROW_ON_ERROR);}catch(JsonException){throw new AppError('Euro-Wechselkurs nicht lesbar.',502);}
    $rate=$json[$lower]['eur']??null;$date=$json['date']??'';$stamp=is_string($date)?strtotime($date):false;
    if(!is_numeric($rate)||!is_finite((float)$rate)||$rate<=0||!$stamp||$stamp<time()-7*86400||$stamp>time()+86400)throw new AppError('Kein ausreichend aktueller Euro-Wechselkurs verfügbar.',502);
    $data=['rate'=>(float)$rate,'date'=>$date,'source'=>'Currency API / jsDelivr'];private_transaction('thecardapi-fx-'.$lower,fn($s)=>[['expires'=>time()+21600,'data'=>$data],null]);return $data;
}
function tca_confirm(array $input,?callable $fx=null): array {
    if(($input['confirmed']??false)!==true)throw new AppError('Bitte Jahr, Set, Kartennummer, Variante und Grading der Vergleichsverkäufe ausdrücklich prüfen.',409);
    $token=$input['token']??'';$ids=$input['ids']??null;
    if(!is_string($token)||!preg_match('/^[a-f0-9]{32}$/D',$token)||!is_array($ids)||!array_is_list($ids)||!$ids||count($ids)>20||count(array_filter($ids,'is_string'))!==count($ids)||count(array_unique($ids))!==count($ids))throw new AppError('Bitte gültige Vergleichsverkäufe auswählen.');
    $cached=read_private('thecardapi-comparisons',[])[$token]??null;if(!$cached||($cached['expires']??0)<=time())throw new AppError('Die Vergleichssuche ist abgelaufen. Bitte erneut suchen.',409);
    $card=tca_card($cached['cardId']);if(tca_identity($card)!==$cached['identity'])throw new AppError('Die Karte wurde zwischenzeitlich geändert. Bitte die Vergleiche neu prüfen.',409);
    $rows=[];foreach($ids as $id){$match=array_values(array_filter($cached['rows'],fn($r)=>$r['id']===$id));if(count($match)!==1)throw new AppError('Ein ausgewählter Verkauf gehört nicht zur aktuellen Suche.');$rows[]=$match[0];}
    $rates=[];$sum=0;foreach($rows as $row){$currency=$row['currency'];if(!isset($rates[$currency]))$rates[$currency]=$fx?$fx($currency):tca_fx($currency);$rate=$rates[$currency]['rate']??null;if(!is_numeric($rate)||!is_finite((float)$rate)||$rate<=0)throw new AppError('Ungültiger Euro-Wechselkurs.',502);$sum+=$row['price']*(float)$rate;}
    $average=round($sum/count($rows),2);if(!is_finite($average))throw new AppError('Die Vergleichspreise konnten nicht berechnet werden.',502);
    if(tca_identity(tca_card($card['id']))!==$cached['identity'])throw new AppError('Die Karte wurde während der Berechnung geändert. Bitte erneut prüfen.',409);
    $snapshot=['id'=>$card['id'],'source'=>'TheCardAPI','priceKind'=>'thecardapi-confirmed-average','averageEur'=>$average,'averageCount'=>count($rows),'currency'=>'EUR','fetchedAt'=>now_iso(),'cardUpdatedAt'=>$card['updatedAt'],'valuationCardVersion'=>$card['updatedAt'],'valuationDetailKeys'=>tca_valuation_keys(),'valuationDetails'=>array_map(fn($k)=>(string)($card[$k]??''),tca_valuation_keys()),'valuationIdentity'=>array_map(fn($k)=>(string)($card[$k]??''),['cardsightId','parallel','grader','grade']),'context'=>['parallel'=>$card['parallel']?:'Variante nicht festgelegt','grade'=>trim(($card['grader']??'').' '.($card['grade']??''))?:'Unbewertet'],'exchangeRates'=>$rates,'selectedSales'=>array_map(fn($r)=>['id'=>$r['id'],'date'=>$r['date'],'currency'=>$r['currency'],'price'=>$r['price']],$rows),'notice'=>'Durchschnitt deiner ausdrücklich geprüften Vergleichsverkäufe, keine automatische exakte Kartenbewertung. Umrechnung zum verfügbaren Tageskurs; Versand und Steuern werden nicht zusätzlich aufgeschlagen.'];
    private_transaction('valuations',function($all)use($snapshot,$card){$all??=[];$all[$card['id']]=$snapshot;return[array_slice($all,-1000,null,true),null];});return $snapshot;
}
function tca_catalog(array $input,array $config,?callable $transport=null): array {
    $q=trim(text_field($input['query']??'',200));$year=text_field($input['year']??'',4);$number=text_field($input['number']??'',60);$sport=text_field($input['sport']??'',60);
    if(strlen($q)<2)throw new AppError('Bitte mindestens zwei Zeichen für die Katalogsuche eingeben.');
    $params=['q'=>$q,'limit'=>20,'page'=>1];if($year!==''){if(!preg_match('/^\d{4}$/D',$year))throw new AppError('Bitte ein vierstelliges Jahr eingeben.');$params['year']=(int)$year;}if($number!=='')$params['card_number']=$number;if($sport!=='')$params['sport']=$sport;
    $reply=tca_request('catalog',$params,$config,$transport);$out=[];
    foreach($reply['data']as $r){$ucid=$r['ucid']??'';if(!is_string($ucid)||!preg_match('/^UC-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]$/iD',$ucid))continue;$out[]=['ucid'=>$ucid,'subject'=>clean_api_text($r['subject']??''),'set'=>clean_api_text($r['set_name']??''),'number'=>clean_api_text($r['card_number']??''),'setUsid'=>clean_api_text($r['set_usid']??''),'parentSet'=>clean_api_text($r['parent_set_name']??''),'printRun'=>is_int($r['print_run']??null)?$r['print_run']:null,'isAuto'=>($r['is_auto']??false)===true];}
    return ['rows'=>$out,'usage'=>tca_status($config),'notice'=>'TheCardAPI-Katalogdaten zur Recherche. UCID/USID sind eigene Kennungen, keine Cardsight-IDs. Ein gemeinsames Set oder eine Kartenfamilie beweist weder Parallel-Typ noch die Zuordnung zu einem Verkauf. Katalogzugriff ist tarifabhängig.'];
}
