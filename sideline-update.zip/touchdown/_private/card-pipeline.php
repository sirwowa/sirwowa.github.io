<?php
declare(strict_types=1);
function pipeline_sport(string $hint): array {
    $sport=cv_sport($hint);return ['sport'=>$sport?:'Andere','sportNeedsReview'=>$sport===''];
}
function pipeline_catalog_card(array $input,array $config,?callable $fetch=null,?callable $segmentsFetch=null): array {
    $id=require_uuid($input['id']??'');$parallel=text_field($input['parallel']??'');$key=$config['apiKey']??'';
    $get=$fetch??fn($path)=>cardsight_request($path,$key);$c=$get('/v1/catalog/cards/'.$id);af_cache_catalog($id,$key,$c);$release=[];$warnings=[];
    if(valid_uuid($c['releaseId']??''))try{$release=$get('/v1/catalog/releases/'.$c['releaseId']);}catch(AppError $e){$warnings[]='Zusätzliche Release-Informationen nicht erreichbar. Der Kartentreffer bleibt auswählbar.';}
    if($parallel&&!array_filter($c['parallels']??[],fn($p)=>($p['name']??'')===$parallel))throw new AppError('Diese Variante gehört nicht zu dieser Karte.');
    if(($c['isParallelOnly']??false)&&!$parallel)throw new AppError('Bitte zuerst eine verfügbare Variante wählen.');
    $hint=text_field($input['sport']??$input['segment']??'');$sport=pipeline_sport($hint);
    if($sport['sportNeedsReview'])$sport=pipeline_sport(clean_api_text($c['segmentName']??$c['sport']??$release['segmentName']??''));
    if($sport['sportNeedsReview'])try{$segments=$segmentsFetch?$segmentsFetch():supported_segments($key);$sport=detection_sport(['segmentId'=>$release['segmentId']??$c['segmentId']??''],'auto',$segments);}catch(AppError){$warnings[]='Sportart bitte selbst bestätigen.';}
    return expand_player_fields(array_merge(card_metadata($c),$sport,['player'=>clean_api_text($c['name']??''),'number'=>clean_api_text($c['number']??''),'year'=>clean_api_text((string)($c['releaseYear']??$release['year']??'')),'set'=>clean_api_text(implode(' · ',array_filter([$c['releaseName']??$release['name']??'',$c['setName']??'']))),'cardsightId'=>$id,'cardsightReleaseId'=>valid_uuid($c['releaseId']??'')?$c['releaseId']:'','cardsightSetId'=>valid_uuid($c['setId']??'')?$c['setId']:'','parallel'=>$parallel,'catalogImage'=>true,'matchLevel'=>'card','catalogSource'=>'Cardsight','_scanReviewRequired'=>true,'_metadataWarnings'=>$warnings]));
}
function pipeline_cardsight(array $input,array $config): array {
    $photo=photo_field($input['image']??'');preg_match('~^data:(image/[^;]+);base64,(.+)$~D',$photo,$parts);$segment=$input['segment'];$key=$config['apiKey'];
    $reply=cardsight_request('/v1/identify/card'.($segment==='auto'?'':'/'.rawurlencode($segment)),$key,base64_decode($parts[2],true),$parts[1]);
    if(!isset($reply['success'])||!is_bool($reply['success']))throw new AppError('Unerwartete Antwort von Cardsight.',502);
    $segments=[];try{$segments=supported_segments($key);}catch(AppError){}
    $cards=reviewed_detections($reply,$segment,$segments,read_private('cards',[]));
    foreach($cards as &$c){$local=oc_route('own-catalog-search',['player'=>$c['player'],'number'=>$c['number'],'year'=>$c['year']],$config);$c['localTotal']=$local['total'];$c['localMatches']=$local['results'];$c['alternatives']=array_merge($c['alternatives'],array_slice($local['results'],0,8));}unset($c);
    return ['detections'=>$cards];
}
function pipeline_tca_candidates(array $reading,array $config,string $hint,?callable $fetch=null): array {
    if(empty($config['externalCardApiKey'])||empty($reading['player']))return [];
    $reply=tca_catalog(['query'=>$reading['player'],'year'=>$reading['year']??'','number'=>$reading['number']??''],$config,$fetch);$sport=pipeline_sport($hint);$out=[];
    foreach($reply['rows']as $r){if(nv_name($r['subject'])!==nv_name($reading['player']))continue;if(!empty($reading['number'])&&normalized($r['number'])!==normalized($reading['number']))continue;
        $out[]=array_merge($sport,['player'=>$r['subject'],'set'=>$r['set'],'number'=>$r['number'],'year'=>$reading['year']??'','parallel'=>'','cardsightId'=>'','cardApiId'=>$r['ucid'],'catalogSource'=>'TheCardAPI','cardType'=>$r['isAuto']?'Autogrammkarte':'','matchLevel'=>'card','confidence'=>'Unknown','_scanReviewRequired'=>true]);
    }
    return array_slice($out,0,5);
}
function pipeline_identify(array $input,array $config,array $adapters=[]): array {
    $GLOBALS['sidelineProviderDeadline']=microtime(true)+42;
    $photo=photo_field($input['image']??'');if(!$photo)throw new AppError('Bitte zuerst ein Kartenfoto wählen.');$segment=$input['segment']??'auto';
    if(!is_string($segment)||($segment!=='auto'&&!preg_match('/^[a-zA-Z0-9-]{1,80}$/D',$segment)))throw new AppError('Ungültige Sportart-Auswahl.');$input['segment']=$segment;
    if(empty($config['apiKey'])&&empty($config['externalCardVaultKey'])&&(empty($config['geminiKey'])||($config['geminiEnabled']??false)!==true))throw new AppError('Kein Bilderkennungsanbieter eingerichtet. Bitte Cardsight, AI CardVault oder Gemini in den Einstellungen aktivieren.',503);
    $providers=[];$cards=[];$reading=null;
    if(!empty($config['apiKey']))try{$reply=isset($adapters['cardsight'])?$adapters['cardsight']($input):pipeline_cardsight($input,$config);$cards=$reply['detections']??[];$providers[]=['name'=>'Cardsight','state'=>$cards?'found':'no-match'];}catch(AppError $e){$providers[]=['name'=>'Cardsight','state'=>'failed','message'=>$e->getMessage()];}
    else $providers[]=['name'=>'Cardsight','state'=>'not-configured','message'=>'Cardsight-Schlüssel fehlt.'];
    $exact=fn($list)=>count(array_filter($list,fn($c)=>!empty($c['player'])&&($c['matchLevel']??'')==='card'))>0;
    $cvCalled=false;
    if(!$exact($cards)&&!empty($config['externalCardVaultKey']))try{$cvCalled=true;$reply=isset($adapters['cardvault'])?$adapters['cardvault']($input):cv_identify(['image'=>$photo,'sport'=>$segment],$config);$cards=array_merge($cards,$reply['detections']??[]);$providers[]=['name'=>'AI CardVault','state'=>empty($reply['detections'])?'no-match':'found'];}catch(AppError $e){$providers[]=['name'=>'AI CardVault','state'=>'failed','message'=>$e->getMessage()];}
    if(!$exact($cards)&&!empty($config['geminiKey'])&&($config['geminiEnabled']??false)===true&&($config['geminiAutoFill']??true)===true){
        try{$reply=isset($adapters['gemini'])?$adapters['gemini']($photo):af_gemini_photo($photo,$config);$reading=$reply['reading'];$providers[]=['name'=>'Gemini','state'=>'read'];
            if(!empty($reading['player'])&&(!empty($reading['number'])||!empty($reading['set']))){
                $hint=$segment;if(pipeline_sport($hint)['sportNeedsReview']&&nv_team_known($reading['team']??''))$hint='football';
                if(function_exists('oc_route')){$local=oc_route('own-catalog-search',['player'=>$reading['player'],'number'=>$reading['number'],'year'=>$reading['year']],$config);foreach($local['results']as $r)if(nv_name($r['player'])===nv_name($reading['player']))$cards[]=$r;}
                if(!$exact($cards)&&!empty($config['apiKey']))try{$more=isset($adapters['catalog'])?$adapters['catalog']($reading):pipeline_cs_candidates($reading,$config,$hint);$cards=array_merge($cards,$more);$providers[]=['name'=>'Cardsight-Katalog nach Gemini','state'=>$more?'found':'no-match'];}catch(AppError $e){$providers[]=['name'=>'Cardsight-Katalog nach Gemini','state'=>'failed','message'=>$e->getMessage()];}
                if(!$exact($cards)&&!empty($config['externalCardApiKey']))try{$more=isset($adapters['thecardapi'])?$adapters['thecardapi']($reading):pipeline_tca_candidates($reading,$config,$hint);$cards=array_merge($cards,$more);$providers[]=['name'=>'TheCardAPI','state'=>$more?'found':'no-match'];}catch(AppError $e){$providers[]=['name'=>'TheCardAPI','state'=>'failed','message'=>$e->getMessage()];}
                if(!$exact($cards)){$sport=pipeline_sport($hint);
                    $cards[]=array_merge(array_intersect_key($reading,array_flip(['player','team','year','set','number','jerseyNumber','position','cardType'])),$sport,['cardsightId'=>'','parallel'=>'','catalogSource'=>'Gemini','confidence'=>'Unknown','confidenceKnown'=>false,'matchLevel'=>'card','_scanReviewRequired'=>true,'parallelNeedsReview'=>true]);}
            }
        }catch(AppError $e){$providers[]=['name'=>'Gemini','state'=>'failed','message'=>$e->getMessage()];}
    }
    // Every exact first proposal gets the same enrichment, regardless of which recognizer won.
    $first=null;foreach($cards as $i=>$c)if(!empty($c['player'])&&($c['matchLevel']??'')==='card'){$first=$i;break;}
    if($first!==null){$c=$cards[$first];$enrichConfig=$config;if($reading!==null)$enrichConfig['geminiAutoFill']=false;$enrichment=isset($adapters['enrich'])?$adapters['enrich']($c,$photo):af_card(['card'=>$c,'image'=>$photo],$enrichConfig);if($reading!==null){$enrichment['gemini']=$reading;$enrichment['geminiState']='read';$enrichment['geminiNeedsReview']=af_conflict($reading,$c);$enrichment['warnings']=array_values(array_filter($enrichment['warnings']??[],fn($w)=>!str_contains($w,'ausgeschaltet')));$enrichment['warnings'][]='Gemini hat das Foto gelesen. Katalogzuordnung und Parallelvariante vor dem Speichern selbst prüfen.';}$cards[$first]=array_merge($c,$enrichment['fields']??[]);$cards[$first]['metadata']=$enrichment;$cards[$first]['geminiNeedsReview']=$enrichment['geminiNeedsReview']??false;
        $providers[]=['name'=>'NFLverse','state'=>array_filter($enrichment['sources']??[],fn($s)=>str_starts_with($s,'nflverse'))?'filled':'checked'];
        if(isset($enrichment['geminiState']))$providers[]=['name'=>'Gemini','state'=>$enrichment['geminiState'],'message'=>implode(' ',$enrichment['warnings']??[])];
        if(!$cvCalled&&!empty($config['externalCardVaultKey'])&&($enrichment['gemini']['verification']['identity']??'')==='mismatch')try{$reply=isset($adapters['cardvault'])?$adapters['cardvault']($input):cv_identify(['image'=>$photo,'sport'=>$segment],$config);$cards=array_merge($cards,$reply['detections']??[]);$providers[]=['name'=>'AI CardVault','state'=>empty($reply['detections'])?'no-match':'found'];}catch(AppError $e){$providers[]=['name'=>'AI CardVault','state'=>'failed','message'=>$e->getMessage()];}
    }
    return ['detections'=>array_values($cards),'providers'=>$providers,'reading'=>$reading,'detectedCount'=>count($cards),'identifiedCount'=>count($cards),'notice'=>'Datenquellen ergänzen sich. Widersprüchliche oder unklare Identitäten und Varianten müssen vor dem Speichern geprüft werden.'];
}

function pipeline_tca_search(array $input,array $config): array {
    $query=text_field($input['query']??$input['player']??$input['manufacturer']??'');$year=text_field($input['year']??'');$number=text_field($input['number']??'');
    $reply=tca_catalog(['query'=>$query,'year'=>$year,'number'=>$number],$config);$out=[];$sport=pipeline_sport($input['sport']??$input['segment']??'auto');
    foreach($reply['rows']as $r){$cardYear=$year;if(!$cardYear&&preg_match('/\b(19\d{2}|20\d{2})\b/',$r['set'],$m))$cardYear=$m[1];$out[]=array_merge($sport,['id'=>'','cardsightId'=>'','cardApiId'=>$r['ucid'],'catalogSource'=>'TheCardAPI','player'=>$r['subject'],'year'=>$cardYear,'set'=>$r['set'],'number'=>$r['number'],'parallel'=>'','parallels'=>[],'cardType'=>$r['isAuto']?'Autogrammkarte':'','matchLevel'=>'card','catalogImage'=>true,'_scanReviewRequired'=>true]);}
    return $out;
}
function pipeline_cs_candidates(array $reading,array $config,string $hint): array {
    $query=implode(' ',array_filter([$reading['player']??'',$reading['year']??'',$reading['number']??'']));
    $reply=cardsight_request('/v1/catalog/search?'.http_build_query(['q'=>$query,'type'=>'card','take'=>5]),$config['apiKey']);$out=[];
    foreach($reply['results']??[]as $r){if(($r['type']??'')!=='card'||!valid_uuid($r['id']??''))continue;$name=clean_api_text($r['name']??'');$number=clean_api_text($r['cardNumber']??'');$year=clean_api_text($r['year']??'');
        if(nv_name($name)!==nv_name($reading['player']??''))continue;if(!empty($reading['number'])&&normalized($number)!==normalized($reading['number']))continue;if(!empty($reading['year'])&&$year!==''&&$reading['year']!==$year)continue;
        $sport=pipeline_sport($hint);if($sport['sportNeedsReview'])$sport=pipeline_sport(clean_api_text($r['segmentName']??''));
        $out[]=array_merge($sport,['player'=>$name,'year'=>$year,'number'=>$number,'set'=>clean_api_text(implode(' · ',array_filter([$r['releaseName']??'',$r['setName']??'']))),'cardsightId'=>$r['id'],'parallel'=>clean_api_text($r['parallelName']??''),'matchLevel'=>'card','catalogSource'=>'Cardsight','confidence'=>'Unknown','confidenceKnown'=>false,'_scanReviewRequired'=>true,'parallelNeedsReview'=>true]);
    }
    return $out;
}
