export async function syncPreparedVault({api,onChanged,onProgress,onPaused,wait=ms=>new Promise(r=>setTimeout(r,ms)),signal}){
 let state=await api('/api/vault-bundle-status');if(state.done||!state.total)return state;
 if(!state.available){onPaused?.('Für deine vorbereiteten Fotos muss einer deiner bisherigen API-Schlüssel in den Einstellungen gespeichert sein.');return state;}
 let retries=0;
 while(!state.done&&!signal?.aborted){try{state=await api('/api/vault-bundle-step',{method:'POST',body:'{}'});retries=0;onProgress?.(state);await onChanged?.(state);await wait(100);}catch(e){if(signal?.aborted)return state;if(e.status===401)throw e;if(++retries>2){onPaused?.(e.message);return state;}await wait(1500*retries);}}
 return state;
}
