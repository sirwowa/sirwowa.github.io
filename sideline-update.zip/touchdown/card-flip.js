export function bindCardRotation(root){
 const card=root.querySelector('.card-flip');if(!card)return;let angle=0,start=null,moved=false;
 const draw=value=>{angle=value;card.dataset.angle=String(value);card.classList.toggle('is-flipped',Math.abs(Math.round(value/180))%2===1);card.querySelector('.card-flip-inner').style.transform=`rotateY(${value}deg)`;const back=Math.abs(Math.round(value/180))%2===1;const label=root.querySelector('[data-flip-side]');if(label)label.textContent=back?'Rückseite':'Vorderseite';const button=root.querySelector('[data-action="flip-card"]');if(button)button.setAttribute('aria-pressed',String(back));};
 card.flip=()=>draw(angle+180);
 if(!card.hasAttribute('data-rotatable'))return;card.querySelectorAll('img').forEach(img=>img.draggable=false);card.addEventListener('dragstart',e=>e.preventDefault());
 card.addEventListener('pointerdown',e=>{if(e.isPrimary===false)return;start={x:e.clientX,y:e.clientY,angle};moved=false;});
 card.addEventListener('pointermove',e=>{if(!start)return;const dx=e.clientX-start.x;if(Math.abs(dx)<10&&!moved)return;moved=true;card.setPointerCapture?.(e.pointerId);card.classList.add('is-dragging');draw(start.angle+dx/Math.max(card.clientWidth,1)*180);});
 const end=()=>{if(!start)return;start=null;card.classList.remove('is-dragging');if(moved){draw(Math.round(angle/180)*180);card.dataset.dragged='1';setTimeout(()=>delete card.dataset.dragged,350);}};card.addEventListener('pointerup',end);card.addEventListener('pointercancel',end);
}
