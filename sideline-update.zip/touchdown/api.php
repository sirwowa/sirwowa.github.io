<?php
declare(strict_types=1);
require __DIR__ . '/_private/bootstrap.php';
require __DIR__ . '/_private/features.php';
require __DIR__ . '/_private/checklists.php';
require __DIR__ . '/_private/sports.php';
require __DIR__ . '/_private/own-catalog.php';
require __DIR__ . '/_private/integrations.php';
require __DIR__ . '/_private/gemini.php';
require __DIR__ . '/_private/thecardapi.php';
require __DIR__ . '/_private/nflverse.php';
require __DIR__ . '/_private/card-autofill.php';
require __DIR__ . '/_private/cardvault.php';
require __DIR__ . '/_private/card-pipeline.php';
security_headers(); start_session();
header('Content-Type: application/json; charset=utf-8');
function respond(int $status, mixed $body): never { http_response_code($status); echo json_encode($body,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
try {
    if (!https_request() && !localhost_request()) throw new AppError('Bitte die App über HTTPS öffnen.',403);
    $config=read_private('config');
    if (!$config) throw new AppError('Bitte zuerst die Einrichtung auf der Startseite abschließen.',503);
    if (!authenticated()) throw new AppError('Bitte erneut anmelden.',401);
    $method=$_SERVER['REQUEST_METHOD'];
    if ($method==='POST') {
        $override=$_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE']??'POST';
        if (!in_array($override,['POST','PUT','DELETE'],true)) throw new AppError('Methode nicht unterstützt.',405);
        $method=$override;
    }
    if ($method!=='GET') check_csrf($_SERVER['HTTP_X_CSRF_TOKEN']??'');
    $config=consume_provider_install($config);
    $route=trim((string)($_GET['r']??''),'/');
    $key=$config['apiKey']??'';
    if($method==='POST'&&$route==='cardvault-identify'){$input=json_body();session_write_close();respond(200,cv_identify($input,$config));}
    if($method==='GET'&&$route==='thecardapi-status')respond(200,tca_status($config));
    if($method==='POST'&&in_array($route,['thecardapi-sales','thecardapi-confirm','thecardapi-catalog'],true)){$input=json_body(10000);session_write_close();respond(200,match($route){'thecardapi-sales'=>tca_sales_search($input,$config),'thecardapi-confirm'=>tca_confirm($input),default=>tca_catalog($input,$config)});}
    if($method==='POST'&&$route==='provider-import')respond(200,provider_import(json_body(10000),$config));
    if($method==='POST'&&$route==='gemini-test'){json_body(1000);session_write_close();respond(200,gemini_test($config));}
    if($method==='GET'&&$route==='gemini-status')respond(200,gemini_status($config));
    if($method==='POST'&&$route==='gemini-settings')respond(200,gemini_settings(json_body(10000),$config));
    if($method==='POST'&&$route==='gemini-read'){$input=json_body();session_write_close();respond(200,af_gemini_photo(photo_field($input['image']??''),$config,null,gemini_card_context($input['card']??[])));}
    if($method==='POST'&&$route==='autofill-card'){$input=json_body();session_write_close();respond(200,af_card($input,$config));}
    if($method==='POST'&&in_array($route,['own-catalog-import','own-catalog-status','own-catalog-products','own-catalog-search'],true)){$input=json_body(3000000);respond(200,oc_route($route,$input,$config));}
    if($method==='GET'&&$route==='usage')respond(200,quota_view());
    if($method==='POST'&&$route==='usage-settings'){$input=json_body(10000);if(!password_verify((string)($input['password']??''),$config['passwordHash']))throw new AppError('Das Passwort ist nicht korrekt.',403);if(!is_int($input['limit']??null))throw new AppError('Bitte eine ganze Obergrenze eingeben.');respond(200,quota_set_limit($input['limit']));}
    if($method==='POST'&&$route==='usage-sync'){json_body(10000);session_write_close();$before=quota_view();$reply=cardsight_request('/v1/subscription/',$key);respond(200,quota_observe($reply,$before['localAttempts'],$before['month']));}
    if($method==='GET'&&$route==='market-saved'){respond(200,array_values(read_private('valuations',[])));}
    if($method==='POST'&&in_array($route,['live-games','live-plays','sports-news'],true)){$input=json_body(10000);session_write_close();respond(200,integrations_route($route,$input,$config));}
    if($method==='POST'&&$route==='ebay-settings'){
        $input=json_body(10000);if(!password_verify((string)($input['password']??''),$config['passwordHash']))throw new AppError('Das Passwort ist nicht korrekt.',403);
        $id=text_field($input['clientId']??'',256);$secret=text_field($input['clientSecret']??'',256);
        private_transaction('config',fn($c)=>[array_merge($c,['ebayClientId'=>$id,'ebayClientSecret'=>$secret]),null]);respond(200,['ok'=>true]);
    }
    if($method==='POST'&&$route==='ebay-test'){json_body(10000);session_write_close();respond(200,ebay_connection($config));}

    if($method==='POST'&&in_array($route,['releases','checklist-product','checklist-chunk'],true)){$input=json_body(10000);session_write_close();respond(200,match($route){'releases'=>browse_releases($input,$key),'checklist-product'=>checklist_product($input,$key),default=>checklist_chunk($input,$key)});}
    if($method==='POST'&&$route==='segments'){json_body(10000);session_write_close();respond(200,['segments'=>supported_segments($key)]);}
    if($method==='POST'&&in_array($route,['sets','checklist','set-updates'],true)){
        $input=json_body(10000);session_write_close();
        if($route==='sets')respond(200,browse_sets($input,$key));
        if($route==='checklist')respond(200,checklist_request($input,$key));
        respond(200,set_updates($key,($input['refresh']??false)===true,($input['read']??false)===true));
    }
    if($method==='POST'&&$route==='resolve-set'){
        $input=json_body(10000);$id=text_field($input['id']??'',80);$found=null;
        foreach(read_private('cards',[])as $c)if($c['id']===$id){$found=$c;break;}
        if(!$found)throw new AppError('Karte nicht gefunden.',404);
        $details=cardsight_request('/v1/catalog/cards/'.require_uuid($found['cardsightId']??''),$key);$setId=require_uuid($details['setId']??'');
        private_transaction('cards',function($rows)use($id,$setId){foreach($rows as &$c)if($c['id']===$id){$c['cardsightSetId']=$setId;$c['updatedAt']=now_iso();}unset($c);return[$rows,null];});respond(200,['setId'=>$setId]);
    }
    if($method==='POST'&&$route==='parallel-options'){$input=json_body(10000);session_write_close();$details=cardsight_request('/v1/catalog/cards/'.require_uuid($input['id']??''),$key);respond(200,['cardInfo'=>expand_player_fields(array_merge(af_cache_catalog($input['id'],$key,$details),['sport'=>text_field($input['sport']??'',80)])),'parallels'=>array_map(fn($p)=>['name'=>clean_api_text($p['name']??''),'numberedTo'=>$p['numberedTo']??null],$details['parallels']??[])]);}
    if($method==='POST'&&$route==='catalog-number'){
        $input=json_body(10000);$number=text_field($input['number']??'',60);$year=text_field($input['year']??'',4);$manufacturer=text_field($input['manufacturer']??'',100);$player=text_field($input['player']??'',200);$skip=$input['skip']??0;
        if(!$number||!preg_match('/^\d{4}$/D',$year)||!$manufacturer||!is_int($skip)||$skip<0||$skip>100000)throw new AppError('Bitte Kartennummer, vierstelliges Jahr und Hersteller eingeben.');
        session_write_close();$query=['number'=>$number,'year'=>$year,'manufacturer'=>$manufacturer,'take'=>20,'skip'=>$skip];if($player!=='')$query['name']=$player;try{$data=cardsight_request('/v1/catalog/cards?'.http_build_query($query),$key);}catch(AppError $e){if(empty($config['externalCardApiKey']))throw $e;if($skip!==0)respond(200,['cards'=>[],'total'=>0,'skip'=>$skip]);$fallback=pipeline_tca_search(array_merge($input,['query'=>$player?:$manufacturer]),$config);respond(200,['cards'=>$fallback,'total'=>count($fallback),'skip'=>0,'notice'=>'Cardsight nicht verfügbar; Treffer aus TheCardAPI. Variante vor dem Speichern prüfen.']);}
        $items=[];foreach($data['cards']??[] as $c){if(!valid_uuid($c['id']??''))continue;$items[]=['id'=>$c['id'],'player'=>clean_api_text($c['name']??''),'number'=>clean_api_text($c['number']??''),'year'=>clean_api_text($c['releaseYear']??''),'set'=>clean_api_text(implode(' · ',array_filter([$c['releaseName']??'',$c['setName']??'']))),'parallelOnly'=>($c['isParallelOnly']??false)===true,'parallels'=>array_values(array_map(fn($p)=>['name'=>clean_api_text($p['name']??'')],$c['parallels']??[]))];}
        if(!$items&&$skip===0&&!empty($config['externalCardApiKey'])){$fallback=pipeline_tca_search(array_merge($input,['query'=>$player?:$manufacturer]),$config);respond(200,['cards'=>$fallback,'total'=>count($fallback),'skip'=>0,'notice'=>'Keine Cardsight-Treffer; ergänzende Suche in TheCardAPI.']);}
        respond(200,['cards'=>$items,'total'=>$data['total_count']??count($items),'skip'=>$skip]);
    }
    if($method==='POST'&&$route==='catalog-card'){
        $input=json_body(10000);session_write_close();respond(200,pipeline_catalog_card($input,$config));
    }
    if($method==='POST'&&$route==='player-info'){json_body(10000);throw new AppError('Spielerdaten werden in dieser Version ausschließlich von Cardsight übernommen. Vorhandene eigene Angaben bleiben erhalten.',409);}    if($method==='POST'&&$route==='card-info'){
        $input=json_body(10000);$id=require_uuid($input['id']??'');session_write_close();
        $data=cardsight_request('/v1/catalog/cards/'.$id,$key);
        respond(200,array_merge(card_metadata($data),['description'=>clean_api_text($data['description']??'')]));
    }
    if($method==='GET'&&$route==='image'){
        $id=require_uuid($_GET['id']??'');session_write_close();
        $response=cardsight_http('/v1/images/cards/'.$id.'?format=raw&default=false',$key);
        if(!in_array($response['type'],['image/jpeg','image/png','image/webp'],true)||strlen($response['body'])>8000000)throw new AppError('Cardsight hat kein gültiges Kartenbild geliefert.',502);
        $info=@getimagesizefromstring($response['body']);
        if(!$info||$info['mime']!==$response['type'])throw new AppError('Ungültiges Kartenbild.',502);
        header('Content-Type: '.$response['type']);header('Cache-Control: private, max-age=300');echo $response['body'];exit;
    }
    if($method==='POST'&&$route==='market'){
        $input=json_body(10000);$id=text_field($input['id']??'',80);$card=null;
        foreach(read_private('cards',[])as $row)if($row['id']===$id){$card=$row;break;}
        if(!$card)throw new AppError('Karte nicht gefunden.',404);
        session_write_close();$data=load_market($card,$key,($input['refresh']??false)===true);$saved=['valuationIdentity'=>array_map(fn($k)=>(string)($card[$k]??''),['cardsightId','parallel','grader','grade']),'id'=>$card['id'],'cardUpdatedAt'=>$card['updatedAt'],'averageEur'=>$data['averageEur'],'fetchedAt'=>$data['fetchedAt'],'priceKind'=>$data['priceKind']];private_transaction('valuations',function($rows)use($saved){$rows??=[];$rows[$saved['id']]=$saved;return[array_slice($rows,-1000,null,true),null];});respond(200,$data);
    }
    if($method==='POST'&&$route==='password'){
        $input=json_body(10000);
        if(!password_verify((string)($input['currentPassword']??''),$config['passwordHash']))throw new AppError('Das aktuelle Passwort ist nicht korrekt.',403);
        $new=$input['newPassword']??'';
        if(!is_string($new)||!preg_match('/^.{6,200}$/usD',$new))throw new AppError('Das neue Passwort muss mindestens 6 und maximal 200 Zeichen haben.');
        if($new!==($input['repeatPassword']??''))throw new AppError('Die beiden neuen Passwörter stimmen nicht überein.');
        private_transaction('config',fn($c)=>[array_merge($c,['passwordHash'=>password_hash($new,PASSWORD_DEFAULT)]),null]);session_regenerate_id(true);respond(200,['ok'=>true]);
    }
    if ($method==='GET' && $route==='status') respond(200,['ok'=>true,'catalogAvailable'=>function_exists('curl_init')&&((bool)$key||!empty($config['externalCardApiKey'])),'scanAvailable'=>function_exists('curl_init')&&((bool)$key||!empty($config['externalCardVaultKey'])||(!empty($config['geminiKey'])&&($config['geminiEnabled']??false)===true)),'scanMessage'=>($key||!empty($config['externalCardVaultKey'])||!empty($config['geminiKey']))?'Erkennung mit den eingerichteten Anbietern. NFLverse ergänzt NFL-Spielerangaben.':'Bitte mindestens einen Erkennungsanbieter unter Einstellungen einrichten.','currency'=>'EUR','additionalApis'=>additional_api_status($config),'gemini'=>gemini_status($config),'nflverse'=>nv_status(),'storage'=>'Geschützter Speicher auf deinem Webspace']);
    if ($method==='POST' && $route==='logout') { $_SESSION=[];session_destroy();respond(200,['ok'=>true]); }
    if ($method==='POST' && $route==='settings') {
        $input=json_body(10000);
        if (!password_verify((string)($input['password']??''),$config['passwordHash'])) throw new AppError('Das Passwort ist nicht korrekt.',403);
        $newKey=text_field($input['apiKey']??'',256);
        if ($newKey && !preg_match('/^[a-zA-Z0-9_-]{16,256}$/D',$newKey)) throw new AppError('Der API-Schlüssel hat ein ungültiges Format.');
        private_transaction('config',fn($c)=>[array_merge($c,['apiKey'=>$newKey]),null]);
        respond(200,['ok'=>true]);
    }
    if ($method==='GET' && ($route==='cards'||$route==='export')) {
        $cards=array_map('expand_player_fields',read_private('cards',[]));
        usort($cards,fn($a,$b)=>strcmp($b['createdAt'],$a['createdAt'])?:strcmp($a['id'],$b['id']));
        if ($route==='export') { header('Content-Disposition: attachment; filename="sideline-sammlung.json"');respond(200,['format'=>'sideline','version'=>1,'exportedAt'=>now_iso(),'cards'=>$cards]); }
        respond(200,$cards);
    }
    if ($method==='POST' && $route==='cards') {
        $input=json_body();if(($input['geminiNeedsReview']??false)===true&&($input['geminiAcknowledged']??false)!==true)throw new AppError('Bitte zuerst den abweichenden Gemini-Kartentext prüfen und ausdrücklich bestätigen.',409);if(($input['_scanReviewRequired']??false)===true&&($input['_scanConfirmed']??false)!==true)throw new AppError('Bitte den vorgeschlagenen Spieler und die Kartendaten vor dem Speichern bestätigen.',409);$card=expand_player_fields(validate_card($input));$card['id']=uuid();if(($input['_scanReviewRequired']??false)===true)$card['scan']=['engine'=>match($input['catalogSource']??''){'CARDLEAGUE CSV'=>'CARDLEAGUE CSV','AI CardVault'=>'AI CardVault',default=>'Cardsight'},'requestId'=>text_field($input['scanRequestId']??'',200),'providerConfidence'=>text_field($input['confidence']??'',20),'confirmedAt'=>now_iso()];$card['createdAt']=$card['updatedAt']=now_iso();
        $result=private_transaction('cards',function($rows) use($card,$input){
            $rows??=[];$matches=duplicate_cards($card,$rows);$action=$input['_duplicateAction']??'';
            if($matches&&$action!=='separate'){
                if($action==='increment')foreach($matches as $match)if($match['id']===($input['_duplicateId']??'')){
                    $index=array_search($match['id'],array_column($rows,'id'),true);
                    if($rows[$index]['quantity']+$card['quantity']>10000)throw new AppError('Die Gesamtanzahl wäre größer als 10.000.');
                    $rows[$index]['quantity']+=$card['quantity'];$rows[$index]['updatedAt']=now_iso();return[$rows,array_merge($rows[$index],['duplicateMerged'=>true])];
                }
                throw new AppError('Diese Karte ist bereits in deiner Sammlung.',409,['duplicates'=>duplicate_summaries($matches)]);
            }
            $rows[]=$card;return[$rows,$card];
        });respond(201,$result);
    }
    if (preg_match('/^cards\/([a-zA-Z0-9-]{1,80})$/D',$route,$matches) && in_array($method,['PUT','DELETE'],true)) {
        $id=$matches[1];$input=$method==='PUT'?json_body():[];$card=$method==='PUT'?validate_card($input):null;
        $result=private_transaction('cards',function($rows) use($id,$card,$method,$input){
            $rows??=[];$index=array_search($id,array_column($rows,'id'),true);
            if($index===false)throw new AppError('Karte nicht gefunden.',404);
            if($method==='DELETE'){array_splice($rows,$index,1);return[$rows,['ok'=>true]];}
            if(!array_key_exists('backImage',$input))unset($card['backImage']);
            $next=array_merge(array_intersect_key($rows[$index],array_flip(['rookieYear','backImage','sleeper','scan'])),$card,['id'=>$id,'createdAt'=>$rows[$index]['createdAt'],'updatedAt'=>now_iso()]);$rows[$index]=$next;return[$rows,$next];
        });respond(200,$result);
    }
    if ($method==='POST' && $route==='import') {
        $input=json_body(DATA_LIMIT);
        if (($input['format']??'')!=='sideline'||($input['version']??0)!==1||!isset($input['cards'])||!is_array($input['cards'])||!array_is_list($input['cards'])||count($input['cards'])>1000) throw new AppError('Bitte ein gültiges Sideline-Backup mit maximal 1.000 Einträgen wählen.');
        $validated=[];$ids=[];
        foreach($input['cards']as $row){$card=validate_card($row);$id=$row['id']??uuid();if(!is_string($id)||!preg_match('/^[a-zA-Z0-9-]{1,80}$/D',$id)||isset($ids[$id]))throw new AppError('Ungültige oder doppelte Karten-IDs im Backup.');$ids[$id]=true;$card['id']=$id;$card['createdAt']=$card['updatedAt']=now_iso();$validated[]=$card;}
        $result=private_transaction('cards',function($rows)use($validated){$rows??=[];$existing=array_fill_keys(array_column($rows,'id'),true);$imported=0;$skipped=0;foreach($validated as $card){if(isset($existing[$card['id']])){$skipped++;continue;}$rows[]=$card;$existing[$card['id']]=true;$imported++;}return[$rows,['imported'=>$imported,'skipped'=>$skipped]];});respond(200,$result);
    }
    if($method==='POST'&&$route==='identify'){$input=json_body();session_write_close();respond(200,pipeline_identify($input,$config));}
    if ($method==='POST' && $route==='catalog') {
        $input=json_body();$segment=$input['segment']??'';
        if(!is_string($segment)||($segment!=='auto'&&!preg_match('/^[a-zA-Z0-9-]{1,80}$/D',$segment)))throw new AppError('Ungültige Sportart-Auswahl.');
        // Release the PHP session lock while the external service is working.
        session_write_close();
        $query=text_field($input['query']??'');if(strlen($query)<2)throw new AppError('Bitte mindestens zwei Suchzeichen eingeben.');
        $params=['q'=>$query,'type'=>'card','take'=>12];if($segment!=='auto')$params['segment']=$segment;
        try{$result=cardsight_request('/v1/catalog/search?'.http_build_query($params),$key);}catch(AppError $e){if(empty($config['externalCardApiKey']))throw $e;$fallback=pipeline_tca_search($input,$config);respond(200,['results'=>$fallback,'total'=>count($fallback),'notice'=>'Cardsight nicht verfügbar; Katalogtreffer aus TheCardAPI.']);}
        if(!isset($result['results'])||!is_array($result['results']))throw new AppError('Unerwartete Antwort von Cardsight.',502);
        $mapped=[];foreach($result['results']as $c){if(($c['type']??'')!=='card')continue;$mapped[]=['player'=>clean_api_text($c['name']??''),'set'=>clean_api_text(implode(' · ',array_unique(array_filter([$c['releaseName']??'',$c['setName']??''])))),'year'=>clean_api_text($c['year']??''),'number'=>clean_api_text($c['cardNumber']??''),'parallel'=>clean_api_text($c['parallelName']??''),'sport'=>sport_name(clean_api_text($c['segmentName']??'Andere')),'cardsightId'=>clean_api_text($c['id']??'')];}
        if(!$mapped&&!empty($config['externalCardApiKey'])){$fallback=pipeline_tca_search($input,$config);respond(200,['results'=>$fallback,'total'=>count($fallback),'notice'=>'Keine Cardsight-Treffer; ergänzende Suche in TheCardAPI.']);}
        respond(200,['results'=>$mapped,'total'=>$result['total_count']??count($mapped)]);
    }
    throw new AppError('Nicht gefunden.',404);
} catch(AppError $e){respond($e->status,array_merge(['error'=>$e->getMessage()],$e->details));}
catch(Throwable $e){error_log('Sideline request failed: '.get_class($e));respond(500,['error'=>'Ein Serverfehler ist aufgetreten. Bitte das PHP-Fehlerprotokoll prüfen.']);}
